/* ──────────────────────────── 类型定义 ──────────────────────────── */

export interface QueueRecord {
  id: string;
  deviceId: string;
  deviceType: string;
  queueDepth: number;
  maxDepth: number;
  status: 'normal' | 'crowded' | 'full';
  latestCommandTime: string;
  oldestWaitTime: string;
  oldestWaitMs: number;
}

export interface CommandFlow {
  id: string;
  deviceId: string;
  commandType: string;
  qosLevel: 0 | 1 | 2;
  sendTime: string;
  timeoutTime: string;
  status: 'created' | 'sent' | 'pending_ack' | 'success' | 'failed' | 'timeout';
  retryCount: number;
}

export interface QosDailyStat {
  date: string;
  qos0Total: number;
  qos0Success: number;
  qos1Total: number;
  qos1Success: number;
  qos2Total: number;
  qos2Success: number;
}

export interface CircuitBreakerRecord {
  id: string;
  deviceId: string;
  deviceType: string;
  reason: string;
  triggerTime: string;
  duration: string;
  durationMs: number;
  status: 'active' | 'recovered';
}

export interface BatchTask {
  id: string;
  name: string;
  targetCount: number;
  sentCount: number;
  ackCount: number;
  failedCount: number;
  status: 'running' | 'paused' | 'completed' | 'cancelled';
  createdAt: string;
  progress: number;
}

/* ──────────────────────────── Mock 数据 ──────────────────────────── */

export const DEVICE_TYPES = ['定位器', '网关', '标签', '传感器', '控制器', '摄像头'];

export const queueRecords: QueueRecord[] = Array.from({ length: 20 }, (_, i) => {
  const depth = Math.floor(Math.random() * 51);
  let status: QueueRecord['status'] = 'normal';
  if (depth >= 46) status = 'full';
  else if (depth >= 31) status = 'crowded';
  const waitMinutes = Math.floor(Math.random() * 120) + 1;
  return {
    id: `q_${i + 1}`,
    deviceId: `DEV_${String(Math.floor(Math.random() * 9999)).padStart(4, '0')}`,
    deviceType: DEVICE_TYPES[Math.floor(Math.random() * DEVICE_TYPES.length)],
    queueDepth: depth,
    maxDepth: 50,
    status,
    latestCommandTime: new Date(Date.now() - Math.floor(Math.random() * 3600000)).toLocaleTimeString('zh-CN', { hour12: false }),
    oldestWaitTime: `${Math.floor(waitMinutes / 60)}h${waitMinutes % 60}m`,
    oldestWaitMs: waitMinutes * 60000,
  };
});

export const commandFlows: CommandFlow[] = Array.from({ length: 30 }, () => {
  const statuses: CommandFlow['status'][] = ['created', 'sent', 'pending_ack', 'success', 'failed', 'timeout'];
  const statusWeights = [0.05, 0.15, 0.2, 0.4, 0.12, 0.08];
  let r = Math.random();
  let statusIdx = 0;
  for (let j = 0; j < statusWeights.length; j++) {
    r -= statusWeights[j];
    if (r <= 0) { statusIdx = j; break; }
  }
  const qosLevels: (0 | 1 | 2)[] = [0, 1, 2];
  const qosWeights = [0.4, 0.4, 0.2];
  r = Math.random();
  let qosIdx = 0;
  for (let j = 0; j < qosWeights.length; j++) {
    r -= qosWeights[j];
    if (r <= 0) { qosIdx = j; break; }
  }
  const sendTime = Date.now() - Math.floor(Math.random() * 7200000);
  const commandTypes = ['重启', '配置更新', '固件升级', '模式切换', '参数读取', '远程诊断', '告警重置', '数据采集'];
  return {
    id: `CMD_${String(Math.floor(Math.random() * 999999)).padStart(6, '0')}`,
    deviceId: `DEV_${String(Math.floor(Math.random() * 9999)).padStart(4, '0')}`,
    commandType: commandTypes[Math.floor(Math.random() * commandTypes.length)],
    qosLevel: qosLevels[qosIdx],
    sendTime: new Date(sendTime).toLocaleString('zh-CN'),
    timeoutTime: new Date(sendTime + 300000).toLocaleString('zh-CN'),
    status: statuses[statusIdx],
    retryCount: Math.floor(Math.random() * 4),
  };
});

export const qosDailyStats: QosDailyStat[] = Array.from({ length: 7 }, (_, i) => {
  const date = new Date();
  date.setDate(date.getDate() - (6 - i));
  const qos0Total = 800 + Math.floor(Math.random() * 400);
  const qos1Total = 400 + Math.floor(Math.random() * 300);
  const qos2Total = 100 + Math.floor(Math.random() * 100);
  return {
    date: `${date.getMonth() + 1}/${date.getDate()}`,
    qos0Total,
    qos0Success: Math.floor(qos0Total * (0.92 + Math.random() * 0.06)),
    qos1Total,
    qos1Success: Math.floor(qos1Total * (0.95 + Math.random() * 0.04)),
    qos2Total,
    qos2Success: Math.floor(qos2Total * (0.97 + Math.random() * 0.03)),
  };
});

export const qosPieData = [
  { name: 'QoS 0', value: qosDailyStats.reduce((s, d) => s + d.qos0Total, 0), color: '#3b82f6' },
  { name: 'QoS 1', value: qosDailyStats.reduce((s, d) => s + d.qos1Total, 0), color: '#10b981' },
  { name: 'QoS 2', value: qosDailyStats.reduce((s, d) => s + d.qos2Total, 0), color: '#f59e0b' },
];

export const circuitBreakerRecords: CircuitBreakerRecord[] = Array.from({ length: 10 }, (_, i) => {
  const reasons = ['连续超时', '响应异常', '网络中断', '重试耗尽', '队列已满'];
  const statuses: CircuitBreakerRecord['status'][] = ['active', 'recovered'];
  const durationMins = Math.floor(Math.random() * 120) + 5;
  return {
    id: `cb_${i + 1}`,
    deviceId: `DEV_${String(Math.floor(Math.random() * 9999)).padStart(4, '0')}`,
    deviceType: DEVICE_TYPES[Math.floor(Math.random() * DEVICE_TYPES.length)],
    reason: reasons[Math.floor(Math.random() * reasons.length)],
    triggerTime: new Date(Date.now() - Math.floor(Math.random() * 86400000)).toLocaleString('zh-CN'),
    duration: `${Math.floor(durationMins / 60)}h${durationMins % 60}m`,
    durationMs: durationMins * 60000,
    status: statuses[Math.floor(Math.random() * statuses.length)],
  };
});

export const batchTasks: BatchTask[] = [
  { id: 'bt_1', name: '全网固件升级v2.4.1', targetCount: 1250, sentCount: 1250, ackCount: 1180, failedCount: 32, status: 'running', createdAt: '2026-05-18 08:00', progress: 94.4 },
  { id: 'bt_2', name: '配置批量下发-节电模式', targetCount: 860, sentCount: 645, ackCount: 580, failedCount: 15, status: 'running', createdAt: '2026-05-18 14:30', progress: 75.0 },
  { id: 'bt_3', name: '远程诊断-传感器组A', targetCount: 320, sentCount: 320, ackCount: 310, failedCount: 10, status: 'completed', createdAt: '2026-05-17 09:00', progress: 100 },
  { id: 'bt_4', name: '告警阈值批量更新', targetCount: 500, sentCount: 200, ackCount: 150, failedCount: 5, status: 'paused', createdAt: '2026-05-18 16:00', progress: 40.0 },
  { id: 'bt_5', name: '数据采集频率调整', targetCount: 640, sentCount: 80, ackCount: 60, failedCount: 2, status: 'cancelled', createdAt: '2026-05-18 10:00', progress: 12.5 },
];

/* ──────────────────────────── 辅助函数 ──────────────────────────── */

export function getStatusColor(status: string): string {
  switch (status) {
    case 'success':
    case 'completed':
    case 'recovered':
    case 'normal': return 'bg-emerald-500';
    case 'failed':
    case 'cancelled': return 'bg-red-500';
    case 'timeout': return 'bg-amber-500';
    case 'running':
    case 'sent':
    case 'pending_ack': return 'bg-blue-500';
    case 'paused': return 'bg-yellow-500';
    case 'crowded': return 'bg-yellow-500';
    case 'full': return 'bg-red-500';
    case 'created': return 'bg-slate-400';
    case 'active': return 'bg-red-500';
    default: return 'bg-slate-400';
  }
}

export function getStatusText(status: string): string {
  const map: Record<string, string> = {
    created: '已创建', sent: '已下发', pending_ack: '等待确认',
    success: '执行成功', failed: '执行失败', timeout: '已超时',
    running: '进行中', paused: '已暂停', completed: '已完成',
    cancelled: '已取消', normal: '正常', crowded: '拥挤',
    full: '已满', active: '熔断中', recovered: '已恢复',
  };
  return map[status] || status;
}

export function getStatusBadgeVariant(status: string): string {
  switch (status) {
    case 'success':
    case 'completed':
    case 'recovered': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case 'failed':
    case 'cancelled':
    case 'full': return 'bg-red-50 text-red-700 border-red-200';
    case 'timeout':
    case 'crowded':
    case 'paused': return 'bg-amber-50 text-amber-700 border-amber-200';
    case 'running':
    case 'sent':
    case 'pending_ack': return 'bg-blue-50 text-blue-700 border-blue-200';
    case 'created':
    case 'normal': return 'bg-slate-50 text-slate-600 border-slate-200';
    case 'active': return 'bg-red-50 text-red-700 border-red-200';
    default: return 'bg-slate-50 text-slate-600 border-slate-200';
  }
}

export function getQueueDepthColor(depth: number): string {
  if (depth <= 30) return 'bg-emerald-500';
  if (depth <= 45) return 'bg-amber-500';
  return 'bg-red-500';
}

export function getQosLabel(level: number): string {
  switch (level) {
    case 0: return 'QoS 0';
    case 1: return 'QoS 1';
    case 2: return 'QoS 2';
    default: return `QoS ${level}`;
  }
}
