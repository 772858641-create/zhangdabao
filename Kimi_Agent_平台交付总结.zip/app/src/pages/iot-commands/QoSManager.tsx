import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  BarChart, Bar, PieChart, Pie,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, Cell
} from 'recharts';
import {
  Clock, RotateCw, AlertTriangle,
  Wifi, Timer, Shield, Zap,
  Server, Layers, BarChart3, PieChart as PieChartIcon
} from 'lucide-react';
import {
  qosDailyStats,
  qosPieData,
  circuitBreakerRecords,
  getStatusBadgeVariant,
  getStatusText,
} from './types';

export default function QoSManager() {
  const qosConfig = [
    { level: 0, label: 'QoS 0', name: '最多一次', desc: '实时配置类指令，允许丢失', color: '#3b82f6', icon: <Wifi className="w-5 h-5" /> },
    { level: 1, label: 'QoS 1', name: '至少一次', desc: '重要配置类指令，必须确认', color: '#10b981', icon: <Shield className="w-5 h-5" /> },
    { level: 2, label: 'QoS 2', name: '恰好一次', desc: '关键安全类指令，双确认', color: '#f59e0b', icon: <Zap className="w-5 h-5" /> },
  ];

  const successRateData = qosDailyStats.map(d => ({
    date: d.date,
    'QoS 0': parseFloat(((d.qos0Success / d.qos0Total) * 100).toFixed(1)),
    'QoS 1': parseFloat(((d.qos1Success / d.qos1Total) * 100).toFixed(1)),
    'QoS 2': parseFloat(((d.qos2Success / d.qos2Total) * 100).toFixed(1)),
  }));

  const timeoutRules = [
    { deviceType: '定位器', timeout: '2h', icon: <Timer className="w-4 h-4" /> },
    { deviceType: '网关', timeout: '5min', icon: <Server className="w-4 h-4" /> },
    { deviceType: '标签', timeout: '30min', icon: <Layers className="w-4 h-4" /> },
  ];

  // 重试统计数据
  const retryStats = [
    { label: '重试1次成功率', value: '87.3%', color: 'bg-emerald-500' },
    { label: '重试2次成功率', value: '94.6%', color: 'bg-blue-500' },
    { label: '重试3次后仍失败', value: '2.1%', color: 'bg-red-500' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      {/* QoS策略配置 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {qosConfig.map((cfg, idx) => (
          <motion.div
            key={cfg.level}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: idx * 0.08 }}
          >
            <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] h-full hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg" style={{ backgroundColor: `${cfg.color}15`, color: cfg.color }}>
                    {cfg.icon}
                  </div>
                  <div>
                    <div className="font-semibold text-[var(--neutral-textPrimary)]">{cfg.label}</div>
                    <div className="text-xs text-[var(--neutral-textSecondary)]">{cfg.name}</div>
                  </div>
                </div>
                <p className="text-xs text-[var(--neutral-textSecondary)] leading-relaxed">{cfg.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* 统计图表 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* QoS占比饼图 */}
        <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <PieChartIcon className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
              <h3 className="font-semibold text-[var(--neutral-textPrimary)]">QoS 指令占比</h3>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={qosPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {qosPieData.map((entry, idx) => (
                    <Cell key={idx} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value: number) => [value.toLocaleString(), '指令数']}
                  contentStyle={{ borderRadius: 8, border: '1px solid var(--neutral-border)', background: 'var(--neutral-surface)' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 成功率对比柱状图 */}
        <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
              <h3 className="font-semibold text-[var(--neutral-textPrimary)]">QoS 成功率对比 (7天)</h3>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={successRateData} barSize={16}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--neutral-border)" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: 'var(--neutral-textSecondary)' }} />
                <YAxis domain={[80, 100]} tick={{ fontSize: 11, fill: 'var(--neutral-textSecondary)' }} unit="%" />
                <Tooltip
                  formatter={(value: number) => [`${value}%`]}
                  contentStyle={{ borderRadius: 8, border: '1px solid var(--neutral-border)', background: 'var(--neutral-surface)' }}
                />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="QoS 0" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                <Bar dataKey="QoS 1" fill="#10b981" radius={[3, 3, 0, 0]} />
                <Bar dataKey="QoS 2" fill="#f59e0b" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* 超时规则 & 重试统计 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
              <h3 className="font-semibold text-[var(--neutral-textPrimary)]">超时规则配置</h3>
            </div>
            <div className="space-y-3">
              {timeoutRules.map((rule, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-[var(--neutral-background)]">
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded-md bg-blue-50 text-blue-600">{rule.icon}</div>
                    <span className="text-sm font-medium text-[var(--neutral-textPrimary)]">{rule.deviceType}</span>
                  </div>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 font-mono">{rule.timeout}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
          <CardContent className="p-5">
            <div className="flex items-center gap-2 mb-4">
              <RotateCw className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
              <h3 className="font-semibold text-[var(--neutral-textPrimary)]">重试统计</h3>
            </div>
            <div className="space-y-4">
              {retryStats.map((stat, idx) => (
                <div key={idx}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm text-[var(--neutral-textSecondary)]">{stat.label}</span>
                    <span className="text-sm font-bold text-[var(--neutral-textPrimary)]">{stat.value}</span>
                  </div>
                  <div className="h-2 bg-[var(--neutral-border)] rounded-full overflow-hidden">
                    <motion.div
                      className={`h-full ${stat.color} rounded-full`}
                      initial={{ width: 0 }}
                      animate={{ width: stat.value }}
                      transition={{ duration: 0.8, delay: idx * 0.15 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 熔断记录 */}
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
            <h3 className="font-semibold text-[var(--neutral-textPrimary)]">熔断记录</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--neutral-border)] bg-[var(--neutral-background)]">
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">设备ID</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">设备类型</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">熔断原因</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">触发时间</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">熔断时长</th>
                  <th className="px-3 py-2.5 text-left font-semibold text-[var(--neutral-textSecondary)]">状态</th>
                </tr>
              </thead>
              <tbody>
                {circuitBreakerRecords.map((cb, idx) => (
                  <motion.tr
                    key={cb.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.2, delay: idx * 0.04 }}
                    className="border-b border-[var(--neutral-border)] hover:bg-[var(--neutral-background)] transition-colors"
                  >
                    <td className="px-3 py-2.5 font-mono text-xs text-[var(--neutral-textPrimary)]">{cb.deviceId}</td>
                    <td className="px-3 py-2.5 text-[var(--neutral-textPrimary)]">{cb.deviceType}</td>
                    <td className="px-3 py-2.5 text-[var(--neutral-textPrimary)]">{cb.reason}</td>
                    <td className="px-3 py-2.5 text-xs text-[var(--neutral-textSecondary)]">{cb.triggerTime}</td>
                    <td className="px-3 py-2.5 text-[var(--neutral-textPrimary)]">{cb.duration}</td>
                    <td className="px-3 py-2.5">
                      <Badge variant="outline" className={getStatusBadgeVariant(cb.status)}>
                        {getStatusText(cb.status)}
                      </Badge>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
