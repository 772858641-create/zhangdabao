import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  CheckCircle, XCircle, Pause, Play,
  Square, ChevronRight, Activity, Layers
} from 'lucide-react';
import {
  batchTasks,
  getStatusBadgeVariant,
  getStatusText,
} from './types';
import type { BatchTask } from './types';

export default function BatchCommandManager() {
  const [tasks, setTasks] = useState(batchTasks);

  const handlePause = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'paused' as const } : t));
  };

  const handleResume = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'running' as const } : t));
  };

  const handleCancel = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'cancelled' as const } : t));
  };

  const getTaskStatusIcon = (status: BatchTask['status']) => {
    switch (status) {
      case 'running': return <Activity className="w-4 h-4 text-blue-500" />;
      case 'paused': return <Pause className="w-4 h-4 text-amber-500" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
      case 'cancelled': return <XCircle className="w-4 h-4 text-red-500" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      <div className="grid gap-4">
        {tasks.map((task, idx) => (
          <motion.div
            key={task.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.06 }}
          >
            <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                  {/* 左侧信息 */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      {getTaskStatusIcon(task.status)}
                      <h4 className="font-semibold text-[var(--neutral-textPrimary)] truncate">{task.name}</h4>
                      <Badge variant="outline" className={getStatusBadgeVariant(task.status)}>
                        {getStatusText(task.status)}
                      </Badge>
                    </div>
                    <div className="flex flex-wrap gap-4 text-xs text-[var(--neutral-textSecondary)] mb-3">
                      <span>目标设备: <strong className="text-[var(--neutral-textPrimary)]">{task.targetCount.toLocaleString()}</strong></span>
                      <span>已下发: <strong className="text-blue-600">{task.sentCount.toLocaleString()}</strong></span>
                      <span>已确认: <strong className="text-emerald-600">{task.ackCount.toLocaleString()}</strong></span>
                      <span>失败: <strong className="text-red-600">{task.failedCount.toLocaleString()}</strong></span>
                      <span>创建于: {task.createdAt}</span>
                    </div>
                    {/* 进度条 */}
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2.5 bg-[var(--neutral-border)] rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full rounded-full ${
                            task.status === 'completed' ? 'bg-emerald-500' :
                            task.status === 'cancelled' ? 'bg-red-500' :
                            task.status === 'paused' ? 'bg-amber-500' :
                            'bg-blue-500'
                          }`}
                          initial={{ width: 0 }}
                          animate={{ width: `${task.progress}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }}
                        />
                      </div>
                      <span className="text-sm font-bold text-[var(--neutral-textPrimary)] w-14 text-right">{task.progress}%</span>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {task.status === 'running' && (
                      <Button variant="outline" size="sm" onClick={() => handlePause(task.id)} className="gap-1 border-amber-300 text-amber-700 hover:bg-amber-50">
                        <Pause className="w-3.5 h-3.5" /> 暂停
                      </Button>
                    )}
                    {task.status === 'paused' && (
                      <Button variant="outline" size="sm" onClick={() => handleResume(task.id)} className="gap-1 border-emerald-300 text-emerald-700 hover:bg-emerald-50">
                        <Play className="w-3.5 h-3.5" /> 恢复
                      </Button>
                    )}
                    {(task.status === 'running' || task.status === 'paused') && (
                      <Button variant="outline" size="sm" onClick={() => handleCancel(task.id)} className="gap-1 border-red-300 text-red-700 hover:bg-red-50">
                        <Square className="w-3.5 h-3.5" /> 取消
                      </Button>
                    )}
                    <Button variant="ghost" size="sm" className="text-[var(--neutral-textSecondary)] hover:text-[var(--neutral-textPrimary)]">
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* 汇总卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
        {[
          { label: '总任务数', value: tasks.length.toString(), icon: <Layers className="w-5 h-5" />, color: 'text-blue-600' },
          { label: '进行中', value: tasks.filter(t => t.status === 'running').length.toString(), icon: <Activity className="w-5 h-5" />, color: 'text-emerald-600' },
          { label: '已暂停', value: tasks.filter(t => t.status === 'paused').length.toString(), icon: <Pause className="w-5 h-5" />, color: 'text-amber-600' },
          { label: '已完成/取消', value: tasks.filter(t => t.status === 'completed' || t.status === 'cancelled').length.toString(), icon: <CheckCircle className="w-5 h-5" />, color: 'text-slate-600' },
        ].map((item, idx) => (
          <Card key={idx} className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`${item.color}`}>{item.icon}</div>
              <div>
                <div className="text-xs text-[var(--neutral-textSecondary)]">{item.label}</div>
                <div className="text-xl font-bold text-[var(--neutral-textPrimary)]">{item.value}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </motion.div>
  );
}
