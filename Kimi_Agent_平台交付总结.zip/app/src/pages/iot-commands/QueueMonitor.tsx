import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search, Filter } from 'lucide-react';
import {
  queueRecords,
  DEVICE_TYPES,
  getStatusBadgeVariant,
  getStatusText,
  getQueueDepthColor,
} from './types';

function QueueDepthBar({ depth, max }: { depth: number; max: number }) {
  const pct = (depth / max) * 100;
  const colorClass = getQueueDepthColor(depth);
  return (
    <div className="flex items-center gap-2 w-full">
      <div className="flex-1 h-2 bg-[var(--neutral-border)] rounded-full overflow-hidden">
        <motion.div
          className={`h-full ${colorClass} rounded-full`}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
      </div>
      <span className="text-xs font-medium text-[var(--neutral-textSecondary)] w-12 text-right">{depth}/{max}</span>
    </div>
  );
}

export default function QueueMonitor() {
  const [deviceTypeFilter, setDeviceTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = useMemo(() => {
    return queueRecords.filter(q => {
      if (deviceTypeFilter !== 'all' && q.deviceType !== deviceTypeFilter) return false;
      if (statusFilter !== 'all' && q.status !== statusFilter) return false;
      if (searchQuery && !q.deviceId.toLowerCase().includes(searchQuery.toLowerCase())) return false;
      return true;
    });
  }, [deviceTypeFilter, statusFilter, searchQuery]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      {/* 筛选栏 */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--neutral-textSecondary)]" />
          <Input
            placeholder="搜索设备ID..."
            className="pl-9 bg-[var(--neutral-surface)] border-[var(--neutral-border)]"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[var(--neutral-textSecondary)]" />
          <select
            className="px-3 py-2 rounded-md border border-[var(--neutral-border)] bg-[var(--neutral-surface)] text-sm text-[var(--neutral-textPrimary)]"
            value={deviceTypeFilter}
            onChange={e => setDeviceTypeFilter(e.target.value)}
          >
            <option value="all">全部类型</option>
            {DEVICE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <select
            className="px-3 py-2 rounded-md border border-[var(--neutral-border)] bg-[var(--neutral-surface)] text-sm text-[var(--neutral-textPrimary)]"
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
          >
            <option value="all">全部状态</option>
            <option value="normal">正常</option>
            <option value="crowded">拥挤</option>
            <option value="full">已满</option>
          </select>
        </div>
      </div>

      {/* 队列列表 */}
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--neutral-border)] bg-[var(--neutral-background)]">
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">设备ID</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">设备类型</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)] w-48">队列深度</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">队列状态</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">最新指令时间</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">最老等待时长</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((q, idx) => (
                  <motion.tr
                    key={q.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.25, delay: idx * 0.03 }}
                    className="border-b border-[var(--neutral-border)] hover:bg-[var(--neutral-background)] transition-colors"
                  >
                    <td className="px-4 py-3 font-mono text-[var(--neutral-textPrimary)]">{q.deviceId}</td>
                    <td className="px-4 py-3 text-[var(--neutral-textPrimary)]">{q.deviceType}</td>
                    <td className="px-4 py-3"><QueueDepthBar depth={q.queueDepth} max={q.maxDepth} /></td>
                    <td className="px-4 py-3">
                      <Badge variant="outline" className={getStatusBadgeVariant(q.status)}>
                        {getStatusText(q.status)}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-[var(--neutral-textSecondary)]">{q.latestCommandTime}</td>
                    <td className="px-4 py-3 text-[var(--neutral-textSecondary)]">{q.oldestWaitTime}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && (
            <div className="py-12 text-center text-[var(--neutral-textSecondary)]">暂无数据</div>
          )}
        </CardContent>
      </Card>

      {/* 图例 */}
      <div className="flex items-center gap-6 text-xs text-[var(--neutral-textSecondary)]">
        <span>队列深度图例：</span>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-emerald-500" /> 0-30 正常</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-amber-500" /> 31-45 拥挤</div>
        <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full bg-red-500" /> 46-50 已满</div>
      </div>
    </motion.div>
  );
}
