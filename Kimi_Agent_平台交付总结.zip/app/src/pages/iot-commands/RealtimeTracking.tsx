import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  commandFlows,
  getStatusColor,
  getStatusBadgeVariant,
  getStatusText,
  getQosLabel,
} from './types';
import type { CommandFlow } from './types';

export default function RealtimeTracking() {
  const [flows, setFlows] = useState(commandFlows);
  const [statusFilter, setStatusFilter] = useState('all');

  // 模拟自动刷新
  useEffect(() => {
    const interval = setInterval(() => {
      setFlows(prev => prev.map(f => {
        if (f.status === 'success' || f.status === 'failed' || f.status === 'timeout') return f;
        const rand = Math.random();
        let newStatus = f.status as CommandFlow['status'];
        if (f.status === 'created' && rand > 0.7) newStatus = 'sent';
        else if (f.status === 'sent' && rand > 0.6) newStatus = 'pending_ack';
        else if (f.status === 'pending_ack' && rand > 0.5) {
          const outcomes: CommandFlow['status'][] = ['success', 'failed', 'timeout'];
          newStatus = outcomes[Math.floor(Math.random() * outcomes.length)];
        }
        return { ...f, status: newStatus, retryCount: newStatus === 'failed' ? f.retryCount + 1 : f.retryCount };
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const filtered = useMemo(() => {
    if (statusFilter === 'all') return flows;
    return flows.filter(f => f.status === statusFilter);
  }, [flows, statusFilter]);

  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    flows.forEach(f => { counts[f.status] = (counts[f.status] || 0) + 1; });
    return counts;
  }, [flows]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-4"
    >
      {/* 状态筛选快捷栏 */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${statusFilter === 'all' ? 'bg-[var(--neutral-textPrimary)] text-white' : 'bg-[var(--neutral-surface)] text-[var(--neutral-textSecondary)] border border-[var(--neutral-border)]'}`}
        >
          全部 ({flows.length})
        </button>
        {(['created', 'sent', 'pending_ack', 'success', 'failed', 'timeout'] as const).map(s => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${statusFilter === s ? 'bg-[var(--neutral-textPrimary)] text-white' : 'bg-[var(--neutral-surface)] text-[var(--neutral-textSecondary)] border border-[var(--neutral-border)]'}`}
          >
            {getStatusText(s)} ({statusCounts[s] || 0})
          </button>
        ))}
      </div>

      {/* 指令流水列表 */}
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--neutral-border)] bg-[var(--neutral-background)]">
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">指令ID</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">设备ID</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">命令类型</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">QoS</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">下发时间</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">超时时间</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">状态</th>
                  <th className="px-4 py-3 text-left font-semibold text-[var(--neutral-textSecondary)]">重试</th>
                </tr>
              </thead>
              <tbody>
                <AnimatePresence mode="popLayout">
                  {filtered.map(f => (
                    <motion.tr
                      key={f.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="border-b border-[var(--neutral-border)] hover:bg-[var(--neutral-background)] transition-colors"
                    >
                      <td className="px-4 py-3 font-mono text-xs text-[var(--neutral-textPrimary)]">{f.id}</td>
                      <td className="px-4 py-3 font-mono text-xs text-[var(--neutral-textPrimary)]">{f.deviceId}</td>
                      <td className="px-4 py-3 text-[var(--neutral-textPrimary)]">{f.commandType}</td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={
                          f.qosLevel === 0 ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          f.qosLevel === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                          'bg-amber-50 text-amber-700 border-amber-200'
                        }>
                          {getQosLabel(f.qosLevel)}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-[var(--neutral-textSecondary)]">{f.sendTime}</td>
                      <td className="px-4 py-3 text-xs text-[var(--neutral-textSecondary)]">{f.timeoutTime}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${getStatusColor(f.status)}`} />
                          <Badge variant="outline" className={getStatusBadgeVariant(f.status)}>
                            {getStatusText(f.status)}
                          </Badge>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-[var(--neutral-textPrimary)]">{f.retryCount}</td>
                    </motion.tr>
                  ))}
                </AnimatePresence>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* 状态颜色图例 */}
      <div className="flex items-center gap-6 text-xs text-[var(--neutral-textSecondary)]">
        <span>状态图例：</span>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-blue-500" /> 进行中</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500" /> 成功</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-red-500" /> 失败</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-500" /> 超时</div>
        <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-slate-400" /> 已创建</div>
      </div>
    </motion.div>
  );
}
