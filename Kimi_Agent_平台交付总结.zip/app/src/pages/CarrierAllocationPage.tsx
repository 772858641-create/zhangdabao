import { useState, useMemo, useCallback } from 'react';
import {
  Container,
  Plus,
  Settings,
  Play,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  Search,
  Filter,
  Pencil,
  Trash2,
  Eye,
  X,
  Warehouse,
  ArrowRightLeft,
  PackageCheck,
  TrendingUp,
  Timer,
  MoreHorizontal,
  Bot,
  MapPin,
  BarChart3,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// ─── Types ───────────────────────────────────────────────

type CarrierType = '托盘' | '周转箱' | '料架' | 'EU箱' | '其他';
type CarrierStatus = '在库' | '已分配' | '运输中' | '维修中' | '报废';

interface Carrier {
  id: string;
  code: string;
  type: CarrierType;
  status: CarrierStatus;
  location: string;
  allocatedTo?: string;
  lastUpdated: string;
  specs: string;
}

interface AllocationRule {
  id: string;
  name: string;
  priority: number;
  condition: string;
  target: string;
  enabled: boolean;
  description: string;
}

interface AllocationRecord {
  id: string;
  carrierCode: string;
  carrierType: CarrierType;
  fromLocation: string;
  toLocation: string;
  operator: string;
  status: '成功' | '失败' | '冲突';
  timestamp: string;
  note?: string;
}

interface TrendData {
  hour: string;
  count: number;
}

// ─── Mock Data ───────────────────────────────────────────

// CARRIER_TYPES not used directly

const CARRIER_STATUS_LIST: CarrierStatus[] = ['在库', '已分配', '运输中', '维修中', '报废'];

const CARRIERS: Carrier[] = [
  { id: '1', code: 'PJ-2024-0001', type: '托盘', status: '在库', location: 'A区-01货架', specs: '1200×1000×150mm', lastUpdated: '2024-01-15' },
  { id: '2', code: 'PJ-2024-0002', type: '托盘', status: '已分配', location: 'B区-出库口', allocatedTo: '网点-华东-上海', specs: '1200×1000×150mm', lastUpdated: '2024-01-15' },
  { id: '3', code: 'PJ-2024-0003', type: '周转箱', status: '运输中', location: '运输-沪宁线', allocatedTo: '网点-华东-南京', specs: '600×400×320mm', lastUpdated: '2024-01-15' },
  { id: '4', code: 'PJ-2024-0004', type: '料架', status: '在库', location: 'C区-03库位', specs: '折叠式-重型', lastUpdated: '2024-01-15' },
  { id: '5', code: 'PJ-2024-0005', type: 'EU箱', status: '已分配', location: 'D区-拣货区', allocatedTo: '网点-华北-北京', specs: '600×400×280mm', lastUpdated: '2024-01-15' },
  { id: '6', code: 'PJ-2024-0006', type: '托盘', status: '维修中', location: '维修车间-A', specs: '1200×1000×150mm', lastUpdated: '2024-01-15' },
  { id: '7', code: 'PJ-2024-0007', type: '周转箱', status: '在库', location: 'A区-02货架', specs: '600×400×320mm', lastUpdated: '2024-01-15' },
  { id: '8', code: 'PJ-2024-0008', type: 'EU箱', status: '在库', location: 'A区-05货架', specs: '400×300×220mm', lastUpdated: '2024-01-15' },
  { id: '9', code: 'PJ-2024-0009', type: '托盘', status: '运输中', location: '运输-京沪线', allocatedTo: '网点-华北-天津', specs: '1100×1100×140mm', lastUpdated: '2024-01-15' },
  { id: '10', code: 'PJ-2024-0010', type: '料架', status: '已分配', location: 'E区-暂存区', allocatedTo: '网点-华南-广州', specs: '折叠式-中型', lastUpdated: '2024-01-15' },
  { id: '11', code: 'PJ-2024-0011', type: '托盘', status: '在库', location: 'B区-04库位', specs: '1200×1000×150mm', lastUpdated: '2024-01-15' },
  { id: '12', code: 'PJ-2024-0012', type: '周转箱', status: '维修中', location: '维修车间-B', specs: '600×400×320mm', lastUpdated: '2024-01-15' },
  { id: '13', code: 'PJ-2024-0013', type: 'EU箱', status: '已分配', location: 'F区-打包区', allocatedTo: '网点-西南-成都', specs: '600×400×280mm', lastUpdated: '2024-01-15' },
  { id: '14', code: 'PJ-2024-0014', type: '托盘', status: '报废', location: '报废区', specs: '1200×1000×150mm', lastUpdated: '2024-01-15' },
  { id: '15', code: 'PJ-2024-0015', type: '周转箱', status: '在库', location: 'C区-06库位', specs: '400×300×200mm', lastUpdated: '2024-01-15' },
  { id: '16', code: 'PJ-2024-0016', type: '料架', status: '在库', location: 'A区-07货架', specs: '固定式-轻型', lastUpdated: '2024-01-15' },
  { id: '17', code: 'PJ-2024-0017', type: '托盘', status: '已分配', location: 'G区-装车区', allocatedTo: '网点-华中-武汉', specs: '1200×800×140mm', lastUpdated: '2024-01-15' },
  { id: '18', code: 'PJ-2024-0018', type: 'EU箱', status: '运输中', location: '运输-沪杭线', allocatedTo: '网点-华东-杭州', specs: '600×400×280mm', lastUpdated: '2024-01-15' },
  { id: '19', code: 'PJ-2024-0019', type: '周转箱', status: '在库', location: 'B区-08库位', specs: '600×400×320mm', lastUpdated: '2024-01-15' },
  { id: '20', code: 'PJ-2024-0020', type: '其他', status: '在库', location: 'H区-特殊区', specs: '定制尺寸', lastUpdated: '2024-01-15' },
];

const ALLOCATION_RULES: AllocationRule[] = [
  {
    id: 'r1',
    name: '网点优先级分配',
    priority: 1,
    condition: '网点等级=一级 且 库存<安全阈值',
    target: '优先分配至一级网点',
    enabled: true,
    description: '当一级网点库存低于安全阈值时，优先将可用载具分配至该类网点',
  },
  {
    id: 'r2',
    name: '载具类型匹配',
    priority: 2,
    condition: '载具类型=请求类型',
    target: '匹配同类型载具',
    enabled: true,
    description: '根据网点的载具需求类型，匹配相同类型的载具进行分配',
  },
  {
    id: 'r3',
    name: '距离最近优先',
    priority: 3,
    condition: '距离<500km',
    target: '优先分配距离最近的网点',
    enabled: true,
    description: '在载具充足的情况下，优先分配给距离最近的网点以降低运输成本',
  },
  {
    id: 'r4',
    name: '载具状态检查',
    priority: 4,
    condition: '状态=在库 且 未过期',
    target: '仅分配在库且未超期载具',
    enabled: true,
    description: '排除维修中、运输中及过期载具，仅选择在库可用载具进行分配',
  },
  {
    id: 'r5',
    name: '紧急调拨规则',
    priority: 0,
    condition: '订单标记=紧急',
    target: '绕过常规流程，立即分配',
    enabled: false,
    description: '针对紧急订单，跳过常规分配流程，直接从最近仓库调拨',
  },
];

const ALLOCATION_RECORDS: AllocationRecord[] = [
  { id: 'a1', carrierCode: 'PJ-2024-0002', carrierType: '托盘', fromLocation: '中心仓库-A区', toLocation: '网点-华东-上海', operator: '张三', status: '成功', timestamp: '2025-01-15 09:23:14', note: '按计划分配' },
  { id: 'a2', carrierCode: 'PJ-2024-0005', carrierType: 'EU箱', fromLocation: '中心仓库-D区', toLocation: '网点-华北-北京', operator: '李四', status: '成功', timestamp: '2025-01-15 09:45:32', note: '紧急补货' },
  { id: 'a3', carrierCode: 'PJ-2024-0010', carrierType: '料架', fromLocation: '中心仓库-E区', toLocation: '网点-华南-广州', operator: '王五', status: '冲突', timestamp: '2025-01-15 10:12:08', note: '与r3规则冲突' },
  { id: 'a4', carrierCode: 'PJ-2024-0013', carrierType: 'EU箱', fromLocation: '中心仓库-F区', toLocation: '网点-西南-成都', operator: '赵六', status: '成功', timestamp: '2025-01-15 10:34:56', note: '常规分配' },
  { id: 'a5', carrierCode: 'PJ-2024-0017', carrierType: '托盘', fromLocation: '中心仓库-G区', toLocation: '网点-华中-武汉', operator: '张三', status: '成功', timestamp: '2025-01-15 11:05:22', note: '按计划分配' },
  { id: 'a6', carrierCode: 'PJ-2024-0009', carrierType: '托盘', fromLocation: '中心仓库-A区', toLocation: '网点-华北-天津', operator: '李四', status: '成功', timestamp: '2025-01-15 11:28:45', note: '跨区调拨' },
  { id: 'a7', carrierCode: 'PJ-2024-0018', carrierType: 'EU箱', fromLocation: '中心仓库-D区', toLocation: '网点-华东-杭州', operator: '王五', status: '失败', timestamp: '2025-01-15 11:45:10', note: '库存不足' },
  { id: 'a8', carrierCode: 'PJ-2024-0003', carrierType: '周转箱', fromLocation: '中心仓库-C区', toLocation: '网点-华东-南京', operator: '赵六', status: '成功', timestamp: '2025-01-15 12:15:33', note: '常规分配' },
  { id: 'a9', carrierCode: 'PJ-2024-0011', carrierType: '托盘', fromLocation: '中心仓库-B区', toLocation: '网点-华东-苏州', operator: '张三', status: '成功', timestamp: '2025-01-15 13:02:18', note: '新增网点配送' },
  { id: 'a10', carrierCode: 'PJ-2024-0015', carrierType: '周转箱', fromLocation: '中心仓库-C区', toLocation: '网点-华南-深圳', operator: '李四', status: '成功', timestamp: '2025-01-15 13:25:47', note: '按计划分配' },
];

const TREND_DATA: TrendData[] = [
  { hour: '00:00', count: 2 },
  { hour: '02:00', count: 0 },
  { hour: '04:00', count: 1 },
  { hour: '06:00', count: 3 },
  { hour: '08:00', count: 8 },
  { hour: '10:00', count: 15 },
  { hour: '12:00', count: 12 },
  { hour: '14:00', count: 18 },
  { hour: '16:00', count: 14 },
  { hour: '18:00', count: 9 },
  { hour: '20:00', count: 6 },
  { hour: '22:00', count: 3 },
];

const TYPE_DIST_DATA = [
  { name: '托盘', value: 8, color: '#3b82f6' },
  { name: '周转箱', value: 5, color: '#10b981' },
  { name: '料架', value: 3, color: '#f59e0b' },
  { name: 'EU箱', value: 3, color: '#8b5cf6' },
  { name: '其他', value: 1, color: '#6b7280' },
];

// ─── Helpers ─────────────────────────────────────────────

function getStatusColor(status: CarrierStatus | string): string {
  switch (status) {
    case '在库': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case '已分配': return 'bg-blue-50 text-blue-700 border-blue-200';
    case '运输中': return 'bg-amber-50 text-amber-700 border-amber-200';
    case '维修中': return 'bg-orange-50 text-orange-700 border-orange-200';
    case '报废': return 'bg-gray-100 text-gray-500 border-gray-200 line-through';
    default: return 'bg-gray-50 text-gray-600 border-gray-200';
  }
}

function getStatusDot(status: CarrierStatus): string {
  switch (status) {
    case '在库': return 'bg-emerald-500';
    case '已分配': return 'bg-blue-500';
    case '运输中': return 'bg-amber-500';
    case '维修中': return 'bg-orange-500';
    case '报废': return 'bg-gray-400';
    default: return 'bg-gray-400';
  }
}

function getRecordStatusBadge(status: AllocationRecord['status']): string {
  switch (status) {
    case '成功': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    case '失败': return 'bg-red-50 text-red-700 border-red-200';
    case '冲突': return 'bg-amber-50 text-amber-700 border-amber-200';
    default: return 'bg-gray-50 text-gray-600 border-gray-200';
  }
}

// ─── Components ──────────────────────────────────────────

export default function CarrierAllocationPage() {
  const [activeTab, setActiveTab] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [rules, setRules] = useState<AllocationRule[]>(ALLOCATION_RULES);
  const [records, setRecords] = useState<AllocationRecord[]>(ALLOCATION_RECORDS);
  const [isSimulating, setIsSimulating] = useState(false);
  const [simResult, setSimResult] = useState<AllocationRecord[] | null>(null);
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<AllocationRule | null>(null);
  const [deleteConfirmRule, setDeleteConfirmRule] = useState<string | null>(null);
  const [viewCarrier, setViewCarrier] = useState<Carrier | null>(null);

  // Form state for rule dialog
  const [ruleForm, setRuleForm] = useState<Partial<AllocationRule>>({
    name: '',
    priority: 1,
    condition: '',
    target: '',
    description: '',
    enabled: true,
  });

  // ── Stats ──
  const stats = useMemo(() => {
    const total = CARRIERS.length;
    const available = CARRIERS.filter(c => c.status === '在库').length;
    const allocated = CARRIERS.filter(c => c.status === '已分配').length;
    const repairing = CARRIERS.filter(c => c.status === '维修中').length;
    const todayAllocations = records.filter(r => r.timestamp.startsWith('2025-01-15')).length;
    const successRate = Math.round(
      (records.filter(r => r.status === '成功').length / records.length) * 100
    );
    return { total, available, allocated, repairing, todayAllocations, successRate };
  }, [records]);

  // ── Filtered carriers ──
  const filteredCarriers = useMemo(() => {
    let result = CARRIERS;

    // Tab filter
    if (activeTab !== 'all') {
      const typeMap: Record<string, CarrierType> = {
        pallet: '托盘',
        box: '周转箱',
        rack: '料架',
        eu: 'EU箱',
        other: '其他',
      };
      result = result.filter(c => c.type === typeMap[activeTab]);
    }

    // Status filter
    if (statusFilter !== 'all') {
      result = result.filter(c => c.status === statusFilter);
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(
        c =>
          c.code.toLowerCase().includes(q) ||
          c.location.toLowerCase().includes(q) ||
          (c.allocatedTo && c.allocatedTo.toLowerCase().includes(q))
      );
    }

    return result;
  }, [activeTab, statusFilter, searchQuery]);

  // ── Handlers ──
  const handleToggleRule = useCallback((id: string) => {
    setRules(prev =>
      prev.map(r => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  }, []);

  const handleDeleteRule = useCallback((id: string) => {
    setRules(prev => prev.filter(r => r.id !== id));
    setDeleteConfirmRule(null);
  }, []);

  const handleSaveRule = useCallback(() => {
    if (!ruleForm.name || !ruleForm.condition || !ruleForm.target) return;

    if (editingRule) {
      setRules(prev =>
        prev.map(r =>
          r.id === editingRule.id
            ? { ...r, ...ruleForm, id: editingRule.id } as AllocationRule
            : r
        )
      );
    } else {
      const newRule: AllocationRule = {
        id: `r${Date.now()}`,
        name: ruleForm.name || '',
        priority: ruleForm.priority ?? 1,
        condition: ruleForm.condition || '',
        target: ruleForm.target || '',
        description: ruleForm.description || '',
        enabled: true,
      };
      setRules(prev => [...prev, newRule]);
    }
    setRuleDialogOpen(false);
    setEditingRule(null);
    setRuleForm({ name: '', priority: 1, condition: '', target: '', description: '', enabled: true });
  }, [editingRule, ruleForm]);

  const handleEditRule = useCallback((rule: AllocationRule) => {
    setEditingRule(rule);
    setRuleForm({ ...rule });
    setRuleDialogOpen(true);
  }, []);

  const handleAddRule = useCallback(() => {
    setEditingRule(null);
    setRuleForm({ name: '', priority: 1, condition: '', target: '', description: '', enabled: true });
    setRuleDialogOpen(true);
  }, []);

  const handleSimulate = useCallback(() => {
    setIsSimulating(true);
    setSimResult(null);

    setTimeout(() => {
      const newResults: AllocationRecord[] = [
        {
          id: `sim-${Date.now()}-1`,
          carrierCode: 'PJ-2024-0007',
          carrierType: '周转箱',
          fromLocation: '中心仓库-A区',
          toLocation: '网点-华东-苏州',
          operator: '系统自动',
          status: '成功',
          timestamp: '2025-01-15 14:30:00',
          note: '按距离最近规则自动分配',
        },
        {
          id: `sim-${Date.now()}-2`,
          carrierCode: 'PJ-2024-0016',
          carrierType: '料架',
          fromLocation: '中心仓库-A区',
          toLocation: '网点-华东-无锡',
          operator: '系统自动',
          status: '成功',
          timestamp: '2025-01-15 14:30:05',
          note: '按网点优先级规则自动分配',
        },
        {
          id: `sim-${Date.now()}-3`,
          carrierCode: 'PJ-2024-0019',
          carrierType: '周转箱',
          fromLocation: '中心仓库-B区',
          toLocation: '网点-华东-常州',
          operator: '系统自动',
          status: '冲突',
          timestamp: '2025-01-15 14:30:10',
          note: '与r2载具类型匹配规则冲突：网点请求托盘但只剩周转箱',
        },
        {
          id: `sim-${Date.now()}-4`,
          carrierCode: 'PJ-2024-0020',
          carrierType: '其他',
          fromLocation: '中心仓库-H区',
          toLocation: '网点-华东-嘉兴',
          operator: '系统自动',
          status: '失败',
          timestamp: '2025-01-15 14:30:15',
          note: '网点不接受其他类型载具',
        },
      ];
      setSimResult(newResults);
      setIsSimulating(false);
    }, 2000);
  }, []);

  const handleApplySimResult = useCallback(() => {
    if (!simResult) return;
    const successRecords = simResult.filter(r => r.status === '成功');
    setRecords(prev => [...successRecords, ...prev]);
    setSimResult(null);
  }, [simResult]);

  // ── Render ──
  return (
    <div className="min-h-screen bg-[var(--neutral-background)] p-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)] flex items-center gap-2">
            <Container className="h-6 w-6 text-[var(--neutral-text-primary)]" />
            载具分配管理
          </h1>
          <p className="mt-1 text-sm text-[var(--neutral-text-secondary)]">
            管理载具分配规则、执行自动分配、查看分配记录
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            className="border-[var(--neutral-border)]"
            onClick={() => setSimResult(null)}
          >
            <RotateCcw className="h-4 w-4 mr-1" />
            刷新
          </Button>
          <Button size="sm" className="bg-[var(--theme-color)] hover:bg-[var(--theme-color)]/90" onClick={handleSimulate}>
            <Play className="h-4 w-4 mr-1" />
            自动分配
          </Button>
        </div>
      </div>

      {/* ── Stats Cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
          <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-[var(--neutral-text-secondary)]">总载具数</p>
                  <p className="mt-1 text-2xl font-bold text-[var(--neutral-text-primary)]">{stats.total}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <Container className="h-5 w-5 text-blue-500" />
                </div>
              </div>
              <div className="mt-3 flex items-center gap-1 text-xs text-emerald-600">
                <TrendingUp className="h-3 w-3" />
                <span>+3 本月新增</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-[var(--neutral-text-secondary)]">在库可用</p>
                  <p className="mt-1 text-2xl font-bold text-emerald-600">{stats.available}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-emerald-50 flex items-center justify-center">
                  <Warehouse className="h-5 w-5 text-emerald-500" />
                </div>
              </div>
              <div className="mt-3 text-xs text-[var(--neutral-text-tertiary)]">
                占比 {Math.round((stats.available / stats.total) * 100)}%
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-[var(--neutral-text-secondary)]">已分配</p>
                  <p className="mt-1 text-2xl font-bold text-blue-600">{stats.allocated}</p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-blue-50 flex items-center justify-center">
                  <ArrowRightLeft className="h-5 w-5 text-blue-500" />
                </div>
              </div>
              <div className="mt-3 flex items-center gap-3 text-xs text-[var(--neutral-text-secondary)]">
                <span>运输中: {CARRIERS.filter(c => c.status === '运输中').length}</span>
                <span>维修中: {stats.repairing}</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium text-[var(--neutral-text-secondary)]">今日分配 / 成功率</p>
                  <p className="mt-1 text-2xl font-bold text-[var(--neutral-text-primary)]">
                    {stats.todayAllocations}
                    <span className="text-sm font-normal text-[var(--neutral-text-secondary)] ml-2">
                      {stats.successRate}%
                    </span>
                  </p>
                </div>
                <div className="h-10 w-10 rounded-lg bg-violet-50 flex items-center justify-center">
                  <PackageCheck className="h-5 w-5 text-violet-500" />
                </div>
              </div>
              <div className="mt-3 text-xs text-[var(--neutral-text-tertiary)]">
                较昨日 +2 次分配
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* ── Charts Row ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2 bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              分配趋势（今日）
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={TREND_DATA}>
                  <defs>
                    <linearGradient id="allocGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="hour" tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <YAxis tick={{ fontSize: 12 }} stroke="#9ca3af" />
                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid var(--neutral-border)',
                      background: 'var(--neutral-surface)',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="count"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    fill="url(#allocGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Container className="h-4 w-4" />
              载具类型分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[180px] relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={TYPE_DIST_DATA}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={70}
                    dataKey="value"
                    stroke="none"
                  >
                    {TYPE_DIST_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border: '1px solid var(--neutral-border)',
                      background: 'var(--neutral-surface)',
                      fontSize: '12px',
                    }}
                    formatter={(value: number, name: string) => [`${value}个`, name]}
                  />
                </PieChart>
              </ResponsiveContainer>
              {/* Legend */}
              <div className="absolute bottom-0 left-0 right-0 flex flex-wrap justify-center gap-x-3 gap-y-1">
                {TYPE_DIST_DATA.map(item => (
                  <div key={item.name} className="flex items-center gap-1 text-xs text-[var(--neutral-text-secondary)]">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                    {item.name}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── Carrier Pool ── */}
      <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)] mb-6">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Container className="h-5 w-5" />
              载具池
            </CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--neutral-text-tertiary)]" />
                <Input
                  placeholder="搜索载具编码或位置..."
                  className="pl-8 h-8 w-56 text-xs border-[var(--neutral-border)] bg-transparent"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Status filter */}
          <div className="flex items-center gap-2 mb-4 flex-wrap">
            <Filter className="h-3.5 w-3.5 text-[var(--neutral-text-tertiary)]" />
            {(['all', ...CARRIER_STATUS_LIST]).map(status => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={cn(
                  'px-2.5 py-1 rounded-md text-xs font-medium transition-colors',
                  statusFilter === status
                    ? 'bg-[var(--theme-color)] text-white'
                    : 'bg-[var(--neutral-background)] text-[var(--neutral-text-secondary)] hover:text-[var(--neutral-text-primary)]'
                )}
              >
                {status === 'all' ? '全部' : status}
              </button>
            ))}
          </div>

          {/* Type Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4 bg-[var(--neutral-background)]">
              <TabsTrigger value="all" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                全部
              </TabsTrigger>
              <TabsTrigger value="pallet" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                托盘
              </TabsTrigger>
              <TabsTrigger value="box" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                周转箱
              </TabsTrigger>
              <TabsTrigger value="rack" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                料架
              </TabsTrigger>
              <TabsTrigger value="eu" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                EU箱
              </TabsTrigger>
              <TabsTrigger value="other" className="text-xs data-[state=active]:bg-[var(--neutral-surface)]">
                其他
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-0">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                <AnimatePresence mode="popLayout">
                  {filteredCarriers.map(carrier => (
                    <motion.div
                      key={carrier.id}
                      layout
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                    >
                      <div
                        className="rounded-lg border border-[var(--neutral-border)] p-4 hover:shadow-md transition-shadow cursor-pointer bg-[var(--neutral-background)]"
                        onClick={() => setViewCarrier(carrier)}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Container className="h-4 w-4 text-[var(--neutral-text-secondary)]" />
                            <span className="text-xs font-semibold text-[var(--neutral-text-primary)]">
                              {carrier.code}
                            </span>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <button className="p-1 rounded hover:bg-[var(--neutral-border)]">
                                <MoreHorizontal className="h-3 w-3 text-[var(--neutral-text-tertiary)]" />
                              </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="text-xs">
                              <DropdownMenuItem onClick={() => setViewCarrier(carrier)}>
                                <Eye className="h-3 w-3 mr-2" /> 查看
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Pencil className="h-3 w-3 mr-2" /> 编辑
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>

                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0.5">
                              {carrier.type}
                            </Badge>
                            <div className="flex items-center gap-1">
                              <div className={cn('w-1.5 h-1.5 rounded-full', getStatusDot(carrier.status))} />
                              <span className={cn('text-[10px] font-medium', carrier.status === '报废' && 'line-through text-gray-400')}>
                                <Badge
                                  variant="outline"
                                  className={cn('text-[10px] px-1.5 py-0', getStatusColor(carrier.status))}
                                >
                                  {carrier.status}
                                </Badge>
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 text-[11px] text-[var(--neutral-text-secondary)]">
                            <MapPin className="h-3 w-3 text-[var(--neutral-text-tertiary)]" />
                            {carrier.location}
                          </div>

                          {carrier.allocatedTo && (
                            <div className="flex items-center gap-1 text-[11px] text-blue-600">
                              <ArrowRightLeft className="h-3 w-3" />
                              {carrier.allocatedTo}
                            </div>
                          )}

                          <div className="text-[10px] text-[var(--neutral-text-tertiary)] pt-1 border-t border-[var(--neutral-border)]">
                            {carrier.specs}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {filteredCarriers.length === 0 && (
                <div className="text-center py-12 text-[var(--neutral-text-tertiary)] text-sm">
                  <Container className="h-8 w-8 mx-auto mb-2 opacity-40" />
                  暂无符合条件的载具
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* ── Allocation Rules ── */}
      <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)] mb-6">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Settings className="h-5 w-5" />
              分配规则配置
            </CardTitle>
            <Button size="sm" variant="outline" className="h-8 text-xs border-[var(--neutral-border)]" onClick={handleAddRule}>
              <Plus className="h-3.5 w-3.5 mr-1" />
              新增规则
            </Button>
          </div>
          <CardDescription className="text-xs text-[var(--neutral-text-secondary)]">
            配置自动分配策略的优先级与执行条件，系统将按优先级顺序依次匹配
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {rules
              .sort((a, b) => a.priority - b.priority)
              .map(rule => (
                <motion.div
                  key={rule.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={cn(
                    'flex items-center gap-4 p-3 rounded-lg border transition-colors',
                    rule.enabled
                      ? 'border-[var(--neutral-border)] bg-[var(--neutral-background)]'
                      : 'border-gray-100 bg-gray-50/50 opacity-60'
                  )}
                >
                  <div className="flex items-center justify-center w-7 h-7 rounded-full bg-[var(--neutral-border)] text-xs font-bold text-[var(--neutral-text-secondary)] shrink-0">
                    {rule.priority}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-[var(--neutral-text-primary)]">{rule.name}</span>
                      {!rule.enabled && (
                        <Badge variant="outline" className="text-[10px] px-1 py-0 bg-gray-100 text-gray-500 border-gray-200">
                          已禁用
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-[var(--neutral-text-secondary)] mt-0.5 truncate">{rule.description}</p>
                    <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[var(--neutral-text-tertiary)]">
                      <span className="flex items-center gap-1">
                        <Filter className="h-3 w-3" />
                        条件: {rule.condition}
                      </span>
                      <span className="flex items-center gap-1">
                        <ArrowRightLeft className="h-3 w-3" />
                        目标: {rule.target}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <Switch
                      checked={rule.enabled}
                      onCheckedChange={() => handleToggleRule(rule.id)}
                    />
                    <button
                      className="p-1.5 rounded-md hover:bg-[var(--neutral-border)] text-[var(--neutral-text-tertiary)]"
                      onClick={() => handleEditRule(rule)}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                      className="p-1.5 rounded-md hover:bg-red-50 text-[var(--neutral-text-tertiary)] hover:text-red-500"
                      onClick={() => setDeleteConfirmRule(rule.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </motion.div>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* ── Auto Allocation Simulation ── */}
      <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)] mb-6">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Bot className="h-5 w-5" />
              自动分配模拟
            </CardTitle>
            <div className="flex items-center gap-2">
              {isSimulating && (
                <span className="text-xs text-[var(--neutral-text-secondary)] flex items-center gap-1">
                  <Timer className="h-3 w-3 animate-spin" />
                  模拟运行中...
                </span>
              )}
              <Button
                size="sm"
                className="h-8 text-xs bg-[var(--theme-color)] hover:bg-[var(--theme-color)]/90"
                onClick={handleSimulate}
                disabled={isSimulating}
              >
                <Play className="h-3.5 w-3.5 mr-1" />
                {isSimulating ? '运行中...' : '开始模拟'}
              </Button>
            </div>
          </div>
          <CardDescription className="text-xs text-[var(--neutral-text-secondary)]">
            点击"开始模拟"按钮，系统将依据当前规则配置执行虚拟分配并展示结果
          </CardDescription>
        </CardHeader>
        <CardContent>
          <AnimatePresence>
            {simResult && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-[var(--neutral-text-secondary)]">
                      模拟结果：共 {simResult.length} 条
                    </span>
                    <span className="flex items-center gap-1 text-emerald-600">
                      <CheckCircle className="h-3 w-3" />
                      成功 {simResult.filter(r => r.status === '成功').length}
                    </span>
                    <span className="flex items-center gap-1 text-amber-600">
                      <AlertTriangle className="h-3 w-3" />
                      冲突 {simResult.filter(r => r.status === '冲突').length}
                    </span>
                    <span className="flex items-center gap-1 text-red-600">
                      <X className="h-3 w-3" />
                      失败 {simResult.filter(r => r.status === '失败').length}
                    </span>
                  </div>
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={handleApplySimResult}>
                    应用成功结果
                  </Button>
                </div>

                {/* Sim Results */}
                <div className="space-y-2">
                  {simResult.map(result => (
                    <Alert
                      key={result.id}
                      variant={result.status === '成功' ? 'default' : result.status === '冲突' ? 'default' : 'destructive'}
                      className={cn(
                        'py-2 px-3 text-xs border',
                        result.status === '成功' && 'bg-emerald-50 border-emerald-200 text-emerald-800',
                        result.status === '冲突' && 'bg-amber-50 border-amber-200 text-amber-800',
                        result.status === '失败' && 'bg-red-50 border-red-200 text-red-800'
                      )}
                    >
                      <div className="flex items-center gap-2">
                        {result.status === '成功' && <CheckCircle className="h-3.5 w-3.5 text-emerald-500 shrink-0" />}
                        {result.status === '冲突' && <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                        {result.status === '失败' && <X className="h-3.5 w-3.5 text-red-500 shrink-0" />}
                        <AlertDescription className="flex-1 text-xs">
                          <span className="font-medium">{result.carrierCode}</span>
                          <span className="mx-1 text-[var(--neutral-text-tertiary)]">→</span>
                          <span>{result.toLocation}</span>
                          <span className="ml-2 text-[var(--neutral-text-tertiary)]">{result.note}</span>
                        </AlertDescription>
                        <Badge
                          variant="outline"
                          className={cn('text-[10px]', getRecordStatusBadge(result.status))}
                        >
                          {result.status}
                        </Badge>
                      </div>
                    </Alert>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!simResult && !isSimulating && (
            <div className="text-center py-8 text-[var(--neutral-text-tertiary)] text-sm">
              <Bot className="h-8 w-8 mx-auto mb-2 opacity-40" />
              点击"开始模拟"运行自动分配逻辑
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Allocation Records ── */}
      <Card className="bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-[var(--neutral-text-primary)] flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5" />
            分配记录
          </CardTitle>
          <CardDescription className="text-xs text-[var(--neutral-text-secondary)]">
            最近的载具分配操作记录
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg border border-[var(--neutral-border)] overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-[var(--neutral-background)]">
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">载具编码</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">类型</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">起始位置</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">目标位置</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">操作人</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">状态</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">时间</TableHead>
                  <TableHead className="text-xs font-medium text-[var(--neutral-text-secondary)]">备注</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {records.map(record => (
                  <TableRow key={record.id} className="hover:bg-[var(--neutral-background)] transition-colors">
                    <TableCell className="text-xs font-medium text-[var(--neutral-text-primary)]">
                      {record.carrierCode}
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                      <Badge variant="outline" className="text-[10px]">
                        {record.carrierType}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                      {record.fromLocation}
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                      {record.toLocation}
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                      {record.operator}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={cn('text-[10px] px-1.5 py-0', getRecordStatusBadge(record.status))}
                      >
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-tertiary)] whitespace-nowrap">
                      {record.timestamp}
                    </TableCell>
                    <TableCell className="text-xs text-[var(--neutral-text-tertiary)] max-w-[150px] truncate">
                      {record.note}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ── Rule Edit/Add Dialog ── */}
      <Dialog open={ruleDialogOpen} onOpenChange={setRuleDialogOpen}>
        <DialogContent className="sm:max-w-lg bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
          <DialogHeader>
            <DialogTitle className="text-base text-[var(--neutral-text-primary)]">
              {editingRule ? '编辑分配规则' : '新增分配规则'}
            </DialogTitle>
            <DialogDescription className="text-xs text-[var(--neutral-text-secondary)]">
              配置规则的优先级、匹配条件和分配目标
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-3">
            <div>
              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">规则名称</label>
              <Input
                placeholder="如：网点优先级分配"
                className="h-9 text-sm border-[var(--neutral-border)]"
                value={ruleForm.name || ''}
                onChange={e => setRuleForm(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">优先级（数字越小越优先）</label>
                <Select
                  value={String(ruleForm.priority ?? 1)}
                  onValueChange={v => setRuleForm(prev => ({ ...prev, priority: Number(v) }))}
                >
                  <SelectTrigger className="h-9 text-sm border-[var(--neutral-border)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[0, 1, 2, 3, 4, 5].map(p => (
                      <SelectItem key={p} value={String(p)} className="text-xs">
                        {p} {p === 0 ? '(最高)' : p === 5 ? '(最低)' : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">启用状态</label>
                <div className="flex items-center h-9">
                  <Switch
                    checked={ruleForm.enabled ?? true}
                    onCheckedChange={v => setRuleForm(prev => ({ ...prev, enabled: v }))}
                  />
                  <span className="ml-2 text-xs text-[var(--neutral-text-secondary)]">
                    {ruleForm.enabled ? '已启用' : '已禁用'}
                  </span>
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">匹配条件</label>
              <Input
                placeholder="如：网点等级=一级 且 库存<安全阈值"
                className="h-9 text-sm border-[var(--neutral-border)]"
                value={ruleForm.condition || ''}
                onChange={e => setRuleForm(prev => ({ ...prev, condition: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">分配目标</label>
              <Input
                placeholder="如：优先分配至一级网点"
                className="h-9 text-sm border-[var(--neutral-border)]"
                value={ruleForm.target || ''}
                onChange={e => setRuleForm(prev => ({ ...prev, target: e.target.value }))}
              />
            </div>

            <div>
              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1.5 block">规则描述</label>
              <textarea
                placeholder="描述规则的业务逻辑..."
                className="w-full h-20 rounded-md border border-[var(--neutral-border)] px-3 py-2 text-xs text-[var(--neutral-text-primary)] bg-transparent resize-none focus:outline-none focus:ring-1 focus:ring-[var(--theme-color)]"
                value={ruleForm.description || ''}
                onChange={e => setRuleForm(prev => ({ ...prev, description: e.target.value }))}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" size="sm" className="text-xs" onClick={() => setRuleDialogOpen(false)}>
              取消
            </Button>
            <Button size="sm" className="text-xs bg-[var(--theme-color)] hover:bg-[var(--theme-color)]/90" onClick={handleSaveRule}>
              {editingRule ? '保存修改' : '创建规则'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Delete Confirm Dialog ── */}
      <Dialog open={!!deleteConfirmRule} onOpenChange={() => setDeleteConfirmRule(null)}>
        <DialogContent className="sm:max-w-sm bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
          <DialogHeader>
            <DialogTitle className="text-base text-[var(--neutral-text-primary)]">确认删除</DialogTitle>
            <DialogDescription className="text-xs text-[var(--neutral-text-secondary)]">
              删除后该规则将不再参与自动分配，此操作不可撤销。
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" size="sm" className="text-xs" onClick={() => setDeleteConfirmRule(null)}>
              取消
            </Button>
            <Button
              size="sm"
              variant="destructive"
              className="text-xs"
              onClick={() => deleteConfirmRule && handleDeleteRule(deleteConfirmRule)}
            >
              确认删除
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Carrier Detail Dialog ── */}
      <Dialog open={!!viewCarrier} onOpenChange={() => setViewCarrier(null)}>
        <DialogContent className="sm:max-w-md bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
          <DialogHeader>
            <DialogTitle className="text-base text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Container className="h-5 w-5" />
              载具详情
            </DialogTitle>
          </DialogHeader>

          {viewCarrier && (
            <div className="space-y-3 py-2">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-[var(--neutral-background)] p-3">
                  <p className="text-[10px] text-[var(--neutral-text-tertiary)]">载具编码</p>
                  <p className="text-sm font-semibold text-[var(--neutral-text-primary)] mt-0.5">{viewCarrier.code}</p>
                </div>
                <div className="rounded-lg bg-[var(--neutral-background)] p-3">
                  <p className="text-[10px] text-[var(--neutral-text-tertiary)]">载具类型</p>
                  <p className="text-sm font-semibold text-[var(--neutral-text-primary)] mt-0.5">{viewCarrier.type}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-[var(--neutral-background)] p-3">
                  <p className="text-[10px] text-[var(--neutral-text-tertiary)]">当前状态</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <div className={cn('w-2 h-2 rounded-full', getStatusDot(viewCarrier.status))} />
                    <span className="text-sm font-semibold text-[var(--neutral-text-primary)]">{viewCarrier.status}</span>
                  </div>
                </div>
                <div className="rounded-lg bg-[var(--neutral-background)] p-3">
                  <p className="text-[10px] text-[var(--neutral-text-tertiary)]">规格</p>
                  <p className="text-sm font-semibold text-[var(--neutral-text-primary)] mt-0.5">{viewCarrier.specs}</p>
                </div>
              </div>

              <div className="rounded-lg bg-[var(--neutral-background)] p-3">
                <p className="text-[10px] text-[var(--neutral-text-tertiary)]">当前位置</p>
                <p className="text-sm font-semibold text-[var(--neutral-text-primary)] mt-0.5 flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5 text-[var(--neutral-text-secondary)]" />
                  {viewCarrier.location}
                </p>
              </div>

              {viewCarrier.allocatedTo && (
                <div className="rounded-lg bg-blue-50 border border-blue-100 p-3">
                  <p className="text-[10px] text-blue-500">分配目标</p>
                  <p className="text-sm font-semibold text-blue-700 mt-0.5 flex items-center gap-1">
                    <ArrowRightLeft className="h-3.5 w-3.5" />
                    {viewCarrier.allocatedTo}
                  </p>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button size="sm" variant="outline" className="text-xs" onClick={() => setViewCarrier(null)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
