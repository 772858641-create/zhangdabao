import { useState, useMemo, useCallback } from 'react';
import type { Device } from '@/lib/mockData';
import { useMockData } from '@/hooks/useMockData';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerClose,
} from '@/components/ui/drawer';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  Search,
  Plus,
  Upload,
  Download,
  Eye,
  Edit3,
  Send,
  Terminal,
  RefreshCw,
  Package,
  BatteryMedium,
  Wifi,
  WifiOff,
  X,
  Tag,
  Bluetooth,
  Cpu,
  CheckCircle2,
  XCircle,
  Timer,
  Navigation,
  Crosshair,
  Radio,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────
type DeviceCategory = 'all' | 'locator' | 'fixed-gateway' | 'vehicle-gateway' | 'tag' | 'beacon';

interface DeviceCategoryTab {
  key: DeviceCategory;
  label: string;
  icon: typeof Navigation;
}

// ─── Constants ───────────────────────────────────────────────────
const CATEGORY_TABS: DeviceCategoryTab[] = [
  { key: 'all', label: '全部', icon: Crosshair },
  { key: 'locator', label: '定位器', icon: Navigation },
  { key: 'fixed-gateway', label: '固定网关', icon: Radio },
  { key: 'vehicle-gateway', label: '车载网关', icon: Cpu },
  { key: 'tag', label: '标签', icon: Tag },
  { key: 'beacon', label: '蓝牙信标', icon: Bluetooth },
];

const DEVICE_TYPE_MAP: Record<DeviceCategory, string[]> = {
  all: ['GPS定位器', '蓝牙标签', 'RFID读写器', '车载网关', '温湿度传感器'],
  locator: ['GPS定位器'],
  'fixed-gateway': ['RFID读写器'],
  'vehicle-gateway': ['车载网关'],
  tag: ['蓝牙标签'],
  beacon: ['温湿度传感器'],
};

interface CommandParam {
  key: string;
  label: string;
  type: 'number' | 'select';
  default?: string;
  options?: string[];
}

interface CommandDef {
  value: string;
  label: string;
  params: CommandParam[];
}

const LOCATOR_COMMANDS: CommandDef[] = [
  { value: 'query_location', label: '查询位置', params: [] },
  { value: 'set_interval', label: '设置上报间隔', params: [{ key: 'interval', label: '上报间隔（秒）', type: 'number', default: '60' }] },
  { value: 'set_mode', label: '设置工作模式', params: [{ key: 'mode', label: '工作模式', type: 'select', options: ['正常', '省电', '追踪'] }] },
  { value: 'reboot', label: '重启设备', params: [] },
  { value: 'factory_reset', label: '恢复出厂设置', params: [] },
];

const TAG_COMMANDS: CommandDef[] = [
  { value: 'query_status', label: '查询状态', params: [] },
  { value: 'set_broadcast', label: '设置广播间隔', params: [{ key: 'interval', label: '广播间隔（毫秒）', type: 'number', default: '500' }] },
  { value: 'set_power', label: '设置功率', params: [{ key: 'power', label: '功率级别', type: 'select', options: ['低', '中', '高'] }] },
  { value: 'set_battery_threshold', label: '低电量报警阈值', params: [{ key: 'threshold', label: '阈值（%）', type: 'number', default: '20' }] },
];

const GATEWAY_COMMANDS: CommandDef[] = [
  { value: 'reboot', label: '重启', params: [] },
  { value: 'query_connected', label: '查询连接设备', params: [] },
  { value: 'set_scan', label: '设置扫描参数', params: [{ key: 'duration', label: '扫描时长（秒）', type: 'number', default: '10' }] },
];

// ─── Helpers ─────────────────────────────────────────────────────
function categoryFromDeviceType(type: string): DeviceCategory {
  switch (type) {
    case 'GPS定位器': return 'locator';
    case 'RFID读写器': return 'fixed-gateway';
    case '车载网关': return 'vehicle-gateway';
    case '蓝牙标签': return 'tag';
    case '温湿度传感器': return 'beacon';
    default: return 'all';
  }
}

function categoryLabel(type: string): string {
  switch (type) {
    case 'GPS定位器': return '定位器';
    case 'RFID读写器': return '固定网关';
    case '车载网关': return '车载网关';
    case '蓝牙标签': return '标签';
    case '温湿度传感器': return '蓝牙信标';
    default: return type;
  }
}

const batteryChartData = Array.from({ length: 24 }, (_, i) => ({
  time: `${String(i).padStart(2, '0')}:00`,
  battery: 60 + Math.sin(i / 4) * 20 + Math.random() * 10,
}));

const signalChartData = Array.from({ length: 24 }, (_, i) => ({
  time: `${String(i).padStart(2, '0')}:00`,
  signal: 50 + Math.cos(i / 3) * 30 + Math.random() * 15,
}));

// ─── Main Component ──────────────────────────────────────────────
export default function DeviceManagementPage() {
  const { devices, getStatusLabel, getStatusColor } = useMockData();

  // ── State ──
  const [activeCategory, setActiveCategory] = useState<DeviceCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedDevices, setSelectedDevices] = useState<Set<string>>(new Set());
  const [detailDevice, setDetailDevice] = useState<Device | null>(null);
  const [detailTab, setDetailTab] = useState('basic');
  const [commandDialogOpen, setCommandDialogOpen] = useState(false);
  const [commandDevice, setCommandDevice] = useState<Device | null>(null);
  const [otaDialogOpen, setOtaDialogOpen] = useState(false);
  const [otaDevice, setOtaDevice] = useState<Device | null>(null);
  const [otaProgress, setOtaProgress] = useState(0);
  const [otaSimulating, setOtaSimulating] = useState(false);
  const [cmdType, setCmdType] = useState('');
  const [cmdParams, setCmdParams] = useState<Record<string, string>>({});
  const [cmdSending, setCmdSending] = useState(false);
  const [cmdResult, setCmdResult] = useState<{ success: boolean; message: string } | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editDevice, setEditDevice] = useState<Device | null>(null);

  // ── Filtering ──
  const filteredDevices = useMemo(() => {
    const types = DEVICE_TYPE_MAP[activeCategory];
    return devices.filter((d) => {
      if (!types.includes(d.type)) return false;
      if (statusFilter !== 'all' && d.status !== statusFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          d.code.toLowerCase().includes(q) ||
          d.name.toLowerCase().includes(q) ||
          d.imei.toLowerCase().includes(q) ||
          (d.carrierName && d.carrierName.toLowerCase().includes(q)) ||
          (d.vehicleName && d.vehicleName.toLowerCase().includes(q)) ||
          d.orgName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [devices, activeCategory, statusFilter, searchQuery]);

  // ── KPI Cards ──
  const kpiCards = useMemo(() => {
    const types = DEVICE_TYPE_MAP[activeCategory];
    const filtered = devices.filter((d) => types.includes(d.type));
    const total = filtered.length;
    const online = filtered.filter((d) => d.status === 'online').length;
    const offline = filtered.filter((d) => d.status === 'offline').length;
    const lowBattery = filtered.filter(
      (d) => d.batteryLevel !== null && d.batteryLevel < 20
    ).length;
    const onlineRate = total > 0 ? ((online / total) * 100).toFixed(1) : '0.0';
    return { total, online, offline, lowBattery, onlineRate };
  }, [devices, activeCategory]);

  // ── Handlers ──
  const handleToggleSelect = useCallback((id: string) => {
    setSelectedDevices((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleSelectAll = useCallback(() => {
    if (selectedDevices.size === filteredDevices.length) {
      setSelectedDevices(new Set());
    } else {
      setSelectedDevices(new Set(filteredDevices.map((d) => d.id)));
    }
  }, [filteredDevices, selectedDevices.size]);

  const openDetail = useCallback((device: Device) => {
    setDetailDevice(device);
    setDetailTab('basic');
  }, []);

  const openCommand = useCallback((device: Device) => {
    setCommandDevice(device);
    setCmdType('');
    setCmdParams({});
    setCmdResult(null);
    setCommandDialogOpen(true);
  }, []);

  const openOTA = useCallback((device: Device) => {
    setOtaDevice(device);
    setOtaProgress(0);
    setOtaDialogOpen(true);
  }, []);

  const openEdit = useCallback((device: Device) => {
    setEditDevice(device);
    setEditDialogOpen(true);
  }, []);

  const sendCommand = useCallback(() => {
    setCmdSending(true);
    setCmdResult(null);
    setTimeout(() => {
      setCmdSending(false);
      setCmdResult({ success: true, message: '指令已下发并成功执行' });
    }, 1500);
  }, []);

  const startOTA = useCallback(() => {
    setOtaSimulating(true);
    setOtaProgress(0);
    let p = 0;
    const timer = setInterval(() => {
      p += Math.floor(Math.random() * 15) + 5;
      if (p >= 100) {
        p = 100;
        clearInterval(timer);
        setOtaSimulating(false);
      }
      setOtaProgress(p);
    }, 400);
  }, []);

  const availableCommands = useMemo(() => {
    if (!commandDevice) return [];
    const cat = categoryFromDeviceType(commandDevice.type);
    if (cat === 'locator') return LOCATOR_COMMANDS;
    if (cat === 'tag') return TAG_COMMANDS;
    return GATEWAY_COMMANDS;
  }, [commandDevice]);

  const activeCommand = useMemo(
    () => availableCommands.find((c) => c.value === cmdType),
    [availableCommands, cmdType]
  );

  // ── Render helpers ──
  const renderStatusDot = (status: string) => (
    <span className="inline-flex items-center gap-1.5">
      <span
        className="w-2 h-2 rounded-full"
        style={{ backgroundColor: getStatusColor(status) }}
      />
      <span style={{ color: getStatusColor(status) }}>{getStatusLabel(status)}</span>
    </span>
  );

  const renderSignalBar = (val: number) => (
    <div className="flex items-center gap-2">
      <div className="w-16 h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{
            width: `${val}%`,
            backgroundColor: val < 30 ? '#EF4444' : val < 60 ? '#F59E0B' : '#10B981',
          }}
        />
      </div>
      <span className="text-xs text-[#475569] tabular-nums">{val}%</span>
    </div>
  );

  const renderBattery = (level: number | null) => {
    if (level === null) return <span className="text-[#94A3B8]">-</span>;
    const color = level < 20 ? '#EF4444' : level < 50 ? '#F59E0B' : '#10B981';
    return (
      <span className="inline-flex items-center gap-1">
        <BatteryMedium size={14} style={{ color }} />
        <span className="text-sm tabular-nums" style={{ color: level < 20 ? '#EF4444' : '#0F172A' }}>
          {level}%
        </span>
      </span>
    );
  };

  return (
    <div className="space-y-5">
      {/* ═══════ Page Header ═══════ */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">设备管理</h1>
          <p className="text-sm text-[#475569] mt-1">共 {devices.length} 台设备</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5">
            <Upload size={14} />
            导入
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download size={14} />
            导出
          </Button>
          <Button size="sm" className="gap-1.5 bg-[#2563EB] hover:bg-[#1D4ED8]">
            <Plus size={14} />
            新增设备
          </Button>
        </div>
      </div>

      {/* ═══════ KPI Cards ═══════ */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: '设备总数', value: kpiCards.total, color: '#2563EB', icon: Package },
          { label: '在线率', value: `${kpiCards.onlineRate}%`, sub: `在线 ${kpiCards.online} 台`, color: '#10B981', icon: Wifi },
          { label: '离线设备数', value: kpiCards.offline, color: '#EF4444', icon: WifiOff },
          { label: '低电量设备', value: kpiCards.lowBattery, color: '#F59E0B', icon: BatteryMedium },
        ].map((card) => (
          <div
            key={card.label}
            className="bg-white rounded-lg p-4 shadow-[0_1px_3px_rgba(0,0,0,0.06)] border-l-4"
            style={{ borderLeftColor: card.color }}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#475569]">{card.label}</span>
              <card.icon size={16} style={{ color: card.color }} />
            </div>
            <div className="mt-2 text-[28px] font-semibold text-[#0F172A] font-number leading-tight">
              {card.value}
            </div>
            {card.sub && <div className="text-xs text-[#94A3B8] mt-1">{card.sub}</div>}
          </div>
        ))}
      </div>

      {/* ═══════ Category Tabs ═══════ */}
      <div className="bg-white rounded-lg p-1.5 shadow-[0_1px_3px_rgba(0,0,0,0.06)]">
        <div className="flex gap-1">
          {CATEGORY_TABS.map((tab) => {
            const Icon = tab.icon;
            const count = devices.filter((d) =>
              tab.key === 'all' ? true : DEVICE_TYPE_MAP[tab.key].includes(d.type)
            ).length;
            const active = activeCategory === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => { setActiveCategory(tab.key); setSelectedDevices(new Set()); }}
                className={cn(
                  'flex items-center gap-1.5 px-4 py-2.5 rounded-md text-sm font-medium transition-all',
                  active
                    ? 'bg-white text-[#2563EB] shadow-sm border-t-2 border-[#2563EB]'
                    : 'text-[#475569] hover:bg-[#F8FAFC]'
                )}
              >
                <Icon size={15} />
                {tab.label}
                <span
                  className={cn(
                    'text-xs px-1.5 py-0.5 rounded-full',
                    active ? 'bg-[#EFF6FF] text-[#2563EB]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                  )}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ═══════ Filter Bar ═══════ */}
      <div className="bg-white rounded-lg p-3 shadow-[0_1px_3px_rgba(0,0,0,0.06)] flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          <Input
            placeholder="搜索设备编号、IMEI、绑定对象..."
            className="pl-8 h-8 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue placeholder="在线状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="online">在线</SelectItem>
            <SelectItem value="offline">离线</SelectItem>
            <SelectItem value="sleeping">休眠</SelectItem>
            <SelectItem value="inactive">未激活</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* ═══════ Bulk Action Bar ═══════ */}
      {selectedDevices.size > 0 && (
        <div className="bg-[#EFF6FF] rounded-lg px-4 py-2.5 flex items-center justify-between">
          <span className="text-sm text-[#2563EB]">
            已选择 <strong>{selectedDevices.size}</strong> 项
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleSelectAll}>
              全选
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSelectedDevices(new Set())}
            >
              取消
            </Button>
          </div>
        </div>
      )}

      {/* ═══════ Data Table ═══════ */}
      <div className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="w-10">
                  <input
                    type="checkbox"
                    className="w-4 h-4 rounded border-[#CBD5E1]"
                    checked={filteredDevices.length > 0 && selectedDevices.size === filteredDevices.length}
                    onChange={handleSelectAll}
                  />
                </TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">设备编号</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">设备类型</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">绑定对象</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">所属组织</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">在线状态</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">信号/电量</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">固件版本</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">最近上报</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium w-28">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDevices.map((device, idx) => {
                const battery = device.batteryLevel ?? Math.floor(Math.random() * 100);
                const signal = Math.floor(Math.random() * 60) + 40;
                const isLowBattery = battery < 20;
                const isOffline = device.status === 'offline';
                return (
                  <TableRow
                    key={device.id}
                    className={cn(
                      'h-12 transition-colors cursor-pointer',
                      idx % 2 === 1 && 'bg-[#F8FAFC]',
                      isOffline && 'text-[#94A3B8]',
                      isLowBattery && 'border-l-[3px] border-l-[#F59E0B]',
                      selectedDevices.has(device.id) && 'bg-[#EFF6FF]'
                    )}
                    onClick={() => openDetail(device)}
                  >
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        className="w-4 h-4 rounded border-[#CBD5E1]"
                        checked={selectedDevices.has(device.id)}
                        onChange={() => handleToggleSelect(device.id)}
                      />
                    </TableCell>
                    <TableCell className="font-mono text-[13px]">{device.code}</TableCell>
                    <TableCell>
                      <span className="text-xs px-2 py-0.5 rounded bg-[#EFF6FF] text-[#2563EB]">
                        {categoryLabel(device.type)}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm">
                      {device.carrierName || device.vehicleName || (
                        <span className="text-[#94A3B8]">未绑定</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm">{device.orgName}</TableCell>
                    <TableCell>{renderStatusDot(device.status)}</TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        {renderSignalBar(signal)}
                        {device.type === '蓝牙标签' && renderBattery(battery)}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{device.firmwareVersion}</TableCell>
                    <TableCell className="text-xs text-[#94A3B8]">{device.lastOnlineAt}</TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-1">
                        <button
                          className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]"
                          title="查看详情"
                          onClick={() => openDetail(device)}
                        >
                          <Eye size={14} />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]"
                          title="编辑"
                          onClick={() => openEdit(device)}
                        >
                          <Edit3 size={14} />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]"
                          title="指令下发"
                          onClick={() => openCommand(device)}
                        >
                          <Terminal size={14} />
                        </button>
                        <button
                          className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]"
                          title="OTA升级"
                          onClick={() => openOTA(device)}
                        >
                          <RefreshCw size={14} />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        {filteredDevices.length === 0 && (
          <div className="py-16 flex flex-col items-center text-[#94A3B8]">
            <Search size={48} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无匹配数据</p>
          </div>
        )}
      </div>

      {/* ═══════════════════════════════════════════
          DETAIL DRAWER
          ═══════════════════════════════════════════ */}
      <Drawer open={!!detailDevice} onOpenChange={(open) => !open && setDetailDevice(null)}>
        <DrawerContent className="w-[640px] sm:max-w-[640px]">
          {detailDevice && (
            <>
              <DrawerHeader className="border-b border-[#E2E8F0]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <DrawerTitle className="text-lg font-semibold">
                      {detailDevice.code}
                    </DrawerTitle>
                    <span
                      className="text-xs px-2 py-0.5 rounded"
                      style={{
                        backgroundColor: getStatusColor(detailDevice.status) + '20',
                        color: getStatusColor(detailDevice.status),
                      }}
                    >
                      {getStatusLabel(detailDevice.status)}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded bg-[#EFF6FF] text-[#2563EB]">
                      {categoryLabel(detailDevice.type)}
                    </span>
                  </div>
                  <DrawerClose asChild>
                    <button className="p-1 rounded hover:bg-[#F1F5F9]">
                      <X size={18} className="text-[#94A3B8]" />
                    </button>
                  </DrawerClose>
                </div>
                <DrawerDescription className="text-xs text-[#94A3B8] mt-1">
                  {detailDevice.name} · IMEI: {detailDevice.imei}
                </DrawerDescription>
              </DrawerHeader>

              <Tabs value={detailTab} onValueChange={setDetailTab} className="flex-1 overflow-hidden">
                <TabsList className="w-full rounded-none border-b bg-transparent px-4 pt-2 gap-0">
                  {['basic', 'realtime', 'history', 'commands', 'bindings'].map((t) => (
                    <TabsTrigger
                      key={t}
                      value={t}
                      className={cn(
                        'rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563EB] data-[state=active]:shadow-none bg-transparent text-xs',
                        detailTab === t ? 'text-[#2563EB]' : 'text-[#475569]'
                      )}
                    >
                      {t === 'basic' && '基本信息'}
                      {t === 'realtime' && '实时数据'}
                      {t === 'history' && '历史数据'}
                      {t === 'commands' && '指令记录'}
                      {t === 'bindings' && '绑定记录'}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {/* ── Tab: Basic Info ── */}
                <TabsContent value="basic" className="p-4 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: '设备编号', value: detailDevice.code },
                      { label: '设备名称', value: detailDevice.name },
                      { label: '设备类型', value: categoryLabel(detailDevice.type) },
                      { label: 'IMEI', value: detailDevice.imei },
                      { label: '型号', value: detailDevice.name.split('-')[0] + '-Pro' },
                      { label: '厂商', value: '云载科技' },
                      { label: '固件版本', value: detailDevice.firmwareVersion },
                      { label: '在线状态', value: getStatusLabel(detailDevice.status) },
                      { label: '绑定载具', value: detailDevice.carrierName || '未绑定' },
                      { label: '绑定车辆', value: detailDevice.vehicleName || '未绑定' },
                      { label: '所属组织', value: detailDevice.orgName },
                      { label: '激活时间', value: detailDevice.installedAt },
                      { label: '创建时间', value: detailDevice.createdAt },
                    ].map((item) => (
                      <div key={item.label} className="py-2">
                        <div className="text-xs text-[#94A3B8] mb-1">{item.label}</div>
                        <div className="text-sm text-[#0F172A] font-medium">{item.value}</div>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-4 pt-4 border-t border-[#E2E8F0]">
                    <Button size="sm" variant="outline" onClick={() => openEdit(detailDevice)}>
                      <Edit3 size={14} className="mr-1" />
                      编辑
                    </Button>
                    <Button size="sm" variant="outline">
                      <RefreshCw size={14} className="mr-1" />
                      过户
                    </Button>
                  </div>
                </TabsContent>

                {/* ── Tab: Realtime Data ── */}
                <TabsContent value="realtime" className="p-4 overflow-y-auto space-y-4">
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { label: '信号强度', value: '78%', unit: '', color: '#10B981' },
                      { label: '电量', value: detailDevice.batteryLevel?.toString() || '-', unit: '%', color: '#2563EB' },
                      { label: '温度', value: '23.5', unit: '°C', color: '#F59E0B' },
                      { label: '卫星数', value: '12', unit: '颗', color: '#8B5CF6' },
                    ].map((item) => (
                      <div key={item.label} className="bg-[#F8FAFC] rounded-lg p-3 text-center">
                        <div className="text-xs text-[#475569] mb-1">{item.label}</div>
                        <div className="text-lg font-semibold font-number" style={{ color: item.color }}>
                          {item.value}
                          {item.unit && <span className="text-xs ml-0.5">{item.unit}</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                    <h4 className="text-sm font-medium text-[#0F172A] mb-3">电量趋势（24小时）</h4>
                    <ResponsiveContainer width="100%" height={160}>
                      <AreaChart data={batteryChartData}>
                        <defs>
                          <linearGradient id="batGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2563EB" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                        <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} domain={[0, 100]} />
                        <Tooltip
                          contentStyle={{
                            background: '#fff',
                            border: '1px solid #E2E8F0',
                            borderRadius: 6,
                            fontSize: 12,
                          }}
                        />
                        <Area type="monotone" dataKey="battery" stroke="#2563EB" fill="url(#batGrad)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                    <h4 className="text-sm font-medium text-[#0F172A] mb-3">信号质量（24小时）</h4>
                    <ResponsiveContainer width="100%" height={160}>
                      <AreaChart data={signalChartData}>
                        <defs>
                          <linearGradient id="sigGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10B981" stopOpacity={0.2} />
                            <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                        <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} domain={[0, 100]} />
                        <Tooltip
                          contentStyle={{
                            background: '#fff',
                            border: '1px solid #E2E8F0',
                            borderRadius: 6,
                            fontSize: 12,
                          }}
                        />
                        <Area type="monotone" dataKey="signal" stroke="#10B981" fill="url(#sigGrad)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </TabsContent>

                {/* ── Tab: History Data ── */}
                <TabsContent value="history" className="p-4 overflow-y-auto space-y-4">
                  <div className="flex items-center gap-2">
                    <Select defaultValue="24h">
                      <SelectTrigger className="w-32 h-8 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="24h">近24小时</SelectItem>
                        <SelectItem value="7d">近7天</SelectItem>
                        <SelectItem value="30d">近30天</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm">
                      <Download size={14} className="mr-1" />
                      导出
                    </Button>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                    <h4 className="text-sm font-medium text-[#0F172A] mb-3">信号强度趋势</h4>
                    <ResponsiveContainer width="100%" height={180}>
                      <AreaChart data={signalChartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                        <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <Tooltip contentStyle={{ fontSize: 12 }} />
                        <Area type="monotone" dataKey="signal" stroke="#2563EB" fill="#2563EB" fillOpacity={0.1} strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#F8FAFC]">
                          <TableHead className="text-xs">时间</TableHead>
                          <TableHead className="text-xs">信号强度</TableHead>
                          <TableHead className="text-xs">电量</TableHead>
                          <TableHead className="text-xs">温度</TableHead>
                          <TableHead className="text-xs">位置</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {Array.from({ length: 10 }).map((_, i) => (
                          <TableRow key={i} className="h-10">
                            <TableCell className="text-xs text-[#475569]">
                              2024-12-20 {String(14 + i).padStart(2, '0')}:00
                            </TableCell>
                            <TableCell className="text-xs">{50 + Math.floor(Math.random() * 40)}%</TableCell>
                            <TableCell className="text-xs">{40 + Math.floor(Math.random() * 50)}%</TableCell>
                            <TableCell className="text-xs">{20 + Math.floor(Math.random() * 10)}°C</TableCell>
                            <TableCell className="text-xs text-[#94A3B8]">上海浦东新区</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* ── Tab: Command Records ── */}
                <TabsContent value="commands" className="p-4 overflow-y-auto space-y-4">
                  <div className="flex justify-end">
                    <Button size="sm" onClick={() => { setCommandDevice(detailDevice); setCmdType(''); setCmdParams({}); setCmdResult(null); setCommandDialogOpen(true); }}>
                      <Send size={14} className="mr-1" />
                      下发指令
                    </Button>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#F8FAFC]">
                          <TableHead className="text-xs">时间</TableHead>
                          <TableHead className="text-xs">指令类型</TableHead>
                          <TableHead className="text-xs">参数</TableHead>
                          <TableHead className="text-xs">状态</TableHead>
                          <TableHead className="text-xs">响应结果</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {[
                          { time: '2024-12-20 10:30:00', type: '查询位置', params: '-', status: 'success', result: '经度121.68, 纬度31.18' },
                          { time: '2024-12-19 16:45:00', type: '设置上报间隔', params: '60秒', status: 'success', result: '已确认' },
                          { time: '2024-12-18 09:20:00', type: '重启设备', params: '-', status: 'timeout', result: '设备未响应' },
                          { time: '2024-12-15 14:10:00', type: '设置工作模式', params: '省电模式', status: 'success', result: '已确认' },
                          { time: '2024-12-10 11:00:00', type: '查询状态', params: '-', status: 'failed', result: '通信超时' },
                        ].map((cmd, i) => (
                          <TableRow key={i} className="h-10">
                            <TableCell className="text-xs text-[#475569]">{cmd.time}</TableCell>
                            <TableCell className="text-xs">{cmd.type}</TableCell>
                            <TableCell className="text-xs text-[#94A3B8]">{cmd.params}</TableCell>
                            <TableCell>
                              {cmd.status === 'success' && <span className="inline-flex items-center gap-1 text-xs text-[#10B981]"><CheckCircle2 size={12} />成功</span>}
                              {cmd.status === 'failed' && <span className="inline-flex items-center gap-1 text-xs text-[#EF4444]"><XCircle size={12} />失败</span>}
                              {cmd.status === 'timeout' && <span className="inline-flex items-center gap-1 text-xs text-[#F59E0B]"><Timer size={12} />超时</span>}
                            </TableCell>
                            <TableCell className="text-xs text-[#94A3B8]">{cmd.result}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* ── Tab: Binding Records ── */}
                <TabsContent value="bindings" className="p-4 overflow-y-auto space-y-3">
                  <div className="relative pl-4 border-l-2 border-[#E2E8F0] space-y-4">
                    {[
                      { time: '2024-12-01 10:00:00', event: '绑定载具', detail: '绑定载具 ZJ-004023', type: 'bind' },
                      { time: '2024-11-15 09:30:00', event: '解绑载具', detail: '解绑载具 ZJ-003891', type: 'unbind' },
                      { time: '2024-10-20 14:00:00', event: '设备激活', detail: '设备首次激活上线', type: 'active' },
                      { time: '2024-10-20 11:00:00', event: '设备入库', detail: '所属组织：华东汽车制造', type: 'store' },
                    ].map((record, i) => (
                      <div key={i} className="relative">
                        <span
                          className="absolute -left-[21px] top-0 w-3 h-3 rounded-full border-2 border-white"
                          style={{
                            backgroundColor:
                              record.type === 'bind' ? '#2563EB' :
                              record.type === 'unbind' ? '#F59E0B' :
                              record.type === 'active' ? '#10B981' : '#94A3B8',
                          }}
                        />
                        <div className="text-xs text-[#94A3B8]">{record.time}</div>
                        <div className="text-sm font-medium text-[#0F172A] mt-0.5">{record.event}</div>
                        <div className="text-xs text-[#475569] mt-0.5">{record.detail}</div>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DrawerContent>
      </Drawer>

      {/* ═══════════════════════════════════════════
          COMMAND DIALOG
          ═══════════════════════════════════════════ */}
      <Dialog open={commandDialogOpen} onOpenChange={setCommandDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">下发指令</DialogTitle>
            <DialogDescription className="text-xs">
              目标设备：{commandDevice?.code}（{commandDevice ? categoryLabel(commandDevice.type) : ''}）
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">指令类型</label>
              <Select value={cmdType} onValueChange={(v) => { setCmdType(v); setCmdParams({}); setCmdResult(null); }}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="请选择指令类型" />
                </SelectTrigger>
                <SelectContent>
                  {availableCommands.map((cmd) => (
                    <SelectItem key={cmd.value} value={cmd.value}>{cmd.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {activeCommand?.params.map((param) => (
              <div key={param.key}>
                <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">{param.label}</label>
                {param.type === 'select' ? (
                  <Select value={cmdParams[param.key] || ''} onValueChange={(v) => setCmdParams((p) => ({ ...p, [param.key]: v }))}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={`请选择${param.label}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {param.options?.map((opt) => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    type="number"
                    placeholder={param.default}
                    value={cmdParams[param.key] || ''}
                    onChange={(e) => setCmdParams((p) => ({ ...p, [param.key]: e.target.value }))}
                  />
                )}
              </div>
            ))}
            {cmdResult && (
              <div className={cn(
                'flex items-center gap-2 p-3 rounded-lg text-sm',
                cmdResult.success ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#FEF2F2] text-[#EF4444]'
              )}>
                {cmdResult.success ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                {cmdResult.message}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCommandDialogOpen(false)}>取消</Button>
            <Button
              className="bg-[#2563EB] hover:bg-[#1D4ED8]"
              disabled={!cmdType || cmdSending}
              onClick={sendCommand}
            >
              {cmdSending ? (
                <span className="inline-flex items-center gap-1">
                  <RefreshCw size={14} className="animate-spin" />
                  发送中...
                </span>
              ) : (
                <span className="inline-flex items-center gap-1">
                  <Send size={14} />
                  发送指令
                </span>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          OTA DIALOG
          ═══════════════════════════════════════════ */}
      <Dialog open={otaDialogOpen} onOpenChange={setOtaDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">OTA 固件升级</DialogTitle>
            <DialogDescription className="text-xs">
              当前设备：{otaDevice?.code} · 当前版本：{otaDevice?.firmwareVersion}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {!otaSimulating && otaProgress === 0 ? (
              <>
                <div>
                  <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">目标版本</label>
                  <Select defaultValue="new">
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">v3.2.1（最新）</SelectItem>
                      <SelectItem value="stable">v3.1.8（稳定版）</SelectItem>
                      <SelectItem value="beta">v3.3.0-beta（测试版）</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="text-xs text-[#475569] bg-[#F8FAFC] rounded-lg p-3">
                  <div className="font-medium mb-1">版本变更日志 v3.2.1：</div>
                  <ul className="list-disc list-inside space-y-0.5 text-[#94A3B8]">
                    <li>优化定位精度，提升GPS搜星速度</li>
                    <li>修复低电量模式下偶发掉线问题</li>
                    <li>新增蓝牙扫描间隔动态调整</li>
                    <li>提升系统稳定性</li>
                  </ul>
                </div>
              </>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#475569]">升级进度</span>
                  <span className="font-medium text-[#0F172A]">{otaProgress}%</span>
                </div>
                <Progress value={otaProgress} className="h-2" />
                <div className="text-xs text-[#94A3B8] space-y-1">
                  <div>{otaProgress < 30 && '正在下载固件包...'}</div>
                  <div>{otaProgress >= 30 && otaProgress < 60 && '正在校验固件完整性...'}</div>
                  <div>{otaProgress >= 60 && otaProgress < 90 && '正在写入固件...'}</div>
                  <div>{otaProgress >= 90 && otaProgress < 100 && '正在重启设备...'}</div>
                  <div>{otaProgress === 100 && '升级完成！'}</div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOtaDialogOpen(false)}>
              {otaProgress === 100 ? '关闭' : '取消'}
            </Button>
            {otaProgress === 0 && (
              <Button className="bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={startOTA}>
                <RefreshCw size={14} className="mr-1" />
                确认升级
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          EDIT DIALOG (placeholder)
          ═══════════════════════════════════════════ */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">编辑设备</DialogTitle>
            <DialogDescription className="text-xs">
              设备编号：{editDevice?.code}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">设备名称</label>
              <Input defaultValue={editDevice?.name} />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">IMEI</label>
              <Input defaultValue={editDevice?.imei} className="font-mono" />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">所属组织</label>
              <Input defaultValue={editDevice?.orgName} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>取消</Button>
            <Button className="bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={() => setEditDialogOpen(false)}>
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
