import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell,
  Search,
  Filter,
  Download,
  Settings,
  ChevronDown,
  X,
  Check,
  Eye,
  Wrench,
  ArrowLeftRight,
  Ban,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Calendar,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type AlarmLevel = 'urgent' | 'important' | 'normal' | 'info';
type AlarmStatus = 'unhandled' | 'handling' | 'resolved' | 'ignored';

interface AlarmItem {
  id: string;
  type: string;
  level: AlarmLevel;
  status: AlarmStatus;
  targetType: string;
  targetName: string;
  targetId: string;
  message: string;
  location: string;
  siteName: string;
  handlerId: string | null;
  handlerName: string | null;
  resolvedAt: string | null;
  createdAt: string;
  duration: string;
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const ALARM_LEVELS: { key: AlarmLevel | 'all'; label: string; color: string }[] = [
  { key: 'all', label: '全部', color: '#475569' },
  { key: 'urgent', label: '紧急', color: '#EF4444' },
  { key: 'important', label: '重要', color: '#F59E0B' },
  { key: 'normal', label: '一般', color: '#06B6D4' },
  { key: 'info', label: '提示', color: '#94A3B8' },
];

const ALARM_TYPES_17 = [
  '进库报警', '出库报警', '呆滞报警', '在途超时', '标签分离',
  '设备离线', '温度报警', '车辆围栏', '跨网点重复入库', '空满载异常',
  '丢失报警', '循环超期', '路线偏离', '调拨异常', '库存预警',
  '设备低电量', '载具状态异常',
];

const STATUS_OPTIONS: { key: AlarmStatus | 'all'; label: string }[] = [
  { key: 'all', label: '全部状态' },
  { key: 'unhandled', label: '未处理' },
  { key: 'handling', label: '处理中' },
  { key: 'resolved', label: '已处理' },
  { key: 'ignored', label: '已忽略' },
];

const LEVEL_CONFIG: Record<AlarmLevel, { color: string; bg: string; label: string; borderColor: string; rowBg: string }> = {
  urgent: { color: '#EF4444', bg: '#FEF2F2', label: '紧急', borderColor: '#EF4444', rowBg: '#FEF2F2' },
  important: { color: '#F59E0B', bg: '#FFFBEB', label: '重要', borderColor: '#F59E0B', rowBg: '#FFFBEB' },
  normal: { color: '#06B6D4', bg: '#ECFEFF', label: '一般', borderColor: '#06B6D4', rowBg: '#FFFFFF' },
  info: { color: '#94A3B8', bg: '#F1F5F9', label: '提示', borderColor: '#94A3B8', rowBg: '#FFFFFF' },
};

const STATUS_CONFIG: Record<string, { color: string; bg: string; label: string }> = {
  unhandled: { color: '#EF4444', bg: '#FEF2F2', label: '未处理' },
  handling: { color: '#F59E0B', bg: '#FFFBEB', label: '处理中' },
  resolved: { color: '#10B981', bg: '#ECFDF5', label: '已处理' },
  ignored: { color: '#94A3B8', bg: '#F1F5F9', label: '已忽略' },
};

// ------------------------------------------------------------------
// Mock extended alarms
// ------------------------------------------------------------------
const MOCK_ALARMS: AlarmItem[] = Array.from({ length: 30 }, (_, i) => {
  const idx = i + 1;
  const levels: AlarmLevel[] = ['urgent', 'important', 'normal', 'info'];
  const statuses: AlarmStatus[] = ['unhandled', 'handling', 'resolved', 'ignored'];
  const types = ALARM_TYPES_17;
  const sites = ['上海浦东工厂', '宁波生产基地', '广州仓储中心', '深圳配送中心', '天津港仓库', '青岛物流中心', '杭州运营中心', '北京运营中心'];
  const level = levels[i % 4];
  const status = statuses[i % 4];
  const type = types[i % types.length];
  const durations = ['15分钟', '2小时30分', '5小时', '1天3小时', '45分钟', '3小时15分', '12小时', '30分钟'];
  return {
    id: `BJ${String(idx).padStart(8, '0')}`,
    type,
    level,
    status,
    targetType: ['载具', '车辆', '设备', '网点'][i % 4],
    targetName: `${['CJ', '沪A', 'SB', 'WD'][i % 4]}${String(idx).padStart(4, '0')}`,
    targetId: `target-${idx}`,
    message: `${type}：${sites[i % sites.length]}的${['载具', '车辆', '设备', '网点'][i % 4]}触发报警，请及时处理`,
    location: ['上海浦东新区', '宁波市北仑区', '广州市白云区', '深圳市宝安区', '天津市滨海新区'][i % 5],
    siteName: sites[i % sites.length],
    handlerId: status !== 'unhandled' ? `u-${(i % 8) + 1}` : null,
    handlerName: status !== 'unhandled' ? ['系统管理员', '张三', '李四', '王五', '赵六', '孙七', '周八', '吴九'][i % 8] : null,
    resolvedAt: status === 'resolved' ? `2024-12-20 ${String((i % 24)).padStart(2, '0')}:30:00` : null,
    createdAt: `2024-12-${String((i % 20) + 1).padStart(2, '0')} ${String((i % 24)).padStart(2, '0')}:15:00`,
    duration: durations[i % durations.length],
  };
});

// ------------------------------------------------------------------
// Utility functions
// ------------------------------------------------------------------
function formatDateTime(dt: string): string {
  return dt;
}

// ------------------------------------------------------------------
// Components
// ------------------------------------------------------------------

/** Tag component */
function Tag({ label, color, bg, className }: { label: string; color: string; bg: string; className?: string }) {
  return (
    <span
      className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', className)}
      style={{ color, backgroundColor: bg }}
    >
      {label}
    </span>
  );
}

/** KPI Card */
function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4 hover:shadow-card-hover transition-shadow duration-200">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-[#475569] mb-1">{title}</p>
        <p className="text-[28px] font-semibold leading-tight" style={{ color: '#0F172A' }}>{value}</p>
        {subtext && <p className="text-xs text-[#94A3B8] mt-1">{subtext}</p>}
      </div>
    </div>
  );
}

/** Detail Drawer */
function AlarmDetailDrawer({ alarm, onClose }: { alarm: AlarmItem | null; onClose: () => void }) {
  if (!alarm) return null;
  const levelCfg = LEVEL_CONFIG[alarm.level];
  const statusCfg = STATUS_CONFIG[alarm.status];

  return (
    <AnimatePresence>
      {alarm && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed right-0 top-14 bottom-0 w-[560px] bg-white shadow-modal z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-3">
                <span className="text-base font-semibold text-[#0F172A]">{alarm.type}</span>
                <Tag label={levelCfg.label} color={levelCfg.color} bg={levelCfg.bg} />
                <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center transition-colors">
                <X size={18} className="text-[#94A3B8]" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Alarm Info Card */}
              <div>
                <h3 className="text-sm font-semibold text-[#0F172A] mb-3">报警信息</h3>
                <div className="bg-[#F8FAFC] rounded-lg p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警编号</span>
                    <span className="text-sm font-mono text-[#0F172A]">{alarm.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警类型</span>
                    <span className="text-sm text-[#0F172A]">{alarm.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警级别</span>
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: levelCfg.color }} />
                      <span className="text-sm" style={{ color: levelCfg.color }}>{levelCfg.label}</span>
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警对象</span>
                    <span className="text-sm text-[#0F172A]">{alarm.targetName}（{alarm.targetType}）</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">触发网点</span>
                    <span className="text-sm text-[#0F172A]">{alarm.siteName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警位置</span>
                    <span className="text-sm text-[#0F172A]">{alarm.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">报警时间</span>
                    <span className="text-sm text-[#0F172A]">{alarm.createdAt}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">持续时长</span>
                    <span className="text-sm text-[#0F172A]">{alarm.duration}</span>
                  </div>
                </div>
              </div>

              {/* Message */}
              <div>
                <h3 className="text-sm font-semibold text-[#0F172A] mb-3">报警内容</h3>
                <div className="bg-[#FEF2F2] border border-[#FECACA] rounded-lg p-4">
                  <p className="text-sm text-[#EF4444]">{alarm.message}</p>
                </div>
              </div>

              {/* Processing Info */}
              {alarm.handlerName && (
                <div>
                  <h3 className="text-sm font-semibold text-[#0F172A] mb-3">处理信息</h3>
                  <div className="bg-[#F8FAFC] rounded-lg p-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-[#475569]">处理人</span>
                      <span className="text-sm text-[#0F172A]">{alarm.handlerName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-[#475569]">处理状态</span>
                      <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
                    </div>
                    {alarm.resolvedAt && (
                      <div className="flex justify-between">
                        <span className="text-sm text-[#475569]">处理时间</span>
                        <span className="text-sm text-[#0F172A]">{alarm.resolvedAt}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Suggested Actions */}
              {alarm.status === 'unhandled' && (
                <div>
                  <h3 className="text-sm font-semibold text-[#0F172A] mb-3">建议操作</h3>
                  <div className="space-y-2">
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg border border-[#E2E8F0] hover:bg-[#EFF6FF] hover:border-[#BFDBFE] transition-colors text-left">
                      <CheckCircle2 size={18} className="text-[#10B981]" />
                      <div>
                        <p className="text-sm font-medium text-[#0F172A]">确认处理</p>
                        <p className="text-xs text-[#475569]">标记为已处理并填写处理说明</p>
                      </div>
                    </button>
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg border border-[#E2E8F0] hover:bg-[#EFF6FF] hover:border-[#BFDBFE] transition-colors text-left">
                      <Wrench size={18} className="text-[#2563EB]" />
                      <div>
                        <p className="text-sm font-medium text-[#0F172A]">转工单</p>
                        <p className="text-xs text-[#475569]">创建维修工单指派给相关人员</p>
                      </div>
                    </button>
                    <button className="w-full flex items-center gap-3 p-3 rounded-lg border border-[#E2E8F0] hover:bg-[#EFF6FF] hover:border-[#BFDBFE] transition-colors text-left">
                      <ArrowLeftRight size={18} className="text-[#8B5CF6]" />
                      <div>
                        <p className="text-sm font-medium text-[#0F172A]">转调拨</p>
                        <p className="text-xs text-[#475569]">发起调拨流程处理此报警</p>
                      </div>
                    </button>
                  </div>
                </div>
              )}

              {/* Processing History Timeline */}
              {alarm.status !== 'unhandled' && (
                <div>
                  <h3 className="text-sm font-semibold text-[#0F172A] mb-3">处理记录</h3>
                  <div className="space-y-4 relative pl-4 border-l-2 border-[#E2E8F0]">
                    <div className="relative">
                      <span className="absolute -left-[21px] w-3 h-3 rounded-full bg-[#10B981] border-2 border-white" />
                      <p className="text-xs text-[#94A3B8]">{alarm.resolvedAt || alarm.createdAt}</p>
                      <p className="text-sm text-[#0F172A]">报警{statusCfg.label}</p>
                      <p className="text-xs text-[#475569]">处理人：{alarm.handlerName}</p>
                    </div>
                    <div className="relative">
                      <span className="absolute -left-[21px] w-3 h-3 rounded-full bg-[#EF4444] border-2 border-white" />
                      <p className="text-xs text-[#94A3B8]">{alarm.createdAt}</p>
                      <p className="text-sm text-[#0F172A]">报警触发</p>
                      <p className="text-xs text-[#475569]">{alarm.type} - {alarm.message}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/** Process Modal */
function ProcessAlarmModal({ alarm, onClose, onProcess }: { alarm: AlarmItem | null; onClose: () => void; onProcess: (id: string, action: string) => void }) {
  const [action, setAction] = useState('resolve');
  const [note, setNote] = useState('');
  if (!alarm) return null;

  const handleConfirm = () => {
    onProcess(alarm.id, action);
    onClose();
  };

  return (
    <AnimatePresence>
      {alarm && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[85vh]"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
              <h3 className="text-base font-semibold text-[#0F172A]">处理报警</h3>
              <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
                <X size={18} className="text-[#94A3B8]" />
              </button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto">
              {/* Alarm summary */}
              <div className="bg-[#F8FAFC] rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-medium text-[#0F172A]">{alarm.type}</span>
                  <Tag label={LEVEL_CONFIG[alarm.level].label} color={LEVEL_CONFIG[alarm.level].color} bg={LEVEL_CONFIG[alarm.level].bg} />
                </div>
                <p className="text-sm text-[#475569]">{alarm.message}</p>
                <div className="flex gap-4 mt-2 text-xs text-[#94A3B8]">
                  <span>对象：{alarm.targetName}</span>
                  <span>网点：{alarm.siteName}</span>
                  <span>时间：{alarm.createdAt}</span>
                </div>
              </div>
              {/* Action type */}
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-2">处理方式</label>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: 'resolve', label: '确认已处理', icon: CheckCircle2, desc: '直接标记为已处理' },
                    { key: 'ticket', label: '转工单', icon: Wrench, desc: '创建工单指派处理' },
                    { key: 'transfer', label: '转调拨', icon: ArrowLeftRight, desc: '发起调拨流程' },
                    { key: 'ignore', label: '忽略', icon: Ban, desc: '标记为已忽略' },
                  ].map((opt) => (
                    <button
                      key={opt.key}
                      onClick={() => setAction(opt.key)}
                      className={cn(
                        'flex items-start gap-3 p-3 rounded-lg border transition-all text-left',
                        action === opt.key
                          ? 'border-[#2563EB] bg-[#EFF6FF]'
                          : 'border-[#E2E8F0] hover:border-[#CBD5E1]'
                      )}
                    >
                      <opt.icon size={18} className={action === opt.key ? 'text-[#2563EB]' : 'text-[#94A3B8]'} />
                      <div>
                        <p className={cn('text-sm font-medium', action === opt.key ? 'text-[#2563EB]' : 'text-[#0F172A]')}>{opt.label}</p>
                        <p className="text-xs text-[#94A3B8]">{opt.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
              {/* Note */}
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-2">处理说明 <span className="text-[#EF4444]">*</span></label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="请输入处理说明..."
                  className="w-full h-24 px-3 py-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus resize-none"
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
              <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC] transition-colors">取消</button>
              <button onClick={handleConfirm} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] transition-colors">确认处理</button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/** Rule Config Modal */
function RuleConfigModal({ onClose }: { onClose: () => void }) {
  const [rules, setRules] = useState([
    { id: 1, name: '呆滞报警规则', type: '呆滞报警', condition: '滞留天数 > 72小时', level: 'important', notify: ['站内消息'], status: true },
    { id: 2, name: '在途超时规则', type: '在途超时', condition: '运输时长 > 48小时', level: 'urgent', notify: ['站内消息', '短信'], status: true },
    { id: 3, name: '温度异常规则', type: '温度报警', condition: '温度 > 60°C 或 < -20°C', level: 'urgent', notify: ['站内消息', '短信', '邮件'], status: true },
    { id: 4, name: '设备离线规则', type: '设备离线', condition: '离线时长 > 30分钟', level: 'important', notify: ['站内消息'], status: true },
    { id: 5, name: '车辆围栏规则', type: '车辆围栏', condition: '偏离围栏范围 > 500米', level: 'normal', notify: ['站内消息'], status: false },
    { id: 6, name: '标签分离规则', type: '标签分离', condition: '标签分离时长 > 30分钟', level: 'urgent', notify: ['站内消息', '短信'], status: true },
    { id: 7, name: '低电量报警规则', type: '设备低电量', condition: '电量 < 20%', level: 'important', notify: ['站内消息'], status: true },
  ]);
  const [editingRule, setEditingRule] = useState<typeof rules[0] | null>(null);

  const toggleRuleStatus = (id: number) => {
    setRules(rules.map(r => r.id === id ? { ...r, status: !r.status } : r));
  };

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-[8%] -translate-x-1/2 w-[720px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[85vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">报警规则配置</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 overflow-y-auto flex-1">
            {!editingRule ? (
              <div className="space-y-3">
                {rules.map((rule) => (
                  <div key={rule.id} className="flex items-center gap-4 p-4 border border-[#E2E8F0] rounded-lg hover:border-[#CBD5E1] transition-colors">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-[#0F172A]">{rule.name}</span>
                        <Tag
                          label={LEVEL_CONFIG[rule.level as AlarmLevel]?.label || rule.level}
                          color={LEVEL_CONFIG[rule.level as AlarmLevel]?.color || '#94A3B8'}
                          bg={LEVEL_CONFIG[rule.level as AlarmLevel]?.bg || '#F1F5F9'}
                        />
                        <span className={cn(
                          'text-xs px-1.5 py-0.5 rounded',
                          rule.status ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                        )}>
                          {rule.status ? '启用' : '停用'}
                        </span>
                      </div>
                      <p className="text-xs text-[#475569]">{rule.type} · {rule.condition}</p>
                      <p className="text-xs text-[#94A3B8] mt-0.5">通知：{rule.notify.join('、')}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <button
                        onClick={() => toggleRuleStatus(rule.id)}
                        className={cn(
                          'relative w-9 h-5 rounded-full transition-colors',
                          rule.status ? 'bg-[#2563EB]' : 'bg-[#CBD5E1]'
                        )}
                      >
                        <span className={cn(
                          'absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform',
                          rule.status ? 'translate-x-4' : 'translate-x-0'
                        )} />
                      </button>
                      <button onClick={() => setEditingRule(rule)} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
                        <Settings size={14} className="text-[#475569]" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-5">
                <button onClick={() => setEditingRule(null)} className="flex items-center gap-1 text-sm text-[#2563EB] hover:underline">
                  <ChevronRight size={16} className="rotate-180" /> 返回规则列表
                </button>
                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-2">规则名称</label>
                  <input
                    defaultValue={editingRule.name}
                    className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-2">报警类型</label>
                    <select defaultValue={editingRule.type} className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
                      {ALARM_TYPES_17.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#0F172A] mb-2">报警级别</label>
                    <select defaultValue={editingRule.level} className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
                      {Object.entries(LEVEL_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-2">触发条件</label>
                  <input
                    defaultValue={editingRule.condition}
                    className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-2">通知方式</label>
                  <div className="flex gap-3">
                    {['站内消息', '短信', '邮件', '微信'].map(n => (
                      <label key={n} className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" defaultChecked={editingRule.notify.includes(n)} className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]" />
                        <span className="text-sm text-[#475569]">{n}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">关闭</button>
            {!editingRule && <button onClick={() => setEditingRule({ id: Date.now(), name: '', type: ALARM_TYPES_17[0], condition: '', level: 'normal', notify: ['站内消息'], status: true })} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">新增规则</button>}
            {editingRule && <button onClick={() => setEditingRule(null)} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存</button>}
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function AlarmManagementPage() {
  const { alarms: rawAlarms } = useMockData();
  const [activeLevelTab, setActiveLevelTab] = useState<AlarmLevel | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<AlarmStatus | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<string[]>([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [detailAlarm, setDetailAlarm] = useState<AlarmItem | null>(null);
  const [processAlarm, setProcessAlarm] = useState<AlarmItem | null>(null);
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);
  const pageSize = 10;

  // Combine mock alarms
  const allAlarms = useMemo(() => {
    void rawAlarms;
    return [...MOCK_ALARMS];
  }, [rawAlarms]);

  // Filtered alarms
  const filteredAlarms = useMemo(() => {
    return allAlarms.filter((alarm) => {
      if (activeLevelTab !== 'all' && alarm.level !== activeLevelTab) return false;
      if (statusFilter !== 'all' && alarm.status !== statusFilter) return false;
      if (typeFilter.length > 0 && !typeFilter.includes(alarm.type)) return false;
      if (searchKeyword) {
        const kw = searchKeyword.toLowerCase();
        return (
          alarm.id.toLowerCase().includes(kw) ||
          alarm.targetName.toLowerCase().includes(kw) ||
          alarm.message.toLowerCase().includes(kw) ||
          alarm.siteName.toLowerCase().includes(kw)
        );
      }
      return true;
    });
  }, [allAlarms, activeLevelTab, statusFilter, typeFilter, searchKeyword]);

  // Pagination
  const totalPages = Math.ceil(filteredAlarms.length / pageSize);
  const paginatedAlarms = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredAlarms.slice(start, start + pageSize);
  }, [filteredAlarms, currentPage]);

  // KPI data
  const kpiData = useMemo(() => {
    const unhandled = allAlarms.filter(a => a.status === 'unhandled').length;
    const today = allAlarms.filter(a => a.createdAt.startsWith('2024-12-20')).length;
    const thisWeek = 312;
    const resolved = allAlarms.filter(a => a.status === 'resolved').length;
    const rate = allAlarms.length > 0 ? ((resolved / allAlarms.length) * 100).toFixed(1) : '0';
    return { unhandled, today, thisWeek, rate };
  }, [allAlarms]);

  // Count per level
  const levelCounts = useMemo(() => {
    const counts: Record<string, number> = { all: allAlarms.length };
    ALARM_LEVELS.slice(1).forEach(l => {
      counts[l.key] = allAlarms.filter(a => a.level === l.key).length;
    });
    return counts;
  }, [allAlarms]);

  // Row selection
  const toggleRow = (id: string) => {
    const next = new Set(selectedRows);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedRows(next);
  };

  const toggleAll = () => {
    if (selectedRows.size === paginatedAlarms.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(paginatedAlarms.map(a => a.id)));
    }
  };

  const handleBatchAction = (action: string) => {
    alert(`批量${action}：${selectedRows.size} 条报警`);
    setSelectedRows(new Set());
  };

  const handleProcess = (_id: string, _action: string) => {
    setSelectedRows(new Set());
  };

  const toggleTypeFilter = (type: string) => {
    setTypeFilter(prev => prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-[#0F172A]">报警中心</h1>
          {kpiData.unhandled > 0 && (
            <span className="bg-[#EF4444] text-white text-xs font-medium px-2 py-0.5 rounded-full min-w-[18px] h-[18px] flex items-center justify-center">
              {kpiData.unhandled}
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowRuleModal(true)}
            className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors"
          >
            <Settings size={15} /> 报警规则配置
          </button>
          <button className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
            <Download size={15} /> 导出
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        <KPICard
          title="未处理报警"
          value={kpiData.unhandled}
          subtext="需立即关注"
          color="#EF4444"
          icon={AlertTriangle}
        />
        <KPICard
          title="今日报警"
          value={kpiData.today}
          subtext="24小时内新增"
          color="#F59E0B"
          icon={Bell}
        />
        <KPICard
          title="本周报警"
          value={kpiData.thisWeek}
          subtext="环比 +8.3%"
          color="#2563EB"
          icon={Calendar}
        />
        <KPICard
          title="处理率"
          value={`${kpiData.rate}%`}
          subtext="已处理 / 总报警"
          color="#10B981"
          icon={CheckCircle2}
        />
      </div>

      {/* Level Filter Tabs */}
      <div className="bg-white rounded-lg shadow-card p-1">
        <div className="flex gap-1">
          {ALARM_LEVELS.map((level) => (
            <button
              key={level.key}
              onClick={() => { setActiveLevelTab(level.key as AlarmLevel | 'all'); setCurrentPage(1); }}
              className={cn(
                'relative flex items-center gap-2 px-4 py-2.5 rounded-md text-sm font-medium transition-all duration-150',
                activeLevelTab === level.key
                  ? 'bg-white shadow-sm'
                  : 'text-[#475569] hover:bg-[#F8FAFC]'
              )}
            >
              {level.key !== 'all' && (
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: level.color }} />
              )}
              <span style={activeLevelTab === level.key ? { color: level.color } : undefined}>{level.label}</span>
              <span
                className="text-xs px-1.5 py-0.5 rounded-full"
                style={{
                  backgroundColor: activeLevelTab === level.key ? `${level.color}15` : '#F1F5F9',
                  color: activeLevelTab === level.key ? level.color : '#94A3B8',
                }}
              >
                {levelCounts[level.key] || 0}
              </span>
              {activeLevelTab === level.key && (
                <motion.div
                  layoutId="levelTabIndicator"
                  className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full"
                  style={{ backgroundColor: level.color }}
                  transition={{ duration: 0.2 }}
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        {/* Status filter */}
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value as AlarmStatus | 'all'); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {STATUS_OPTIONS.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
        </div>

        {/* Type filter dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowTypeDropdown(!showTypeDropdown)}
            className={cn(
              'h-9 px-3 border rounded-md text-sm flex items-center gap-2 transition-colors',
              typeFilter.length > 0 ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]' : 'border-[#CBD5E1] text-[#475569] hover:border-[#94A3B8]'
            )}
          >
            报警类型 {typeFilter.length > 0 && `(${typeFilter.length})`}
            <ChevronDown size={14} />
          </button>
          <AnimatePresence>
            {showTypeDropdown && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowTypeDropdown(false)} />
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="absolute top-full mt-1 left-0 w-56 bg-white rounded-lg shadow-dropdown border border-[#E2E8F0] z-20 max-h-72 overflow-y-auto p-2"
                >
                  <div className="flex items-center justify-between px-2 py-1 mb-1">
                    <span className="text-xs text-[#94A3B8]">共 {ALARM_TYPES_17.length} 种</span>
                    {typeFilter.length > 0 && (
                      <button onClick={() => setTypeFilter([])} className="text-xs text-[#2563EB] hover:underline">清除</button>
                    )}
                  </div>
                  {ALARM_TYPES_17.map((type) => (
                    <label key={type} className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-[#F1F5F9] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={typeFilter.includes(type)}
                        onChange={() => toggleTypeFilter(type)}
                        className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]"
                      />
                      <span className="text-sm text-[#475569]">{type}</span>
                    </label>
                  ))}
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* Search */}
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => { setSearchKeyword(e.target.value); setCurrentPage(1); }}
              placeholder="搜索报警编号、载具编号、网点名称..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
      </div>

      {/* Batch Operation Bar */}
      <AnimatePresence>
        {selectedRows.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="bg-[#EFF6FF] border border-[#BFDBFE] rounded-lg px-4 py-3 flex items-center justify-between"
          >
            <span className="text-sm text-[#2563EB]">已选择 <strong>{selectedRows.size}</strong> 条报警</span>
            <div className="flex items-center gap-2">
              <button onClick={() => handleBatchAction('确认')} className="h-8 px-3 rounded-md bg-[#10B981] text-white text-xs hover:bg-[#059669] flex items-center gap-1 transition-colors">
                <Check size={14} /> 批量确认
              </button>
              <button onClick={() => handleBatchAction('忽略')} className="h-8 px-3 rounded-md bg-[#94A3B8] text-white text-xs hover:bg-[#64748B] flex items-center gap-1 transition-colors">
                <Ban size={14} /> 批量忽略
              </button>
              <button onClick={() => handleBatchAction('转工单')} className="h-8 px-3 rounded-md bg-[#2563EB] text-white text-xs hover:bg-[#1D4ED8] flex items-center gap-1 transition-colors">
                <Wrench size={14} /> 批量转工单
              </button>
              <button onClick={() => setSelectedRows(new Set())} className="h-8 px-3 rounded-md border border-[#BFDBFE] text-[#2563EB] text-xs hover:bg-white transition-colors">
                取消选择
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="w-10 px-3 py-2.5">
                  <input
                    type="checkbox"
                    checked={paginatedAlarms.length > 0 && selectedRows.size === paginatedAlarms.length}
                    onChange={toggleAll}
                    className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]"
                  />
                </th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">级别</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">报警类型</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">报警对象</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">报警内容</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">所属网点</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">报警时间</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">持续时长</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">处理人</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedAlarms.map((alarm, idx) => {
                const levelCfg = LEVEL_CONFIG[alarm.level];
                const statusCfg = STATUS_CONFIG[alarm.status];
                const isSelected = selectedRows.has(alarm.id);
                return (
                  <motion.tr
                    key={alarm.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: idx * 0.03 }}
                    className={cn(
                      'group border-b border-[#E2E8F0] transition-colors duration-150',
                      isSelected ? 'bg-[#EFF6FF]' : 'hover:bg-[#EFF6FF]'
                    )}
                    style={alarm.level === 'urgent' && alarm.status === 'unhandled' ? { borderLeft: `3px solid ${levelCfg.borderColor}`, backgroundColor: isSelected ? '#EFF6FF' : levelCfg.rowBg } : { borderLeft: `3px solid ${isSelected ? '#2563EB' : 'transparent'}` }}
                  >
                    <td className="px-3 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleRow(alarm.id)}
                        className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: levelCfg.color }} />
                        <span className="text-xs font-medium" style={{ color: levelCfg.color }}>{levelCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#0F172A]">{alarm.type}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-col">
                        <span className="text-sm text-[#0F172A]">{alarm.targetName}</span>
                        <span className="text-xs text-[#94A3B8]">{alarm.targetType}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3 max-w-[200px]">
                      <p className="text-sm text-[#475569] truncate">{alarm.message}</p>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569]">{alarm.siteName}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#475569] font-mono">{formatDateTime(alarm.createdAt)}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#94A3B8]">{alarm.duration}</span>
                    </td>
                    <td className="px-3 py-3">
                      <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569]">{alarm.handlerName || '-'}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {alarm.status === 'unhandled' && (
                          <button onClick={() => setProcessAlarm(alarm)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="处理">
                            <Check size={14} className="text-[#10B981]" />
                          </button>
                        )}
                        <button onClick={() => setDetailAlarm(alarm)} className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center" title="查看详情">
                          <Eye size={14} className="text-[#475569]" />
                        </button>
                        {alarm.status === 'unhandled' && (
                          <button onClick={() => { if (confirm('确定忽略此报警？')) { /* handle ignore */ } }} className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="忽略">
                            <Ban size={14} className="text-[#94A3B8]" />
                          </button>
                        )}
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {paginatedAlarms.length === 0 && (
                <tr>
                  <td colSpan={11} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Bell size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无报警数据</p>
                      <p className="text-sm text-[#94A3B8]">当前筛选条件下没有符合条件的报警</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredAlarms.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">
              共 <strong>{filteredAlarms.length}</strong> 条，第 <strong>{currentPage}</strong> / {totalPages} 页
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={cn(
                      'w-8 h-8 rounded-md text-sm font-medium transition-colors',
                      currentPage === page
                        ? 'bg-[#2563EB] text-white'
                        : 'text-[#475569] hover:bg-[#F1F5F9]'
                    )}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      {detailAlarm && <AlarmDetailDrawer alarm={detailAlarm} onClose={() => setDetailAlarm(null)} />}

      {/* Process Modal */}
      {processAlarm && <ProcessAlarmModal alarm={processAlarm} onClose={() => setProcessAlarm(null)} onProcess={handleProcess} />}

      {/* Rule Config Modal */}
      {showRuleModal && <RuleConfigModal onClose={() => setShowRuleModal(false)} />}
    </div>
  );
}
