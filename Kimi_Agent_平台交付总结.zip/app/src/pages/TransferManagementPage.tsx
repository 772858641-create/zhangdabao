import { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Download,
  Search,
  Eye,
  Edit3,
  CheckCircle,
  XCircle,
  Truck,
  AlertTriangle,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Package,
  ArrowRight,
  X,
  FileText,
  ClipboardCheck,
  RotateCcw,
  BarChart3,
  Upload,
  Warehouse,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import type { TransferOrder } from '@/lib/mockData';

// ============================================================
// Status Config
// ============================================================

const transferStatusConfig: Record<string, { label: string; bg: string; text: string; border: string }> = {
  draft: { label: '草稿', bg: '#F1F5F9', text: '#475569', border: '#E2E8F0' },
  pending_review: { label: '待审核', bg: '#FFFBEB', text: '#F59E0B', border: '#FDE68A' },
  approved: { label: '审核通过', bg: '#EFF6FF', text: '#2563EB', border: '#BFDBFE' },
  rejected: { label: '审核驳回', bg: '#FEF2F2', text: '#EF4444', border: '#FECACA' },
  in_transit: { label: '运输中', bg: '#ECFEFF', text: '#06B6D4', border: '#A5F3FC' },
  pending_receipt: { label: '待签收', bg: '#F5F3FF', text: '#8B5CF6', border: '#DDD6FE' },
  completed: { label: '已完成', bg: '#ECFDF5', text: '#10B981', border: '#A7F3D0' },
  cancelled: { label: '已取消', bg: '#F1F5F9', text: '#94A3B8', border: '#E2E8F0' },
  exception: { label: '异常', bg: '#FEF2F2', text: '#EF4444', border: '#FECACA' },
};

const statusTabList = [
  { key: 'all', label: '全部' },
  { key: 'draft', label: '草稿' },
  { key: 'pending_review', label: '待审核' },
  { key: 'approved', label: '审核通过' },
  { key: 'in_transit', label: '运输中' },
  { key: 'pending_receipt', label: '待签收' },
  { key: 'completed', label: '已完成' },
  { key: 'cancelled', label: '已取消' },
  { key: 'exception', label: '异常' },
];

const typeOptions = [
  { value: '调拨', label: '调拨' },
  { value: '退运', label: '退运' },
  { value: '维修', label: '维修' },
];

// ============================================================
// Utility Components
// ============================================================

function StatusBadge({ status }: { status: string }) {
  const config = transferStatusConfig[status] || transferStatusConfig.draft;
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: config.bg, color: config.text }}
    >
      {config.label}
    </span>
  );
}

function KPICard({ title, value, color }: { title: string; value: string | number; color: string }) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-center gap-4">
      <div className="w-1 h-10 rounded-full" style={{ backgroundColor: color }} />
      <div>
        <div className="text-xs text-neutral-textSecondary mb-1">{title}</div>
        <div className="text-xl font-bold font-number text-neutral-textPrimary">{value}</div>
      </div>
    </div>
  );
}

// ============================================================
// Filter Bar Component
// ============================================================

function FilterBar({
  filterCode,
  setFilterCode,
  filterFromSite,
  setFilterFromSite,
  filterToSite,
  setFilterToSite,
  filterType,
  setFilterType,
  filterDateRange,
  setFilterDateRange,
  sites,
}: {
  filterCode: string;
  setFilterCode: (v: string) => void;
  filterFromSite: string;
  setFilterFromSite: (v: string) => void;
  filterToSite: string;
  setFilterToSite: (v: string) => void;
  filterType: string;
  setFilterType: (v: string) => void;
  filterDateRange: string;
  setFilterDateRange: (v: string) => void;
  sites: { id: string; name: string }[];
}) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 mb-4">
      <div className="flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-[180px]">
          <label className="block text-xs text-neutral-textSecondary mb-1">调拨编号</label>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
            <input
              type="text"
              placeholder="请输入调拨编号"
              value={filterCode}
              onChange={(e) => setFilterCode(e.target.value)}
              className="w-full h-8 pl-8 pr-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus"
            />
          </div>
        </div>
        <div className="min-w-[150px]">
          <label className="block text-xs text-neutral-textSecondary mb-1">发起网点</label>
          <select
            value={filterFromSite}
            onChange={(e) => setFilterFromSite(e.target.value)}
            className="w-full h-8 px-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus bg-white"
          >
            <option value="">全部网点</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-[150px]">
          <label className="block text-xs text-neutral-textSecondary mb-1">目标网点</label>
          <select
            value={filterToSite}
            onChange={(e) => setFilterToSite(e.target.value)}
            className="w-full h-8 px-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus bg-white"
          >
            <option value="">全部网点</option>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
        <div className="min-w-[120px]">
          <label className="block text-xs text-neutral-textSecondary mb-1">调拨类型</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full h-8 px-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus bg-white"
          >
            <option value="">全部类型</option>
            {typeOptions.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>
        <div className="min-w-[160px]">
          <label className="block text-xs text-neutral-textSecondary mb-1">发起时间</label>
          <select
            value={filterDateRange}
            onChange={(e) => setFilterDateRange(e.target.value)}
            className="w-full h-8 px-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus bg-white"
          >
            <option value="">全部时间</option>
            <option value="today">今天</option>
            <option value="week">近7天</option>
            <option value="month">近30天</option>
          </select>
        </div>
        <button
          onClick={() => {
            setFilterCode('');
            setFilterFromSite('');
            setFilterToSite('');
            setFilterType('');
            setFilterDateRange('');
          }}
          className="h-8 px-3 text-xs text-neutral-textSecondary hover:text-primary hover:bg-primary-light rounded-md transition-colors"
        >
          重置筛选
        </button>
      </div>
    </div>
  );
}

// ============================================================
// Transfer Detail Drawer
// ============================================================

function TransferDetailDrawer({
  transfer,
  onClose,
  carriers,
  sites,
}: {
  transfer: TransferOrder | null;
  onClose: () => void;
  carriers: { id: string; code: string; type: string; status: string }[];
  sites: { id: string; name: string; lat: number; lng: number }[];
}) {
  const [activeTab, setActiveTab] = useState<'info' | 'carriers' | 'track' | 'logs'>('info');

  if (!transfer) return null;

  const statusSteps = [
    { key: 'draft', label: '草稿' },
    { key: 'pending_review', label: '提交审核' },
    { key: 'approved', label: '审核通过' },
    { key: 'in_transit', label: '运输中' },
    { key: 'pending_receipt', label: '待签收' },
    { key: 'completed', label: '已完成' },
  ];

  const currentStepIndex = statusSteps.findIndex((s) => s.key === transfer.status);
  const effectiveIndex = currentStepIndex >= 0 ? currentStepIndex : 0;

  const fromSite = sites.find((s) => s.id === transfer.fromSiteId);
  const toSite = sites.find((s) => s.id === transfer.toSiteId);

  const trackLogs = [
    { time: transfer.createdAt, event: '调拨单创建', operator: transfer.createdBy, detail: `创建调拨单 ${transfer.code}` },
    ...(transfer.status !== 'draft' ? [{ time: transfer.createdAt, event: '提交审核', operator: transfer.createdBy, detail: '提交调拨审核' }] : []),
    ...(transfer.status === 'approved' || transfer.status === 'in_transit' || transfer.status === 'pending_receipt' || transfer.status === 'completed' ? [{ time: transfer.createdAt, event: '审核通过', operator: '审核员', detail: '调拨审核已通过' }] : []),
    ...(transfer.status === 'in_transit' || transfer.status === 'pending_receipt' || transfer.status === 'completed' ? [{ time: transfer.actualDate || '', event: '开始运输', operator: transfer.driverName || '司机', detail: `车辆 ${transfer.vehicleName || '-'} 开始运输` }] : []),
    ...(transfer.status === 'completed' && transfer.completedDate ? [{ time: transfer.completedDate, event: '到货签收', operator: '收货员', detail: '调拨已完成签收' }] : []),
  ];

  const transferCarriers = carriers.filter((c) => transfer.carriers.includes(c.id));

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex justify-end"
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        {/* Drawer */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[720px] max-w-[90vw] h-full bg-white shadow-modal flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-semibold text-neutral-textPrimary">{transfer.code}</h2>
              <StatusBadge status={transfer.status} />
              <span
                className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
                style={{ backgroundColor: '#F1F5F9', color: '#475569' }}
              >
                {transfer.type}
              </span>
            </div>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          {/* Overview */}
          <div className="px-6 py-4 border-b border-neutral-border bg-neutral-background">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-primary" />
                <span className="text-sm font-medium text-neutral-textPrimary">{transfer.fromSiteName}</span>
              </div>
              <ArrowRight size={16} className="text-neutral-textTertiary" />
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-purple" />
                <span className="text-sm font-medium text-neutral-textPrimary">{transfer.toSiteName}</span>
              </div>
            </div>
            {/* Progress Stepper */}
            <div className="flex items-center gap-1">
              {statusSteps.map((step, idx) => (
                <div key={step.key} className="flex-1 flex items-center">
                  <div className="flex flex-col items-center flex-1">
                    <div
                      className={cn(
                        'w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-medium border-2',
                        idx < effectiveIndex && 'bg-success text-white border-success',
                        idx === effectiveIndex && 'bg-primary text-white border-primary',
                        idx > effectiveIndex && 'bg-white text-neutral-textTertiary border-neutral-border'
                      )}
                    >
                      {idx < effectiveIndex ? <CheckCircle size={14} /> : idx + 1}
                    </div>
                    <span
                      className={cn(
                        'text-[11px] mt-1',
                        idx <= effectiveIndex ? 'text-neutral-textPrimary font-medium' : 'text-neutral-textTertiary'
                      )}
                    >
                      {step.label}
                    </span>
                  </div>
                  {idx < statusSteps.length - 1 && (
                    <div
                      className={cn(
                        'h-0.5 w-full mb-5',
                        idx < effectiveIndex ? 'bg-success' : 'bg-neutral-border'
                      )}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-6 mt-3 text-xs text-neutral-textSecondary">
              <span>载具数量: <strong className="text-neutral-textPrimary">{transfer.carrierCount}</strong></span>
              <span>发起时间: <strong className="text-neutral-textPrimary">{transfer.createdAt}</strong></span>
              <span>期望到达: <strong className="text-neutral-textPrimary">{transfer.plannedDate}</strong></span>
              {transfer.completedDate && (
                <span>完成时间: <strong className="text-success">{transfer.completedDate}</strong></span>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-neutral-border px-6">
            {[
              { key: 'info' as const, label: '调拨信息', icon: FileText },
              { key: 'carriers' as const, label: '载具清单', icon: Package },
              { key: 'track' as const, label: '轨迹回放', icon: Truck },
              { key: 'logs' as const, label: '操作记录', icon: ClipboardCheck },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={cn(
                  'flex items-center gap-1.5 px-4 py-3 text-sm border-b-2 transition-colors',
                  activeTab === tab.key
                    ? 'border-primary text-primary font-medium'
                    : 'border-transparent text-neutral-textSecondary hover:text-neutral-textPrimary'
                )}
              >
                <tab.icon size={14} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="flex-1 overflow-y-auto p-6">
            <AnimatePresence mode="wait">
              {activeTab === 'info' && (
                <motion.div
                  key="info"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="grid grid-cols-2 gap-4">
                    <InfoRow label="调拨编号" value={transfer.code} />
                    <InfoRow label="调拨类型" value={transfer.type} />
                    <InfoRow label="调拨状态" value={<StatusBadge status={transfer.status} />} />
                    <InfoRow label="发起人" value={transfer.createdBy} />
                    <InfoRow label="发起时间" value={transfer.createdAt} />
                    <InfoRow label="发起网点" value={transfer.fromSiteName} />
                    <InfoRow label="目标网点" value={transfer.toSiteName} />
                    <InfoRow label="期望到达" value={transfer.plannedDate} />
                    <InfoRow label="调出组织" value={transfer.fromOrgName} />
                    <InfoRow label="调入组织" value={transfer.toOrgName} />
                    {transfer.vehicleName && <InfoRow label="运输车辆" value={transfer.vehicleName} />}
                    {transfer.driverName && <InfoRow label="司机" value={transfer.driverName} />}
                  </div>
                  {transfer.remark && (
                    <div className="mt-4">
                      <label className="block text-xs text-neutral-textSecondary mb-1">调拨备注</label>
                      <div className="p-3 bg-neutral-background rounded-md text-sm text-neutral-textPrimary">{transfer.remark}</div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'carriers' && (
                <motion.div
                  key="carriers"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                        <th className="text-left px-3 py-2 rounded-tl-md">载具编号</th>
                        <th className="text-left px-3 py-2">类型</th>
                        <th className="text-left px-3 py-2">状态</th>
                        <th className="text-left px-3 py-2 rounded-tr-md">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {transferCarriers.map((c, i) => (
                        <tr key={c.id} className={cn('border-b border-neutral-border', i % 2 === 1 && 'bg-neutral-background')}>
                          <td className="px-3 py-2.5 font-mono text-xs">{c.code}</td>
                          <td className="px-3 py-2.5">{c.type}</td>
                          <td className="px-3 py-2.5">
                            <StatusDot color={c.status === 'normal' ? '#10B981' : '#F59E0B'} label={c.status === 'normal' ? '正常' : c.status} />
                          </td>
                          <td className="px-3 py-2.5">
                            <button className="text-xs text-primary hover:underline">查看位置</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </motion.div>
              )}

              {activeTab === 'track' && (
                <motion.div
                  key="track"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <SimulatedRouteMap fromSite={fromSite} toSite={toSite} status={transfer.status} />
                  <div className="mt-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-2">运输时间轴</h4>
                    <div className="space-y-3">
                      {trackLogs.map((log, i) => (
                        <div key={i} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                            {i < trackLogs.length - 1 && <div className="w-0.5 h-8 bg-neutral-border" />}
                          </div>
                          <div>
                            <div className="text-xs text-neutral-textTertiary">{log.time}</div>
                            <div className="text-sm text-neutral-textPrimary font-medium">{log.event}</div>
                            <div className="text-xs text-neutral-textSecondary">{log.detail}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'logs' && (
                <motion.div
                  key="logs"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="space-y-0">
                    {trackLogs.map((log, i) => (
                      <div key={i} className="flex gap-4 py-3 border-b border-neutral-border last:border-0">
                        <div className="flex flex-col items-center pt-0.5">
                          <div className={cn('w-3 h-3 rounded-full', i === 0 ? 'bg-primary' : i === trackLogs.length - 1 ? 'bg-success' : 'bg-warning')} />
                          {i < trackLogs.length - 1 && <div className="w-0.5 flex-1 bg-neutral-border mt-1" />}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-sm font-medium text-neutral-textPrimary">{log.event}</span>
                            <span className="text-xs text-neutral-textTertiary">{log.time}</span>
                          </div>
                          <div className="text-xs text-neutral-textSecondary">{log.detail}</div>
                          <div className="text-xs text-neutral-textTertiary mt-1">操作人: {log.operator}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs text-neutral-textSecondary mb-1">{label}</label>
      <div className="text-sm text-neutral-textPrimary">{value}</div>
    </div>
  );
}

function StatusDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1 text-xs">
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {label}
    </span>
  );
}

// ============================================================
// Simulated Route Map
// ============================================================

function SimulatedRouteMap({
  fromSite,
  toSite,
  status,
}: {
  fromSite?: { lat: number; lng: number; name: string };
  toSite?: { lat: number; lng: number; name: string };
  status: string;
}) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const animRef = useRef<number | null>(null);

  useEffect(() => {
    if (status === 'completed') {
      setProgress(100);
    } else if (status === 'in_transit' || status === 'pending_receipt') {
      setProgress(60);
    } else {
      setProgress(0);
    }
  }, [status]);

  useEffect(() => {
    if (playing) {
      const animate = () => {
        setProgress((p) => {
          if (p >= 100) {
            setPlaying(false);
            return 100;
          }
          return p + 0.5;
        });
        animRef.current = requestAnimationFrame(animate);
      };
      animRef.current = requestAnimationFrame(animate);
    }
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [playing]);

  return (
    <div className="bg-neutral-background rounded-lg p-4">
      <div className="h-[200px] relative bg-[#F1F5F9] rounded-md overflow-hidden mb-3">
        {/* Simulated map background */}
        <svg width="100%" height="100%" viewBox="0 0 600 200" className="absolute inset-0">
          {/* Grid lines */}
          {Array.from({ length: 10 }).map((_, i) => (
            <g key={i}>
              <line x1={i * 60} y1={0} x2={i * 60} y2={200} stroke="#E2E8F0" strokeWidth={0.5} />
              <line x1={0} y1={i * 20} x2={600} y2={i * 20} stroke="#E2E8F0" strokeWidth={0.5} />
            </g>
          ))}
          {/* Route path */}
          {fromSite && toSite && (
            <>
              <line
                x1={80}
                y1={100}
                x2={520}
                y2={100}
                stroke="#BFDBFE"
                strokeWidth={4}
                strokeDasharray="8 4"
              />
              <line
                x1={80}
                y1={100}
                x2={80 + (4.4 * progress)}
                y2={100}
                stroke="#2563EB"
                strokeWidth={4}
              />
              {/* From marker */}
              <circle cx={80} cy={100} r={8} fill="#10B981" />
              <text x={80} y={125} textAnchor="middle" fontSize={10} fill="#0F172A">{fromSite.name}</text>
              {/* To marker */}
              <circle cx={520} cy={100} r={8} fill="#8B5CF6" />
              <text x={520} y={125} textAnchor="middle" fontSize={10} fill="#0F172A">{toSite.name}</text>
              {/* Progress dot */}
              {progress > 0 && progress < 100 && (
                <circle cx={80 + (4.4 * progress)} cy={100} r={6} fill="#2563EB">
                  <animate attributeName="r" values="6;8;6" dur="1.5s" repeatCount="indefinite" />
                </circle>
              )}
            </>
          )}
        </svg>
      </div>
      {/* Controls */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setPlaying(!playing)}
          className="w-8 h-8 flex items-center justify-center rounded-full bg-primary text-white hover:bg-primary-hover transition-colors"
        >
          {playing ? <Pause size={14} /> : <Play size={14} />}
        </button>
        <div className="flex-1 h-1.5 bg-neutral-border rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-xs text-neutral-textSecondary w-10 text-right">{Math.round(progress)}%</span>
        <button
          onClick={() => { setProgress(0); setPlaying(false); }}
          className="w-7 h-7 flex items-center justify-center rounded hover:bg-neutral-surface-elevated transition-colors"
        >
          <RotateCcw size={12} className="text-neutral-textSecondary" />
        </button>
        <div className="flex gap-1">
          {['1x', '2x', '4x'].map((speed) => (
            <button key={speed} className="px-1.5 py-0.5 text-[10px] rounded bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors">
              {speed}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Create Transfer Modal
// ============================================================

function CreateTransferModal({
  open,
  onClose,
  sites,
  carriers,
  vehicles,
}: {
  open: boolean;
  onClose: () => void;
  sites: { id: string; name: string }[];
  carriers: { id: string; code: string; name: string; type: string; siteId: string; siteName: string }[];
  vehicles: { id: string; plateNumber: string; driverName: string | null }[];
}) {
  const [step, setStep] = useState(0);
  const [selectedCarriers, setSelectedCarriers] = useState<string[]>([]);
  const [selectMethod, setSelectMethod] = useState<'list' | 'site' | 'project' | 'import'>('list');
  const [fromSite, setFromSite] = useState('');
  const [toSite, setToSite] = useState('');
  const [transferType, setTransferType] = useState<'normal' | 'urgent'>('normal');
  const [plannedDate, setPlannedDate] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [remark, setRemark] = useState('');

  const steps = ['选择载具', '配置调拨', '确认提交'];

  const reset = () => {
    setStep(0);
    setSelectedCarriers([]);
    setSelectMethod('list');
    setFromSite('');
    setToSite('');
    setTransferType('normal');
    setPlannedDate('');
    setSelectedVehicle('');
    setRemark('');
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const toggleCarrier = (id: string) => {
    setSelectedCarriers((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  };

  const filteredCarriers = useMemo(() => {
    if (selectMethod === 'list') {
      return fromSite ? carriers.filter((c) => c.siteId === fromSite) : carriers;
    }
    return carriers;
  }, [selectMethod, fromSite, carriers]);

  if (!open) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={handleClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[720px] max-w-[90vw] max-h-[85vh] bg-white rounded-xl shadow-modal flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <h2 className="text-lg font-semibold text-neutral-textPrimary">发起调拨</h2>
            <button onClick={handleClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          {/* Stepper */}
          <div className="px-6 py-4 border-b border-neutral-border">
            <div className="flex items-center gap-2">
              {steps.map((s, i) => (
                <div key={i} className="flex items-center flex-1">
                  <div className="flex items-center gap-2">
                    <div
                      className={cn(
                        'w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium',
                        i < step && 'bg-success text-white',
                        i === step && 'bg-primary text-white',
                        i > step && 'bg-neutral-border text-neutral-textTertiary'
                      )}
                    >
                      {i < step ? <CheckCircle size={14} /> : i + 1}
                    </div>
                    <span
                      className={cn(
                        'text-sm',
                        i <= step ? 'text-neutral-textPrimary font-medium' : 'text-neutral-textTertiary'
                      )}
                    >
                      {s}
                    </span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className={cn('h-0.5 flex-1 mx-2', i < step ? 'bg-success' : 'bg-neutral-border')} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <div className="flex-1 overflow-y-auto p-6 min-h-[300px]">
            <AnimatePresence mode="wait">
              {step === 0 && (
                <motion.div
                  key="step0"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                >
                  {/* Selection method tabs */}
                  <div className="flex gap-1 p-1 bg-neutral-background rounded-lg mb-4">
                    {[
                      { key: 'list' as const, label: '按载具选择', icon: Package },
                      { key: 'site' as const, label: '按网点选择', icon: Warehouse },
                      { key: 'project' as const, label: '按项目选择', icon: BarChart3 },
                      { key: 'import' as const, label: '批量导入', icon: Upload },
                    ].map((m) => (
                      <button
                        key={m.key}
                        onClick={() => setSelectMethod(m.key)}
                        className={cn(
                          'flex items-center gap-1.5 px-3 py-2 text-xs rounded-md transition-colors flex-1 justify-center',
                          selectMethod === m.key
                            ? 'bg-white text-primary shadow-sm'
                            : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                        )}
                      >
                        <m.icon size={14} />
                        {m.label}
                      </button>
                    ))}
                  </div>

                  {selectMethod === 'list' && (
                    <>
                      <div className="mb-3">
                        <select
                          value={fromSite}
                          onChange={(e) => setFromSite(e.target.value)}
                          className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary"
                        >
                          <option value="">选择出发网点筛选</option>
                          {sites.map((s) => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                          ))}
                        </select>
                      </div>
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                            <th className="text-left px-3 py-2 rounded-tl-md w-10">
                              <input type="checkbox" className="rounded" readOnly checked={false} />
                            </th>
                            <th className="text-left px-3 py-2">编号</th>
                            <th className="text-left px-3 py-2">名称</th>
                            <th className="text-left px-3 py-2">类型</th>
                            <th className="text-left px-3 py-2">所在网点</th>
                            <th className="text-left px-3 py-2 rounded-tr-md">状态</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredCarriers.slice(0, 10).map((c) => (
                            <tr
                              key={c.id}
                              className="border-b border-neutral-border hover:bg-primary-light transition-colors cursor-pointer"
                              onClick={() => toggleCarrier(c.id)}
                            >
                              <td className="px-3 py-2">
                                <input
                                  type="checkbox"
                                  className="rounded"
                                  checked={selectedCarriers.includes(c.id)}
                                  onChange={() => toggleCarrier(c.id)}
                                />
                              </td>
                              <td className="px-3 py-2 font-mono text-xs">{c.code}</td>
                              <td className="px-3 py-2">{c.name}</td>
                              <td className="px-3 py-2">{c.type}</td>
                              <td className="px-3 py-2 text-neutral-textSecondary">{c.siteName}</td>
                              <td className="px-3 py-2"><StatusDot color="#10B981" label="正常" /></td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </>
                  )}

                  {selectMethod === 'site' && (
                    <div className="space-y-2">
                      {sites.map((s) => {
                        const siteCarrierCount = carriers.filter((c) => c.siteId === s.id).length;
                        return (
                          <div
                            key={s.id}
                            className="flex items-center justify-between p-3 border border-neutral-border rounded-md hover:border-primary hover:bg-primary-light transition-colors cursor-pointer"
                            onClick={() => {
                              setFromSite(s.id);
                              const siteCarrierIds = carriers.filter((c) => c.siteId === s.id).map((c) => c.id);
                              setSelectedCarriers((prev) =>
                                prev.includes(siteCarrierIds[0]) ? prev.filter((id) => !siteCarrierIds.includes(id)) : [...prev, ...siteCarrierIds]
                              );
                            }}
                          >
                            <div className="flex items-center gap-3">
                              <Warehouse size={16} className="text-primary" />
                              <span className="text-sm text-neutral-textPrimary">{s.name}</span>
                            </div>
                            <span className="text-xs text-neutral-textSecondary">{siteCarrierCount} 个载具</span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {selectMethod === 'project' && (
                    <div className="text-center py-12 text-neutral-textSecondary">
                      <BarChart3 size={48} className="mx-auto mb-3 text-neutral-textTertiary" />
                      <p className="text-sm">选择项目后，将加载该项目下的所有载具</p>
                      <select className="mt-4 h-8 px-3 text-xs border border-neutral-border-strong rounded-md">
                        <option>华东汽车制造项目</option>
                        <option>南方物流配送项目</option>
                        <option>北方供应链项目</option>
                      </select>
                    </div>
                  )}

                  {selectMethod === 'import' && (
                    <div className="text-center py-8">
                      <div className="border-2 border-dashed border-neutral-border-strong rounded-lg p-8 mb-4 hover:border-primary hover:bg-primary-light transition-colors cursor-pointer">
                        <Upload size={36} className="mx-auto mb-3 text-neutral-textTertiary" />
                        <p className="text-sm text-neutral-textSecondary mb-1">点击上传或拖拽Excel文件到此处</p>
                        <p className="text-xs text-neutral-textTertiary">支持 .xlsx, .csv 格式</p>
                      </div>
                      <div className="text-left">
                        <label className="block text-xs text-neutral-textSecondary mb-1">或直接输入载具编号（每行一个）</label>
                        <textarea
                          className="w-full h-32 px-3 py-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus resize-none"
                          placeholder="CJ000001&#10;CJ000002&#10;CJ000003"
                        />
                      </div>
                    </div>
                  )}

                  {/* Selected count */}
                  {selectedCarriers.length > 0 && (
                    <div className="mt-4 p-3 bg-primary-light rounded-md flex items-center justify-between">
                      <span className="text-sm text-primary">已选择 <strong>{selectedCarriers.length}</strong> 个载具</span>
                      <button onClick={() => setSelectedCarriers([])} className="text-xs text-primary hover:underline">清空</button>
                    </div>
                  )}
                </motion.div>
              )}

              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-neutral-textSecondary mb-1">发起网点</label>
                      <select
                        value={fromSite}
                        onChange={(e) => setFromSite(e.target.value)}
                        className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary"
                      >
                        <option value="">选择网点</option>
                        {sites.map((s) => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs text-neutral-textSecondary mb-1">目标网点 <span className="text-danger">*</span></label>
                      <select
                        value={toSite}
                        onChange={(e) => setToSite(e.target.value)}
                        className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary"
                      >
                        <option value="">选择网点</option>
                        {sites.map((s) => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">调拨类型</label>
                    <div className="flex gap-3">
                      {[
                        { value: 'normal' as const, label: '普通调拨' },
                        { value: 'urgent' as const, label: '紧急调拨' },
                      ].map((t) => (
                        <label
                          key={t.value}
                          className={cn(
                            'flex items-center gap-2 px-4 py-2 border rounded-md cursor-pointer transition-colors',
                            transferType === t.value
                              ? 'border-primary bg-primary-light text-primary'
                              : 'border-neutral-border text-neutral-textSecondary hover:border-neutral-border-strong'
                          )}
                        >
                          <input
                            type="radio"
                            name="transferType"
                            value={t.value}
                            checked={transferType === t.value}
                            onChange={() => setTransferType(t.value)}
                            className="sr-only"
                          />
                          {t.label}
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">期望到达时间</label>
                    <input
                      type="datetime-local"
                      value={plannedDate}
                      onChange={(e) => setPlannedDate(e.target.value)}
                      className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">指派车辆</label>
                    <select
                      value={selectedVehicle}
                      onChange={(e) => setSelectedVehicle(e.target.value)}
                      className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary"
                    >
                      <option value="">选择车辆</option>
                      {vehicles.map((v) => (
                        <option key={v.id} value={v.id}>{v.plateNumber} {v.driverName ? `- ${v.driverName}` : ''}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">调拨备注</label>
                    <textarea
                      value={remark}
                      onChange={(e) => setRemark(e.target.value)}
                      className="w-full h-20 px-3 py-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary resize-none"
                      placeholder="请输入调拨备注..."
                    />
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                >
                  <div className="bg-neutral-background rounded-lg p-4 mb-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">调拨信息确认</h4>
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div className="text-neutral-textSecondary">载具数量: <strong className="text-neutral-textPrimary">{selectedCarriers.length}</strong></div>
                      <div className="text-neutral-textSecondary">调拨类型: <strong className="text-neutral-textPrimary">{transferType === 'urgent' ? '紧急调拨' : '普通调拨'}</strong></div>
                      <div className="text-neutral-textSecondary">发起网点: <strong className="text-neutral-textPrimary">{sites.find((s) => s.id === fromSite)?.name || '-'}</strong></div>
                      <div className="text-neutral-textSecondary">目标网点: <strong className="text-neutral-textPrimary">{sites.find((s) => s.id === toSite)?.name || '-'}</strong></div>
                      {plannedDate && <div className="text-neutral-textSecondary">期望到达: <strong className="text-neutral-textPrimary">{plannedDate}</strong></div>}
                      {selectedVehicle && <div className="text-neutral-textSecondary">运输车辆: <strong className="text-neutral-textPrimary">{vehicles.find((v) => v.id === selectedVehicle)?.plateNumber}</strong></div>}
                    </div>
                  </div>
                  <div className="bg-white border border-neutral-border rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-2">载具预览</h4>
                    <div className="space-y-1 max-h-[160px] overflow-y-auto">
                      {selectedCarriers.slice(0, 5).map((id) => {
                        const c = carriers.find((x) => x.id === id);
                        return c ? (
                          <div key={id} className="flex items-center gap-2 text-xs py-1">
                            <Package size={12} className="text-primary" />
                            <span className="font-mono">{c.code}</span>
                            <span className="text-neutral-textSecondary">{c.name}</span>
                          </div>
                        ) : null;
                      })}
                      {selectedCarriers.length > 5 && (
                        <div className="text-xs text-neutral-textSecondary">等 {selectedCarriers.length - 5} 个载具</div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-border">
            <button
              onClick={handleClose}
              className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors"
            >
              取消
            </button>
            <div className="flex gap-2">
              {step > 0 && (
                <button
                  onClick={() => setStep(step - 1)}
                  className="h-8 px-4 text-xs border border-neutral-border rounded-md hover:bg-neutral-background transition-colors"
                >
                  上一步
                </button>
              )}
              {step < steps.length - 1 ? (
                <button
                  onClick={() => setStep(step + 1)}
                  disabled={step === 0 && selectedCarriers.length === 0}
                  className={cn(
                    'h-8 px-4 text-xs rounded-md transition-colors',
                    step === 0 && selectedCarriers.length === 0
                      ? 'bg-neutral-border text-neutral-textTertiary cursor-not-allowed'
                      : 'bg-primary text-white hover:bg-primary-hover'
                  )}
                >
                  下一步
                </button>
              ) : (
                <button
                  onClick={handleClose}
                  className="h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors"
                >
                  确认提交
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Receipt Confirmation Modal
// ============================================================

function ReceiptModal({
  open,
  onClose,
  transfer,
  carriers,
}: {
  open: boolean;
  onClose: () => void;
  transfer: TransferOrder | null;
  carriers: { id: string; code: string; name: string; type: string }[];
}) {
  const [checkedCarriers, setCheckedCarriers] = useState<Record<string, boolean>>({});
  const [note, setNote] = useState('');
  const [hasException, setHasException] = useState(false);
  const [exceptionReason, setExceptionReason] = useState('');

  useEffect(() => {
    if (transfer) {
      const initial: Record<string, boolean> = {};
      transfer.carriers.forEach((id) => { initial[id] = true; });
      setCheckedCarriers(initial);
    }
  }, [transfer]);

  if (!open || !transfer) return null;

  const transferCarriers = carriers.filter((c) => transfer.carriers.includes(c.id));
  const receivedCount = Object.values(checkedCarriers).filter(Boolean).length;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[560px] max-w-[90vw] max-h-[85vh] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <h2 className="text-lg font-semibold text-neutral-textPrimary">到货签收</h2>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <div className="bg-neutral-background rounded-lg p-3 mb-4 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-textSecondary">调拨编号: <strong className="text-neutral-textPrimary">{transfer.code}</strong></span>
                <span className="text-neutral-textSecondary">载具: <strong className="text-neutral-textPrimary">{transfer.carrierCount}</strong></span>
              </div>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-medium text-neutral-textPrimary mb-2">载具签收确认</h4>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                    <th className="text-left px-3 py-2 rounded-tl-md w-10">签收</th>
                    <th className="text-left px-3 py-2">编号</th>
                    <th className="text-left px-3 py-2">名称</th>
                    <th className="text-left px-3 py-2 rounded-tr-md">类型</th>
                  </tr>
                </thead>
                <tbody>
                  {transferCarriers.map((c, i) => (
                    <tr key={c.id} className={cn('border-b border-neutral-border', i % 2 === 1 && 'bg-neutral-background')}>
                      <td className="px-3 py-2">
                        <input
                          type="checkbox"
                          className="rounded"
                          checked={checkedCarriers[c.id] || false}
                          onChange={(e) => setCheckedCarriers((prev) => ({ ...prev, [c.id]: e.target.checked }))}
                        />
                      </td>
                      <td className="px-3 py-2 font-mono text-xs">{c.code}</td>
                      <td className="px-3 py-2">{c.name}</td>
                      <td className="px-3 py-2">{c.type}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="mt-2 text-xs text-success">
                已勾选签收: {receivedCount} / {transfer.carrierCount}
              </div>
            </div>

            <div className="mb-4">
              <label className="flex items-center gap-2 text-sm text-neutral-textPrimary mb-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="rounded"
                  checked={hasException}
                  onChange={(e) => setHasException(e.target.checked)}
                />
                存在异常
              </label>
              {hasException && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <textarea
                    value={exceptionReason}
                    onChange={(e) => setExceptionReason(e.target.value)}
                    className="w-full h-20 px-3 py-2 text-xs border border-danger rounded-md focus:outline-none focus:shadow-error resize-none"
                    placeholder="请描述异常情况..."
                  />
                </motion.div>
              )}
            </div>

            <div>
              <label className="block text-xs text-neutral-textSecondary mb-1">签收备注</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full h-16 px-3 py-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus resize-none"
                placeholder="请输入签收备注..."
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-neutral-border">
            <button
              onClick={onClose}
              className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors"
            >
              取消
            </button>
            <button
              onClick={onClose}
              className="h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors"
            >
              确认签收
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Exception Handle Modal
// ============================================================

function ExceptionModal({
  open,
  onClose,
  transfer,
}: {
  open: boolean;
  onClose: () => void;
  transfer: TransferOrder | null;
}) {
  const [handleType, setHandleType] = useState<'cancel' | 'abort' | 'partial'>('cancel');
  const [reason, setReason] = useState('');

  if (!open || !transfer) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[480px] max-w-[90vw] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <div className="flex items-center gap-2">
              <AlertTriangle size={18} className="text-danger" />
              <h2 className="text-lg font-semibold text-neutral-textPrimary">异常处理</h2>
            </div>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          <div className="p-6">
            <div className="bg-danger-light rounded-lg p-3 mb-4 text-sm">
              <div className="flex justify-between">
                <span className="text-danger">调拨编号: <strong>{transfer.code}</strong></span>
                <StatusBadge status="exception" />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-xs text-neutral-textSecondary mb-2">处理方式</label>
              <div className="space-y-2">
                {[
                  { value: 'cancel' as const, label: '取消调拨', desc: '终止调拨，载具返回原网点' },
                  { value: 'abort' as const, label: '异常终止', desc: '标记为异常完成' },
                  { value: 'partial' as const, label: '部分完成', desc: '部分载具已送达，剩余重新调拨' },
                ].map((opt) => (
                  <label
                    key={opt.value}
                    className={cn(
                      'flex items-start gap-3 p-3 border rounded-md cursor-pointer transition-colors',
                      handleType === opt.value
                        ? 'border-primary bg-primary-light'
                        : 'border-neutral-border hover:border-neutral-border-strong'
                    )}
                  >
                    <input
                      type="radio"
                      name="handleType"
                      value={opt.value}
                      checked={handleType === opt.value}
                      onChange={() => setHandleType(opt.value)}
                      className="mt-0.5"
                    />
                    <div>
                      <div className="text-sm font-medium text-neutral-textPrimary">{opt.label}</div>
                      <div className="text-xs text-neutral-textSecondary">{opt.desc}</div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-neutral-textSecondary mb-1">处理说明</label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full h-20 px-3 py-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus resize-none"
                placeholder="请输入处理说明..."
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-neutral-border">
            <button
              onClick={onClose}
              className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors"
            >
              取消
            </button>
            <button
              onClick={onClose}
              className="h-8 px-4 text-xs bg-danger text-white rounded-md hover:bg-danger-hover transition-colors"
            >
              确认处理
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Track Playback Panel
// ============================================================

function TrackPlaybackPanel({
  open,
  onClose,
  transfer,
  sites,
}: {
  open: boolean;
  onClose: () => void;
  transfer: TransferOrder | null;
  sites: { id: string; name: string; lat: number; lng: number }[];
}) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const animRef = useRef<number | null>(null);

  useEffect(() => {
    if (playing) {
      const animate = () => {
        setProgress((p) => {
          if (p >= 100) { setPlaying(false); return 100; }
          return p + 0.3;
        });
        animRef.current = requestAnimationFrame(animate);
      };
      animRef.current = requestAnimationFrame(animate);
    }
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [playing]);

  if (!open || !transfer) return null;

  const fromSite = sites.find((s) => s.id === transfer.fromSiteId);
  const toSite = sites.find((s) => s.id === transfer.toSiteId);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.5)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[800px] max-w-[95vw] h-[500px] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-3 border-b border-neutral-border">
            <div>
              <h2 className="text-base font-semibold text-neutral-textPrimary">轨迹回放 - {transfer.code}</h2>
              <p className="text-xs text-neutral-textSecondary">{transfer.fromSiteName} → {transfer.toSiteName}</p>
            </div>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          <div className="flex-1 relative bg-[#F1F5F9]">
            <svg width="100%" height="100%" viewBox="0 0 760 400" className="absolute inset-0">
              {Array.from({ length: 15 }).map((_, i) => (
                <g key={i}>
                  <line x1={i * 50} y1={0} x2={i * 50} y2={400} stroke="#E2E8F0" strokeWidth={0.5} />
                  <line x1={0} y1={i * 26} x2={760} y2={i * 26} stroke="#E2E8F0" strokeWidth={0.5} />
                </g>
              ))}
              {fromSite && toSite && (
                <>
                  <defs>
                    <linearGradient id="trackGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#10B981" />
                      <stop offset="100%" stopColor="#8B5CF6" />
                    </linearGradient>
                  </defs>
                  <line x1={80} y1={200} x2={680} y2={200} stroke="#E2E8F0" strokeWidth={6} strokeLinecap="round" />
                  <line x1={80} y1={200} x2={80 + (6 * progress)} y2={200} stroke="url(#trackGradient)" strokeWidth={6} strokeLinecap="round" />
                  <circle cx={80} cy={200} r={10} fill="#10B981" stroke="white" strokeWidth={2} />
                  <text x={80} y={230} textAnchor="middle" fontSize={11} fill="#0F172A" fontWeight={500}>{fromSite.name}</text>
                  <text x={80} y={245} textAnchor="middle" fontSize={9} fill="#94A3B8">{transfer.createdAt}</text>
                  <circle cx={680} cy={200} r={10} fill="#8B5CF6" stroke="white" strokeWidth={2} />
                  <text x={680} y={230} textAnchor="middle" fontSize={11} fill="#0F172A" fontWeight={500}>{toSite.name}</text>
                  {transfer.completedDate && <text x={680} y={245} textAnchor="middle" fontSize={9} fill="#94A3B8">{transfer.completedDate}</text>}
                  {progress > 0 && progress < 100 && (
                    <g>
                      <circle cx={80 + (6 * progress)} cy={200} r={8} fill="#2563EB" stroke="white" strokeWidth={2} />
                      <circle cx={80 + (6 * progress)} cy={200} r={14} fill="none" stroke="#2563EB" strokeWidth={1} opacity={0.5}>
                        <animate attributeName="r" values="14;20;14" dur="1.5s" repeatCount="indefinite" />
                        <animate attributeName="opacity" values="0.5;0;0.5" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                    </g>
                  )}
                </>
              )}
            </svg>
          </div>

          <div className="px-6 py-3 border-t border-neutral-border bg-white">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setPlaying(!playing)}
                className="w-9 h-9 flex items-center justify-center rounded-full bg-primary text-white hover:bg-primary-hover transition-colors"
              >
                {playing ? <Pause size={16} /> : <Play size={16} />}
              </button>
              <div className="flex-1 h-2 bg-neutral-border rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress}%` }} />
              </div>
              <span className="text-xs text-neutral-textSecondary w-12 text-right font-number">{Math.round(progress)}%</span>
              <button onClick={() => { setProgress(0); setPlaying(false); }} className="w-8 h-8 flex items-center justify-center rounded hover:bg-neutral-background transition-colors">
                <RotateCcw size={14} className="text-neutral-textSecondary" />
              </button>
              <div className="flex gap-1">
                {['1x', '2x', '4x', '8x'].map((s) => (
                  <button key={s} className="px-2 py-1 text-[10px] rounded bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Review Modal
// ============================================================

function ReviewModal({
  open,
  onClose,
  transfer,
}: {
  open: boolean;
  onClose: () => void;
  transfer: TransferOrder | null;
}) {
  const [result, setResult] = useState<'approve' | 'reject'>('approve');
  const [note, setNote] = useState('');

  if (!open || !transfer) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[480px] max-w-[90vw] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <h2 className="text-lg font-semibold text-neutral-textPrimary">调拨审核</h2>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>
          <div className="p-6">
            <div className="bg-neutral-background rounded-lg p-3 mb-4 text-sm">
              <div className="grid grid-cols-2 gap-2">
                <div className="text-neutral-textSecondary">编号: <strong className="text-neutral-textPrimary">{transfer.code}</strong></div>
                <div className="text-neutral-textSecondary">载具: <strong className="text-neutral-textPrimary">{transfer.carrierCount}</strong></div>
                <div className="text-neutral-textSecondary">发起: <strong className="text-neutral-textPrimary">{transfer.fromSiteName}</strong></div>
                <div className="text-neutral-textSecondary">目标: <strong className="text-neutral-textPrimary">{transfer.toSiteName}</strong></div>
              </div>
            </div>
            <div className="mb-4">
              <label className="block text-xs text-neutral-textSecondary mb-2">审核意见</label>
              <div className="flex gap-3">
                <label
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 border rounded-md cursor-pointer transition-colors flex-1 justify-center',
                    result === 'approve' ? 'border-success bg-success-light text-success' : 'border-neutral-border'
                  )}
                >
                  <input type="radio" name="reviewResult" value="approve" checked={result === 'approve'} onChange={() => setResult('approve')} className="sr-only" />
                  <CheckCircle size={16} />
                  通过
                </label>
                <label
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 border rounded-md cursor-pointer transition-colors flex-1 justify-center',
                    result === 'reject' ? 'border-danger bg-danger-light text-danger' : 'border-neutral-border'
                  )}
                >
                  <input type="radio" name="reviewResult" value="reject" checked={result === 'reject'} onChange={() => setResult('reject')} className="sr-only" />
                  <XCircle size={16} />
                  驳回
                </label>
              </div>
            </div>
            <div>
              <label className="block text-xs text-neutral-textSecondary mb-1">审核备注</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full h-20 px-3 py-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus resize-none"
                placeholder="请输入审核备注..."
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-neutral-border">
            <button onClick={onClose} className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors">取消</button>
            <button onClick={onClose} className="h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors">确认</button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Main Page Component
// ============================================================

export default function TransferManagementPage() {
  const mockData = useMockData();
  const [activeStatusTab, setActiveStatusTab] = useState('all');
  const [filterCode, setFilterCode] = useState('');
  const [filterFromSite, setFilterFromSite] = useState('');
  const [filterToSite, setFilterToSite] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterDateRange, setFilterDateRange] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [detailTransfer, setDetailTransfer] = useState<TransferOrder | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [receiptTransfer, setReceiptTransfer] = useState<TransferOrder | null>(null);
  const [exceptionTransfer, setExceptionTransfer] = useState<TransferOrder | null>(null);
  const [trackTransfer, setTrackTransfer] = useState<TransferOrder | null>(null);
  const [reviewTransfer, setReviewTransfer] = useState<TransferOrder | null>(null);

  // Stats
  const stats = useMemo(() => {
    const all = mockData.transferOrders;
    return {
      total: all.length,
      pending_review: all.filter((t) => t.status === 'pending_review').length,
      in_transit: all.filter((t) => t.status === 'in_transit').length,
      pending_receipt: all.filter((t) => t.status === 'pending_receipt').length,
      completed: all.filter((t) => t.status === 'completed').length,
      exception: all.filter((t) => t.status === 'exception').length,
    };
  }, [mockData.transferOrders]);

  // Filtered data
  const filteredTransfers = useMemo(() => {
    let result = [...mockData.transferOrders];
    if (activeStatusTab !== 'all') {
      result = result.filter((t) => t.status === activeStatusTab);
    }
    if (filterCode) {
      result = result.filter((t) => t.code.toLowerCase().includes(filterCode.toLowerCase()));
    }
    if (filterFromSite) {
      result = result.filter((t) => t.fromSiteId === filterFromSite);
    }
    if (filterToSite) {
      result = result.filter((t) => t.toSiteId === filterToSite);
    }
    if (filterType) {
      result = result.filter((t) => t.type === filterType);
    }
    return result;
  }, [mockData.transferOrders, activeStatusTab, filterCode, filterFromSite, filterToSite, filterType]);

  // Pagination
  const totalPages = Math.ceil(filteredTransfers.length / pageSize);
  const paginatedTransfers = filteredTransfers.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  // Status count per tab
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { all: mockData.transferOrders.length };
    mockData.transferOrders.forEach((t) => {
      counts[t.status] = (counts[t.status] || 0) + 1;
    });
    return counts;
  }, [mockData.transferOrders]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  // Carrier map for detail drawer
  const carrierMap = useMemo(() => {
    return mockData.carriers.map((c) => ({
      id: c.id,
      code: c.code,
      name: c.name,
      type: c.type,
      status: c.status,
      siteId: c.siteId,
      siteName: c.siteName,
    }));
  }, [mockData.carriers]);

  const vehicleList = useMemo(() => {
    return mockData.vehicles.map((v) => ({
      id: v.id,
      plateNumber: v.plateNumber,
      driverName: v.driverName,
    }));
  }, [mockData.vehicles]);

  const siteList = useMemo(() => {
    return mockData.sites.map((s) => ({
      id: s.id,
      name: s.name,
      lat: s.lat,
      lng: s.lng,
    }));
  }, [mockData.sites]);

  return (
    <div className="animate-fade-in-up">
      {/* Page Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-neutral-textPrimary tracking-tight">调拨管理</h1>
          <p className="text-sm text-neutral-textSecondary mt-1">共 {mockData.transferOrders.length} 条调拨记录</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowCreateModal(true)}
            className="h-9 px-4 flex items-center gap-2 text-sm bg-primary text-white rounded-md hover:bg-primary-hover transition-colors shadow-sm"
          >
            <Plus size={16} />
            发起调拨
          </button>
          <button className="h-9 px-4 flex items-center gap-2 text-sm border border-neutral-border bg-white text-neutral-textPrimary rounded-md hover:bg-neutral-background transition-colors">
            <Download size={16} />
            导出
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-6 gap-4 mb-5">
        <KPICard title="本月调拨总数" value={stats.total} color="#2563EB" />
        <KPICard title="待审核" value={stats.pending_review} color="#F59E0B" />
        <KPICard title="运输中" value={stats.in_transit} color="#06B6D4" />
        <KPICard title="待签收" value={stats.pending_receipt} color="#8B5CF6" />
        <KPICard title="已完成" value={stats.completed} color="#10B981" />
        <KPICard title="异常" value={stats.exception} color="#EF4444" />
      </div>

      {/* Status Tabs */}
      <div className="bg-white rounded-lg shadow-card p-1 mb-4">
        <div className="flex gap-1">
          {statusTabList.map((tab) => (
            <button
              key={tab.key}
              onClick={() => { setActiveStatusTab(tab.key); setCurrentPage(1); }}
              className={cn(
                'relative flex items-center gap-1.5 px-4 py-2.5 text-sm rounded-md transition-colors font-medium',
                activeStatusTab === tab.key
                  ? 'bg-white text-primary shadow-sm'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary hover:bg-neutral-background'
              )}
            >
              {tab.label}
              {statusCounts[tab.key] !== undefined && (
                <span
                  className="min-w-[18px] h-[18px] px-1 inline-flex items-center justify-center rounded-full text-[11px] font-medium"
                  style={{
                    backgroundColor: activeStatusTab === tab.key
                      ? (tab.key === 'all' ? '#EFF6FF' : transferStatusConfig[tab.key]?.bg || '#F1F5F9')
                      : '#F1F5F9',
                    color: activeStatusTab === tab.key
                      ? (tab.key === 'all' ? '#2563EB' : transferStatusConfig[tab.key]?.text || '#475569')
                      : '#94A3B8',
                  }}
                >
                  {statusCounts[tab.key] || 0}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter Bar */}
      <FilterBar
        filterCode={filterCode}
        setFilterCode={setFilterCode}
        filterFromSite={filterFromSite}
        setFilterFromSite={setFilterFromSite}
        filterToSite={filterToSite}
        setFilterToSite={setFilterToSite}
        filterType={filterType}
        setFilterType={setFilterType}
        filterDateRange={filterDateRange}
        setFilterDateRange={setFilterDateRange}
        sites={mockData.sites.map((s) => ({ id: s.id, name: s.name }))}
      />

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                <th className="text-left px-4 py-2.5 w-10">
                  <input type="checkbox" className="rounded" readOnly checked={false} />
                </th>
                <th className="text-left px-4 py-2.5 font-medium">调拨编号</th>
                <th className="text-left px-4 py-2.5 font-medium">状态</th>
                <th className="text-left px-4 py-2.5 font-medium">类型</th>
                <th className="text-left px-4 py-2.5 font-medium">发起网点</th>
                <th className="text-left px-4 py-2.5 font-medium">目标网点</th>
                <th className="text-left px-4 py-2.5 font-medium">载具数量</th>
                <th className="text-left px-4 py-2.5 font-medium">发起人</th>
                <th className="text-left px-4 py-2.5 font-medium">发起时间</th>
                <th className="text-left px-4 py-2.5 font-medium">期望到达</th>
                <th className="text-left px-4 py-2.5 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedTransfers.map((transfer, index) => (
                <tr
                  key={transfer.id}
                  className={cn(
                    'border-b border-neutral-border hover:bg-primary-light transition-colors',
                    index % 2 === 1 && 'bg-[#F8FAFC]'
                  )}
                >
                  <td className="px-4 py-3">
                    <input type="checkbox" className="rounded" />
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => setDetailTransfer(transfer)}
                      className="font-mono text-xs text-primary hover:underline"
                    >
                      {transfer.code}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={transfer.status} />
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs text-neutral-textSecondary">{transfer.type}</span>
                  </td>
                  <td className="px-4 py-3 text-neutral-textPrimary">{transfer.fromSiteName}</td>
                  <td className="px-4 py-3 text-neutral-textPrimary">{transfer.toSiteName}</td>
                  <td className="px-4 py-3 font-number text-neutral-textPrimary">{transfer.carrierCount}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary">{transfer.createdBy}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary text-xs">{transfer.createdAt}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary text-xs">{transfer.plannedDate}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setDetailTransfer(transfer)}
                        className="p-1 rounded hover:bg-neutral-background transition-colors"
                        title="查看详情"
                      >
                        <Eye size={14} className="text-primary" />
                      </button>
                      {transfer.status === 'draft' && (
                        <button className="p-1 rounded hover:bg-neutral-background transition-colors" title="编辑">
                          <Edit3 size={14} className="text-warning" />
                        </button>
                      )}
                      {transfer.status === 'pending_review' && (
                        <button
                          onClick={() => setReviewTransfer(transfer)}
                          className="p-1 rounded hover:bg-neutral-background transition-colors"
                          title="审核"
                        >
                          <ClipboardCheck size={14} className="text-success" />
                        </button>
                      )}
                      {transfer.status === 'pending_receipt' && (
                        <button
                          onClick={() => setReceiptTransfer(transfer)}
                          className="p-1 rounded hover:bg-neutral-background transition-colors"
                          title="签收"
                        >
                          <CheckCircle size={14} className="text-success" />
                        </button>
                      )}
                      {(transfer.status === 'in_transit' || transfer.status === 'pending_receipt') && (
                        <button
                          onClick={() => setTrackTransfer(transfer)}
                          className="p-1 rounded hover:bg-neutral-background transition-colors"
                          title="轨迹回放"
                        >
                          <Play size={14} className="text-info" />
                        </button>
                      )}
                      {transfer.status === 'exception' && (
                        <button
                          onClick={() => setExceptionTransfer(transfer)}
                          className="p-1 rounded hover:bg-neutral-background transition-colors"
                          title="异常处理"
                        >
                          <AlertTriangle size={14} className="text-danger" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Empty state */}
        {paginatedTransfers.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <Package size={64} className="text-neutral-border mb-4" />
            <p className="text-neutral-textSecondary text-sm">暂无调拨记录</p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="mt-3 h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors"
            >
              发起调拨
            </button>
          </div>
        )}

        {/* Pagination */}
        {paginatedTransfers.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-neutral-border">
            <span className="text-xs text-neutral-textSecondary">
              共 {filteredTransfers.length} 条，第 {currentPage}/{totalPages} 页
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-background disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={cn(
                    'w-8 h-8 flex items-center justify-center rounded-md text-xs transition-colors',
                    currentPage === page
                      ? 'bg-primary text-white'
                      : 'border border-neutral-border hover:bg-neutral-background text-neutral-textSecondary'
                  )}
                >
                  {page}
                </button>
              ))}
              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-background disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      <AnimatePresence>
        {detailTransfer && (
          <TransferDetailDrawer
            transfer={detailTransfer}
            onClose={() => setDetailTransfer(null)}
            carriers={carrierMap}
            sites={siteList}
          />
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <CreateTransferModal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        sites={mockData.sites.map((s) => ({ id: s.id, name: s.name }))}
        carriers={carrierMap}
        vehicles={vehicleList}
      />

      {/* Receipt Modal */}
      <ReceiptModal
        open={!!receiptTransfer}
        onClose={() => setReceiptTransfer(null)}
        transfer={receiptTransfer}
        carriers={mockData.carriers.map((c) => ({ id: c.id, code: c.code, name: c.name, type: c.type }))}
      />

      {/* Exception Modal */}
      <ExceptionModal
        open={!!exceptionTransfer}
        onClose={() => setExceptionTransfer(null)}
        transfer={exceptionTransfer}
      />

      {/* Track Playback Panel */}
      <TrackPlaybackPanel
        open={!!trackTransfer}
        onClose={() => setTrackTransfer(null)}
        transfer={trackTransfer}
        sites={siteList}
      />

      {/* Review Modal */}
      <ReviewModal
        open={!!reviewTransfer}
        onClose={() => setReviewTransfer(null)}
        transfer={reviewTransfer}
      />
    </div>
  );
}
