import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DeviceStatusData {
  name: string;
  value: number;
  color: string;
}

interface MessageTypeData {
  type: string;
  count: number;
}

interface HourlyData {
  hour: string;
  messages: number;
  onlineRate: number;
}

const deviceStatusData: DeviceStatusData[] = [
  { name: '在线', value: 342, color: '#10B981' },
  { name: '离线', value: 58, color: '#94A3B8' },
  { name: '告警', value: 23, color: '#EF4444' },
  { name: '休眠', value: 17, color: '#F59E0B' },
];

const messageTypeData: MessageTypeData[] = [
  { type: '位置', count: 4820 },
  { type: '状态', count: 3150 },
  { type: '告警', count: 890 },
  { type: '心跳', count: 12560 },
];

const hourlyData: HourlyData[] = [
  { hour: '00:00', messages: 420, onlineRate: 96.2 },
  { hour: '01:00', messages: 380, onlineRate: 95.8 },
  { hour: '02:00', messages: 350, onlineRate: 95.5 },
  { hour: '03:00', messages: 310, onlineRate: 95.1 },
  { hour: '04:00', messages: 290, onlineRate: 94.8 },
  { hour: '05:00', messages: 340, onlineRate: 95.3 },
  { hour: '06:00', messages: 450, onlineRate: 96.0 },
  { hour: '07:00', messages: 620, onlineRate: 96.5 },
  { hour: '08:00', messages: 780, onlineRate: 97.1 },
  { hour: '09:00', messages: 850, onlineRate: 97.3 },
  { hour: '10:00', messages: 920, onlineRate: 97.5 },
  { hour: '11:00', messages: 880, onlineRate: 97.2 },
  { hour: '12:00', messages: 760, onlineRate: 96.8 },
  { hour: '13:00', messages: 810, onlineRate: 97.0 },
  { hour: '14:00', messages: 940, onlineRate: 97.6 },
  { hour: '15:00', messages: 980, onlineRate: 97.8 },
  { hour: '16:00', messages: 920, onlineRate: 97.4 },
  { hour: '17:00', messages: 860, onlineRate: 97.1 },
  { hour: '18:00', messages: 790, onlineRate: 96.9 },
  { hour: '19:00', messages: 720, onlineRate: 96.6 },
  { hour: '20:00', messages: 650, onlineRate: 96.4 },
  { hour: '21:00', messages: 580, onlineRate: 96.1 },
  { hour: '22:00', messages: 510, onlineRate: 96.0 },
  { hour: '23:00', messages: 460, onlineRate: 95.9 },
];

export default function IotOverviewTab() {
  return (
    <div className="space-y-5">
      {/* Row 1: Pie + Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary">
              设备状态分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={deviceStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {deviceStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary">
              消息类型分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={messageTypeData} barSize={40}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="type"
                  tick={{ fontSize: 12, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                />
                <YAxis
                  tick={{ fontSize: 12, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Row 2: Area + Line */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary">
              24小时消息流量趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <AreaChart data={hourlyData}>
                <defs>
                  <linearGradient id="msgGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563EB" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="hour"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  interval={3}
                />
                <YAxis
                  tick={{ fontSize: 12, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="messages"
                  stroke="#2563EB"
                  strokeWidth={2}
                  fill="url(#msgGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary">
              设备在线率趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="hour"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  interval={3}
                />
                <YAxis
                  tick={{ fontSize: 12, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  domain={[90, 100]}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E2E8F0',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                  formatter={(value: number) => [`${value}%`, '在线率']}
                />
                <Line
                  type="monotone"
                  dataKey="onlineRate"
                  stroke="#10B981"
                  strokeWidth={2}
                  dot={{ r: 3, fill: '#10B981' }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
