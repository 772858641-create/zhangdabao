import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Box,
  History,
  GitCompare,
  Copy,
  AlertTriangle,
  ArrowRight,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  type ThingModel,
  type ModelVersion,
} from './iot-thingmodel/types';
import ThingModelList from './iot-thingmodel/ThingModelList';
import ThingModelDetail from './iot-thingmodel/ThingModelDetail';

export default function IotThingModelTab() {
  const [selectedModel, setSelectedModel] = useState<ThingModel | null>(null);
  const [versionDialogOpen, setVersionDialogOpen] = useState(false);
  const [compareDialogOpen, setCompareDialogOpen] = useState(false);
  const [selectedVersions, setSelectedVersions] = useState<[string, string] | null>(null);
  const [copyDialogOpen, setCopyDialogOpen] = useState(false);
  const [copyTargetName, setCopyTargetName] = useState('');
  const [deprecateDialogOpen, setDeprecateDialogOpen] = useState(false);

  const handleSelectModel = (model: ThingModel) => {
    setSelectedModel(model);
  };

  const handleCopyModel = (model: ThingModel) => {
    setSelectedModel(model);
    setCopyDialogOpen(true);
  };

  const handleDeprecateModel = (model: ThingModel) => {
    setSelectedModel(model);
    setDeprecateDialogOpen(true);
  };

  const handleCopyConfirm = () => {
    if (selectedModel && copyTargetName.trim()) {
      setCopyDialogOpen(false);
      setCopyTargetName('');
    }
  };

  const handleDeprecateConfirm = () => {
    if (selectedModel) {
      setDeprecateDialogOpen(false);
      setSelectedModel(null);
    }
  };

  const handleCompareVersions = (v1: string, v2: string) => {
    setSelectedVersions([v1, v2]);
    setCompareDialogOpen(true);
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* ─── Main Content: List + Detail ─── */}
      <div className="flex gap-4 flex-1 min-h-0">
        {/* ─── Left: List (60%) ─── */}
        <div className="w-[60%] flex flex-col min-h-0">
          <ThingModelList
            selectedModel={selectedModel}
            onSelectModel={handleSelectModel}
            onCopyModel={handleCopyModel}
            onDeprecateModel={handleDeprecateModel}
          />
        </div>

        {/* ─── Right: Detail Panel (40%) ─── */}
        <div className="w-[40%] min-h-0">
          <AnimatePresence mode="wait">
            {selectedModel ? (
              <ThingModelDetail
                key={selectedModel.id}
                model={selectedModel}
                onClose={() => setSelectedModel(null)}
                onOpenVersionDialog={() => setVersionDialogOpen(true)}
              />
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="h-full flex items-center justify-center"
              >
                <Card className="bg-neutral-surface border-neutral-border w-full h-full flex items-center justify-center">
                  <CardContent className="flex flex-col items-center text-neutral-textTertiary py-12">
                    <Box size={48} className="mb-4 opacity-30" />
                    <p className="text-sm">点击左侧物模型查看详情</p>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ─── Version History Dialog ─── */}
      <Dialog open={versionDialogOpen} onOpenChange={setVersionDialogOpen}>
        <DialogContent className="max-w-lg bg-neutral-surface border-neutral-border max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary flex items-center gap-2">
              <History size={16} />
              版本历史 — {selectedModel?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {selectedModel?.versionHistory.map((ver, idx, arr) => (
              <VersionHistoryItem
                key={ver.version}
                ver={ver}
                idx={idx}
                total={selectedModel.versionHistory.length}
                nextVersion={idx < arr.length - 1 ? arr[idx + 1].version : undefined}
                onCompare={handleCompareVersions}
              />
            ))}
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => setVersionDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Version Compare Dialog ─── */}
      <Dialog open={compareDialogOpen} onOpenChange={setCompareDialogOpen}>
        <DialogContent className="max-w-md bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary flex items-center gap-2">
              <GitCompare size={16} />
              版本对比
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            {selectedVersions && (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-neutral-background rounded-md p-3 border border-neutral-border text-center">
                    <span className="text-sm font-mono font-semibold text-primary">{selectedVersions[0]}</span>
                    <p className="text-[10px] text-neutral-textTertiary mt-1">新版本</p>
                  </div>
                  <ArrowRight size={16} className="text-neutral-textTertiary flex-shrink-0" />
                  <div className="flex-1 bg-neutral-background rounded-md p-3 border border-neutral-border text-center">
                    <span className="text-sm font-mono font-semibold text-neutral-textSecondary">{selectedVersions[1]}</span>
                    <p className="text-[10px] text-neutral-textTertiary mt-1">旧版本</p>
                  </div>
                </div>
                <div className="border border-neutral-border rounded-lg p-3 bg-neutral-background">
                  <h4 className="text-xs font-semibold text-neutral-textSecondary mb-2">变更说明</h4>
                  <div className="space-y-1">
                    {selectedModel?.versionHistory
                      .find((v) => v.version === selectedVersions[0])
                      ?.changelog.split('，')
                      .map((item, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs text-neutral-textPrimary">
                          <span className="text-success mt-0.5">+</span>
                          <span>{item.trim()}</span>
                        </div>
                      ))}
                  </div>
                </div>
                <div className="border border-neutral-border rounded-lg p-3 bg-neutral-background">
                  <h4 className="text-xs font-semibold text-neutral-textSecondary mb-2">兼容设备差异</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedModel?.versionHistory
                      .find((v) => v.version === selectedVersions[0])
                      ?.compatibleDevices.map((dev) => (
                        <span key={dev} className="text-[10px] px-1.5 py-0.5 bg-success-light border border-success rounded text-success">
                          {dev}
                        </span>
                      ))}
                    {selectedModel?.versionHistory
                      .find((v) => v.version === selectedVersions[1])
                      ?.compatibleDevices.filter(
                        (dev) =>
                          !selectedModel?.versionHistory
                            .find((v) => v.version === selectedVersions[0])
                            ?.compatibleDevices.includes(dev)
                      )
                      .map((dev) => (
                        <span key={dev} className="text-[10px] px-1.5 py-0.5 bg-danger-light border border-danger rounded text-danger">
                          {dev} (移除)
                        </span>
                      ))}
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => setCompareDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Copy Dialog ─── */}
      <Dialog open={copyDialogOpen} onOpenChange={setCopyDialogOpen}>
        <DialogContent className="max-w-sm bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary flex items-center gap-2">
              <Copy size={16} />
              复制物模型
            </DialogTitle>
          </DialogHeader>
          <div className="py-3 space-y-3">
            <p className="text-xs text-neutral-textSecondary">
              复制 <span className="font-medium text-neutral-textPrimary">{selectedModel?.name}</span> 的所有定义到一个新物模型
            </p>
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1 block">新物模型名称</label>
              <Input
                value={copyTargetName}
                onChange={(e) => setCopyTargetName(e.target.value)}
                placeholder="请输入新物模型名称"
              />
            </div>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => { setCopyDialogOpen(false); setCopyTargetName(''); }}>
              取消
            </Button>
            <Button size="sm" className="h-8 text-xs" disabled={!copyTargetName.trim()} onClick={handleCopyConfirm}>
              确认复制
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Deprecate Dialog ─── */}
      <Dialog open={deprecateDialogOpen} onOpenChange={setDeprecateDialogOpen}>
        <DialogContent className="max-w-sm bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-danger flex items-center gap-2">
              <AlertTriangle size={16} />
              废弃物模型
            </DialogTitle>
          </DialogHeader>
          <div className="py-3">
            <p className="text-xs text-neutral-textSecondary">
              确认废弃 <span className="font-medium text-neutral-textPrimary">{selectedModel?.name}</span>？
            </p>
            <p className="text-xs text-neutral-textTertiary mt-2">
              废弃后该物模型将不再允许新设备绑定，已有设备不受影响。
            </p>
          </div>
          <DialogFooter>
            <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => setDeprecateDialogOpen(false)}>
              取消
            </Button>
            <Button size="sm" variant="destructive" className="h-8 text-xs" onClick={handleDeprecateConfirm}>
              确认废弃
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function VersionHistoryItem({
  ver,
  idx,
  total,
  nextVersion,
  onCompare,
}: {
  ver: ModelVersion;
  idx: number;
  total: number;
  nextVersion?: string;
  onCompare: (v1: string, v2: string) => void;
}) {
  return (
    <div className="border border-neutral-border rounded-lg p-3 bg-neutral-background">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="text-sm font-mono font-semibold text-primary">{ver.version}</span>
          {idx === 0 && <Badge className="text-[10px] h-5 bg-success-light text-success border-success">当前</Badge>}
        </div>
        <span className="text-xs text-neutral-textTertiary">{ver.releaseTime}</span>
      </div>
      <p className="text-xs text-neutral-textSecondary mb-2">{ver.changelog}</p>
      <div className="flex flex-wrap gap-1">
        {ver.compatibleDevices.map((dev) => (
          <span key={dev} className="text-[10px] px-1.5 py-0.5 bg-neutral-surface border border-neutral-border rounded text-neutral-textSecondary">
            {dev}
          </span>
        ))}
      </div>
      {total > 1 && nextVersion && (
        <button
          className="mt-2 flex items-center gap-1 text-[10px] text-primary hover:underline"
          onClick={() => onCompare(ver.version, nextVersion)}
        >
          <GitCompare size={10} />
          与 {nextVersion} 对比
        </button>
      )}
    </div>
  );
}
