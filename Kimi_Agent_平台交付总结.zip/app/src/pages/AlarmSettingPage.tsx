import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell,
  VolumeX,
  Volume2,
  Save,
  RotateCcw,
  SlidersHorizontal,
  TrendingUp,
  RotateCcwIcon,
  CheckCircle2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type SettingsTab = 'threshold' | 'notification' | 'escalation' | 'silence';

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const NAV_ITEMS: { key: SettingsTab; label: string; icon: React.ElementType }[] = [
  { key: 'threshold', label: '阈值配置', icon: SlidersHorizontal },
  { key: 'notification', label: '通知方式', icon: Bell },
  { key: 'escalation', label: '升级规则', icon: TrendingUp },
  { key: 'silence', label: '报警静默', icon: VolumeX },
];

// ------------------------------------------------------------------
// Reusable Components
// ------------------------------------------------------------------
function Tag({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

function SectionCard({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('bg-white rounded-lg shadow-card p-6', className)}>
      <h3 className="text-base font-semibold text-[#0F172A] mb-4">{title}</h3>
      {children}
    </div>
  );
}

function FormRow({ label, children, required, description }: { label: string; children: React.ReactNode; required?: boolean; description?: string }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 py-3 border-b border-[#F1F5F9] last:border-0">
      <label className="w-44 text-sm text-[#475569] flex-shrink-0 sm:text-right">
        {label}
        {required && <span className="text-[#EF4444] ml-0.5">*</span>}
      </label>
      <div className="flex-1">
        <div className="flex items-center gap-3 flex-wrap">{children}</div>
        {description && <p className="text-xs text-[#94A3B8] mt-1">{description}</p>}
      </div>
    </div>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn('relative w-9 h-5 rounded-full transition-colors flex-shrink-0', checked ? 'bg-[#2563EB]' : 'bg-[#CBD5E1]')}
    >
      <span className={cn('absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform', checked ? 'translate-x-4' : 'translate-x-0')} />
    </button>
  );
}

function NumberInput({ value, onChange, min, max, suffix, step }: { value: number; onChange: (v: number) => void; min?: number; max?: number; suffix?: string; step?: number }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        step={step || 1}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-9 w-28 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
      />
      {suffix && <span className="text-sm text-[#475569]">{suffix}</span>}
    </div>
  );
}

function TimeInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <input
      type="time"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-9 w-28 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
    />
  );
}

function SelectInput({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-9 min-w-[120px] px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
    >
      {options.map((opt) => (
        <option key={opt} value={opt}>{opt}</option>
      ))}
    </select>
  );
}

// ------------------------------------------------------------------
// Tab 1: Threshold Configuration
// ------------------------------------------------------------------
function ThresholdTab({ settings, update }: { settings: Record<string, unknown>; update: (key: string, value: unknown) => void }) {
  const get = <T,>(key: string, defaultValue: T): T => (settings[key] !== undefined ? settings[key] as T : defaultValue);

  return (
    <div className="space-y-6">
      {/* Device Offline */}
      <SectionCard title="设备离线阈值">
        <FormRow label="4G设备离线判定" description="4G设备超过该时长未上报数据即判定为离线">
          <NumberInput
            value={get('offline4G', 30)}
            onChange={(v) => update('offline4G', v)}
            suffix="分钟"
            min={5}
          />
        </FormRow>
        <FormRow label="蓝牙设备离线判定" description="蓝牙设备超过该时长未上报数据即判定为离线">
          <NumberInput
            value={get('offlineBluetooth', 60)}
            onChange={(v) => update('offlineBluetooth', v)}
            suffix="分钟"
            min={5}
          />
        </FormRow>
      </SectionCard>

      {/* Tag Separation */}
      <SectionCard title="标签分离阈值">
        <FormRow label="RSSI阈值" description="信号强度低于此值视为标签分离风险">
          <div className="flex items-center gap-2">
            <input
              type="range"
              min={-100}
              max={-50}
              value={get('rssiThreshold', -75)}
              onChange={(e) => update('rssiThreshold', Number(e.target.value))}
              className="w-40 h-2 bg-[#E2E8F0] rounded-lg appearance-none cursor-pointer accent-[#2563EB]"
            />
            <span className="text-sm text-[#0F172A] font-medium w-16">{get('rssiThreshold', -75)} dBm</span>
          </div>
        </FormRow>
        <FormRow label="信号弱持续时长" description="信号弱持续超过该时长触发标签分离报警">
          <NumberInput
            value={get('weakSignalDuration', 30)}
            onChange={(v) => update('weakSignalDuration', v)}
            suffix="分钟"
            min={1}
          />
        </FormRow>
      </SectionCard>

      {/* Transit Timeout */}
      <SectionCard title="在途超时阈值">
        <FormRow label="预计到达时间倍数" description="实际运输时间超过预计时间的倍数时触发报警">
          <NumberInput
            value={get('transitMultiplier', 2)}
            onChange={(v) => update('transitMultiplier', v)}
            suffix="倍"
            min={1}
            step={0.5}
          />
        </FormRow>
        <FormRow label="最大调拨时长" description="调拨超过该天数强制触发超时报警">
          <NumberInput
            value={get('maxTransferDays', 30)}
            onChange={(v) => update('maxTransferDays', v)}
            suffix="天"
            min={1}
          />
        </FormRow>
      </SectionCard>

      {/* Stagnation */}
      <SectionCard title="呆滞阈值">
        <FormRow label="默认呆滞天数" description="载具停留超过该天数触发呆滞报警">
          <div className="flex items-center gap-3 flex-wrap">
            {['7', '15', '30', '60'].map((days) => (
              <button
                key={days}
                onClick={() => update('stagnationDays', Number(days))}
                className={cn(
                  'h-9 px-4 rounded-md text-sm border transition-colors',
                  get('stagnationDays', 30) === Number(days)
                    ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                    : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                )}
              >
                {days}天
              </button>
            ))}
            <div className="flex items-center gap-2">
              <span className="text-sm text-[#475569]">自定义：</span>
              <NumberInput
                value={get('customStagnationDays', 0)}
                onChange={(v) => update('customStagnationDays', v)}
                suffix="天"
                min={1}
              />
            </div>
          </div>
        </FormRow>
      </SectionCard>

      {/* Temperature */}
      <SectionCard title="温度报警阈值">
        <FormRow label="高温阈值" description="温度超过此值触发高温报警">
          <NumberInput
            value={get('tempHigh', 45)}
            onChange={(v) => update('tempHigh', v)}
            suffix="°C"
          />
        </FormRow>
        <FormRow label="低温阈值" description="温度低于此值触发低温报警">
          <NumberInput
            value={get('tempLow', -10)}
            onChange={(v) => update('tempLow', v)}
            suffix="°C"
          />
        </FormRow>
      </SectionCard>

      {/* Cycle Timeout */}
      <SectionCard title="流转循环超期阈值">
        <FormRow label="循环超期倍数" description="实际循环时长超过标准时长的倍数时触发报警">
          <div className="flex items-center gap-3">
            <NumberInput
              value={get('cycleMultiplier', 1.2)}
              onChange={(v) => update('cycleMultiplier', v)}
              suffix="倍"
              min={1}
              step={0.1}
            />
            <span className="text-xs text-[#94A3B8]">自定义倍数，默认1.2倍</span>
          </div>
        </FormRow>
      </SectionCard>

      {/* Vehicle Fence */}
      <SectionCard title="车辆围栏联动">
        <FormRow label="停留时长阈值" description="车辆在围栏外停留超过该时长触发报警">
          <NumberInput
            value={get('stayDuration', 5)}
            onChange={(v) => update('stayDuration', v)}
            suffix="分钟"
            min={1}
          />
        </FormRow>
        <FormRow label="超时未判定自动报警" description="报警产生后超过该时长未处理自动升级">
          <NumberInput
            value={get('autoAlarmHours', 1)}
            onChange={(v) => update('autoAlarmHours', v)}
            suffix="小时"
            min={0.5}
            step={0.5}
          />
        </FormRow>
      </SectionCard>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 2: Notification Methods
// ------------------------------------------------------------------
function NotificationTab({ settings, update }: { settings: Record<string, unknown>; update: (key: string, value: unknown) => void }) {
  const get = <T,>(key: string, defaultValue: T): T => (settings[key] !== undefined ? settings[key] as T : defaultValue);

  return (
    <div className="space-y-6">
      {/* In-site Message */}
      <SectionCard title="站内消息通知">
        <FormRow label="启用状态" description="系统内部消息通知中心推送">
          <Switch checked={get('inSiteEnabled', true)} onChange={(v) => update('inSiteEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('inSiteEnabled', true) ? '已启用' : '已停用'}</span>
        </FormRow>
      </SectionCard>

      {/* SMS */}
      <SectionCard title="短信通知">
        <FormRow label="启用状态" description="通过短信向接收人发送报警通知">
          <Switch checked={get('smsEnabled', false)} onChange={(v) => update('smsEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('smsEnabled', false) ? '已启用' : '已停用'}</span>
        </FormRow>
        {get('smsEnabled', false) && (
          <FormRow label="短信模板" description="编辑短信通知模板内容">
            <textarea
              value={get('smsTemplate', '【载具平台】您的{{载具编号}}触发{{报警类型}}报警，请及时处理。')}
              onChange={(e) => update('smsTemplate', e.target.value)}
              className="w-full max-w-md h-20 px-3 py-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus resize-none"
            />
          </FormRow>
        )}
      </SectionCard>

      {/* Email */}
      <SectionCard title="邮件通知">
        <FormRow label="启用状态" description="通过邮件向接收人发送报警通知">
          <Switch checked={get('emailEnabled', false)} onChange={(v) => update('emailEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('emailEnabled', false) ? '已启用' : '已停用'}</span>
        </FormRow>
        {get('emailEnabled', false) && (
          <FormRow label="邮件模板" description="编辑邮件通知标题及正文模板">
            <div className="space-y-2 w-full max-w-md">
              <input
                type="text"
                value={get('emailSubject', '【报警通知】{{报警类型}} - {{载具编号}}')}
                onChange={(e) => update('emailSubject', e.target.value)}
                placeholder="邮件标题模板"
                className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
              />
              <textarea
                value={get('emailBody', '您好，\n\n您的载具 {{载具编号}} 于 {{报警时间}} 触发 {{报警类型}} 报警，请及时处理。\n\n详情请联系系统管理员。')}
                onChange={(e) => update('emailBody', e.target.value)}
                placeholder="邮件正文模板"
                className="w-full h-24 px-3 py-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus resize-none"
              />
            </div>
          </FormRow>
        )}
      </SectionCard>

      {/* DingTalk / WeCom */}
      <SectionCard title="钉钉 / 企业微信通知">
        <FormRow label="钉钉通知" description="通过钉钉群机器人推送报警消息">
          <Switch checked={get('dingtalkEnabled', false)} onChange={(v) => update('dingtalkEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('dingtalkEnabled', false) ? '已启用' : '已停用'}</span>
        </FormRow>
        <FormRow label="企业微信通知" description="通过企业微信群机器人推送报警消息">
          <Switch checked={get('wecomEnabled', false)} onChange={(v) => update('wecomEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('wecomEnabled', false) ? '已启用' : '已停用'}</span>
        </FormRow>
      </SectionCard>

      {/* Notification Period */}
      <SectionCard title="通知时段">
        <FormRow label="通知时段模式" description="选择报警通知的发送时段策略">
          <div className="flex gap-3 flex-wrap">
            {['工作时间', '全天候', '自定义时段'].map((mode) => (
              <button
                key={mode}
                onClick={() => update('notifyPeriod', mode)}
                className={cn(
                  'h-9 px-4 rounded-md text-sm border transition-colors',
                  get('notifyPeriod', '工作时间') === mode
                    ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                    : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                )}
              >
                {mode}
              </button>
            ))}
          </div>
        </FormRow>
        {get<string>('notifyPeriod', '工作时间') === '自定义时段' && (
          <FormRow label="自定义时段" description="设置通知有效时间段">
            <div className="flex items-center gap-2">
              <TimeInput value={get('customStart', '09:00')} onChange={(v) => update('customStart', v)} />
              <span className="text-sm text-[#475569]">至</span>
              <TimeInput value={get('customEnd', '18:00')} onChange={(v) => update('customEnd', v)} />
            </div>
          </FormRow>
        )}
      </SectionCard>

      {/* Night Do Not Disturb */}
      <SectionCard title="夜间免打扰">
        <FormRow label="启用免打扰" description="免打扰时段内不发送通知">
          <Switch checked={get('dndEnabled', true)} onChange={(v) => update('dndEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('dndEnabled', true) ? '已启用' : '已停用'}</span>
        </FormRow>
        {get('dndEnabled', true) && (
          <FormRow label="免打扰时段" description="设置夜间不发送通知的时间段">
            <div className="flex items-center gap-2">
              <TimeInput value={get('dndStart', '22:00')} onChange={(v) => update('dndStart', v)} />
              <span className="text-sm text-[#475569]">至</span>
              <TimeInput value={get('dndEnd', '08:00')} onChange={(v) => update('dndEnd', v)} />
            </div>
          </FormRow>
        )}
      </SectionCard>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 3: Escalation Rules
// ------------------------------------------------------------------
function EscalationTab({ settings, update }: { settings: Record<string, unknown>; update: (key: string, value: unknown) => void }) {
  const get = <T,>(key: string, defaultValue: T): T => (settings[key] !== undefined ? settings[key] as T : defaultValue);

  return (
    <div className="space-y-6">
      {/* Level 1 -> Level 2 */}
      <SectionCard title="一级报警升级">
        <FormRow label="自动升级时长" description="一级报警超过该时长未处理自动升级为二级">
          <NumberInput
            value={get('level1EscalateHours', 2)}
            onChange={(v) => update('level1EscalateHours', v)}
            suffix="小时"
            min={0.5}
            step={0.5}
          />
        </FormRow>
      </SectionCard>

      {/* Level 2 -> Level 3 */}
      <SectionCard title="二级报警升级">
        <FormRow label="自动升级时长" description="二级报警超过该时长未处理自动升级为三级">
          <NumberInput
            value={get('level2EscalateHours', 4)}
            onChange={(v) => update('level2EscalateHours', v)}
            suffix="小时"
            min={0.5}
            step={0.5}
          />
        </FormRow>
      </SectionCard>

      {/* Escalation Target */}
      <SectionCard title="升级通知对象">
        <FormRow label="通知对象" description="报警升级后通知的接收人">
          <div className="flex gap-3 flex-wrap">
            {['直接上级', '部门主管', '项目管理员'].map((target) => {
              const targets = get('escalateTargets', ['直接上级'] as string[]);
              const isSelected = targets.includes(target);
              return (
                <label key={target} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => {
                      if (isSelected) {
                        update('escalateTargets', targets.filter((t) => t !== target));
                      } else {
                        update('escalateTargets', [...targets, target]);
                      }
                    }}
                    className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]"
                  />
                  <span className="text-sm text-[#475569]">{target}</span>
                </label>
              );
            })}
          </div>
        </FormRow>
        <FormRow label="升级通知方式" description="升级时采用的通知渠道">
          <div className="flex gap-3 flex-wrap">
            {['站内信+短信', '仅站内信'].map((method) => (
              <button
                key={method}
                onClick={() => update('escalateMethod', method)}
                className={cn(
                  'h-9 px-4 rounded-md text-sm border transition-colors',
                  get('escalateMethod', '站内信+短信') === method
                    ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                    : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                )}
              >
                {method}
              </button>
            ))}
          </div>
        </FormRow>
      </SectionCard>

      {/* Holiday Delay */}
      <SectionCard title="节假日延迟升级">
        <FormRow label="节假日延迟" description="节假日期间暂停自动升级计时">
          <Switch checked={get('holidayDelay', false)} onChange={(v) => update('holidayDelay', v)} />
          <span className="text-sm text-[#475569]">{get('holidayDelay', false) ? '已启用' : '已停用'}</span>
        </FormRow>
      </SectionCard>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 4: Alarm Silence
// ------------------------------------------------------------------
function SilenceTab({ settings, update }: { settings: Record<string, unknown>; update: (key: string, value: unknown) => void }) {
  const get = <T,>(key: string, defaultValue: T): T => (settings[key] !== undefined ? settings[key] as T : defaultValue);

  const alarmTypes = ['设备离线', '标签分离', '在途超时', '温度报警', '车辆围栏', '呆滞报警', '循环超期'];

  const silenceStrategies: Record<string, { period: string; start: string; end: string }> = get('typeSilence', {
    '设备离线': { period: '夜间', start: '22:00', end: '06:00' },
    '标签分离': { period: '全天', start: '00:00', end: '23:59' },
  });

  const handleToggleTypeSilence = (type: string) => {
    const current = { ...silenceStrategies };
    if (current[type]) {
      delete current[type];
    } else {
      current[type] = { period: '夜间', start: '22:00', end: '08:00' };
    }
    update('typeSilence', current);
  };

  const orgs = ['云载科技（总部）', '上海运营中心', '广州仓储中心', '北方供应链管理'];
  const orgSilence: Record<string, boolean> = get('orgSilence', {
    '云载科技（总部）': false,
    '上海运营中心': true,
    '广州仓储中心': false,
    '北方供应链管理': true,
  });

  return (
    <div className="space-y-6">
      {/* Global Silence */}
      <SectionCard title="全局静默时段">
        <FormRow label="启用全局静默" description="设置全系统统一的报警静默时段">
          <Switch checked={get('globalSilenceEnabled', true)} onChange={(v) => update('globalSilenceEnabled', v)} />
          <span className="text-sm text-[#475569]">{get('globalSilenceEnabled', true) ? '已启用' : '已停用'}</span>
        </FormRow>
        {get('globalSilenceEnabled', true) && (
          <FormRow label="静默时段" description="该时段内所有报警进入静默处理">
            <div className="flex items-center gap-2">
              <TimeInput value={get('globalSilenceStart', '22:00')} onChange={(v) => update('globalSilenceStart', v)} />
              <span className="text-sm text-[#475569]">至</span>
              <TimeInput value={get('globalSilenceEnd', '08:00')} onChange={(v) => update('globalSilenceEnd', v)} />
            </div>
          </FormRow>
        )}
      </SectionCard>

      {/* By Alarm Type */}
      <SectionCard title="按报警类型静默">
        <FormRow label="报警类型静默" description="配置特定报警类型在特定时段静默">
          <div className="w-full">
            <div className="flex flex-wrap gap-2 mb-3">
              {alarmTypes.map((type) => (
                <button
                  key={type}
                  onClick={() => handleToggleTypeSilence(type)}
                  className={cn(
                    'h-8 px-3 rounded-md text-sm border transition-colors flex items-center gap-1.5',
                    silenceStrategies[type]
                      ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                      : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                  )}
                >
                  {silenceStrategies[type] ? <VolumeX size={13} /> : <Volume2 size={13} />}
                  {type}
                </button>
              ))}
            </div>
            {Object.entries(silenceStrategies).map(([type, cfg]) => (
              <div key={type} className="flex items-center gap-3 py-2 px-3 bg-[#F8FAFC] rounded-md mb-2">
                <span className="text-sm text-[#0F172A] font-medium w-24">{type}</span>
                <SelectInput
                  value={cfg.period}
                  onChange={(v) => {
                    const next = { ...silenceStrategies, [type]: { ...cfg, period: v } };
                    update('typeSilence', next);
                  }}
                  options={['夜间', '白天', '全天', '自定义']}
                />
                {cfg.period === '自定义' && (
                  <>
                    <TimeInput
                      value={cfg.start}
                      onChange={(v) => {
                        const next = { ...silenceStrategies, [type]: { ...cfg, start: v } };
                        update('typeSilence', next);
                      }}
                    />
                    <span className="text-sm text-[#475569]">至</span>
                    <TimeInput
                      value={cfg.end}
                      onChange={(v) => {
                        const next = { ...silenceStrategies, [type]: { ...cfg, end: v } };
                        update('typeSilence', next);
                      }}
                    />
                  </>
                )}
                <span className="text-xs text-[#94A3B8]">
                  {cfg.period === '夜间' && '22:00 - 08:00'}
                  {cfg.period === '白天' && '08:00 - 22:00'}
                  {cfg.period === '全天' && '00:00 - 23:59'}
                  {cfg.period === '自定义' && `${cfg.start} - ${cfg.end}`}
                </span>
              </div>
            ))}
            {Object.keys(silenceStrategies).length === 0 && (
              <p className="text-sm text-[#94A3B8] py-2">暂未配置报警类型静默策略，点击上方按钮添加</p>
            )}
          </div>
        </FormRow>
      </SectionCard>

      {/* By Organization */}
      <SectionCard title="按组织静默">
        <FormRow label="组织静默策略" description="不同组织可配置不同的静默策略">
          <div className="w-full space-y-2">
            {orgs.map((org) => (
              <div key={org} className="flex items-center justify-between py-2 px-3 bg-[#F8FAFC] rounded-md">
                <span className="text-sm text-[#0F172A]">{org}</span>
                <div className="flex items-center gap-3">
                  <Switch
                    checked={orgSilence[org] || false}
                    onChange={(v) => {
                      const next = { ...orgSilence, [org]: v };
                      update('orgSilence', next);
                    }}
                  />
                  <span className="text-sm text-[#475569] w-16">
                    {orgSilence[org] ? (
                      <span className="flex items-center gap-1 text-[#F59E0B]"><VolumeX size={13} /> 静默中</span>
                    ) : (
                      <span className="flex items-center gap-1 text-[#10B981]"><Volume2 size={13} /> 正常通知</span>
                    )}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </FormRow>
      </SectionCard>

      {/* Silence Handling */}
      <SectionCard title="静默期间报警处理">
        <FormRow label="处理方式" description="静默期间产生报警的处理策略">
          <div className="flex gap-3 flex-wrap">
            {['暂存', '直接丢弃', '仅记录不通知'].map((method) => (
              <button
                key={method}
                onClick={() => update('silenceHandle', method)}
                className={cn(
                  'h-9 px-4 rounded-md text-sm border transition-colors',
                  get('silenceHandle', '暂存') === method
                    ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                    : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                )}
              >
                {method}
              </button>
            ))}
          </div>
        </FormRow>
        <FormRow label="说明">
          <div className="text-sm text-[#475569] bg-[#F8FAFC] rounded-md p-3 max-w-lg">
            <p className="mb-1"><strong className="text-[#0F172A]">暂存</strong>：报警进入待处理队列，静默结束后批量通知</p>
            <p className="mb-1"><strong className="text-[#0F172A]">直接丢弃</strong>：静默期间报警不产生任何记录</p>
            <p><strong className="text-[#0F172A]">仅记录不通知</strong>：报警记录到日志但不做任何通知推送</p>
          </div>
        </FormRow>
      </SectionCard>
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function AlarmSettingPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('threshold');
  const [settings, setSettings] = useState<Record<string, unknown>>({
    // Threshold defaults
    offline4G: 30,
    offlineBluetooth: 60,
    rssiThreshold: -75,
    weakSignalDuration: 30,
    transitMultiplier: 2,
    maxTransferDays: 30,
    stagnationDays: 30,
    customStagnationDays: 0,
    tempHigh: 45,
    tempLow: -10,
    cycleMultiplier: 1.2,
    stayDuration: 5,
    autoAlarmHours: 1,
    // Notification defaults
    inSiteEnabled: true,
    smsEnabled: false,
    smsTemplate: '【载具平台】您的{{载具编号}}触发{{报警类型}}报警，请及时处理。',
    emailEnabled: false,
    emailSubject: '【报警通知】{{报警类型}} - {{载具编号}}',
    emailBody: '您好，\n\n您的载具 {{载具编号}} 于 {{报警时间}} 触发 {{报警类型}} 报警，请及时处理。\n\n详情请联系系统管理员。',
    dingtalkEnabled: false,
    wecomEnabled: false,
    notifyPeriod: '工作时间',
    customStart: '09:00',
    customEnd: '18:00',
    dndEnabled: true,
    dndStart: '22:00',
    dndEnd: '08:00',
    // Escalation defaults
    level1EscalateHours: 2,
    level2EscalateHours: 4,
    escalateTargets: ['直接上级'],
    escalateMethod: '站内信+短信',
    holidayDelay: false,
    // Silence defaults
    globalSilenceEnabled: true,
    globalSilenceStart: '22:00',
    globalSilenceEnd: '08:00',
    typeSilence: {
      '设备离线': { period: '夜间', start: '22:00', end: '06:00' },
      '标签分离': { period: '全天', start: '00:00', end: '23:59' },
    },
    orgSilence: {
      '云载科技（总部）': false,
      '上海运营中心': true,
      '广州仓储中心': false,
      '北方供应链管理': true,
    },
    silenceHandle: '暂存',
  });

  const [saving, setSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const update = (key: string, value: unknown) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2500);
    }, 800);
  };

  const handleReset = () => {
    if (confirm('确定恢复当前Tab的所有配置为默认值？')) {
      setSettings({
        offline4G: 30,
        offlineBluetooth: 60,
        rssiThreshold: -75,
        weakSignalDuration: 30,
        transitMultiplier: 2,
        maxTransferDays: 30,
        stagnationDays: 30,
        customStagnationDays: 0,
        tempHigh: 45,
        tempLow: -10,
        cycleMultiplier: 1.2,
        stayDuration: 5,
        autoAlarmHours: 1,
        inSiteEnabled: true,
        smsEnabled: false,
        smsTemplate: '【载具平台】您的{{载具编号}}触发{{报警类型}}报警，请及时处理。',
        emailEnabled: false,
        emailSubject: '【报警通知】{{报警类型}} - {{载具编号}}',
        emailBody: '您好，\n\n您的载具 {{载具编号}} 于 {{报警时间}} 触发 {{报警类型}} 报警，请及时处理。\n\n详情请联系系统管理员。',
        dingtalkEnabled: false,
        wecomEnabled: false,
        notifyPeriod: '工作时间',
        customStart: '09:00',
        customEnd: '18:00',
        dndEnabled: true,
        dndStart: '22:00',
        dndEnd: '08:00',
        level1EscalateHours: 2,
        level2EscalateHours: 4,
        escalateTargets: ['直接上级'],
        escalateMethod: '站内信+短信',
        holidayDelay: false,
        globalSilenceEnabled: true,
        globalSilenceStart: '22:00',
        globalSilenceEnd: '08:00',
        typeSilence: {
          '设备离线': { period: '夜间', start: '22:00', end: '06:00' },
          '标签分离': { period: '全天', start: '00:00', end: '23:59' },
        },
        orgSilence: {
          '云载科技（总部）': false,
          '上海运营中心': true,
          '广州仓储中心': false,
          '北方供应链管理': true,
        },
        silenceHandle: '暂存',
      });
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2500);
    }
  };

  return (
    <div className="space-y-5 relative">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-[#0F172A]">报警设置</h1>
          <Tag label="全局配置" color="#2563EB" bg="#EFF6FF" />
        </div>
      </div>

      {/* Two-column layout: nav + content */}
      <div className="flex gap-5">
        {/* Left Navigation */}
        <nav className="w-[200px] bg-white rounded-lg shadow-card flex-shrink-0 self-start overflow-hidden">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors text-left',
                activeTab === item.key
                  ? 'bg-[#EFF6FF] text-[#2563EB]'
                  : 'text-[#475569] hover:bg-[#F8FAFC]'
              )}
              style={activeTab === item.key ? { borderLeft: '3px solid #2563EB' } : { borderLeft: '3px solid transparent' }}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Content */}
        <div className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="space-y-6"
            >
              {activeTab === 'threshold' && <ThresholdTab settings={settings} update={update} />}
              {activeTab === 'notification' && <NotificationTab settings={settings} update={update} />}
              {activeTab === 'escalation' && <EscalationTab settings={settings} update={update} />}
              {activeTab === 'silence' && <SilenceTab settings={settings} update={update} />}

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  onClick={handleReset}
                  className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors"
                >
                  <RotateCcw size={14} /> 重置为默认
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className={cn(
                    'h-9 px-4 rounded-md text-white text-sm flex items-center gap-2 transition-colors',
                    saving ? 'bg-[#93C5FD] cursor-not-allowed' : 'bg-[#2563EB] hover:bg-[#1D4ED8]'
                  )}
                >
                  {saving ? (
                    <>
                      <RotateCcwIcon size={14} className="animate-spin" /> 保存中...
                    </>
                  ) : (
                    <>
                      <Save size={14} /> 保存配置
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Success Toast */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: 20, x: '-50%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed bottom-8 left-1/2 z-50"
          >
            <div className="flex items-center gap-2 bg-[#0F172A] text-white px-4 py-2.5 rounded-lg shadow-lg">
              <CheckCircle2 size={16} className="text-[#10B981]" />
              <span className="text-sm">配置保存成功</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
