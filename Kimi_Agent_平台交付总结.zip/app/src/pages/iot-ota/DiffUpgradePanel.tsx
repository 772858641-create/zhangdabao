import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  ArrowUpDown, Power, RotateCcw, ChevronRight,
  Clock, Search, } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  diffPackages, powerProtectRecords, rollbackRecords,
  formatBytes,
} from './types';

export default function DiffUpgradePanel() {
  const [rollbackSearch, setRollbackSearch] = useState('');

  const filteredRollbacks = useMemo(() => {
    return rollbackRecords.filter((r) =>
      !rollbackSearch.trim() ||
      r.deviceId.toLowerCase().includes(rollbackSearch.toLowerCase()) ||
      r.rollbackReason.includes(rollbackSearch)
    );
  }, [rollbackSearch]);

  return (
    <div className="space-y-4">
      {/* Diff Packages */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <ArrowUpDown size={15} className="text-primary" />
            差分包管理
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-border bg-neutral-background">
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">版本范围</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">设备类型</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">全量包大小</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">差分包大小</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">压缩比</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">节省流量</th>
              </tr>
            </thead>
            <tbody>
              {diffPackages.map((dp, idx) => (
                <motion.tr
                  key={dp.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.04 }}
                  className="border-b border-neutral-border hover:bg-neutral-background transition-colors"
                >
                  <td className="px-4 py-2.5 text-xs font-mono text-neutral-textPrimary">
                    {dp.versionFrom} <ChevronRight size={10} className="inline text-neutral-textTertiary" /> {dp.versionTo}
                  </td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary">{dp.deviceType}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-mono">{formatBytes(dp.fullSize)}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-mono">{formatBytes(dp.diffSize)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-neutral-background rounded-full overflow-hidden border border-neutral-border">
                        <div
                          className="h-full bg-success rounded-full"
                          style={{ width: `${dp.compressionRatio}%` }}
                        />
                      </div>
                      <span className="text-xs font-number text-success font-medium">{dp.compressionRatio.toFixed(1)}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-success font-mono">{formatBytes(dp.fullSize - dp.diffSize)}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Power Protection & Rollback */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Power Protection Records */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Power size={15} className="text-warning" />
              断电保护记录
              <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {powerProtectRecords.length} 条</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
            {powerProtectRecords.map((pp, idx) => (
              <motion.div
                key={pp.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.03 }}
                className="bg-neutral-background rounded-md p-3 border border-neutral-border"
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-neutral-textPrimary">{pp.deviceId}</span>
                    <span className="text-xs text-neutral-textSecondary">{pp.deviceName}</span>
                  </div>
                  <Badge
                    className={cn(
                      'text-xs',
                      pp.resumeSuccess
                        ? 'bg-success-light text-success border-success'
                        : 'bg-danger-light text-danger border-danger'
                    )}
                  >
                    {pp.resumeSuccess ? '续传成功' : '回滚'}
                  </Badge>
                </div>
                <p className="text-xs text-neutral-textSecondary mb-1">{pp.detail}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-neutral-textTertiary font-mono flex items-center gap-1">
                    <Clock size={10} /> {pp.powerOffTime}
                  </span>
                  {pp.rollbackCount > 0 && (
                    <span className="text-xs text-danger font-number">回滚 {pp.rollbackCount} 次</span>
                  )}
                </div>
              </motion.div>
            ))}
          </CardContent>
        </Card>

        {/* Rollback Records */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <RotateCcw size={15} className="text-danger" />
              升级回滚记录
              <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {filteredRollbacks.length} 条</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
              <Input
                placeholder="搜索设备ID、回滚原因..."
                value={rollbackSearch}
                onChange={(e) => setRollbackSearch(e.target.value)}
                className="pl-8 h-8 bg-neutral-background border-neutral-border text-xs"
              />
            </div>
            <div className="space-y-2 max-h-[340px] overflow-y-auto pr-1">
              {filteredRollbacks.map((rb, idx) => (
                <motion.div
                  key={rb.id}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.04 }}
                  className="bg-neutral-background rounded-md p-3 border border-neutral-border"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-mono text-neutral-textPrimary">{rb.deviceId}</span>
                    <span className="text-xs text-neutral-textTertiary font-mono">{rb.rollbackTime}</span>
                  </div>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <Badge variant="outline" className="text-xs text-neutral-textSecondary border-neutral-border">{rb.originalVersion}</Badge>
                    <RotateCcw size={10} className="text-danger" />
                    <Badge variant="outline" className="text-xs text-primary border-primary-border">{rb.upgradeVersion}</Badge>
                  </div>
                  <p className="text-xs text-neutral-textSecondary">{rb.rollbackReason}</p>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
