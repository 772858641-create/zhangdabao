import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import {
  PieChart, Pie, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell,
} from 'recharts';
import {
  AlertTriangle, Activity,
  BarChart as BarChartIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  upgradeStatusDistribution, weeklyUpgradeTrend,
  failReasonDistribution, upgradeDevices,
  getDeviceStatusBadge,
} from './types';

export default function UpgradeMonitoring() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Status Distribution Pie */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <PieChart />
              升级状态分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={upgradeStatusDistribution}
                  cx="50%"
                  cy="45%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={false}
                >
                  {upgradeStatusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--neutral-surface)',
                    border: '1px solid var(--neutral-border)',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Weekly Trend Bar */}
        <Card className="bg-neutral-surface border-neutral-border lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <BarChartIcon size={15} className="text-primary" />
              近7天升级趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={weeklyUpgradeTrend} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="day"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                />
                <YAxis
                  yAxisId="left"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                />
                <YAxis
                  yAxisId="right"
                  orientation="right"
                  tick={{ fontSize: 11, fill: '#475569' }}
                  axisLine={{ stroke: '#E2E8F0' }}
                  domain={[90, 100]}
                  tickFormatter={(v) => `${v}%`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--neutral-surface)',
                    border: '1px solid var(--neutral-border)',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar yAxisId="left" dataKey="upgradedDevices" name="升级设备数" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="successRate" name="成功率(%)" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Fail Reason Pie */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <AlertTriangle size={15} className="text-danger" />
              升级失败原因分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={failReasonDistribution}
                  cx="50%"
                  cy="45%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={3}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={false}
                >
                  {failReasonDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'var(--neutral-surface)',
                    border: '1px solid var(--neutral-border)',
                    borderRadius: '6px',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Realtime Device Status */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Activity size={15} className="text-primary" />
              实时升级设备状态
              <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {upgradeDevices.length} 台</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-neutral-border bg-neutral-background">
                  <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2">设备ID</th>
                  <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2">设备名称</th>
                  <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2">目标版本</th>
                  <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2">状态</th>
                  <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2">进度</th>
                </tr>
              </thead>
              <tbody>
                {upgradeDevices.slice(0, 8).map((dev) => (
                  <tr key={dev.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                    <td className="px-4 py-1.5 text-xs font-mono text-neutral-textPrimary">{dev.deviceId}</td>
                    <td className="px-4 py-1.5 text-xs text-neutral-textSecondary">{dev.deviceName}</td>
                    <td className="px-4 py-1.5 text-xs font-mono text-primary">{dev.targetVersion}</td>
                    <td className="px-4 py-1.5">{getDeviceStatusBadge(dev.status)}</td>
                    <td className="px-4 py-1.5">
                      <div className="flex items-center gap-1.5">
                        <div className="w-10 h-1 bg-neutral-background rounded-full overflow-hidden border border-neutral-border">
                          <div
                            className={cn(
                              'h-full rounded-full',
                              dev.status === 'verify_failed' ? 'bg-danger' : dev.progress === 100 ? 'bg-success' : 'bg-primary'
                            )}
                            style={{ width: `${dev.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-neutral-textSecondary font-number">{dev.progress}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {upgradeDevices.length > 8 && (
              <p className="text-xs text-neutral-textTertiary text-center py-2">
                还有 {upgradeDevices.length - 8} 台设备...
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
