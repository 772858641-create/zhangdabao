import { Badge } from '@/components/ui/badge';
import {
  Clock, CheckCircle, XCircle,
  Download, Zap, RefreshCw,
} from 'lucide-react';

// ==================== Types ====================
export interface FirmwareVersion {
  id: string;
  version: string;
  deviceType: string;
  releaseDate: string;
  fileSize: string;
  fileSizeBytes: number;
  changelog: string;
  compatibleBatches: string;
  sha256: string;
  status: 'released' | 'gray' | 'revoked';
}

export interface GrayBatch {
  batchNum: number;
  deviceCount: number;
  observeHours: number;
  description: string;
}

export interface GrayStrategy {
  id: string;
  firmwareVersion: string;
  deviceType: string;
  currentBatch: number;
  totalBatches: number;
  upgradedDevices: number;
  totalDevices: number;
  observeStatus: 'observing' | 'passed' | 'failed' | 'waiting';
  autoProgress: boolean;
  batches: GrayBatch[];
}

export interface UpgradeTask {
  id: string;
  taskName: string;
  targetVersion: string;
  targetDevices: number;
  completed: number;
  failed: number;
  running: number;
  progress: number;
  status: 'pending' | 'running' | 'completed' | 'paused';
  timeWindow: string;
  startTime: string;
}

export interface PowerProtectRecord {
  id: string;
  deviceId: string;
  deviceName: string;
  powerOffTime: string;
  resumeSuccess: boolean;
  rollbackCount: number;
  detail: string;
}

export interface RollbackRecord {
  id: string;
  deviceId: string;
  originalVersion: string;
  upgradeVersion: string;
  rollbackReason: string;
  rollbackTime: string;
}

export interface DiffPackage {
  id: string;
  versionFrom: string;
  versionTo: string;
  deviceType: string;
  fullSize: number;
  diffSize: number;
  compressionRatio: number;
}

export interface UpgradeDevice {
  id: string;
  deviceId: string;
  deviceName: string;
  status: 'downloading' | 'download_done' | 'installing' | 'install_done' | 'rebooting' | 'verify_failed';
  progress: number;
  targetVersion: string;
}

// ==================== Mock Data ====================
export const deviceTypes = ['车载终端', '定位器', '传感器', '网关', '摄像头'];

export const firmwareVersions: FirmwareVersion[] = [
  // 车载终端 x3
  { id: 'FW-001', version: 'v3.2.1', deviceType: '车载终端', releaseDate: '2025-04-10', fileSize: '12.5 MB', fileSizeBytes: 13107200, changelog: '优化GPS定位精度；新增CAN总线诊断；修复高温休眠问题', compatibleBatches: 'BT-2024A, BT-2024B, BT-2025A', sha256: 'a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456', status: 'released' },
  { id: 'FW-002', version: 'v3.1.8', deviceType: '车载终端', releaseDate: '2025-03-15', fileSize: '11.9 MB', fileSizeBytes: 12478054, changelog: '改进4G信号稳定性；优化功耗管理', compatibleBatches: 'BT-2024A, BT-2024B', sha256: 'b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456a1', status: 'gray' },
  { id: 'FW-003', version: 'v3.0.5', deviceType: '车载终端', releaseDate: '2025-01-20', fileSize: '11.2 MB', fileSizeBytes: 11744051, changelog: '基础稳定版本；支持远程诊断', compatibleBatches: 'BT-2024A', sha256: 'c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456a1b2', status: 'revoked' },
  // 定位器 x3
  { id: 'FW-004', version: 'v2.5.3', deviceType: '定位器', releaseDate: '2025-04-12', fileSize: '8.3 MB', fileSizeBytes: 8703180, changelog: '新增北斗三号支持；优化低功耗定位；修复蓝牙配对失败问题', compatibleBatches: 'LC-2024, LC-2025', sha256: 'd4e5f6789012345678901234567890abcdef1234567890abcdef123456a1b2c3', status: 'released' },
  { id: 'FW-005', version: 'v2.4.1', deviceType: '定位器', releaseDate: '2025-02-28', fileSize: '7.8 MB', fileSizeBytes: 8178892, changelog: '增强AGPS辅助定位速度；优化电池续航', compatibleBatches: 'LC-2024', sha256: 'e5f6789012345678901234567890abcdef1234567890abcdef123456a1b2c3d4', status: 'gray' },
  { id: 'FW-006', version: 'v2.3.0', deviceType: '定位器', releaseDate: '2024-12-10', fileSize: '7.2 MB', fileSizeBytes: 7549747, changelog: '初始稳定版本', compatibleBatches: 'LC-2024', sha256: 'f6789012345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5', status: 'revoked' },
  // 传感器 x3
  { id: 'FW-007', version: 'v1.8.2', deviceType: '传感器', releaseDate: '2025-04-08', fileSize: '4.1 MB', fileSizeBytes: 4299161, changelog: '新增多传感器融合算法；优化温湿度校准；支持OTA差分升级', compatibleBatches: 'SN-2024A, SN-2024B, SN-2025', sha256: '6789012345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f6', status: 'released' },
  { id: 'FW-008', version: 'v1.7.5', deviceType: '传感器', releaseDate: '2025-03-01', fileSize: '3.8 MB', fileSizeBytes: 3984588, changelog: '修复数据上报间隔异常；优化功耗', compatibleBatches: 'SN-2024A, SN-2024B', sha256: '789012345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f67', status: 'gray' },
  { id: 'FW-009', version: 'v1.6.0', deviceType: '传感器', releaseDate: '2024-11-15', fileSize: '3.5 MB', fileSizeBytes: 3670016, changelog: '基础版本；支持基本数据采集', compatibleBatches: 'SN-2024A', sha256: '89012345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f678', status: 'revoked' },
  // 网关 x3
  { id: 'FW-010', version: 'v4.1.3', deviceType: '网关', releaseDate: '2025-04-15', fileSize: '18.6 MB', fileSizeBytes: 19503513, changelog: '新增边缘计算能力；优化Mesh组网；支持断点续传', compatibleBatches: 'GW-2024, GW-2025A, GW-2025B', sha256: '9012345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f6789', status: 'released' },
  { id: 'FW-011', version: 'v4.0.2', deviceType: '网关', releaseDate: '2025-02-20', fileSize: '17.4 MB', fileSizeBytes: 18245222, changelog: '增强Wi-Fi吞吐量；修复DNS解析偶发失败', compatibleBatches: 'GW-2024, GW-2025A', sha256: '012345678901234567890abcdef1234567890abcdef1234567890abcdef123456a1b2c3d4e5f67890', status: 'gray' },
  { id: 'FW-012', version: 'v3.9.1', deviceType: '网关', releaseDate: '2024-12-01', fileSize: '16.8 MB', fileSizeBytes: 17616076, changelog: '稳定版本；基础组网功能', compatibleBatches: 'GW-2024', sha256: '12345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f678901', status: 'revoked' },
  // 摄像头 x3
  { id: 'FW-013', version: 'v2.1.4', deviceType: '摄像头', releaseDate: '2025-04-05', fileSize: '24.2 MB', fileSizeBytes: 25333596, changelog: '新增AI人形检测；优化夜视效果；支持H.265编码', compatibleBatches: 'CM-2024, CM-2025', sha256: '2345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f6789012', status: 'released' },
  { id: 'FW-014', version: 'v2.0.8', deviceType: '摄像头', releaseDate: '2025-03-10', fileSize: '22.7 MB', fileSizeBytes: 23802672, changelog: '修复移动侦测误报；优化存储空间管理', compatibleBatches: 'CM-2024', sha256: '345678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f67890123', status: 'gray' },
  { id: 'FW-015', version: 'v1.9.5', deviceType: '摄像头', releaseDate: '2025-01-05', fileSize: '21.3 MB', fileSizeBytes: 22334674, changelog: '基础版本；支持1080P实时预览', compatibleBatches: 'CM-2024', sha256: '45678901234567890abcdef1234567890abcdef123456a1b2c3d4e5f678901234', status: 'revoked' },
];

export const grayStrategies: GrayStrategy[] = [
  {
    id: 'GS-001', firmwareVersion: 'v3.2.1', deviceType: '车载终端', currentBatch: 2, totalBatches: 3,
    upgradedDevices: 110, totalDevices: 1200, observeStatus: 'observing', autoProgress: true,
    batches: [
      { batchNum: 1, deviceCount: 10, observeHours: 24, description: '核心测试设备验证' },
      { batchNum: 2, deviceCount: 100, observeHours: 48, description: '小批量灰度验证' },
      { batchNum: 3, deviceCount: 1090, observeHours: 0, description: '全量推送' },
    ],
  },
  {
    id: 'GS-002', firmwareVersion: 'v2.5.3', deviceType: '定位器', currentBatch: 3, totalBatches: 3,
    upgradedDevices: 2150, totalDevices: 2150, observeStatus: 'passed', autoProgress: true,
    batches: [
      { batchNum: 1, deviceCount: 10, observeHours: 24, description: '核心测试设备验证' },
      { batchNum: 2, deviceCount: 100, observeHours: 48, description: '小批量灰度验证' },
      { batchNum: 3, deviceCount: 2040, observeHours: 0, description: '全量推送' },
    ],
  },
  {
    id: 'GS-003', firmwareVersion: 'v4.1.3', deviceType: '网关', currentBatch: 1, totalBatches: 3,
    upgradedDevices: 8, totalDevices: 480, observeStatus: 'observing', autoProgress: false,
    batches: [
      { batchNum: 1, deviceCount: 10, observeHours: 24, description: '核心测试设备验证' },
      { batchNum: 2, deviceCount: 50, observeHours: 48, description: '小批量灰度验证' },
      { batchNum: 3, deviceCount: 420, observeHours: 0, description: '全量推送' },
    ],
  },
];

export const upgradeTasks: UpgradeTask[] = [
  { id: 'UT-001', taskName: '车载终端春季升级', targetVersion: 'v3.2.1', targetDevices: 1200, completed: 892, failed: 12, running: 296, progress: 74, status: 'running', timeWindow: '02:00-05:00', startTime: '2025-04-20 02:00' },
  { id: 'UT-002', taskName: '定位器固件更新', targetVersion: 'v2.5.3', targetDevices: 2150, completed: 2150, failed: 0, running: 0, progress: 100, status: 'completed', timeWindow: '01:00-04:00', startTime: '2025-04-15 01:00' },
  { id: 'UT-003', taskName: '传感器差分升级', targetVersion: 'v1.8.2', targetDevices: 850, completed: 420, failed: 8, running: 180, progress: 47, status: 'running', timeWindow: '02:30-05:30', startTime: '2025-04-22 02:30' },
  { id: 'UT-004', taskName: '网关边缘计算版本', targetVersion: 'v4.1.3', targetDevices: 480, completed: 0, failed: 0, running: 0, progress: 0, status: 'pending', timeWindow: '01:00-06:00', startTime: '2025-04-28 01:00' },
  { id: 'UT-005', taskName: '摄像头AI检测版本', targetVersion: 'v2.1.4', targetDevices: 320, completed: 310, failed: 5, running: 5, progress: 97, status: 'running', timeWindow: '00:00-05:00', startTime: '2025-04-18 00:00' },
  { id: 'UT-006', taskName: '定位器v2.4.1灰度', targetVersion: 'v2.4.1', targetDevices: 200, completed: 0, failed: 0, running: 0, progress: 0, status: 'pending', timeWindow: '02:00-04:00', startTime: '2025-04-29 02:00' },
  { id: 'UT-007', taskName: '车载终端v3.1.8回滚', targetVersion: 'v3.0.5', targetDevices: 15, completed: 15, failed: 0, running: 0, progress: 100, status: 'completed', timeWindow: '03:00-04:00', startTime: '2025-04-21 03:00' },
  { id: 'UT-008', taskName: '传感器功耗优化', targetVersion: 'v1.8.2', targetDevices: 850, completed: 600, failed: 3, running: 0, progress: 71, status: 'paused', timeWindow: '02:00-05:00', startTime: '2025-04-19 02:00' },
];

export const upgradeDevices: UpgradeDevice[] = [
  { id: 'UD-001', deviceId: 'DEV-CA-1001', deviceName: '车载终端-A001', status: 'downloading', progress: 35, targetVersion: 'v3.2.1' },
  { id: 'UD-002', deviceId: 'DEV-CA-1002', deviceName: '车载终端-A002', status: 'download_done', progress: 100, targetVersion: 'v3.2.1' },
  { id: 'UD-003', deviceId: 'DEV-CA-1003', deviceName: '车载终端-A003', status: 'installing', progress: 62, targetVersion: 'v3.2.1' },
  { id: 'UD-004', deviceId: 'DEV-CA-1004', deviceName: '车载终端-A004', status: 'install_done', progress: 100, targetVersion: 'v3.2.1' },
  { id: 'UD-005', deviceId: 'DEV-CA-1005', deviceName: '车载终端-A005', status: 'rebooting', progress: 80, targetVersion: 'v3.2.1' },
  { id: 'UD-006', deviceId: 'DEV-CA-1006', deviceName: '车载终端-A006', status: 'verify_failed', progress: 100, targetVersion: 'v3.2.1' },
  { id: 'UD-007', deviceId: 'DEV-LC-2001', deviceName: '定位器-B001', status: 'downloading', progress: 15, targetVersion: 'v2.5.3' },
  { id: 'UD-008', deviceId: 'DEV-LC-2002', deviceName: '定位器-B002', status: 'download_done', progress: 100, targetVersion: 'v2.5.3' },
  { id: 'UD-009', deviceId: 'DEV-SN-3001', deviceName: '传感器-C001', status: 'installing', progress: 45, targetVersion: 'v1.8.2' },
  { id: 'UD-010', deviceId: 'DEV-SN-3002', deviceName: '传感器-C002', status: 'install_done', progress: 100, targetVersion: 'v1.8.2' },
  { id: 'UD-011', deviceId: 'DEV-GW-4001', deviceName: '网关-D001', status: 'rebooting', progress: 90, targetVersion: 'v4.1.3' },
  { id: 'UD-012', deviceId: 'DEV-GW-4002', deviceName: '网关-D002', status: 'verify_failed', progress: 100, targetVersion: 'v4.1.3' },
  { id: 'UD-013', deviceId: 'DEV-CM-5001', deviceName: '摄像头-E001', status: 'downloading', progress: 55, targetVersion: 'v2.1.4' },
  { id: 'UD-014', deviceId: 'DEV-CM-5002', deviceName: '摄像头-E002', status: 'download_done', progress: 100, targetVersion: 'v2.1.4' },
  { id: 'UD-015', deviceId: 'DEV-CM-5003', deviceName: '摄像头-E003', status: 'installing', progress: 78, targetVersion: 'v2.1.4' },
  { id: 'UD-016', deviceId: 'DEV-CA-1007', deviceName: '车载终端-A007', status: 'install_done', progress: 100, targetVersion: 'v3.2.1' },
  { id: 'UD-017', deviceId: 'DEV-LC-2003', deviceName: '定位器-B003', status: 'rebooting', progress: 60, targetVersion: 'v2.5.3' },
  { id: 'UD-018', deviceId: 'DEV-SN-3003', deviceName: '传感器-C003', status: 'downloading', progress: 22, targetVersion: 'v1.8.2' },
  { id: 'UD-019', deviceId: 'DEV-GW-4003', deviceName: '网关-D003', status: 'download_done', progress: 100, targetVersion: 'v4.1.3' },
  { id: 'UD-020', deviceId: 'DEV-CM-5004', deviceName: '摄像头-E004', status: 'verify_failed', progress: 100, targetVersion: 'v2.1.4' },
];

export const powerProtectRecords: PowerProtectRecord[] = [
  { id: 'PP-001', deviceId: 'DEV-CA-1023', deviceName: '车载终端-A023', powerOffTime: '2025-04-20 02:35', resumeSuccess: true, rollbackCount: 0, detail: '升级过程中断电，断点续传成功' },
  { id: 'PP-002', deviceId: 'DEV-LC-2056', deviceName: '定位器-B056', powerOffTime: '2025-04-18 03:12', resumeSuccess: true, rollbackCount: 0, detail: '电池电量低导致断电，续传成功' },
  { id: 'PP-003', deviceId: 'DEV-SN-3012', deviceName: '传感器-C012', powerOffTime: '2025-04-19 02:48', resumeSuccess: false, rollbackCount: 1, detail: '升级失败，自动回滚至v1.7.5' },
  { id: 'PP-004', deviceId: 'DEV-GW-4018', deviceName: '网关-D018', powerOffTime: '2025-04-17 01:55', resumeSuccess: true, rollbackCount: 0, detail: '网络波动导致连接断开，续传成功' },
  { id: 'PP-005', deviceId: 'DEV-CA-1045', deviceName: '车载终端-A045', powerOffTime: '2025-04-21 02:20', resumeSuccess: false, rollbackCount: 1, detail: '校验失败，执行回滚操作' },
  { id: 'PP-006', deviceId: 'DEV-CM-5023', deviceName: '摄像头-E023', powerOffTime: '2025-04-16 00:45', resumeSuccess: true, rollbackCount: 0, detail: '存储写入中断，断点续传恢复' },
  { id: 'PP-007', deviceId: 'DEV-LC-2078', deviceName: '定位器-B078', powerOffTime: '2025-04-22 03:05', resumeSuccess: true, rollbackCount: 0, detail: '信号弱导致下载中断，自动恢复' },
  { id: 'PP-008', deviceId: 'DEV-SN-3034', deviceName: '传感器-C034', powerOffTime: '2025-04-15 02:30', resumeSuccess: false, rollbackCount: 1, detail: '固件签名验证失败，安全回滚' },
  { id: 'PP-009', deviceId: 'DEV-GW-4025', deviceName: '网关-D025', powerOffTime: '2025-04-14 01:40', resumeSuccess: true, rollbackCount: 0, detail: 'MQTT连接断开，升级恢复成功' },
  { id: 'PP-010', deviceId: 'DEV-CA-1067', deviceName: '车载终端-A067', powerOffTime: '2025-04-23 02:15', resumeSuccess: true, rollbackCount: 0, detail: 'CAN总线干扰导致短暂中断，续传成功' },
];

export const rollbackRecords: RollbackRecord[] = [
  { id: 'RB-001', deviceId: 'DEV-SN-3012', originalVersion: 'v1.7.5', upgradeVersion: 'v1.8.2', rollbackReason: '升级后功耗异常增加30%', rollbackTime: '2025-04-19 04:20' },
  { id: 'RB-002', deviceId: 'DEV-CA-1045', originalVersion: 'v3.1.8', upgradeVersion: 'v3.2.1', rollbackReason: 'CAN总线通信中断', rollbackTime: '2025-04-21 03:45' },
  { id: 'RB-003', deviceId: 'DEV-GW-4031', originalVersion: 'v4.0.2', upgradeVersion: 'v4.1.3', rollbackReason: 'Mesh组网功能异常', rollbackTime: '2025-04-18 05:10' },
  { id: 'RB-004', deviceId: 'DEV-LC-2089', originalVersion: 'v2.4.1', upgradeVersion: 'v2.5.3', rollbackReason: '北斗三号模块初始化失败', rollbackTime: '2025-04-17 04:30' },
  { id: 'RB-005', deviceId: 'DEV-CM-5045', originalVersion: 'v2.0.8', upgradeVersion: 'v2.1.4', rollbackReason: 'AI检测误报率过高', rollbackTime: '2025-04-16 03:20' },
  { id: 'RB-006', deviceId: 'DEV-SN-3056', originalVersion: 'v1.7.5', upgradeVersion: 'v1.8.2', rollbackReason: '温湿度数据漂移', rollbackTime: '2025-04-15 04:00' },
  { id: 'RB-007', deviceId: 'DEV-CA-1078', originalVersion: 'v3.1.8', upgradeVersion: 'v3.2.1', rollbackReason: '高温环境GPS定位失效', rollbackTime: '2025-04-14 03:50' },
];

export const diffPackages: DiffPackage[] = [
  { id: 'DP-001', versionFrom: 'v3.1.8', versionTo: 'v3.2.1', deviceType: '车载终端', fullSize: 13107200, diffSize: 4325376, compressionRatio: 67.0 },
  { id: 'DP-002', versionFrom: 'v2.4.1', versionTo: 'v2.5.3', deviceType: '定位器', fullSize: 8703180, diffSize: 2850816, compressionRatio: 67.2 },
  { id: 'DP-003', versionFrom: 'v1.7.5', versionTo: 'v1.8.2', deviceType: '传感器', fullSize: 4299161, diffSize: 1376256, compressionRatio: 68.0 },
  { id: 'DP-004', versionFrom: 'v4.0.2', versionTo: 'v4.1.3', deviceType: '网关', fullSize: 19503513, diffSize: 6553600, compressionRatio: 66.4 },
  { id: 'DP-005', versionFrom: 'v2.0.8', versionTo: 'v2.1.4', deviceType: '摄像头', fullSize: 25333596, diffSize: 8912896, compressionRatio: 64.8 },
];

export const upgradeStatusDistribution = [
  { name: '下载中', value: 4, color: '#3B82F6' },
  { name: '下载完成', value: 5, color: '#60A5FA' },
  { name: '安装中', value: 4, color: '#F59E0B' },
  { name: '安装完成', value: 4, color: '#10B981' },
  { name: '重启中', value: 2, color: '#8B5CF6' },
  { name: '验证失败', value: 3, color: '#EF4444' },
];

export const weeklyUpgradeTrend = [
  { day: '04-17', upgradedDevices: 156, successRate: 98.1 },
  { day: '04-18', upgradedDevices: 342, successRate: 99.4 },
  { day: '04-19', upgradedDevices: 215, successRate: 96.3 },
  { day: '04-20', upgradedDevices: 428, successRate: 97.8 },
  { day: '04-21', upgradedDevices: 189, successRate: 98.9 },
  { day: '04-22', upgradedDevices: 267, successRate: 97.2 },
  { day: '04-23', upgradedDevices: 198, successRate: 99.0 },
];

export const failReasonDistribution = [
  { name: '网络超时', value: 8, color: '#3B82F6' },
  { name: '存储不足', value: 5, color: '#F59E0B' },
  { name: '校验失败', value: 4, color: '#EF4444' },
  { name: '断电', value: 6, color: '#8B5CF6' },
  { name: '版本不兼容', value: 2, color: '#94A3B8' },
];

export const blacklistItems = [
  { model: '车载终端-A批次2023', reason: '硬件版本过旧，不支持新固件', date: '2025-04-01' },
  { model: '定位器-LC-2023', reason: '内存容量不足（<8MB）', date: '2025-04-05' },
  { model: '传感器-SN-2023A', reason: '芯片型号EOL，停止支持', date: '2025-04-10' },
  { model: '网关-GW-2023', reason: 'Wi-Fi模块驱动不兼容', date: '2025-04-12' },
];

export const timeWindowConfig = { startTime: '02:00', endTime: '05:00', enabled: true, days: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'] };

// ==================== Helpers ====================
export function getFirmwareStatusBadge(status: FirmwareVersion['status']) {
  switch (status) {
    case 'released':
      return <Badge className="bg-success-light text-success border-success text-xs">已发布</Badge>;
    case 'gray':
      return <Badge className="bg-primary-light text-primary border-primary-border text-xs">灰度中</Badge>;
    case 'revoked':
      return <Badge className="bg-neutral-background text-neutral-textSecondary border-neutral-border-strong text-xs">已撤回</Badge>;
  }
}

export function getTaskStatusBadge(status: UpgradeTask['status']) {
  switch (status) {
    case 'pending':
      return <Badge variant="outline" className="text-neutral-textSecondary border-neutral-border-strong text-xs">待执行</Badge>;
    case 'running':
      return <Badge className="bg-primary-light text-primary border-primary-border text-xs">执行中</Badge>;
    case 'completed':
      return <Badge className="bg-success-light text-success border-success text-xs">已完成</Badge>;
    case 'paused':
      return <Badge className="bg-warning-light text-warning border-warning text-xs">已暂停</Badge>;
  }
}

export function getGrayObserveBadge(status: GrayStrategy['observeStatus']) {
  switch (status) {
    case 'observing':
      return <Badge className="bg-primary-light text-primary border-primary-border text-xs"><Clock size={10} className="mr-1" />观察中</Badge>;
    case 'passed':
      return <Badge className="bg-success-light text-success border-success text-xs"><CheckCircle size={10} className="mr-1" />已通过</Badge>;
    case 'failed':
      return <Badge className="bg-danger-light text-danger border-danger text-xs"><XCircle size={10} className="mr-1" />已失败</Badge>;
    case 'waiting':
      return <Badge variant="outline" className="text-neutral-textSecondary border-neutral-border-strong text-xs">待开始</Badge>;
  }
}

export function getDeviceStatusBadge(status: UpgradeDevice['status']) {
  switch (status) {
    case 'downloading':
      return <Badge className="bg-primary-light text-primary border-primary-border text-xs"><Download size={10} className="mr-1" />下载中</Badge>;
    case 'download_done':
      return <Badge className="bg-info-light text-info border-info text-xs"><CheckCircle size={10} className="mr-1" />下载完成</Badge>;
    case 'installing':
      return <Badge className="bg-warning-light text-warning border-warning text-xs"><Zap size={10} className="mr-1" />安装中</Badge>;
    case 'install_done':
      return <Badge className="bg-success-light text-success border-success text-xs"><CheckCircle size={10} className="mr-1" />安装完成</Badge>;
    case 'rebooting':
      return <Badge className="bg-purple-100 text-purple-600 border-purple-300 text-xs"><RefreshCw size={10} className="mr-1" />重启中</Badge>;
    case 'verify_failed':
      return <Badge className="bg-danger-light text-danger border-danger text-xs"><XCircle size={10} className="mr-1" />验证失败</Badge>;
  }
}

export function formatBytes(bytes: number) {
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${bytes} B`;
}
