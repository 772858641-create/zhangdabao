import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import {
  Search, Filter, Server, Pause, Play, StopCircle,
  Moon, Ban, AlertTriangle, Clock, ChevronDown, ChevronUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  upgradeTasks, blacklistItems, timeWindowConfig,
  getTaskStatusBadge,
} from './types';

export default function UpgradeTaskManager() {
  const [taskSearch, setTaskSearch] = useState('');
  const [taskStatusFilter, setTaskStatusFilter] = useState('全部');
  const [expandedTaskId, setExpandedTaskId] = useState<string | null>(null);

  const filteredTasks = useMemo(() => {
    return upgradeTasks.filter((t) => {
      const matchSearch = !taskSearch.trim() ||
        t.taskName.includes(taskSearch) ||
        t.targetVersion.includes(taskSearch);
      const matchStatus = taskStatusFilter === '全部' ||
        (taskStatusFilter === '待执行' && t.status === 'pending') ||
        (taskStatusFilter === '执行中' && t.status === 'running') ||
        (taskStatusFilter === '已完成' && t.status === 'completed') ||
        (taskStatusFilter === '已暂停' && t.status === 'paused');
      return matchSearch && matchStatus;
    });
  }, [taskSearch, taskStatusFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
          <Input
            placeholder="搜索任务名称、目标版本..."
            value={taskSearch}
            onChange={(e) => setTaskSearch(e.target.value)}
            className="pl-9 h-9 bg-neutral-background border-neutral-border text-xs"
          />
        </div>
        <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
          <Filter size={12} className="text-neutral-textTertiary mr-1" />
          {['全部', '待执行', '执行中', '已完成', '已暂停'].map((s) => (
            <button
              key={s}
              onClick={() => setTaskStatusFilter(s)}
              className={cn(
                'px-2.5 py-1 text-xs rounded transition-colors',
                taskStatusFilter === s
                  ? 'bg-primary text-white'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Task List */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Server size={15} className="text-primary" />
            升级任务列表
            <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {filteredTasks.length} 条</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-border bg-neutral-background">
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5"></th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">任务名称</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">目标版本</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">目标设备</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">已完成/失败/进行中</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">进度</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">时段窗口</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">状态</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks.map((task, idx) => (
                <motion.tr
                  key={task.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.03 }}
                  className="border-b border-neutral-border hover:bg-neutral-background transition-colors"
                >
                  <td className="px-2 py-2.5 text-center">
                    <button
                      onClick={() => setExpandedTaskId(expandedTaskId === task.id ? null : task.id)}
                      className="text-neutral-textTertiary hover:text-neutral-textPrimary transition-colors"
                    >
                      {expandedTaskId === task.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    </button>
                  </td>
                  <td className="px-4 py-2.5 text-xs font-medium text-neutral-textPrimary">{task.taskName}</td>
                  <td className="px-4 py-2.5 text-xs font-mono text-primary">{task.targetVersion}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-number">{task.targetDevices.toLocaleString()}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1 text-xs">
                      <span className="text-success font-number">{task.completed}</span>
                      <span className="text-neutral-textTertiary">/</span>
                      <span className="text-danger font-number">{task.failed}</span>
                      <span className="text-neutral-textTertiary">/</span>
                      <span className="text-primary font-number">{task.running}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-neutral-background rounded-full overflow-hidden border border-neutral-border">
                        <div
                          className={cn(
                            'h-full rounded-full transition-all',
                            task.progress === 100 ? 'bg-success' : task.status === 'paused' ? 'bg-warning' : 'bg-primary'
                          )}
                          style={{ width: `${task.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-neutral-textSecondary font-number">{task.progress}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-mono flex items-center gap-1">
                    <Moon size={11} />
                    {task.timeWindow}
                  </td>
                  <td className="px-4 py-2.5">{getTaskStatusBadge(task.status)}</td>
                  <td className="px-4 py-2.5 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {task.status === 'pending' && (
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-success" title="启动">
                          <Play size={13} />
                        </Button>
                      )}
                      {task.status === 'running' && (
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-warning" title="暂停">
                          <Pause size={13} />
                        </Button>
                      )}
                      {task.status === 'paused' && (
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-success" title="恢复">
                          <Play size={13} />
                        </Button>
                      )}
                      {(task.status === 'running' || task.status === 'paused') && (
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-danger" title="取消">
                          <StopCircle size={13} />
                        </Button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Expanded Task Detail */}
      <AnimatePresence>
        {expandedTaskId && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            <Card className="bg-neutral-surface border-neutral-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-semibold text-neutral-textPrimary">
                  任务详情 — {upgradeTasks.find((t) => t.id === expandedTaskId)?.taskName}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {(() => {
                    const task = upgradeTasks.find((t) => t.id === expandedTaskId);
                    if (!task) return null;
                    return (
                      <>
                        <div className="bg-neutral-background rounded-md p-3 border border-neutral-border">
                          <span className="text-xs text-neutral-textTertiary">目标设备</span>
                          <p className="text-sm font-medium text-neutral-textPrimary font-number mt-1">{task.targetDevices.toLocaleString()}</p>
                        </div>
                        <div className="bg-neutral-background rounded-md p-3 border border-neutral-border">
                          <span className="text-xs text-neutral-textTertiary">已完成</span>
                          <p className="text-sm font-medium text-success font-number mt-1">{task.completed.toLocaleString()}</p>
                        </div>
                        <div className="bg-neutral-background rounded-md p-3 border border-neutral-border">
                          <span className="text-xs text-neutral-textTertiary">失败</span>
                          <p className="text-sm font-medium text-danger font-number mt-1">{task.failed.toLocaleString()}</p>
                        </div>
                        <div className="bg-neutral-background rounded-md p-3 border border-neutral-border">
                          <span className="text-xs text-neutral-textTertiary">开始时间</span>
                          <p className="text-sm font-medium text-neutral-textPrimary font-number mt-1">{task.startTime}</p>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Time Window & Blacklist */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Clock size={15} className="text-primary" />
              升级时段控制
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between bg-neutral-background rounded-md p-3 border border-neutral-border">
              <div className="flex items-center gap-2">
                <Moon size={14} className="text-neutral-textSecondary" />
                <div>
                  <p className="text-xs font-medium text-neutral-textPrimary">允许升级时段</p>
                  <p className="text-xs text-neutral-textSecondary font-mono">{timeWindowConfig.startTime} - {timeWindowConfig.endTime}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={timeWindowConfig.enabled} />
                <span className={cn('text-xs', timeWindowConfig.enabled ? 'text-success' : 'text-neutral-textTertiary')}>
                  {timeWindowConfig.enabled ? '已启用' : '已禁用'}
                </span>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {timeWindowConfig.days.map((day) => (
                <Badge key={day} variant="outline" className="text-xs border-neutral-border text-neutral-textSecondary">
                  {day}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Ban size={15} className="text-danger" />
              升级黑名单
              <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {blacklistItems.length} 条</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {blacklistItems.map((item, _idx) => (
              <div key={_idx} className="flex items-start gap-2 bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <AlertTriangle size={13} className="text-warning mt-0.5 shrink-0" />
                <div className="min-w-0">
                  <p className="text-xs font-medium text-neutral-textPrimary truncate">{item.model}</p>
                  <p className="text-xs text-neutral-textSecondary mt-0.5">{item.reason}</p>
                  <p className="text-xs text-neutral-textTertiary font-mono mt-0.5">{item.date}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
