import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Eye, RotateCcw, Upload, Search, Filter,
  FileCode, Zap, Clock, CheckCircle, Activity,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type {
  FirmwareVersion, GrayStrategy,
} from './types';
import {
  deviceTypes, firmwareVersions, grayStrategies,
  getFirmwareStatusBadge, getGrayObserveBadge,
} from './types';

export default function FirmwareLibrary() {
  const [firmwareSearch, setFirmwareSearch] = useState('');
  const [firmwareTypeFilter, setFirmwareTypeFilter] = useState('全部');
  const [selectedFirmware, setSelectedFirmware] = useState<FirmwareVersion | null>(null);
  const [firmwareDialogOpen, setFirmwareDialogOpen] = useState(false);
  const [selectedGrayStrategy, setSelectedGrayStrategy] = useState<GrayStrategy | null>(null);
  const [grayDialogOpen, setGrayDialogOpen] = useState(false);

  const filteredFirmwares = useMemo(() => {
    return firmwareVersions.filter((fw) => {
      const matchSearch = !firmwareSearch.trim() ||
        fw.version.toLowerCase().includes(firmwareSearch.toLowerCase()) ||
        fw.deviceType.includes(firmwareSearch) ||
        fw.changelog.includes(firmwareSearch);
      const matchType = firmwareTypeFilter === '全部' || fw.deviceType === firmwareTypeFilter;
      return matchSearch && matchType;
    });
  }, [firmwareSearch, firmwareTypeFilter]);

  const handleViewFirmware = (fw: FirmwareVersion) => {
    setSelectedFirmware(fw);
    setFirmwareDialogOpen(true);
  };

  const handleViewGray = (gs: GrayStrategy) => {
    setSelectedGrayStrategy(gs);
    setGrayDialogOpen(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
          <Input
            placeholder="搜索版本号、设备类型、更新说明..."
            value={firmwareSearch}
            onChange={(e) => setFirmwareSearch(e.target.value)}
            className="pl-9 h-9 bg-neutral-background border-neutral-border text-xs"
          />
        </div>
        <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
          <Filter size={12} className="text-neutral-textTertiary mr-1" />
          {['全部', ...deviceTypes].map((t) => (
            <button
              key={t}
              onClick={() => setFirmwareTypeFilter(t)}
              className={cn(
                'px-2.5 py-1 text-xs rounded transition-colors',
                firmwareTypeFilter === t
                  ? 'bg-primary text-white'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Firmware Table */}
      <Card className="bg-neutral-surface border-neutral-border overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <FileCode size={15} className="text-primary" />
            固件版本列表
            <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {filteredFirmwares.length} 条</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-border bg-neutral-background">
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">版本号</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">设备类型</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">发布日期</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">文件大小</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5 min-w-[200px]">更新说明</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">兼容批次</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">状态</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredFirmwares.map((fw) => (
                <motion.tr
                  key={fw.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0 }}
                  className="border-b border-neutral-border hover:bg-neutral-background transition-colors"
                >
                  <td className="px-4 py-2.5 text-xs font-mono text-neutral-textPrimary">{fw.version}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary">{fw.deviceType}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-mono">{fw.releaseDate}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary font-mono">{fw.fileSize}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary max-w-[240px] truncate">{fw.changelog}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary">{fw.compatibleBatches}</td>
                  <td className="px-4 py-2.5">{getFirmwareStatusBadge(fw.status)}</td>
                  <td className="px-4 py-2.5 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-primary" onClick={() => handleViewFirmware(fw)}>
                        <Eye size={13} className="mr-1" /> 详情
                      </Button>
                      {fw.status === 'released' && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-warning">
                          <RotateCcw size={13} className="mr-1" /> 撤回
                        </Button>
                      )}
                      {fw.status === 'revoked' && (
                        <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-success">
                          <Upload size={13} className="mr-1" /> 发布
                        </Button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Gray Strategy */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Zap size={15} className="text-warning" />
            灰度策略管理
            <span className="text-xs font-normal text-neutral-textTertiary ml-1">共 {grayStrategies.length} 条策略</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-neutral-border bg-neutral-background">
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">策略ID</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">目标版本</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">设备类型</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">当前批次</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">已升级/总数</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">观察状态</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5">推进规则</th>
                <th className="text-xs text-neutral-textSecondary font-medium px-4 py-2.5 text-right">操作</th>
              </tr>
            </thead>
            <tbody>
              {grayStrategies.map((gs, idx) => (
                <motion.tr
                  key={gs.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className="border-b border-neutral-border hover:bg-neutral-background transition-colors"
                >
                  <td className="px-4 py-2.5 text-xs font-mono text-neutral-textPrimary">{gs.id}</td>
                  <td className="px-4 py-2.5 text-xs font-mono text-primary">{gs.firmwareVersion}</td>
                  <td className="px-4 py-2.5 text-xs text-neutral-textSecondary">{gs.deviceType}</td>
                  <td className="px-4 py-2.5">
                    <span className="text-xs text-neutral-textPrimary font-medium">
                      批次 {gs.currentBatch} / {gs.totalBatches}
                    </span>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-neutral-textPrimary font-number">{gs.upgradedDevices}</span>
                      <span className="text-xs text-neutral-textTertiary">/</span>
                      <span className="text-xs text-neutral-textSecondary font-number">{gs.totalDevices}</span>
                      <div className="w-16 h-1.5 bg-neutral-background rounded-full overflow-hidden border border-neutral-border">
                        <div
                          className="h-full bg-primary rounded-full transition-all"
                          style={{ width: `${(gs.upgradedDevices / gs.totalDevices) * 100}%` }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-2.5">{getGrayObserveBadge(gs.observeStatus)}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn('text-xs', gs.autoProgress ? 'text-success' : 'text-neutral-textSecondary')}>
                      {gs.autoProgress ? '自动推进' : '手动推进'}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-primary" onClick={() => handleViewGray(gs)}>
                      <Eye size={13} className="mr-1" /> 查看详情
                    </Button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {/* Firmware Detail Dialog */}
      <Dialog open={firmwareDialogOpen} onOpenChange={setFirmwareDialogOpen}>
        <DialogContent className="max-w-lg bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary flex items-center gap-2">
              <FileCode size={16} className="text-primary" />
              固件详情
            </DialogTitle>
          </DialogHeader>
          {selectedFirmware && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">版本号</span>
                  <p className="text-sm font-mono text-neutral-textPrimary mt-0.5">{selectedFirmware.version}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">设备类型</span>
                  <p className="text-sm text-neutral-textPrimary mt-0.5">{selectedFirmware.deviceType}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">文件大小</span>
                  <p className="text-sm text-neutral-textPrimary font-mono mt-0.5">{selectedFirmware.fileSize}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">发布日期</span>
                  <p className="text-sm text-neutral-textPrimary font-mono mt-0.5">{selectedFirmware.releaseDate}</p>
                </div>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-xs text-neutral-textTertiary">状态</span>
                <div className="mt-0.5">{getFirmwareStatusBadge(selectedFirmware.status)}</div>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-xs text-neutral-textTertiary">兼容硬件批次</span>
                <p className="text-sm text-neutral-textPrimary mt-0.5">{selectedFirmware.compatibleBatches}</p>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-xs text-neutral-textTertiary">SHA-256 校验和</span>
                <p className="text-xs text-neutral-textPrimary font-mono mt-0.5 break-all">{selectedFirmware.sha256}</p>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-xs text-neutral-textTertiary">更新说明</span>
                <p className="text-sm text-neutral-textPrimary mt-0.5">{selectedFirmware.changelog}</p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setFirmwareDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Gray Strategy Detail Dialog */}
      <Dialog open={grayDialogOpen} onOpenChange={setGrayDialogOpen}>
        <DialogContent className="max-w-lg bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary flex items-center gap-2">
              <Zap size={16} className="text-warning" />
              灰度策略详情
            </DialogTitle>
          </DialogHeader>
          {selectedGrayStrategy && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">策略ID</span>
                  <p className="text-sm font-mono text-neutral-textPrimary mt-0.5">{selectedGrayStrategy.id}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">目标版本</span>
                  <p className="text-sm font-mono text-primary mt-0.5">{selectedGrayStrategy.firmwareVersion}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">设备类型</span>
                  <p className="text-sm text-neutral-textPrimary mt-0.5">{selectedGrayStrategy.deviceType}</p>
                </div>
                <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                  <span className="text-xs text-neutral-textTertiary">观察状态</span>
                  <div className="mt-0.5">{getGrayObserveBadge(selectedGrayStrategy.observeStatus)}</div>
                </div>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-neutral-textTertiary">总进度</span>
                  <span className="text-xs font-number text-neutral-textPrimary">
                    {selectedGrayStrategy.upgradedDevices} / {selectedGrayStrategy.totalDevices}
                  </span>
                </div>
                <div className="w-full h-2 bg-neutral-surface rounded-full overflow-hidden border border-neutral-border">
                  <div
                    className="h-full bg-primary rounded-full transition-all"
                    style={{ width: `${(selectedGrayStrategy.upgradedDevices / selectedGrayStrategy.totalDevices) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-neutral-textTertiary mt-1 text-right font-number">
                  {((selectedGrayStrategy.upgradedDevices / selectedGrayStrategy.totalDevices) * 100).toFixed(1)}%
                </p>
              </div>
              <div>
                <span className="text-xs text-neutral-textSecondary mb-2 block">灰度批次配置</span>
                <div className="space-y-2">
                  {selectedGrayStrategy.batches.map((batch) => {
                    const isCurrent = batch.batchNum === selectedGrayStrategy.currentBatch;
                    const isPassed = batch.batchNum < selectedGrayStrategy.currentBatch;
                    return (
                      <div
                        key={batch.batchNum}
                        className={cn(
                          'bg-neutral-background rounded-md p-3 border transition-colors',
                          isCurrent ? 'border-primary' : isPassed ? 'border-success' : 'border-neutral-border'
                        )}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            {isPassed && <CheckCircle size={13} className="text-success" />}
                            {isCurrent && <Activity size={13} className="text-primary" />}
                            {!isPassed && !isCurrent && <Clock size={13} className="text-neutral-textTertiary" />}
                            <span className="text-xs font-medium text-neutral-textPrimary">
                              批次 {batch.batchNum}
                              {isCurrent && <span className="text-primary ml-1">(当前)</span>}
                              {isPassed && <span className="text-success ml-1">(已完成)</span>}
                            </span>
                          </div>
                          <span className="text-xs text-neutral-textSecondary font-number">{batch.deviceCount} 台</span>
                        </div>
                        <p className="text-xs text-neutral-textSecondary ml-5">{batch.description}</p>
                        {batch.observeHours > 0 && (
                          <p className="text-xs text-neutral-textTertiary ml-5 mt-0.5 flex items-center gap-1">
                            <Clock size={10} /> 观察时长: {batch.observeHours}h
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="flex items-center gap-2 bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-xs text-neutral-textSecondary">推进规则:</span>
                <Switch checked={selectedGrayStrategy.autoProgress} />
                <span className={cn('text-xs', selectedGrayStrategy.autoProgress ? 'text-success' : 'text-neutral-textSecondary')}>
                  {selectedGrayStrategy.autoProgress ? '自动推进' : '手动推进'}
                </span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setGrayDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
