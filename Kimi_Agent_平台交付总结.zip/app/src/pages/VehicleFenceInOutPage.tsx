import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  MapPin,
  Circle,
  Hexagon,
  Route,
  Settings,
  Play,
  Plus,
  Trash2,
  Edit,
  CheckCircle,
  AlertTriangle,
  Lock,
  Unlock,
  Search,
  Shield,
  Activity,
  Zap,
  ArrowDownToLine,
  ArrowUpFromLine,
  Clock,
  Car,
  Building2,
  Eye,
  ChevronRight,
} from 'lucide-react';

// ============ 类型定义 ============

type FenceType = 'circle' | 'polygon' | 'route';
type FenceStatus = 'active' | 'inactive';

interface Fence {
  id: string;
  name: string;
  type: FenceType;
  warehouse: string;
  radius?: number;
  range?: string;
  status: FenceStatus;
  createTime: string;
  centerX: number;
  centerY: number;
  points?: string;
  color: string;
}

interface LinkageRecord {
  id: string;
  triggerTime: string;
  plateNumber: string;
  fenceName: string;
  eventType: 'enter' | 'leave';
  action: '入库' | '出库';
  status: 'success' | 'failed';
  operator: string;
}

interface LinkageRule {
  id: string;
  name: string;
  description: string;
  triggerCondition: string;
  action: string;
  enabled: boolean;
  priority: number;
}

// ============ Mock 数据 ============

const FENCE_MOCK: Fence[] = [
  {
    id: 'F001',
    name: '苏州仓-入口',
    type: 'circle',
    warehouse: '苏州昆山物流中心',
    radius: 500,
    status: 'active',
    createTime: '2025-03-15 10:30',
    centerX: 120.6,
    centerY: 31.3,
    color: '#3B82F6',
  },
  {
    id: 'F002',
    name: '上海仓-卸货区',
    type: 'polygon',
    warehouse: '上海浦东转运仓',
    range: '多边形区域',
    status: 'active',
    createTime: '2025-03-18 14:20',
    centerX: 121.5,
    centerY: 31.2,
    points: '30,20 70,10 90,50 60,80 20,60',
    color: '#10B981',
  },
  {
    id: 'F003',
    name: '杭州仓-大门',
    type: 'circle',
    warehouse: '杭州萧山仓储园',
    radius: 300,
    status: 'active',
    createTime: '2025-03-20 09:15',
    centerX: 120.2,
    centerY: 30.25,
    color: '#F59E0B',
  },
  {
    id: 'F004',
    name: '南京仓-绕城通道',
    type: 'route',
    warehouse: '南京江宁物流港',
    range: '线路两侧100m',
    status: 'inactive',
    createTime: '2025-04-01 16:45',
    centerX: 118.8,
    centerY: 32.0,
    color: '#8B5CF6',
  },
  {
    id: 'F005',
    name: '无锡仓-东区围栏',
    type: 'polygon',
    warehouse: '无锡新区物流园',
    range: '多边形区域',
    status: 'active',
    createTime: '2025-04-05 11:00',
    centerX: 120.35,
    centerY: 31.55,
    points: '10,30 50,10 80,30 70,70 30,80',
    color: '#EF4444',
  },
  {
    id: 'F006',
    name: '合肥仓-北门',
    type: 'circle',
    warehouse: '合肥经开区仓库',
    radius: 400,
    status: 'active',
    createTime: '2025-04-10 08:30',
    centerX: 117.3,
    centerY: 31.85,
    color: '#06B6D4',
  },
  {
    id: 'F007',
    name: '常州仓-主干道',
    type: 'route',
    warehouse: '常州武进物流中心',
    range: '线路两侧150m',
    status: 'inactive',
    createTime: '2025-04-12 13:20',
    centerX: 119.95,
    centerY: 31.8,
    color: '#EC4899',
  },
];

const LINKAGE_RECORD_MOCK: LinkageRecord[] = [
  {
    id: 'L001',
    triggerTime: '2025-04-30 08:32:15',
    plateNumber: '沪A·B8792',
    fenceName: '苏州仓-入口',
    eventType: 'enter',
    action: '入库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L002',
    triggerTime: '2025-04-30 08:45:33',
    plateNumber: '苏E·C1234',
    fenceName: '苏州仓-入口',
    eventType: 'leave',
    action: '出库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L003',
    triggerTime: '2025-04-30 09:10:22',
    plateNumber: '浙A·D5678',
    fenceName: '杭州仓-大门',
    eventType: 'enter',
    action: '入库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L004',
    triggerTime: '2025-04-30 09:35:48',
    plateNumber: '沪C·E9012',
    fenceName: '上海仓-卸货区',
    eventType: 'enter',
    action: '入库',
    status: 'failed',
    operator: '系统自动',
  },
  {
    id: 'L005',
    triggerTime: '2025-04-30 10:02:11',
    plateNumber: '苏A·F3456',
    fenceName: '无锡仓-东区围栏',
    eventType: 'enter',
    action: '入库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L006',
    triggerTime: '2025-04-30 10:28:55',
    plateNumber: '皖A·G7890',
    fenceName: '合肥仓-北门',
    eventType: 'leave',
    action: '出库',
    status: 'failed',
    operator: '系统自动',
  },
  {
    id: 'L007',
    triggerTime: '2025-04-30 10:45:30',
    plateNumber: '沪B·H2345',
    fenceName: '上海仓-卸货区',
    eventType: 'leave',
    action: '出库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L008',
    triggerTime: '2025-04-30 11:15:42',
    plateNumber: '浙B·J6789',
    fenceName: '杭州仓-大门',
    eventType: 'leave',
    action: '出库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L009',
    triggerTime: '2025-04-30 11:38:19',
    plateNumber: '苏E·K0123',
    fenceName: '苏州仓-入口',
    eventType: 'enter',
    action: '入库',
    status: 'success',
    operator: '系统自动',
  },
  {
    id: 'L010',
    triggerTime: '2025-04-30 12:05:27',
    plateNumber: '苏D·L4567',
    fenceName: '无锡仓-东区围栏',
    eventType: 'leave',
    action: '出库',
    status: 'success',
    operator: '系统自动',
  },
];

const LINKAGE_RULE_MOCK: LinkageRule[] = [
  {
    id: 'R001',
    name: '入库联动规则',
    description: '车辆进入围栏范围时，自动触发入库登记流程',
    triggerCondition: '车辆 GPS 坐标进入围栏边界',
    action: '自动创建入库单，更新载具位置状态为"在库"',
    enabled: true,
    priority: 1,
  },
  {
    id: 'R002',
    name: '出库联动规则',
    description: '车辆离开围栏范围时，自动触发出库确认流程',
    triggerCondition: '车辆 GPS 坐标离开围栏边界',
    action: '自动创建出库单，更新载具位置状态为"在途"',
    enabled: true,
    priority: 2,
  },
  {
    id: 'R003',
    name: '报警联动规则',
    description: '非授权车辆进入围栏时触发安全报警',
    triggerCondition: '未在白名单内的车辆进入围栏',
    action: '发送报警通知给仓库管理员，记录异常事件',
    enabled: false,
    priority: 3,
  },
  {
    id: 'R004',
    name: '滞留检测规则',
    description: '车辆在围栏内停留超过阈值时触发提醒',
    triggerCondition: '车辆在围栏内停留超过 30 分钟',
    action: '发送滞留提醒给调度员，建议优化装卸效率',
    enabled: true,
    priority: 4,
  },
  {
    id: 'R005',
    name: '围栏异常离线规则',
    description: '围栏关联设备离线时触发报警',
    triggerCondition: '围栏绑定的 GPS/RFID 设备超过 10 分钟无数据',
    action: '标记围栏状态异常，通知运维人员检修',
    enabled: false,
    priority: 5,
  },
];

// ============ SVG 地图组件 ============

function FenceMap({ fences }: { fences: Fence[] }) {
  const mapWidth = 560;
  const mapHeight = 360;

  // 经纬度范围
  const lonMin = 117.0;
  const lonMax = 122.0;
  const latMin = 30.0;
  const latMax = 32.5;

  const toSvgX = (lon: number) =>
    ((lon - lonMin) / (lonMax - lonMin)) * mapWidth;
  const toSvgY = (lat: number) =>
    mapHeight - ((lat - latMin) / (latMax - latMin)) * mapHeight;

  // 道路线条（模拟）
  const roads = [
    { x1: 120.6, y1: 31.3, x2: 121.5, y2: 31.2 },
    { x1: 120.2, y1: 30.25, x2: 120.6, y2: 31.3 },
    { x1: 118.8, y1: 32.0, x2: 120.6, y2: 31.3 },
    { x1: 120.35, y1: 31.55, x2: 120.6, y2: 31.3 },
    { x1: 117.3, y1: 31.85, x2: 118.8, y2: 32.0 },
    { x1: 119.95, y1: 31.8, x2: 120.35, y2: 31.55 },
  ];

  // 水域
  const waters = [
    { cx: 121.2, cy: 31.05, r: 15 },
    { cx: 120.8, cy: 31.45, r: 10 },
  ];

  return (
    <svg
      viewBox={`0 0 ${mapWidth} ${mapHeight}`}
      className="w-full h-full rounded-lg"
      style={{ background: '#eef2f7' }}
    >
      {/* 地图背景网格 */}
      <defs>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path
            d="M 40 0 L 0 0 0 40"
            fill="none"
            stroke="#d1d8e0"
            strokeWidth="0.5"
          />
        </pattern>
      </defs>
      <rect width={mapWidth} height={mapHeight} fill="url(#grid)" />

      {/* 水域 */}
      {waters.map((w, i) => (
        <circle
          key={`water-${i}`}
          cx={toSvgX(w.cx)}
          cy={toSvgY(w.cy)}
          r={w.r}
          fill="#93C5FD"
          opacity={0.5}
        />
      ))}

      {/* 道路 */}
      {roads.map((r, i) => (
        <line
          key={`road-${i}`}
          x1={toSvgX(r.x1)}
          y1={toSvgY(r.y1)}
          x2={toSvgX(r.x2)}
          y2={toSvgY(r.y2)}
          stroke="#CBD5E1"
          strokeWidth="4"
          strokeLinecap="round"
        />
      ))}

      {/* 城市标签 */}
      {[
        { name: '苏州', lon: 120.6, lat: 31.38 },
        { name: '上海', lon: 121.55, lat: 31.28 },
        { name: '杭州', lon: 120.2, lat: 30.32 },
        { name: '南京', lon: 118.75, lat: 32.08 },
        { name: '无锡', lon: 120.32, lat: 31.62 },
        { name: '合肥', lon: 117.22, lat: 31.93 },
        { name: '常州', lon: 119.92, lat: 31.87 },
      ].map((city) => (
        <text
          key={city.name}
          x={toSvgX(city.lon)}
          y={toSvgY(city.lat)}
          textAnchor="middle"
          fill="#64748B"
          fontSize="11"
          fontWeight="600"
        >
          {city.name}
        </text>
      ))}

      {/* 围栏绘制 */}
      {fences.map((fence) => {
        const cx = toSvgX(fence.centerX);
        const cy = toSvgY(fence.centerY);
        const baseRadius =
          fence.type === 'circle'
            ? Math.max(18, (fence.radius || 300) / 35)
            : 28;

        if (fence.type === 'circle') {
          return (
            <g key={fence.id}>
              {/* 覆盖范围 */}
              <circle
                cx={cx}
                cy={cy}
                r={baseRadius}
                fill={fence.color}
                opacity={fence.status === 'active' ? 0.2 : 0.08}
                stroke={fence.color}
                strokeWidth="2"
                strokeDasharray={fence.status === 'inactive' ? '6,4' : 'none'}
              />
              {/* 中心点 */}
              <circle cx={cx} cy={cy} r={5} fill={fence.color} />
              <circle cx={cx} cy={cy} r={3} fill="#fff" />
              {/* 标签 */}
              <text
                x={cx}
                y={cy - baseRadius - 8}
                textAnchor="middle"
                fill={fence.color}
                fontSize="10"
                fontWeight="600"
              >
                {fence.name}
              </text>
            </g>
          );
        }

        if (fence.type === 'polygon') {
          return (
            <g key={fence.id}>
              <polygon
                points={fence.points || ''}
                transform={`translate(${cx - 50}, ${cy - 45})`}
                fill={fence.color}
                opacity={fence.status === 'active' ? 0.2 : 0.08}
                stroke={fence.color}
                strokeWidth="2"
                strokeDasharray={fence.status === 'inactive' ? '6,4' : 'none'}
              />
              <circle cx={cx} cy={cy} r={5} fill={fence.color} />
              <circle cx={cx} cy={cy} r={3} fill="#fff" />
              <text
                x={cx}
                y={cy - 55}
                textAnchor="middle"
                fill={fence.color}
                fontSize="10"
                fontWeight="600"
              >
                {fence.name}
              </text>
            </g>
          );
        }

        // route
        return (
          <g key={fence.id}>
            {/* 路线用椭圆模拟 */}
            <ellipse
              cx={cx}
              cy={cy}
              rx={baseRadius + 12}
              ry={10}
              fill={fence.color}
              opacity={fence.status === 'active' ? 0.15 : 0.06}
              stroke={fence.color}
              strokeWidth="2"
              strokeDasharray={fence.status === 'inactive' ? '6,4' : '8,4'}
            />
            <circle cx={cx} cy={cy} r={5} fill={fence.color} />
            <circle cx={cx} cy={cy} r={3} fill="#fff" />
            <text
              x={cx}
              y={cy - 22}
              textAnchor="middle"
              fill={fence.color}
              fontSize="10"
              fontWeight="600"
            >
              {fence.name}
            </text>
          </g>
        );
      })}

      {/* 图例 */}
      <g transform={`translate(${mapWidth - 130}, 12)`}>
        <rect
          x="0"
          y="0"
          width="120"
          height="80"
          rx="6"
          fill="white"
          opacity={0.9}
          stroke="#E2E8F0"
        />
        <text x="60" y="16" textAnchor="middle" fill="#475569" fontSize="11" fontWeight="600">
          图例
        </text>
        {/* 圆形 */}
        <circle cx="16" cy="36" r="8" fill="#3B82F6" opacity={0.3} stroke="#3B82F6" strokeWidth="1.5" />
        <circle cx="16" cy="36" r="3" fill="#3B82F6" />
        <text x="30" y="40" fill="#64748B" fontSize="10">圆形围栏</text>
        {/* 多边形 */}
        <polygon points="14,54 20,50 24,56 18,60" fill="#10B981" opacity={0.4} stroke="#10B981" strokeWidth="1" />
        <text x="30" y="58" fill="#64748B" fontSize="10">多边形围栏</text>
        {/* 线路 */}
        <line x1="10" y1="72" x2="24" y2="72" stroke="#8B5CF6" strokeWidth="2" strokeDasharray="4,2" />
        <text x="30" y="76" fill="#64748B" fontSize="10">线路围栏</text>
      </g>
    </svg>
  );
}

// ============ 统计卡片组件 ============

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  colorClass,
  delay,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  sub: string;
  colorClass: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] hover:shadow-md transition-shadow">
        <CardContent className="p-4 flex items-center gap-3">
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center ${colorClass}`}
          >
            <Icon className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs text-[var(--neutral-text-secondary)]">
              {label}
            </div>
            <div className="text-2xl font-bold text-[var(--neutral-text-primary)] mt-0.5">
              {value}
            </div>
            <div className="text-xs text-[var(--neutral-text-tertiary)] mt-0.5">
              {sub}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ============ 主页面组件 ============

export default function VehicleFenceInOutPage() {
  const [fenceFilter, setFenceFilter] = useState<FenceType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFence, setSelectedFence] = useState<Fence | null>(null);
  const [rules, setRules] = useState<LinkageRule[]>(LINKAGE_RULE_MOCK);
  const [activeTab, setActiveTab] = useState('overview');
  const [recordFilter, setRecordFilter] = useState<'all' | 'success' | 'failed'>('all');

  // 围栏统计
  const totalFences = FENCE_MOCK.length;
  const activeFences = FENCE_MOCK.filter((f) => f.status === 'active').length;
  const todayTriggers = LINKAGE_RECORD_MOCK.length;
  const successRate = (() => {
    const success = LINKAGE_RECORD_MOCK.filter((r) => r.status === 'success').length;
    return Math.round((success / LINKAGE_RECORD_MOCK.length) * 100);
  })();

  // 筛选后的围栏
  const filteredFences = useMemo(() => {
    return FENCE_MOCK.filter((f) => {
      const matchType = fenceFilter === 'all' || f.type === fenceFilter;
      const matchSearch =
        !searchQuery ||
        f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.warehouse.toLowerCase().includes(searchQuery.toLowerCase());
      return matchType && matchSearch;
    });
  }, [fenceFilter, searchQuery]);

  // 筛选后的联动记录
  const filteredRecords = useMemo(() => {
    if (recordFilter === 'all') return LINKAGE_RECORD_MOCK;
    return LINKAGE_RECORD_MOCK.filter((r) => r.status === recordFilter);
  }, [recordFilter]);

  const toggleRule = (ruleId: string) => {
    setRules((prev) =>
      prev.map((r) =>
        r.id === ruleId ? { ...r, enabled: !r.enabled } : r
      )
    );
  };

  const getFenceTypeIcon = (type: FenceType) => {
    switch (type) {
      case 'circle':
        return <Circle className="w-4 h-4" />;
      case 'polygon':
        return <Hexagon className="w-4 h-4" />;
      case 'route':
        return <Route className="w-4 h-4" />;
    }
  };

  const getFenceTypeLabel = (type: FenceType) => {
    switch (type) {
      case 'circle':
        return '圆形';
      case 'polygon':
        return '多边形';
      case 'route':
        return '线路';
    }
  };

  const getEventIcon = (type: 'enter' | 'leave') => {
    return type === 'enter' ? (
      <ArrowDownToLine className="w-4 h-4 text-blue-500" />
    ) : (
      <ArrowUpFromLine className="w-4 h-4 text-green-500" />
    );
  };

  const getEventLabel = (type: 'enter' | 'leave') => {
    return type === 'enter' ? '进入' : '离开';
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">
          车辆围栏联动出入库
        </h1>
        <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">
          管理地理围栏、可视化监控车辆进出联动规则与出入库记录
        </p>
      </motion.div>

      {/* 顶部统计卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Shield}
          label="围栏总数"
          value={String(totalFences)}
          sub={`启用中 ${activeFences} 个`}
          colorClass="bg-blue-500/10 text-blue-500"
          delay={0}
        />
        <StatCard
          icon={Activity}
          label="启用中"
          value={String(activeFences)}
          sub={`占比 ${Math.round((activeFences / totalFences) * 100)}%`}
          colorClass="bg-green-500/10 text-green-500"
          delay={0.1}
        />
        <StatCard
          icon={Zap}
          label="今日触发"
          value={String(todayTriggers)}
          sub="次联动事件"
          colorClass="bg-amber-500/10 text-amber-500"
          delay={0.2}
        />
        <StatCard
          icon={CheckCircle}
          label="联动成功率"
          value={`${successRate}%`}
          sub={`成功 ${LINKAGE_RECORD_MOCK.filter((r) => r.status === 'success').length} / 失败 ${LINKAGE_RECORD_MOCK.filter((r) => r.status === 'failed').length}`}
          colorClass="bg-emerald-500/10 text-emerald-500"
          delay={0.3}
        />
      </div>

      {/* Tab 切换 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-[var(--neutral-surface)] border border-[var(--neutral-border)]">
          <TabsTrigger value="overview" className="text-xs sm:text-sm">
            <MapPin className="w-4 h-4 mr-1" />
            围栏总览
          </TabsTrigger>
          <TabsTrigger value="records" className="text-xs sm:text-sm">
            <Clock className="w-4 h-4 mr-1" />
            联动记录
          </TabsTrigger>
          <TabsTrigger value="rules" className="text-xs sm:text-sm">
            <Settings className="w-4 h-4 mr-1" />
            规则配置
          </TabsTrigger>
        </TabsList>

        {/* ========== 围栏总览 Tab ========== */}
        <TabsContent value="overview" className="space-y-4">
          {/* 地图可视化 + 围栏列表 */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            {/* 地图区域 */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              className="xl:col-span-2"
            >
              <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] h-full">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-base text-[var(--neutral-text-primary)]">
                        围栏分布地图
                      </CardTitle>
                      <CardDescription className="text-xs mt-0.5">
                        华东区域仓库围栏可视化 (CSS/SVG 模拟)
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        <MapPin className="w-3 h-3 mr-1" />
                        {FENCE_MOCK.filter((f) => f.status === 'active').length} 活跃
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-3 pt-0">
                  <div className="rounded-lg overflow-hidden border border-[var(--neutral-border)]">
                    <FenceMap fences={FENCE_MOCK} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* 围栏列表 */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.15 }}
            >
              <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] h-full flex flex-col">
                <CardHeader className="pb-3 flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base text-[var(--neutral-text-primary)]">
                      围栏列表
                    </CardTitle>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button size="sm" className="h-7 text-xs">
                          <Plus className="w-3.5 h-3.5 mr-1" />
                          添加围栏
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-lg bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
                        <DialogHeader>
                          <DialogTitle className="text-[var(--neutral-text-primary)]">
                            添加新围栏
                          </DialogTitle>
                          <DialogDescription className="text-[var(--neutral-text-secondary)]">
                            配置地理围栏的边界范围和联动属性
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-3">
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                                围栏名称
                              </label>
                              <Input
                                placeholder="如：苏州仓-入口"
                                className="h-8 text-sm"
                              />
                            </div>
                            <div>
                              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                                围栏类型
                              </label>
                              <Select>
                                <SelectTrigger className="h-8 text-sm">
                                  <SelectValue placeholder="选择类型" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="circle">圆形</SelectItem>
                                  <SelectItem value="polygon">多边形</SelectItem>
                                  <SelectItem value="route">线路</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div>
                              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                                关联仓库
                              </label>
                              <Select>
                                <SelectTrigger className="h-8 text-sm">
                                  <SelectValue placeholder="选择仓库" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="w1">苏州昆山物流中心</SelectItem>
                                  <SelectItem value="w2">上海浦东转运仓</SelectItem>
                                  <SelectItem value="w3">杭州萧山仓储园</SelectItem>
                                  <SelectItem value="w4">南京江宁物流港</SelectItem>
                                  <SelectItem value="w5">无锡新区物流园</SelectItem>
                                  <SelectItem value="w6">合肥经开区仓库</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div>
                              <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                                半径/范围
                              </label>
                              <Input placeholder="如：500m" className="h-8 text-sm" />
                            </div>
                          </div>
                          <div>
                            <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                              中心坐标 (经度, 纬度)
                            </label>
                            <div className="grid grid-cols-2 gap-3">
                              <Input placeholder="120.600" className="h-8 text-sm" />
                              <Input placeholder="31.300" className="h-8 text-sm" />
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" size="sm" className="text-xs">
                            取消
                          </Button>
                          <Button size="sm" className="text-xs">
                            确认添加
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 flex-1 overflow-auto">
                  {/* 搜索和筛选 */}
                  <div className="flex gap-2 mb-3">
                    <div className="relative flex-1">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[var(--neutral-text-tertiary)]" />
                      <Input
                        placeholder="搜索围栏..."
                        className="h-8 text-xs pl-8"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Select
                      value={fenceFilter}
                      onValueChange={(v) => setFenceFilter(v as FenceType | 'all')}
                    >
                      <SelectTrigger className="h-8 text-xs w-[90px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部</SelectItem>
                        <SelectItem value="circle">圆形</SelectItem>
                        <SelectItem value="polygon">多边形</SelectItem>
                        <SelectItem value="route">线路</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* 围栏卡片列表 */}
                  <div className="space-y-2 max-h-[400px] overflow-auto pr-1">
                    <AnimatePresence>
                      {filteredFences.map((fence, index) => (
                        <motion.div
                          key={fence.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          transition={{ duration: 0.2, delay: index * 0.04 }}
                          className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-sm ${
                            selectedFence?.id === fence.id
                              ? 'border-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
                              : 'border-[var(--neutral-border)] hover:border-[var(--neutral-border-hover)]'
                          }`}
                          onClick={() => setSelectedFence(fence)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2 min-w-0">
                              <div
                                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                                style={{
                                  backgroundColor: `${fence.color}15`,
                                  color: fence.color,
                                }}
                              >
                                {getFenceTypeIcon(fence.type)}
                              </div>
                              <div className="min-w-0">
                                <div className="text-sm font-medium text-[var(--neutral-text-primary)] truncate">
                                  {fence.name}
                                </div>
                                <div className="text-xs text-[var(--neutral-text-secondary)] truncate">
                                  {fence.warehouse}
                                </div>
                              </div>
                            </div>
                            <Badge
                              variant={
                                fence.status === 'active' ? 'default' : 'secondary'
                              }
                              className="text-[10px] h-5 flex-shrink-0"
                            >
                              {fence.status === 'active' ? (
                                <Unlock className="w-3 h-3 mr-0.5" />
                              ) : (
                                <Lock className="w-3 h-3 mr-0.5" />
                              )}
                              {fence.status === 'active' ? '启用' : '停用'}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between mt-2 text-xs text-[var(--neutral-text-tertiary)]">
                            <div className="flex items-center gap-3">
                              <span className="flex items-center gap-1">
                                {getFenceTypeIcon(fence.type)}
                                {getFenceTypeLabel(fence.type)}
                              </span>
                              <span>
                                {fence.radius
                                  ? `半径 ${fence.radius}m`
                                  : fence.range}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-6 h-6 text-[var(--neutral-text-secondary)]"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-6 h-6 text-[var(--neutral-text-secondary)]"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                    {filteredFences.length === 0 && (
                      <div className="text-center py-8 text-[var(--neutral-text-tertiary)] text-sm">
                        <Shield className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        未找到匹配的围栏
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* 围栏详情表格 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.25 }}
          >
            <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-[var(--neutral-text-primary)]">
                  围栏管理明细
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="rounded-md border border-[var(--neutral-border)] overflow-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[var(--neutral-background)] hover:bg-transparent">
                        <TableHead className="text-xs">围栏编号</TableHead>
                        <TableHead className="text-xs">围栏名称</TableHead>
                        <TableHead className="text-xs">类型</TableHead>
                        <TableHead className="text-xs">关联仓库</TableHead>
                        <TableHead className="text-xs">半径/范围</TableHead>
                        <TableHead className="text-xs">状态</TableHead>
                        <TableHead className="text-xs">创建时间</TableHead>
                        <TableHead className="text-xs text-right">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredFences.map((fence) => (
                        <TableRow
                          key={fence.id}
                          className="cursor-pointer hover:bg-[var(--neutral-background)] transition-colors"
                          onClick={() => setSelectedFence(fence)}
                        >
                          <TableCell className="text-xs font-mono">
                            {fence.id}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div
                                className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
                                style={{
                                  backgroundColor: `${fence.color}15`,
                                  color: fence.color,
                                }}
                              >
                                {getFenceTypeIcon(fence.type)}
                              </div>
                              <span className="text-sm font-medium text-[var(--neutral-text-primary)]">
                                {fence.name}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className="text-[10px] h-5 gap-1"
                            >
                              {getFenceTypeIcon(fence.type)}
                              {getFenceTypeLabel(fence.type)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                            <div className="flex items-center gap-1">
                              <Building2 className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)]" />
                              {fence.warehouse}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                            {fence.radius ? `半径 ${fence.radius}m` : fence.range}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                fence.status === 'active' ? 'default' : 'secondary'
                              }
                              className="text-[10px] h-5"
                            >
                              {fence.status === 'active' ? '启用中' : '已停用'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-tertiary)]">
                            {fence.createTime}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-7 h-7 text-[var(--neutral-text-secondary)]"
                                title="查看"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-7 h-7 text-[var(--neutral-text-secondary)]"
                                title="编辑"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="w-7 h-7 text-red-500 hover:text-red-600"
                                title="删除"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* ========== 联动记录 Tab ========== */}
        <TabsContent value="records" className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div>
                    <CardTitle className="text-base text-[var(--neutral-text-primary)]">
                      出入库联动记录
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      车辆进出围栏触发的自动出入库操作日志
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select
                      value={recordFilter}
                      onValueChange={(v) => setRecordFilter(v as typeof recordFilter)}
                    >
                      <SelectTrigger className="h-8 text-xs w-[100px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">全部状态</SelectItem>
                        <SelectItem value="success">成功</SelectItem>
                        <SelectItem value="failed">失败</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="rounded-md border border-[var(--neutral-border)] overflow-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[var(--neutral-background)] hover:bg-transparent">
                        <TableHead className="text-xs">触发时间</TableHead>
                        <TableHead className="text-xs">车牌号</TableHead>
                        <TableHead className="text-xs">围栏名称</TableHead>
                        <TableHead className="text-xs">事件类型</TableHead>
                        <TableHead className="text-xs">联动动作</TableHead>
                        <TableHead className="text-xs">执行状态</TableHead>
                        <TableHead className="text-xs">操作人</TableHead>
                        <TableHead className="text-xs text-right">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRecords.map((record) => (
                        <TableRow
                          key={record.id}
                          className="hover:bg-[var(--neutral-background)] transition-colors"
                        >
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)] whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)]" />
                              {record.triggerTime}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1.5">
                              <Car className="w-4 h-4 text-[var(--neutral-text-secondary)]" />
                              <span className="text-sm font-medium text-[var(--neutral-text-primary)] font-mono">
                                {record.plateNumber}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-[var(--neutral-text-secondary)]">
                            {record.fenceName}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1.5">
                              {getEventIcon(record.eventType)}
                              <span className="text-xs font-medium text-[var(--neutral-text-primary)]">
                                {getEventLabel(record.eventType)}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={`text-[10px] h-5 ${
                                record.action === '入库'
                                  ? 'border-blue-300 text-blue-600 bg-blue-50'
                                  : 'border-green-300 text-green-600 bg-green-50'
                              }`}
                            >
                              {record.action}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                record.status === 'success' ? 'default' : 'destructive'
                              }
                              className="text-[10px] h-5 gap-1"
                            >
                              {record.status === 'success' ? (
                                <CheckCircle className="w-3 h-3" />
                              ) : (
                                <AlertTriangle className="w-3 h-3" />
                              )}
                              {record.status === 'success' ? '成功' : '失败'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)]">
                            {record.operator}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-xs text-[var(--neutral-text-secondary)]"
                            >
                              详情
                              <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                {/* 分页 */}
                <div className="flex items-center justify-between mt-3 px-1">
                  <div className="text-xs text-[var(--neutral-text-tertiary)]">
                    共 {filteredRecords.length} 条记录
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="outline" size="sm" className="h-7 text-xs px-2">
                      上一页
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 text-xs px-2"
                    >
                      下一页
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>

        {/* ========== 规则配置 Tab ========== */}
        <TabsContent value="rules" className="space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base text-[var(--neutral-text-primary)]">
                      联动规则配置
                    </CardTitle>
                    <CardDescription className="text-xs mt-0.5">
                      管理围栏触发后的自动联动规则，启用或禁用规则
                    </CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" className="h-8 text-xs">
                        <Plus className="w-3.5 h-3.5 mr-1" />
                        新建规则
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-lg bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
                      <DialogHeader>
                        <DialogTitle className="text-[var(--neutral-text-primary)]">
                          新建联动规则
                        </DialogTitle>
                        <DialogDescription className="text-[var(--neutral-text-secondary)]">
                          配置围栏触发条件和自动执行动作
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-3">
                        <div>
                          <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                            规则名称
                          </label>
                          <Input
                            placeholder="如：入库自动确认规则"
                            className="h-8 text-sm"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                            规则描述
                          </label>
                          <Input
                            placeholder="描述规则的业务场景和作用"
                            className="h-8 text-sm"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                              触发条件
                            </label>
                            <Select>
                              <SelectTrigger className="h-8 text-sm">
                                <SelectValue placeholder="选择条件" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="enter">车辆进入围栏</SelectItem>
                                <SelectItem value="leave">车辆离开围栏</SelectItem>
                                <SelectItem value="stay">车辆停留超时</SelectItem>
                                <SelectItem value="unauthorized">未授权车辆</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="text-xs font-medium text-[var(--neutral-text-secondary)] mb-1 block">
                              执行动作
                            </label>
                            <Select>
                              <SelectTrigger className="h-8 text-sm">
                                <SelectValue placeholder="选择动作" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="in">自动入库</SelectItem>
                                <SelectItem value="out">自动出库</SelectItem>
                                <SelectItem value="alarm">发送报警</SelectItem>
                                <SelectItem value="notify">通知调度员</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" size="sm" className="text-xs">
                          取消
                        </Button>
                        <Button size="sm" className="text-xs">
                          创建规则
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-3">
                  {rules.map((rule, index) => (
                    <motion.div
                      key={rule.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.25, delay: index * 0.05 }}
                      className="p-4 rounded-lg border border-[var(--neutral-border)] hover:shadow-sm transition-shadow bg-[var(--neutral-background)]"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                              rule.enabled
                                ? 'bg-blue-500/10 text-blue-500'
                                : 'bg-gray-200 text-gray-400'
                            }`}
                          >
                            <Settings className="w-5 h-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-semibold text-[var(--neutral-text-primary)]">
                                {rule.name}
                              </span>
                              <Badge
                                variant="outline"
                                className="text-[10px] h-5"
                              >
                                优先级 {rule.priority}
                              </Badge>
                              {rule.enabled ? (
                                <Badge
                                  variant="default"
                                  className="text-[10px] h-5 gap-1"
                                >
                                  <Play className="w-3 h-3" />
                                  运行中
                                </Badge>
                              ) : (
                                <Badge
                                  variant="secondary"
                                  className="text-[10px] h-5 gap-1"
                                >
                                  已停用
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-[var(--neutral-text-secondary)] mb-2">
                              {rule.description}
                            </p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              <div className="flex items-start gap-1.5 text-xs">
                                <ChevronRight className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)] mt-0.5 flex-shrink-0" />
                                <div>
                                  <span className="text-[var(--neutral-text-tertiary)]">
                                    触发条件：
                                  </span>
                                  <span className="text-[var(--neutral-text-secondary)]">
                                    {rule.triggerCondition}
                                  </span>
                                </div>
                              </div>
                              <div className="flex items-start gap-1.5 text-xs">
                                <ChevronRight className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)] mt-0.5 flex-shrink-0" />
                                <div>
                                  <span className="text-[var(--neutral-text-tertiary)]">
                                    执行动作：
                                  </span>
                                  <span className="text-[var(--neutral-text-secondary)]">
                                    {rule.action}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Switch
                            checked={rule.enabled}
                            onCheckedChange={() => toggleRule(rule.id)}
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-[var(--neutral-text-secondary)]"
                            title="编辑"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-red-500 hover:text-red-600"
                            title="删除"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
