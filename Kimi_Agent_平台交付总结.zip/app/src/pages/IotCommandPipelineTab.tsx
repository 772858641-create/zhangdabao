import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Terminal, CheckCircle, XCircle, Clock,
  Layers, Server, Activity, Shield
} from 'lucide-react';
import {
  queueRecords,
  commandFlows,
} from './iot-commands/types';
import QueueMonitor from './iot-commands/QueueMonitor';
import RealtimeTracking from './iot-commands/RealtimeTracking';
import QoSManager from './iot-commands/QoSManager';
import BatchCommandManager from './iot-commands/BatchCommandManager';

function KpiCard({ icon, label, value, subtext, colorClass, delay }: {
  icon: React.ReactNode; label: string; value: string; subtext: string; colorClass: string; delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
    >
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] hover:shadow-lg transition-shadow duration-300">
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-sm text-[var(--neutral-textSecondary)] mb-1">{label}</p>
              <p className={`text-2xl font-bold ${colorClass} truncate`}>{value}</p>
              <p className="text-xs text-[var(--neutral-textSecondary)] mt-1">{subtext}</p>
            </div>
            <div className={`p-3 rounded-xl ${colorClass.replace('text-', 'bg-').replace('600', '100')} bg-opacity-10`}>
              {icon}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default function IotCommandPipelineTab() {
  const [activeTab, setActiveTab] = useState('queue');

  // 计算KPI数据
  const totalQueueDepth = queueRecords.reduce((s, q) => s + q.queueDepth, 0);
  const todaySuccess = commandFlows.filter(f => f.status === 'success').length;
  const todayFailed = commandFlows.filter(f => f.status === 'failed').length;
  const avgResponseTime = Math.floor(Math.random() * 150 + 50);

  const kpiData = [
    {
      icon: <Layers className="w-6 h-6 text-blue-600" />,
      label: '指令队列总量',
      value: totalQueueDepth.toLocaleString(),
      subtext: `峰值容量 ${(queueRecords.length * 50).toLocaleString()}`,
      colorClass: 'text-blue-600',
      delay: 0,
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-emerald-600" />,
      label: '今日下发成功',
      value: todaySuccess.toString(),
      subtext: `成功率 ${((todaySuccess / (todaySuccess + todayFailed || 1)) * 100).toFixed(1)}%`,
      colorClass: 'text-emerald-600',
      delay: 0.08,
    },
    {
      icon: <XCircle className="w-6 h-6 text-red-600" />,
      label: '今日下发失败',
      value: todayFailed.toString(),
      subtext: '含超时与熔断',
      colorClass: 'text-red-600',
      delay: 0.16,
    },
    {
      icon: <Clock className="w-6 h-6 text-amber-600" />,
      label: '平均响应时间',
      value: `${avgResponseTime}ms`,
      subtext: '近7天平均',
      colorClass: 'text-amber-600',
      delay: 0.24,
    },
  ];

  return (
    <div className="p-6 space-y-6 bg-[var(--neutral-background)] min-h-screen">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600">
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-[var(--neutral-textPrimary)]">指令管道管理</h1>
            <p className="text-sm text-[var(--neutral-textSecondary)]">设备控制命令的可靠传输与监控中心</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200 gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            实时监控中
          </Badge>
        </div>
      </motion.div>

      {/* KPI 卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpiData.map(kpi => (
          <KpiCard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Tab 切换 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-[var(--neutral-surface)] border border-[var(--neutral-border)] p-1">
          <TabsTrigger value="queue" className="data-[state=active]:bg-[var(--neutral-textPrimary)] data-[state=active]:text-white gap-1.5">
            <Server className="w-4 h-4" /> 队列监控
          </TabsTrigger>
          <TabsTrigger value="track" className="data-[state=active]:bg-[var(--neutral-textPrimary)] data-[state=active]:text-white gap-1.5">
            <Activity className="w-4 h-4" /> 实时追踪
          </TabsTrigger>
          <TabsTrigger value="qos" className="data-[state=active]:bg-[var(--neutral-textPrimary)] data-[state=active]:text-white gap-1.5">
            <Shield className="w-4 h-4" /> QoS与熔断
          </TabsTrigger>
          <TabsTrigger value="batch" className="data-[state=active]:bg-[var(--neutral-textPrimary)] data-[state=active]:text-white gap-1.5">
            <Layers className="w-4 h-4" /> 批量管理
          </TabsTrigger>
        </TabsList>

        <AnimatePresence mode="wait">
          <TabsContent value="queue" className="mt-0">
            {activeTab === 'queue' && <QueueMonitor />}
          </TabsContent>
          <TabsContent value="track" className="mt-0">
            {activeTab === 'track' && <RealtimeTracking />}
          </TabsContent>
          <TabsContent value="qos" className="mt-0">
            {activeTab === 'qos' && <QoSManager />}
          </TabsContent>
          <TabsContent value="batch" className="mt-0">
            {activeTab === 'batch' && <BatchCommandManager />}
          </TabsContent>
        </AnimatePresence>
      </Tabs>
    </div>
  );
}
