import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Clock, Eye, CheckCircle, AlertTriangle, RotateCcw,
  Search, ArrowRight, X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
interface TransferOrder {
  id: string;
  orderNo: string;
  fromOrg: string;
  toOrg: string;
  carrierCount: number;
  type: string;
  priority: 'high' | 'medium' | 'low';
  applyTime: string;
  applicant: string;
  expectArrival: string;
  status: string;
  auditTime?: string;
  auditor?: string;
  auditRemark?: string;
  result?: string;
}

interface ReceiptRecord {
  id: string;
  orderNo: string;
  fromOrg: string;
  toOrg: string;
  carrierCount: number;
  sendTime: string;
  arrivalTime: string;
  duration: string;
  status: string;
}

interface ExceptionRecord {
  id: string;
  relatedOrder: string;
  excType: string;
  description: string;
  submitTime: string;
  status: string;
}

interface ReverseTransfer {
  id: string;
  reverseNo: string;
  originalOrder: string;
  reason: string;
  fromOrg: string;
  toOrg: string;
  carrierCount: number;
  status: string;
}

// ==================== Mock Data ====================
const pendingOrders: TransferOrder[] = [
  { id: 'A001', orderNo: 'TB-20250429-0089', fromOrg: '华东分部-上海', toOrg: '华南分部-广州', carrierCount: 45, type: '普通调拨', priority: 'high', applyTime: '2025-04-29 08:30', applicant: '张伟', expectArrival: '2025-04-30 18:00', status: 'pending' },
  { id: 'A002', orderNo: 'TB-20250429-0090', fromOrg: '华北分部-北京', toOrg: '华东分部-苏州', carrierCount: 120, type: '紧急调拨', priority: 'high', applyTime: '2025-04-29 09:15', applicant: '李强', expectArrival: '2025-04-29 22:00', status: 'pending' },
  { id: 'A003', orderNo: 'TB-20250429-0091', fromOrg: '华中分部-武汉', toOrg: '西南分部-成都', carrierCount: 32, type: '跨区调拨', priority: 'medium', applyTime: '2025-04-29 10:00', applicant: '王芳', expectArrival: '2025-05-01 12:00', status: 'pending' },
  { id: 'A004', orderNo: 'TB-20250429-0092', fromOrg: '华南分部-深圳', toOrg: '华东分部-宁波', carrierCount: 68, type: '普通调拨', priority: 'medium', applyTime: '2025-04-29 11:20', applicant: '赵磊', expectArrival: '2025-05-01 10:00', status: 'pending' },
  { id: 'A005', orderNo: 'TB-20250429-0093', fromOrg: '华东分部-苏州', toOrg: '华北分部-天津', carrierCount: 15, type: '普通调拨', priority: 'low', applyTime: '2025-04-29 13:45', applicant: '孙丽', expectArrival: '2025-05-02 09:00', status: 'pending' },
  { id: 'A006', orderNo: 'TB-20250429-0094', fromOrg: '西南分部-重庆', toOrg: '华中分部-长沙', carrierCount: 55, type: '紧急调拨', priority: 'high', applyTime: '2025-04-29 14:10', applicant: '周杰', expectArrival: '2025-04-30 08:00', status: 'pending' },
  { id: 'A007', orderNo: 'TB-20250429-0095', fromOrg: '华南分部-佛山', toOrg: '华东分部-杭州', carrierCount: 28, type: '普通调拨', priority: 'low', applyTime: '2025-04-29 15:30', applicant: '吴敏', expectArrival: '2025-05-02 15:00', status: 'pending' },
  { id: 'A008', orderNo: 'TB-20250429-0096', fromOrg: '华北分部-青岛', toOrg: '华南分部-东莞', carrierCount: 90, type: '跨区调拨', priority: 'medium', applyTime: '2025-04-29 16:00', applicant: '郑华', expectArrival: '2025-05-03 12:00', status: 'pending' },
  { id: 'A009', orderNo: 'TB-20250428-0085', fromOrg: '华中分部-郑州', toOrg: '西南分部-昆明', carrierCount: 40, type: '普通调拨', priority: 'medium', applyTime: '2025-04-28 09:00', applicant: '陈静', expectArrival: '2025-04-30 10:00', status: 'pending' },
  { id: 'A010', orderNo: 'TB-20250428-0086', fromOrg: '华东分部-南京', toOrg: '华北分部-石家庄', carrierCount: 22, type: '普通调拨', priority: 'low', applyTime: '2025-04-28 11:30', applicant: '刘洋', expectArrival: '2025-05-01 16:00', status: 'pending' },
];

const auditHistory: TransferOrder[] = [
  { id: 'H001', orderNo: 'TB-20250427-0078', fromOrg: '华东分部-上海', toOrg: '华南分部-广州', carrierCount: 60, type: '普通调拨', priority: 'medium', applyTime: '2025-04-27 08:00', applicant: '张三', expectArrival: '2025-04-28 18:00', status: 'audited', auditTime: '2025-04-27 10:30', auditor: '李审核', auditRemark: '库存充足，同意调拨', result: 'approved' },
  { id: 'H002', orderNo: 'TB-20250427-0079', fromOrg: '华北分部-北京', toOrg: '华东分部-苏州', carrierCount: 30, type: '紧急调拨', priority: 'high', applyTime: '2025-04-27 09:00', applicant: '王五', expectArrival: '2025-04-27 22:00', status: 'audited', auditTime: '2025-04-27 11:00', auditor: '赵审核', auditRemark: '紧急需求，优先处理', result: 'approved' },
  { id: 'H003', orderNo: 'TB-20250426-0070', fromOrg: '华中分部-武汉', toOrg: '西南分部-成都', carrierCount: 50, type: '跨区调拨', priority: 'medium', applyTime: '2025-04-26 10:00', applicant: '李四', expectArrival: '2025-04-28 12:00', status: 'audited', auditTime: '2025-04-26 14:00', auditor: '钱审核', auditRemark: '路线调整，暂不调拨', result: 'rejected' },
  { id: 'H004', orderNo: 'TB-20250426-0071', fromOrg: '华南分部-深圳', toOrg: '华东分部-宁波', carrierCount: 80, type: '普通调拨', priority: 'low', applyTime: '2025-04-26 11:00', applicant: '赵六', expectArrival: '2025-04-28 10:00', status: 'audited', auditTime: '2025-04-26 16:00', auditor: '孙审核', auditRemark: '同意', result: 'approved' },
  { id: 'H005', orderNo: 'TB-20250425-0065', fromOrg: '华东分部-苏州', toOrg: '华北分部-天津', carrierCount: 25, type: '普通调拨', priority: 'low', applyTime: '2025-04-25 09:00', applicant: '钱七', expectArrival: '2025-04-27 09:00', status: 'audited', auditTime: '2025-04-25 11:30', auditor: '周审核', auditRemark: '组织变更，驳回', result: 'rejected' },
  { id: 'H006', orderNo: 'TB-20250425-0066', fromOrg: '西南分部-重庆', toOrg: '华中分部-长沙', carrierCount: 70, type: '紧急调拨', priority: 'high', applyTime: '2025-04-25 10:00', applicant: '孙八', expectArrival: '2025-04-26 08:00', status: 'audited', auditTime: '2025-04-25 12:00', auditor: '吴审核', auditRemark: '通过', result: 'approved' },
  { id: 'H007', orderNo: 'TB-20250424-0060', fromOrg: '华南分部-佛山', toOrg: '华东分部-杭州', carrierCount: 35, type: '普通调拨', priority: 'medium', applyTime: '2025-04-24 08:00', applicant: '周九', expectArrival: '2025-04-26 15:00', status: 'audited', auditTime: '2025-04-24 10:00', auditor: '郑审核', auditRemark: '库存不足，驳回', result: 'rejected' },
  { id: 'H008', orderNo: 'TB-20250424-0061', fromOrg: '华北分部-青岛', toOrg: '华南分部-东莞', carrierCount: 100, type: '跨区调拨', priority: 'high', applyTime: '2025-04-24 09:00', applicant: '吴十', expectArrival: '2025-04-27 12:00', status: 'audited', auditTime: '2025-04-24 11:00', auditor: '王审核', auditRemark: '同意调拨', result: 'approved' },
];

const receiptRecords: ReceiptRecord[] = [
  { id: 'R001', orderNo: 'TB-20250425-0066', fromOrg: '西南分部-重庆', toOrg: '华中分部-长沙', carrierCount: 70, sendTime: '2025-04-25 14:00', arrivalTime: '2025-04-26 06:30', duration: '16.5小时', status: 'pending_receipt' },
  { id: 'R002', orderNo: 'TB-20250424-0061', fromOrg: '华北分部-青岛', toOrg: '华南分部-东莞', carrierCount: 100, sendTime: '2025-04-24 13:00', arrivalTime: '2025-04-26 08:00', duration: '43小时', status: 'pending_receipt' },
  { id: 'R003', orderNo: 'TB-20250427-0078', fromOrg: '华东分部-上海', toOrg: '华南分部-广州', carrierCount: 60, sendTime: '2025-04-27 12:00', arrivalTime: '2025-04-28 10:00', duration: '22小时', status: 'pending_receipt' },
  { id: 'R004', orderNo: 'TB-20250427-0079', fromOrg: '华北分部-北京', toOrg: '华东分部-苏州', carrierCount: 30, sendTime: '2025-04-27 14:00', arrivalTime: '2025-04-27 20:00', duration: '6小时', status: 'received' },
  { id: 'R005', orderNo: 'TB-20250426-0071', fromOrg: '华南分部-深圳', toOrg: '华东分部-宁波', carrierCount: 80, sendTime: '2025-04-26 18:00', arrivalTime: '2025-04-28 09:00', duration: '39小时', status: 'partial' },
  { id: 'R006', orderNo: 'TB-20250423-0055', fromOrg: '华中分部-武汉', toOrg: '华东分部-上海', carrierCount: 45, sendTime: '2025-04-23 10:00', arrivalTime: '2025-04-24 16:00', duration: '30小时', status: 'exception' },
  { id: 'R007', orderNo: 'TB-20250422-0050', fromOrg: '华南分部-广州', toOrg: '华北分部-北京', carrierCount: 55, sendTime: '2025-04-22 08:00', arrivalTime: '2025-04-24 12:00', duration: '52小时', status: 'received' },
  { id: 'R008', orderNo: 'TB-20250421-0045', fromOrg: '华东分部-杭州', toOrg: '西南分部-成都', carrierCount: 38, sendTime: '2025-04-21 14:00', arrivalTime: '2025-04-23 20:00', duration: '54小时', status: 'pending_receipt' },
];

const exceptionRecords: ExceptionRecord[] = [
  { id: 'E001', relatedOrder: 'TB-20250423-0055', excType: '数量不符', description: '实际到达42个载具，比调拨单少3个', submitTime: '2025-04-24 16:30', status: 'pending' },
  { id: 'E002', relatedOrder: 'TB-20250420-0040', excType: '载具损坏', description: '运输途中5个载具出现结构性损坏', submitTime: '2025-04-21 09:00', status: 'processing' },
  { id: 'E003', relatedOrder: 'TB-20250418-0035', excType: '延迟到达', description: '原定4月19日到达，实际4月22日才到', submitTime: '2025-04-22 10:00', status: 'resolved' },
  { id: 'E004', relatedOrder: 'TB-20250415-0030', excType: '载具丢失', description: '2个载具在运输途中失联', submitTime: '2025-04-16 08:00', status: 'pending' },
  { id: 'E005', relatedOrder: 'TB-20250412-0025', excType: '数量不符', description: '多出2个未登记载具', submitTime: '2025-04-13 14:00', status: 'processing' },
  { id: 'E006', relatedOrder: 'TB-20250410-0020', excType: '载具损坏', description: '8个载具表面严重刮擦', submitTime: '2025-04-11 11:00', status: 'resolved' },
];

const reverseTransfers: ReverseTransfer[] = [
  { id: 'V001', reverseNo: 'RT-20250428-001', originalOrder: 'TB-20250420-0040', reason: '客户退货', fromOrg: '华南分部-广州', toOrg: '华东分部-上海', carrierCount: 15, status: 'draft' },
  { id: 'V002', reverseNo: 'RT-20250427-002', originalOrder: 'TB-20250418-0035', reason: '质量问题', fromOrg: '华中分部-长沙', toOrg: '西南分部-重庆', carrierCount: 8, status: 'auditing' },
  { id: 'V003', reverseNo: 'RT-20250426-003', originalOrder: 'TB-20250415-0030', reason: '调拨错误', fromOrg: '华北分部-天津', toOrg: '华东分部-苏州', carrierCount: 22, status: 'sent' },
  { id: 'V004', reverseNo: 'RT-20250425-004', originalOrder: 'TB-20250412-0025', reason: '库存调整', fromOrg: '华南分部-东莞', toOrg: '华北分部-青岛', carrierCount: 10, status: 'received' },
  { id: 'V005', reverseNo: 'RT-20250424-005', originalOrder: 'TB-20250410-0020', reason: '客户退货', fromOrg: '西南分部-成都', toOrg: '华中分部-武汉', carrierCount: 6, status: 'draft' },
];

// ==================== Helpers ====================
function getPriorityBadge(p: string) {
  if (p === 'high') return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">高</Badge>;
  if (p === 'medium') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">中</Badge>;
  return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">低</Badge>;
}

function getResultBadge(r: string) {
  if (r === 'approved') return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已通过</Badge>;
  if (r === 'rejected') return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">已驳回</Badge>;
  return <Badge variant="secondary">{r}</Badge>;
}

function getReceiptBadge(s: string) {
  if (s === 'pending_receipt') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">待签收</Badge>;
  if (s === 'received') return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已签收</Badge>;
  if (s === 'partial') return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">部分签收</Badge>;
  return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">异常签收</Badge>;
}

function getExcStatusBadge(s: string) {
  if (s === 'pending') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">待处理</Badge>;
  if (s === 'processing') return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">处理中</Badge>;
  return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已解决</Badge>;
}

function getReverseStatusBadge(s: string) {
  if (s === 'draft') return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">草稿</Badge>;
  if (s === 'auditing') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">审核中</Badge>;
  if (s === 'sent') return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">已发出</Badge>;
  return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已签收</Badge>;
}

export default function TransferAuditPage() {
  const [activeTab, setActiveTab] = useState('pending');
  const [search, setSearch] = useState('');
  const [pendingData, setPendingData] = useState(pendingOrders);
  const [historyData] = useState(auditHistory);
  const [receiptData] = useState(receiptRecords);
  const [excData, setExcData] = useState(exceptionRecords);
  const [reverseData, setReverseData] = useState(reverseTransfers);

  // Dialogs
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [excReceiptOpen, setExcReceiptOpen] = useState(false);
  const [handleExcOpen, setHandleExcOpen] = useState(false);
  const [createReverseOpen, setCreateReverseOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<TransferOrder | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<ReceiptRecord | null>(null);
  const [selectedExc, setSelectedExc] = useState<ExceptionRecord | null>(null);

  // Form states
  const [approveRemark, setApproveRemark] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [rejectRemark, setRejectRemark] = useState('');
  const [actualCount, setActualCount] = useState('');
  const [receiptRemark, setReceiptRemark] = useState('');
  const [excType, setExcType] = useState('');
  const [excDesc, setExcDesc] = useState('');
  const [handleMethod, setHandleMethod] = useState('');
  const [handleResult, setHandleResult] = useState('');
  const [handlePerson, setHandlePerson] = useState('');
  const [reverseReason, setReverseReason] = useState('');
  const [reverseRemark, setReverseRemark] = useState('');

  const filteredPending = useMemo(() => {
    return pendingData.filter(o => o.orderNo.toLowerCase().includes(search.toLowerCase()));
  }, [pendingData, search]);

  const stats = useMemo(() => ({
    pending: pendingData.length,
    auditing: pendingData.filter(o => o.status === 'auditing').length + historyData.filter(o => o.result === 'approved' && !o.auditTime).length,
    received: receiptData.filter(r => r.status === 'received').length,
    exception: excData.filter(e => e.status !== 'resolved').length,
    reverse: reverseData.length,
  }), [pendingData, historyData, receiptData, excData, reverseData]);

  const openApprove = (o: TransferOrder) => { setSelectedOrder(o); setApproveRemark(''); setApproveOpen(true); };
  const openReject = (o: TransferOrder) => { setSelectedOrder(o); setRejectReason(''); setRejectRemark(''); setRejectOpen(true); };
  const openReceipt = (r: ReceiptRecord) => { setSelectedReceipt(r); setActualCount(String(r.carrierCount)); setReceiptRemark(''); setReceiptOpen(true); };
  const openExcReceipt = (r: ReceiptRecord) => { setSelectedReceipt(r); setExcType(''); setExcDesc(''); setExcReceiptOpen(true); };
  const openHandleExc = (e: ExceptionRecord) => { setSelectedExc(e); setHandleMethod(''); setHandleResult(''); setHandlePerson(''); setHandleExcOpen(true); };

  const confirmApprove = () => {
    if (!selectedOrder) return;
    setPendingData(prev => prev.filter(o => o.id !== selectedOrder.id));
    setApproveOpen(false);
    alert(`调拨单 ${selectedOrder.orderNo} 已通过审核`);
  };

  const confirmReject = () => {
    if (!selectedOrder) return;
    setPendingData(prev => prev.filter(o => o.id !== selectedOrder.id));
    setRejectOpen(false);
    alert(`调拨单 ${selectedOrder.orderNo} 已驳回\n原因：${rejectReason}`);
  };

  const confirmReceipt = () => {
    setReceiptOpen(false);
    alert('签收成功');
  };

  const submitExcReceipt = () => {
    setExcReceiptOpen(false);
    alert('异常签收已提交');
  };

  const submitHandleExc = () => {
    if (!selectedExc) return;
    setExcData(prev => prev.map(e => e.id === selectedExc.id ? { ...e, status: 'resolved' as const } : e));
    setHandleExcOpen(false);
    alert('异常处理已提交');
  };

  const createReverse = () => {
    setCreateReverseOpen(false);
    alert('反向调拨单已创建');
  };

  const deleteReverse = (id: string) => {
    setReverseData(prev => prev.filter(r => r.id !== id));
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">调拨审核流程</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">调入审批 · 到货签收 · 异常处理 · 反向调拨</p>
        </div>
        <Button size="sm" onClick={() => { setReverseReason(''); setReverseRemark(''); setCreateReverseOpen(true); }}>
          <RotateCcw className="w-4 h-4 mr-1" />创建反向调拨
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '待审核', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '审核中', value: stats.auditing, icon: Eye, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '已签收', value: stats.received, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '异常处理', value: stats.exception, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
          { label: '反向调拨', value: stats.reverse, icon: RotateCcw, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-[600px]">
          <TabsTrigger value="pending">待审核 ({stats.pending})</TabsTrigger>
          <TabsTrigger value="history">审核历史</TabsTrigger>
          <TabsTrigger value="receipt">到货签收</TabsTrigger>
          <TabsTrigger value="exception">异常处理</TabsTrigger>
          <TabsTrigger value="reverse">反向调拨</TabsTrigger>
        </TabsList>

        {/* Tab 1: Pending */}
        <TabsContent value="pending" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索调拨单号..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
          </div>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">调拨单号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">调出组织</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">调入组织</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">优先级</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">申请时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">申请人</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">期望到达</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPending.map(o => (
                    <TableRow key={o.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{o.orderNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{o.fromOrg}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{o.toOrg}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)] font-medium">{o.carrierCount}</TableCell>
                      <TableCell><Badge variant="outline">{o.type}</Badge></TableCell>
                      <TableCell>{getPriorityBadge(o.priority)}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{o.applyTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{o.applicant}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{o.expectArrival}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="sm" className="h-7 text-emerald-600" onClick={() => openApprove(o)}>通过</Button>
                          <Button variant="ghost" size="sm" className="h-7 text-red-500" onClick={() => openReject(o)}>驳回</Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: History */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">调拨单号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">调出→调入</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">审核结果</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">审核时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">审核人</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">备注</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historyData.map(h => (
                    <TableRow key={h.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{h.orderNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{h.fromOrg}<ArrowRight className="inline w-3 h-3 mx-1" />{h.toOrg}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{h.carrierCount}</TableCell>
                      <TableCell>{getResultBadge(h.result || '')}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.auditTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.auditor}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{h.auditRemark}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Receipt */}
        <TabsContent value="receipt" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">调拨单号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">调出→调入</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">发出时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">到达时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">运输时长</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">签收状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {receiptData.map(r => (
                    <TableRow key={r.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{r.orderNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{r.fromOrg}<ArrowRight className="inline w-3 h-3 mx-1" />{r.toOrg}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{r.carrierCount}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.sendTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.arrivalTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.duration}</TableCell>
                      <TableCell>{getReceiptBadge(r.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {r.status === 'pending_receipt' && (
                            <>
                              <Button variant="ghost" size="sm" className="h-7 text-emerald-600" onClick={() => openReceipt(r)}>签收</Button>
                              <Button variant="ghost" size="sm" className="h-7 text-red-500" onClick={() => openExcReceipt(r)}>异常</Button>
                            </>
                          )}
                          {r.status !== 'pending_receipt' && (
                            <Button variant="ghost" size="sm" className="h-7">查看</Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 4: Exception */}
        <TabsContent value="exception" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">异常编号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">关联调拨单</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">异常类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">异常描述</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">提交时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">处理状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {excData.map(e => (
                    <TableRow key={e.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{e.id}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{e.relatedOrder}</TableCell>
                      <TableCell><Badge variant="outline">{e.excType}</Badge></TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs max-w-[200px] truncate">{e.description}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{e.submitTime}</TableCell>
                      <TableCell>{getExcStatusBadge(e.status)}</TableCell>
                      <TableCell className="text-right">
                        {e.status !== 'resolved' && (
                          <Button variant="ghost" size="sm" className="h-7 text-blue-600" onClick={() => openHandleExc(e)}>处理</Button>
                        )}
                        {e.status === 'resolved' && (
                          <Button variant="ghost" size="sm" className="h-7">查看</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 5: Reverse */}
        <TabsContent value="reverse" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">反向调拨单号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">原调拨单</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">召回原因</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">召回→目标</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reverseData.map(v => (
                    <TableRow key={v.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{v.reverseNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{v.originalOrder}</TableCell>
                      <TableCell><Badge variant="outline">{v.reason}</Badge></TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{v.fromOrg}<ArrowRight className="inline w-3 h-3 mx-1" />{v.toOrg}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{v.carrierCount}</TableCell>
                      <TableCell>{getReverseStatusBadge(v.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="sm" className="h-7">查看</Button>
                          {v.status === 'draft' && (
                            <Button variant="ghost" size="sm" className="h-7 text-red-500" onClick={() => deleteReverse(v.id)}>
                              <X className="w-3 h-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ========== Dialogs ========== */}

      {/* Approve Dialog */}
      <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>审核通过</DialogTitle></DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">调拨单号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedOrder.orderNo}</span></div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">调入组织：{selectedOrder.toOrg}，载具数量：{selectedOrder.carrierCount}</div>
              <div>
                <Label className="text-sm font-medium">审核备注</Label>
                <Textarea value={approveRemark} onChange={e => setApproveRemark(e.target.value)} placeholder="输入审核备注（可选）" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setApproveOpen(false)}>取消</Button>
                <Button onClick={confirmApprove} className="bg-emerald-600 hover:bg-emerald-700">确认通过</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>驳回调拨</DialogTitle></DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">调拨单号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedOrder.orderNo}</span></div>
              <div>
                <Label className="text-sm font-medium">驳回原因</Label>
                <Select value={rejectReason} onValueChange={setRejectReason}>
                  <SelectTrigger><SelectValue placeholder="选择驳回原因" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="库存不足">库存不足</SelectItem>
                    <SelectItem value="路线调整">路线调整</SelectItem>
                    <SelectItem value="组织变更">组织变更</SelectItem>
                    <SelectItem value="其他">其他</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">备注</Label>
                <Textarea value={rejectRemark} onChange={e => setRejectRemark(e.target.value)} placeholder="输入备注" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setRejectOpen(false)}>取消</Button>
                <Button variant="destructive" onClick={confirmReject} disabled={!rejectReason}>确认驳回</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Receipt Dialog */}
      <Dialog open={receiptOpen} onOpenChange={setReceiptOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>到货签收</DialogTitle></DialogHeader>
          {selectedReceipt && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">调拨单号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedReceipt.orderNo}</span></div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">调入组织：{selectedReceipt.toOrg}</div>
              <div>
                <Label className="text-sm font-medium">实际到达载具数量</Label>
                <Input type="number" value={actualCount} onChange={e => setActualCount(e.target.value)} />
              </div>
              <div>
                <Label className="text-sm font-medium">载具状态检查</Label>
                <div className="space-y-2 mt-2">
                  {['外观完好', '结构无损坏', '编号可识别', '数量核对无误'].map(item => (
                    <div key={item} className="flex items-center gap-2">
                      <Checkbox id={item} defaultChecked />
                      <label htmlFor={item} className="text-sm text-[var(--neutral-text-primary)]">{item}</label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">备注</Label>
                <Textarea value={receiptRemark} onChange={e => setReceiptRemark(e.target.value)} placeholder="签收备注" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setReceiptOpen(false)}>取消</Button>
                <Button onClick={confirmReceipt}>确认签收</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Exception Receipt Dialog */}
      <Dialog open={excReceiptOpen} onOpenChange={setExcReceiptOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>异常签收</DialogTitle></DialogHeader>
          {selectedReceipt && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">调拨单号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedReceipt.orderNo}</span></div>
              <div>
                <Label className="text-sm font-medium">异常类型</Label>
                <Select value={excType} onValueChange={setExcType}>
                  <SelectTrigger><SelectValue placeholder="选择异常类型" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="数量不符">数量不符</SelectItem>
                    <SelectItem value="载具损坏">载具损坏</SelectItem>
                    <SelectItem value="载具丢失">载具丢失</SelectItem>
                    <SelectItem value="延迟到达">延迟到达</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">异常描述</Label>
                <Textarea value={excDesc} onChange={e => setExcDesc(e.target.value)} placeholder="描述异常情况" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setExcReceiptOpen(false)}>取消</Button>
                <Button variant="destructive" onClick={submitExcReceipt} disabled={!excType}>提交异常</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Handle Exception Dialog */}
      <Dialog open={handleExcOpen} onOpenChange={setHandleExcOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>处理异常</DialogTitle></DialogHeader>
          {selectedExc && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">异常编号：{selectedExc.id}，关联调拨：{selectedExc.relatedOrder}</div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">异常类型：{selectedExc.excType}</div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">描述：{selectedExc.description}</div>
              <div>
                <Label className="text-sm font-medium">处理方式</Label>
                <Select value={handleMethod} onValueChange={setHandleMethod}>
                  <SelectTrigger><SelectValue placeholder="选择处理方式" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="重新发货">重新发货</SelectItem>
                    <SelectItem value="赔偿处理">赔偿处理</SelectItem>
                    <SelectItem value="调拨取消">调拨取消</SelectItem>
                    <SelectItem value="其他">其他</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">处理结果</Label>
                <Textarea value={handleResult} onChange={e => setHandleResult(e.target.value)} placeholder="输入处理结果" />
              </div>
              <div>
                <Label className="text-sm font-medium">责任人</Label>
                <Input value={handlePerson} onChange={e => setHandlePerson(e.target.value)} placeholder="输入责任人" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setHandleExcOpen(false)}>取消</Button>
                <Button onClick={submitHandleExc} disabled={!handleMethod}>提交处理</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Reverse Transfer Dialog */}
      <Dialog open={createReverseOpen} onOpenChange={setCreateReverseOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>创建反向调拨</DialogTitle></DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="text-sm font-medium">原调拨单号</Label>
              <Select>
                <SelectTrigger><SelectValue placeholder="选择原调拨单" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="TB-20250420-0040">TB-20250420-0040</SelectItem>
                  <SelectItem value="TB-20250418-0035">TB-20250418-0035</SelectItem>
                  <SelectItem value="TB-20250415-0030">TB-20250415-0030</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">召回原因</Label>
              <Select value={reverseReason} onValueChange={setReverseReason}>
                <SelectTrigger><SelectValue placeholder="选择召回原因" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="客户退货">客户退货</SelectItem>
                  <SelectItem value="质量问题">质量问题</SelectItem>
                  <SelectItem value="调拨错误">调拨错误</SelectItem>
                  <SelectItem value="库存调整">库存调整</SelectItem>
                  <SelectItem value="其他">其他</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">召回载具</Label>
              <div className="space-y-2 mt-2 border rounded-md p-3 bg-[var(--neutral-background)]">
                {['CA-20250401-001', 'CA-20250401-015', 'CA-20250402-032', 'CA-20250403-008'].map(c => (
                  <div key={c} className="flex items-center gap-2">
                    <Checkbox id={`c-${c}`} />
                    <label htmlFor={`c-${c}`} className="text-sm text-[var(--neutral-text-primary)]">{c}</label>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-sm font-medium">备注</Label>
              <Textarea value={reverseRemark} onChange={e => setReverseRemark(e.target.value)} placeholder="输入备注" />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateReverseOpen(false)}>取消</Button>
              <Button onClick={createReverse} disabled={!reverseReason}>创建</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
