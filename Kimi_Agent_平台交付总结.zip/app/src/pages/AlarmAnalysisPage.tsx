import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  BarChart3,
  PieChart,
  TrendingUp,
  AlertTriangle,
  Clock,
  Activity,
  Zap,
  Shield,
  Search,
  Eye,
  FileText,
  Users,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Server,
  ChevronRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  PieChart as RePieChart,
  Pie,
  Cell,
  ComposedChart,
  Area,
} from 'recharts';

// ─────────────────────────────────────────────
// 1. Mock Data
// ─────────────────────────────────────────────

// 1.1 30-day alarm trend
const trendData = Array.from({ length: 30 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (29 - i));
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const total = 30 + Math.floor(Math.random() * 40) + (i > 20 ? 15 : 0);
  const handled = Math.floor(total * (0.6 + Math.random() * 0.3));
  const unhandled = total - handled;
  return {
    date: `${month}-${day}`,
    total,
    handled,
    unhandled,
  };
});

// 1.2 17 alarm types
const ALARM_TYPES = [
  '标签分离', '设备离线', '在途超时', '呆滞报警', '温度异常',
  '湿度异常', '震动报警', '开门报警', '电量低', '信号弱',
  '围栏越界', '超速报警', '停留过长', '非法移动', '光照异常',
  '水浸报警', '烟感报警',
];
const TYPE_COLORS = [
  '#0ea5e9', '#8b5cf6', '#f59e0b', '#ef4444', '#10b981',
  '#06b6d4', '#f97316', '#ec4899', '#84cc16', '#6366f1',
  '#14b8a6', '#d946ef', '#f43f5e', '#3b82f6', '#eab308',
  '#22c55e', '#a855f7',
];
const alarmTypeData = ALARM_TYPES.map((name, i) => ({
  name,
  value: 120 + Math.floor(Math.random() * 380),
  color: TYPE_COLORS[i],
}));

// 1.3 Alarm level distribution
const levelData = [
  { level: '紧急', count: 156, color: '#ef4444' },
  { level: '重要', count: 342, color: '#f59e0b' },
  { level: '一般', count: 580, color: '#3b82f6' },
  { level: '提示', count: 289, color: '#10b981' },
];

// 1.4 KPIs
const kpiData = {
  avgResponse: '8.5 分钟',
  avgHandle: '42 分钟',
  timeoutRate: '4.2%',
  firstResolve: '91.6%',
  responseTrend: -12,
  handleTrend: -8,
  timeoutTrend: -1.5,
  resolveTrend: +3.2,
};

// 1.5 Efficiency trend (14 days)
const efficiencyTrend = Array.from({ length: 14 }, (_, i) => {
  const d = new Date();
  d.setDate(d.getDate() - (13 - i));
  const day = String(d.getDate()).padStart(2, '0');
  return {
    date: `${d.getMonth() + 1}-${day}`,
    responseTime: 5 + Math.floor(Math.random() * 10),
    handleTime: 25 + Math.floor(Math.random() * 30),
    timeoutRate: Number((2 + Math.random() * 5).toFixed(1)),
    firstResolve: Number((85 + Math.random() * 10).toFixed(1)),
  };
});

// 1.6 Handler ranking (10 people)
const handlerData = Array.from({ length: 10 }, (_, i) => ({
  rank: i + 1,
  name: ['张伟', '李娜', '王强', '刘洋', '陈静', '赵军', '孙丽', '周杰', '吴敏', '郑涛'][i],
  department: ['运维A组', '运维B组', '安全组', '设备组', '运维A组', '运维B组', '安全组', '设备组', '运维A组', '运维B组'][i],
  total: 180 - i * 12 + Math.floor(Math.random() * 20),
  resolved: 160 - i * 10 + Math.floor(Math.random() * 18),
  avgTime: 25 + Math.floor(Math.random() * 20),
  firstRate: Number((98 - i * 3 - Math.random() * 2).toFixed(1)),
  score: Number((98 - i * 4 + Math.random() * 3).toFixed(1)),
}));

// 1.7 Root cause Top10
const rootCauseData = [
  { cause: '网关覆盖不足/信号干扰', count: 186, category: '网络问题' },
  { cause: '设备电量耗尽', count: 142, category: '设备故障' },
  { cause: '路线规划不合理', count: 128, category: '运营问题' },
  { cause: '仓库调度策略问题', count: 115, category: '运营问题' },
  { cause: '环境温湿度超标', count: 98, category: '环境问题' },
  { cause: '传感器校准偏移', count: 87, category: '设备故障' },
  { cause: '司机操作不规范', count: 76, category: '人为因素' },
  { cause: '固件版本过旧', count: 65, category: '软件问题' },
  { cause: 'GPS信号遮挡', count: 54, category: '网络问题' },
  { cause: '电池老化衰减', count: 48, category: '设备故障' },
];

// 1.8 Root cause analysis table
const rootCauseTable = Array.from({ length: 12 }, (_, i) => ({
  id: `RC-${20250401 + i}`,
  alarmType: ALARM_TYPES[i % ALARM_TYPES.length],
  device: `DEV-${String(1000 + i * 17).padStart(4, '0')}`,
  site: ['上海浦东仓库', '苏州昆山工厂', '深圳龙岗仓库', '武汉东西湖仓库', '成都双流中心'][i % 5],
  rootCause: rootCauseData[i % rootCauseData.length].cause,
  confidence: ['HIGH', 'HIGH', 'MEDIUM', 'MEDIUM', 'LOW'][i % 5] as 'HIGH' | 'MEDIUM' | 'LOW',
  status: ['CONFIRMED', 'PENDING', 'PENDING', 'IGNORED', 'CONFIRMED'][i % 5] as 'CONFIRMED' | 'PENDING' | 'IGNORED',
  suggestion: '调整网关位置/更换电池/优化路线/校准传感器/升级固件'.split('/')[i % 5],
}));

// 1.9 Alarm correlation heatmap (8x8)
const heatLabels = ['标签分离', '设备离线', '在途超时', '温度异常', '电量低', '信号弱', '围栏越界', '震动报警'];
const heatmapData = heatLabels.map((label, row) =>
  heatLabels.map((_, col) => {
    const base = row === col ? 100 : Math.floor(Math.random() * 80);
    return base;
  })
);

// 1.10 Device profile (20 devices)
const deviceData = Array.from({ length: 20 }, (_, i) => ({
  rank: i + 1,
  deviceId: `DEV-${String(1001 + i).padStart(4, '0')}`,
  name: `智能温湿度传感器 ${String.fromCharCode(65 + i)}${Math.floor(Math.random() * 99)}`,
  site: ['上海浦东仓库', '苏州昆山工厂', '深圳龙岗仓库', '武汉东西湖仓库', '成都双流中心'][i % 5],
  totalAlarms: 120 - i * 5 + Math.floor(Math.random() * 15),
  thisMonth: 35 - Math.floor(i * 1.2) + Math.floor(Math.random() * 8),
  healthScore: Math.max(30, 95 - i * 3 - Math.floor(Math.random() * 5)),
  topType: ALARM_TYPES[i % ALARM_TYPES.length],
  lastAlarm: `2025-05-${String(20 + (i % 10)).padStart(2, '0')}`,
}));

// 1.11 24-hour distribution
const hourDist = Array.from({ length: 24 }, (_, i) => ({
  hour: `${String(i).padStart(2, '0')}:00`,
  count: Math.floor(10 + Math.random() * 60 + (i >= 8 && i <= 18 ? 30 : 0)),
}));

// 1.12 Weekday vs Weekend
const weekdayData = [
  { period: '00-04', weekday: 25, weekend: 18 },
  { period: '04-08', weekday: 35, weekend: 22 },
  { period: '08-12', weekday: 85, weekend: 45 },
  { period: '12-16', weekday: 78, weekend: 52 },
  { period: '16-20', weekday: 65, weekend: 48 },
  { period: '20-24', weekday: 40, weekend: 32 },
];

// 1.13 Prediction data
const predictionData = {
  thisWeekPredict: 285,
  lastWeekActual: 268,
  highRiskHours: ['09:00-10:00', '14:00-15:00', '17:00-18:00'],
  highRiskDevices: deviceData.filter((d) => d.healthScore < 70).slice(0, 5),
  dailyPredict: Array.from({ length: 7 }, (_, i) => ({
    day: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'][i],
    predict: 35 + Math.floor(Math.random() * 15),
    upper: 55 + Math.floor(Math.random() * 10),
    lower: 20 + Math.floor(Math.random() * 10),
  })),
};

// ─────────────────────────────────────────────
// 2. Helper Components
// ─────────────────────────────────────────────

function KpiCard({
  title,
  value,
  trend,
  trendUp,
  icon: Icon,
  subtitle,
}: {
  title: string;
  value: string;
  trend: number;
  trendUp: boolean;
  icon: React.ElementType;
  subtitle: string;
}) {
  return (
    <Card className="relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-1 mt-1">
          {trendUp ? (
            <ArrowUpRight className="h-3.5 w-3.5 text-emerald-500" />
          ) : (
            <ArrowDownRight className="h-3.5 w-3.5 text-emerald-500" />
          )}
          <span className="text-xs text-emerald-500 font-medium">{Math.abs(trend)}%</span>
          <span className="text-xs text-muted-foreground ml-1">{subtitle}</span>
        </div>
      </CardContent>
    </Card>
  );
}

function SectionTitle({ icon: Icon, title }: { icon: React.ElementType; title: string }) {
  return (
    <div className="flex items-center gap-2 mb-4">
      <div className="h-6 w-6 rounded bg-primary/10 flex items-center justify-center">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <h3 className="text-base font-semibold">{title}</h3>
    </div>
  );
}

// ─────────────────────────────────────────────
// 3. Sub-page Components
// ─────────────────────────────────────────────

function TrendAnalysis() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 30-day trend line chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <SectionTitle icon={TrendingUp} title="近30天每日报警数量趋势" />
            <CardDescription>总报警 / 已处理 / 未处理</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="total" name="总报警" stroke="#0ea5e9" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="handled" name="已处理" stroke="#10b981" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="unhandled" name="未处理" stroke="#ef4444" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Alarm type pie chart */}
        <Card>
          <CardHeader>
            <SectionTitle icon={PieChart} title="17种报警类型分布" />
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RePieChart>
                <Pie
                  data={alarmTypeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {alarmTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                  }}
                  formatter={(value: number, name: string) => [value, name]}
                />
                <Legend fontSize={12} />
              </RePieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Level distribution */}
      <Card>
        <CardHeader>
          <SectionTitle icon={BarChart3} title="报警级别分布" />
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={levelData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="level" tick={{ fontSize: 13 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 8,
                }}
              />
              <Bar dataKey="count" name="报警数量" radius={[6, 6, 0, 0]}>
                {levelData.map((entry, index) => (
                  <Cell key={`lvl-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}

function EfficiencyAnalysis() {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          title="平均响应时间"
          value={kpiData.avgResponse}
          trend={kpiData.responseTrend}
          trendUp={false}
          icon={Clock}
          subtitle="较上月"
        />
        <KpiCard
          title="平均处理时长"
          value={kpiData.avgHandle}
          trend={kpiData.handleTrend}
          trendUp={false}
          icon={Activity}
          subtitle="较上月"
        />
        <KpiCard
          title="超时率"
          value={kpiData.timeoutRate}
          trend={kpiData.timeoutTrend}
          trendUp={false}
          icon={AlertTriangle}
          subtitle="较上月"
        />
        <KpiCard
          title="一次解决率"
          value={kpiData.firstResolve}
          trend={kpiData.resolveTrend}
          trendUp={true}
          icon={Shield}
          subtitle="较上月"
        />
      </div>

      {/* Efficiency trend */}
      <Card>
        <CardHeader>
          <SectionTitle icon={TrendingUp} title="处理效率趋势（近14天）" />
          <CardDescription>响应时间与处理时长 / 超时率与一次解决率</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <ComposedChart data={efficiencyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis yAxisId="left" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" label={{ value: '分钟', angle: -90, position: 'insideLeft', fontSize: 12 }} />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" label={{ value: '%', angle: 90, position: 'insideRight', fontSize: 12 }} />
              <Tooltip
                contentStyle={{
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 8,
                }}
              />
              <Legend />
              <Bar yAxisId="left" dataKey="responseTime" name="响应时间(分钟)" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              <Bar yAxisId="left" dataKey="handleTime" name="处理时长(分钟)" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              <Line yAxisId="right" type="monotone" dataKey="timeoutRate" name="超时率(%)" stroke="#ef4444" strokeWidth={2} dot={false} />
              <Line yAxisId="right" type="monotone" dataKey="firstResolve" name="一次解决率(%)" stroke="#10b981" strokeWidth={2} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Handler ranking table */}
      <Card>
        <CardHeader>
          <SectionTitle icon={Users} title="处理人排行榜" />
          <CardDescription>按综合评分排序（共10人）</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">排名</TableHead>
                <TableHead>姓名</TableHead>
                <TableHead>部门</TableHead>
                <TableHead className="text-right">处理总数</TableHead>
                <TableHead className="text-right">已解决</TableHead>
                <TableHead className="text-right">平均用时</TableHead>
                <TableHead className="text-right">一次解决率</TableHead>
                <TableHead className="text-right">综合评分</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {handlerData.map((h) => (
                <TableRow key={h.rank} className={h.rank <= 3 ? 'bg-primary/5' : undefined}>
                  <TableCell>
                    <Badge variant={h.rank === 1 ? 'default' : h.rank <= 3 ? 'secondary' : 'outline'} className="w-8 justify-center">
                      {h.rank}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-medium">{h.name}</TableCell>
                  <TableCell>{h.department}</TableCell>
                  <TableCell className="text-right">{h.total}</TableCell>
                  <TableCell className="text-right">{h.resolved}</TableCell>
                  <TableCell className="text-right">{h.avgTime}m</TableCell>
                  <TableCell className="text-right">{h.firstRate}%</TableCell>
                  <TableCell className="text-right font-semibold">{h.score}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function RootCauseAnalysis() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState<(typeof rootCauseTable)[0] | null>(null);

  const confidenceColor = (c: string) => {
    if (c === 'HIGH') return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400';
    if (c === 'MEDIUM') return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400';
    return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400';
  };

  const statusColor = (s: string) => {
    if (s === 'CONFIRMED') return 'default';
    if (s === 'PENDING') return 'secondary';
    return 'outline';
  };

  return (
    <div className="space-y-6">
      {/* Top10 root cause bar chart */}
      <Card>
        <CardHeader>
          <SectionTitle icon={Search} title="Top10 报警根因排名" />
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={360}>
            <BarChart data={[...rootCauseData].reverse()} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis type="number" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis dataKey="cause" type="category" tick={{ fontSize: 11 }} width={160} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 8,
                }}
              />
              <Bar dataKey="count" name="出现次数" fill="#0ea5e9" radius={[0, 6, 6, 0]} barSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Root cause table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <SectionTitle icon={FileText} title="根因分析明细" />
            <CardDescription>共 {rootCauseTable.length} 条根因记录</CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Search className="h-4 w-4 mr-1" />
            筛选
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>编号</TableHead>
                <TableHead>报警类型</TableHead>
                <TableHead>设备</TableHead>
                <TableHead>站点</TableHead>
                <TableHead>根因推断</TableHead>
                <TableHead>置信度</TableHead>
                <TableHead>状态</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rootCauseTable.map((row) => (
                <TableRow key={row.id}>
                  <TableCell className="font-mono text-xs">{row.id}</TableCell>
                  <TableCell>{row.alarmType}</TableCell>
                  <TableCell className="font-mono text-xs">{row.device}</TableCell>
                  <TableCell>{row.site}</TableCell>
                  <TableCell className="max-w-[200px] truncate" title={row.rootCause}>
                    {row.rootCause}
                  </TableCell>
                  <TableCell>
                    <Badge className={confidenceColor(row.confidence)} variant="secondary">
                      {row.confidence}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={statusColor(row.status)}>{row.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog open={dialogOpen && selectedRow?.id === row.id} onOpenChange={setDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedRow(row)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <DialogTitle>根因详情</DialogTitle>
                        </DialogHeader>
                        {selectedRow && (
                          <div className="space-y-3 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">编号</span>
                              <span className="font-mono">{selectedRow.id}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">报警类型</span>
                              <span>{selectedRow.alarmType}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">设备</span>
                              <span className="font-mono">{selectedRow.device}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">站点</span>
                              <span>{selectedRow.site}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">根因</span>
                              <span className="text-right max-w-[280px]">{selectedRow.rootCause}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">置信度</span>
                              <Badge className={confidenceColor(selectedRow.confidence)} variant="secondary">
                                {selectedRow.confidence}
                              </Badge>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">状态</span>
                              <Badge variant={statusColor(selectedRow.status)}>{selectedRow.status}</Badge>
                            </div>
                            <div className="pt-2 border-t">
                              <span className="text-muted-foreground">建议措施</span>
                              <p className="mt-1 text-foreground">{selectedRow.suggestion}</p>
                            </div>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Heatmap */}
      <Card>
        <CardHeader>
          <SectionTitle icon={Activity} title="报警关联热力图" />
          <CardDescription>报警类型共现频率矩阵（颜色越深表示关联越强）</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <div className="min-w-[600px]">
              {/* Header */}
              <div className="grid grid-cols-[120px_repeat(8,1fr)] gap-1 mb-1">
                <div />
                {heatLabels.map((label) => (
                  <div key={label} className="text-[10px] text-center text-muted-foreground truncate px-1" title={label}>
                    {label}
                  </div>
                ))}
              </div>
              {/* Grid */}
              {heatLabels.map((rowLabel, row) => (
                <div key={rowLabel} className="grid grid-cols-[120px_repeat(8,1fr)] gap-1 mb-1">
                  <div className="text-[11px] text-muted-foreground truncate pr-2 flex items-center" title={rowLabel}>
                    {rowLabel}
                  </div>
                  {heatLabels.map((_, col) => {
                    const val = heatmapData[row][col];
                    const opacity = val / 100;
                    return (
                      <div
                        key={col}
                        className="h-10 rounded flex items-center justify-center text-[10px] font-medium cursor-pointer transition-transform hover:scale-110"
                        style={{
                          backgroundColor: `rgba(14, 165, 233, ${0.08 + opacity * 0.88})`,
                          color: opacity > 0.5 ? '#fff' : 'hsl(var(--foreground))',
                        }}
                        title={`${rowLabel} × ${heatLabels[col]}: ${val}`}
                      >
                        {val}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
          {/* Legend */}
          <div className="flex items-center gap-3 mt-4 justify-end">
            <span className="text-xs text-muted-foreground">弱</span>
            <div className="flex gap-0.5">
              {[0.1, 0.3, 0.5, 0.7, 0.9].map((op) => (
                <div key={op} className="w-5 h-3 rounded-sm" style={{ backgroundColor: `rgba(14, 165, 233, ${0.08 + op * 0.88})` }} />
              ))}
            </div>
            <span className="text-xs text-muted-foreground">强</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DeviceProfile() {
  return (
    <div className="space-y-6">
      {/* High risk alert banner */}
      <Card className="border-destructive/50 bg-destructive/5">
        <CardHeader className="flex flex-row items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-destructive" />
          <div>
            <CardTitle className="text-destructive text-base">高风险设备预警</CardTitle>
            <CardDescription>
              检测到 <strong>{deviceData.filter((d) => d.healthScore < 60).length}</strong> 台设备健康评分低于60，建议立即检修
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {deviceData
              .filter((d) => d.healthScore < 60)
              .map((d) => (
                <Badge key={d.deviceId} variant="destructive" className="gap-1">
                  <Zap className="h-3 w-3" />
                  {d.deviceId}（{d.healthScore}分）
                </Badge>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Device ranking table */}
      <Card>
        <CardHeader>
          <SectionTitle icon={Server} title="设备报警排名（Top20）" />
          <CardDescription>按报警总数降序排列</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">排名</TableHead>
                <TableHead>设备ID</TableHead>
                <TableHead>设备名称</TableHead>
                <TableHead>所属站点</TableHead>
                <TableHead className="text-right">总报警</TableHead>
                <TableHead className="text-right">本月报警</TableHead>
                <TableHead className="text-right">健康评分</TableHead>
                <TableHead>主要报警类型</TableHead>
                <TableHead>最近报警</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deviceData.map((dev) => (
                <TableRow key={dev.deviceId} className={dev.healthScore < 60 ? 'bg-destructive/5' : undefined}>
                  <TableCell>
                    <Badge variant={dev.rank <= 3 ? 'default' : 'outline'} className="w-8 justify-center">
                      {dev.rank}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-xs">{dev.deviceId}</TableCell>
                  <TableCell className="font-medium max-w-[180px] truncate" title={dev.name}>
                    {dev.name}
                  </TableCell>
                  <TableCell>{dev.site}</TableCell>
                  <TableCell className="text-right">{dev.totalAlarms}</TableCell>
                  <TableCell className="text-right">{dev.thisMonth}</TableCell>
                  <TableCell className="text-right">
                    <span
                      className={`inline-flex items-center justify-center w-10 h-6 rounded text-xs font-bold ${
                        dev.healthScore >= 80
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
                          : dev.healthScore >= 60
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400'
                            : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                      }`}
                    >
                      {dev.healthScore}
                    </span>
                  </TableCell>
                  <TableCell>{dev.topType}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{dev.lastAlarm}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function TimeAnalysis() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 24-hour distribution */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <SectionTitle icon={Clock} title="24小时报警分布" />
            <CardDescription>全天各时段报警数量统计</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={hourDist}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="hour" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                  }}
                />
                <Bar dataKey="count" name="报警数量" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Weekday vs Weekend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <SectionTitle icon={Calendar} title="工作日 vs 周末对比" />
            <CardDescription>不同时段报警数量对比分析</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={weekdayData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="period" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: 8,
                  }}
                />
                <Legend />
                <Bar dataKey="weekday" name="工作日" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                <Bar dataKey="weekend" name="周末" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function PredictionAnalysis() {
  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">本周预测报警数</CardTitle>
            <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{predictionData.thisWeekPredict}</div>
            <div className="text-xs text-muted-foreground mt-1">
              上周实际: {predictionData.lastWeekActual}（+
              {((predictionData.thisWeekPredict - predictionData.lastWeekActual) / predictionData.lastWeekActual * 100).toFixed(1)}%）
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">高风险时段</CardTitle>
            <div className="h-8 w-8 rounded-md bg-amber-500/10 flex items-center justify-center">
              <Clock className="h-4 w-4 text-amber-500" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-1">
              {predictionData.highRiskHours.map((h) => (
                <Badge key={h} variant="secondary">
                  {h}
                </Badge>
              ))}
            </div>
            <div className="text-xs text-muted-foreground mt-2">建议加强上述时段监控</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">高风险设备数</CardTitle>
            <div className="h-8 w-8 rounded-md bg-destructive/10 flex items-center justify-center">
              <AlertTriangle className="h-4 w-4 text-destructive" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{predictionData.highRiskDevices.length}</div>
            <div className="text-xs text-muted-foreground mt-1">健康评分低于70分的设备</div>
          </CardContent>
        </Card>
      </div>

      {/* Daily prediction chart */}
      <Card>
        <CardHeader>
          <SectionTitle icon={BarChart3} title="本周每日报警预测" />
          <CardDescription>基于历史数据的预测区间（上界/预测/下界）</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <ComposedChart data={predictionData.dailyPredict}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="day" tick={{ fontSize: 13 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: 8,
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="upper" name="预测上界" fill="#bae6fd" stroke="#7dd3fc" fillOpacity={0.4} />
              <Area type="monotone" dataKey="lower" name="预测下界" fill="#f0f9ff" stroke="#bae6fd" fillOpacity={0.4} />
              <Bar dataKey="predict" name="预测值" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* High risk devices detail */}
      <Card>
        <CardHeader>
          <SectionTitle icon={Shield} title="高风险设备预警详情" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {predictionData.highRiskDevices.map((dev) => (
              <Card key={dev.deviceId} className={`${dev.healthScore < 60 ? 'border-destructive/50' : 'border-amber-500/50'}`}>
                <CardContent className="pt-5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="font-mono text-xs text-muted-foreground">{dev.deviceId}</div>
                    <Badge variant={dev.healthScore < 60 ? 'destructive' : 'secondary'}>{dev.healthScore}分</Badge>
                  </div>
                  <div className="text-sm font-medium mb-1 truncate" title={dev.name}>
                    {dev.name}
                  </div>
                  <div className="text-xs text-muted-foreground mb-3">{dev.site}</div>
                  <div className="flex items-center justify-between text-xs">
                    <span>总报警: <strong>{dev.totalAlarms}</strong></span>
                    <span>本月: <strong>{dev.thisMonth}</strong></span>
                  </div>
                  <div className="mt-3 pt-3 border-t flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">主要类型: {dev.topType}</span>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ─────────────────────────────────────────────
// 4. Main Page
// ─────────────────────────────────────────────

export default function AlarmAnalysisPage() {
  const [activeTab, setActiveTab] = useState('trend');

  const tabs = useMemo(
    () => [
      { id: 'trend', label: '报警趋势', icon: TrendingUp },
      { id: 'efficiency', label: '处理效率', icon: Zap },
      { id: 'rootcause', label: '根因分析', icon: Search },
      { id: 'device', label: '设备画像', icon: Server },
      { id: 'time', label: '时段分析', icon: Clock },
      { id: 'prediction', label: '报警预测', icon: Activity },
    ],
    []
  );

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Page header */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <BarChart3 className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">报警分析中心</h1>
            <p className="text-sm text-muted-foreground">全方位报警数据统计、效率评估与智能预测</p>
          </div>
        </div>
      </div>

      {/* Top summary strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <span className="text-sm text-muted-foreground">本月报警</span>
            </div>
            <div className="text-xl font-bold mt-1">1,367</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-emerald-500" />
              <span className="text-sm text-muted-foreground">已处理</span>
            </div>
            <div className="text-xl font-bold mt-1">1,182</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-500" />
              <span className="text-sm text-muted-foreground">平均响应</span>
            </div>
            <div className="text-xl font-bold mt-1">8.5m</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">处理人员</span>
            </div>
            <div className="text-xl font-bold mt-1">{handlerData.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1">
          {tabs.map((t) => (
            <TabsTrigger key={t.id} value={t.id} className="gap-1.5">
              <t.icon className="h-4 w-4" />
              <span className="hidden sm:inline">{t.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="trend" className="mt-4">
          <TrendAnalysis />
        </TabsContent>

        <TabsContent value="efficiency" className="mt-4">
          <EfficiencyAnalysis />
        </TabsContent>

        <TabsContent value="rootcause" className="mt-4">
          <RootCauseAnalysis />
        </TabsContent>

        <TabsContent value="device" className="mt-4">
          <DeviceProfile />
        </TabsContent>

        <TabsContent value="time" className="mt-4">
          <TimeAnalysis />
        </TabsContent>

        <TabsContent value="prediction" className="mt-4">
          <PredictionAnalysis />
        </TabsContent>
      </Tabs>
    </div>
  );
}
