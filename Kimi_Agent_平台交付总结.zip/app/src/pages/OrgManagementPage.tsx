import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import {
  Search,
  Plus,
  Edit3,
  Eye,
  Building2,
  Network,
  Users,
  Truck,
  Warehouse,
  Cpu,
  ChevronRight,
  ChevronDown,
  X,
  MoreHorizontal,
  FolderTree,
  CheckCircle2,
  PauseCircle,
  Clock,
  ImagePlus,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────

type OrgType = 'platform' | 'service' | 'user';
type OrgStatus = 'active' | 'inactive';

interface OrgItem {
  id: string;
  code: string;
  name: string;
  type: OrgType;
  parentId: string | null;
  level: number;
  contactName: string;
  contactPhone: string;
  address: string;
  logo?: string;
  status: OrgStatus;
  crossTransferEnabled: boolean;
  createdAt: string;
  userCount: number;
  carrierCount: number;
  siteCount: number;
  deviceCount: number;
  projectCount: number;
  children?: OrgItem[];
}

interface OperationLog {
  id: string;
  action: string;
  operator: string;
  time: string;
  detail: string;
}

// ─── Constants ───────────────────────────────────────────────────

const ORG_TYPE_CONFIG: Record<OrgType, { label: string; color: string; bg: string; icon: typeof Building2 }> = {
  platform: { label: '平台方', color: '#7C3AED', bg: '#F3E8FF', icon: Network },
  service: { label: '服务方', color: '#2563EB', bg: '#EFF6FF', icon: Truck },
  user: { label: '用户方', color: '#10B981', bg: '#ECFDF5', icon: Building2 },
};

const STATUS_CONFIG: Record<OrgStatus, { label: string; color: string; bg: string; icon: typeof CheckCircle2 }> = {
  active: { label: '启用', color: '#10B981', bg: '#ECFDF5', icon: CheckCircle2 },
  inactive: { label: '停用', color: '#94A3B8', bg: '#F1F5F9', icon: PauseCircle },
};

// ─── Mock Data ───────────────────────────────────────────────────

const MOCK_ORGS: OrgItem[] = [
  {
    id: 'org-platform',
    code: 'CNTL-PLATFORM',
    name: '宁德时代物流平台',
    type: 'platform',
    parentId: null,
    level: 1,
    contactName: '李总',
    contactPhone: '13800138000',
    address: '福建省宁德市东侨经济开发区',
    status: 'active',
    crossTransferEnabled: true,
    createdAt: '2023-01-15',
    userCount: 12,
    carrierCount: 0,
    siteCount: 0,
    deviceCount: 0,
    projectCount: 0,
    children: [
      {
        id: 'org-svc-1',
        code: 'SH-LOGISTICS',
        name: '上海物流有限公司',
        type: 'service',
        parentId: 'org-platform',
        level: 2,
        contactName: '张经理',
        contactPhone: '13800138001',
        address: '上海市浦东新区张江高科技园区',
        status: 'active',
        crossTransferEnabled: true,
        createdAt: '2023-03-10',
        userCount: 8,
        carrierCount: 520,
        siteCount: 4,
        deviceCount: 45,
        projectCount: 3,
        children: [
          {
            id: 'org-user-1-1',
            code: 'SH-PD-FACTORY',
            name: '上海浦东汽车工厂',
            type: 'user',
            parentId: 'org-svc-1',
            level: 3,
            contactName: '王厂长',
            contactPhone: '13800138002',
            address: '上海市浦东新区临港新片区',
            status: 'active',
            crossTransferEnabled: false,
            createdAt: '2023-05-20',
            userCount: 24,
            carrierCount: 320,
            siteCount: 2,
            deviceCount: 28,
            projectCount: 2,
          },
          {
            id: 'org-user-1-2',
            code: 'SH-JD-PARTS',
            name: '上海嘉定零部件厂',
            type: 'user',
            parentId: 'org-svc-1',
            level: 3,
            contactName: '赵主管',
            contactPhone: '13800138003',
            address: '上海市嘉定区安亭镇',
            status: 'active',
            crossTransferEnabled: false,
            createdAt: '2023-06-15',
            userCount: 16,
            carrierCount: 180,
            siteCount: 1,
            deviceCount: 15,
            projectCount: 1,
          },
          {
            id: 'org-user-1-3',
            code: 'SH-MH-HUB',
            name: '上海闵行物流中心',
            type: 'user',
            parentId: 'org-svc-1',
            level: 3,
            contactName: '刘主任',
            contactPhone: '13800138004',
            address: '上海市闵行区莘庄镇',
            status: 'inactive',
            crossTransferEnabled: false,
            createdAt: '2023-08-01',
            userCount: 10,
            carrierCount: 120,
            siteCount: 1,
            deviceCount: 12,
            projectCount: 1,
          },
        ],
      },
      {
        id: 'org-svc-2',
        code: 'NB-TRANSPORT',
        name: '宁波运输有限公司',
        type: 'service',
        parentId: 'org-platform',
        level: 2,
        contactName: '陈经理',
        contactPhone: '13800138005',
        address: '浙江省宁波市鄞州区',
        status: 'active',
        crossTransferEnabled: true,
        createdAt: '2023-04-05',
        userCount: 6,
        carrierCount: 380,
        siteCount: 3,
        deviceCount: 32,
        projectCount: 2,
        children: [
          {
            id: 'org-user-2-1',
            code: 'NB-BL-BASE',
            name: '宁波北仑生产基地',
            type: 'user',
            parentId: 'org-svc-2',
            level: 3,
            contactName: '孙厂长',
            contactPhone: '13800138006',
            address: '浙江省宁波市北仑区大碶街道',
            status: 'active',
            crossTransferEnabled: false,
            createdAt: '2023-07-10',
            userCount: 32,
            carrierCount: 260,
            siteCount: 2,
            deviceCount: 22,
            projectCount: 2,
          },
          {
            id: 'org-user-2-2',
            code: 'NB-YZ-DC',
            name: '宁波鄞州配送中心',
            type: 'user',
            parentId: 'org-svc-2',
            level: 3,
            contactName: '周主管',
            contactPhone: '13800138007',
            address: '浙江省宁波市鄞州区首南街道',
            status: 'active',
            crossTransferEnabled: false,
            createdAt: '2023-09-20',
            userCount: 14,
            carrierCount: 120,
            siteCount: 1,
            deviceCount: 10,
            projectCount: 1,
          },
        ],
      },
      {
        id: 'org-svc-3',
        code: 'HZ-WAREHOUSE',
        name: '杭州仓储有限公司',
        type: 'service',
        parentId: 'org-platform',
        level: 2,
        contactName: '吴经理',
        contactPhone: '13800138008',
        address: '浙江省杭州市萧山区',
        status: 'active',
        crossTransferEnabled: true,
        createdAt: '2023-05-12',
        userCount: 7,
        carrierCount: 290,
        siteCount: 3,
        deviceCount: 28,
        projectCount: 2,
        children: [
          {
            id: 'org-user-3-1',
            code: 'HZ-XS-WAREHOUSE',
            name: '杭州萧山仓库',
            type: 'user',
            parentId: 'org-svc-3',
            level: 3,
            contactName: '郑仓管',
            contactPhone: '13800138009',
            address: '浙江省杭州市萧山区靖江街道',
            status: 'active',
            crossTransferEnabled: false,
            createdAt: '2023-08-25',
            userCount: 18,
            carrierCount: 190,
            siteCount: 2,
            deviceCount: 18,
            projectCount: 1,
          },
          {
            id: 'org-user-3-2',
            code: 'HZ-YH-HUB',
            name: '杭州余杭中转站',
            type: 'user',
            parentId: 'org-svc-3',
            level: 3,
            contactName: '钱主管',
            contactPhone: '13800138010',
            address: '浙江省杭州市余杭区仁和街道',
            status: 'inactive',
            crossTransferEnabled: false,
            createdAt: '2023-10-15',
            userCount: 8,
            carrierCount: 100,
            siteCount: 1,
            deviceCount: 10,
            projectCount: 1,
          },
        ],
      },
    ],
  },
];

const MOCK_SUB_USERS = [
  { id: 'su-1', name: '张三', account: 'zhangsan', phone: '138****0001', role: '组织管理员', status: 'active', lastLogin: '2024-12-20 09:30' },
  { id: 'su-2', name: '李四', account: 'lisi', phone: '138****0002', role: '调度员', status: 'active', lastLogin: '2024-12-19 17:20' },
  { id: 'su-3', name: '王五', account: 'wangwu', phone: '138****0003', role: '仓库管理员', status: 'active', lastLogin: '2024-12-18 16:00' },
  { id: 'su-4', name: '赵六', account: 'zhaoliu', phone: '138****0004', role: '观察员', status: 'inactive', lastLogin: '2024-11-30 14:00' },
  { id: 'su-5', name: '孙七', account: 'sunqi', phone: '138****0005', role: '司机', status: 'active', lastLogin: '2024-12-20 08:00' },
];

const MOCK_SUB_CARRIERS = [
  { id: 'sc-1', code: 'CJ000123', type: '托盘', status: 'normal', location: '上海浦东工厂仓库A', lastUsed: '2024-12-20' },
  { id: 'sc-2', code: 'CJ000124', type: '周转箱', status: 'in_transit', location: '运输中(沪A12345)', lastUsed: '2024-12-20' },
  { id: 'sc-3', code: 'CJ000125', type: '料架', status: 'normal', location: '宁波北仑生产基地', lastUsed: '2024-12-19' },
  { id: 'sc-4', code: 'CJ000126', type: '集装箱', status: 'repairing', location: '杭州萧山仓库', lastUsed: '2024-12-15' },
  { id: 'sc-5', code: 'CJ000127', type: '笼车', status: 'normal', location: '上海嘉定零部件厂', lastUsed: '2024-12-20' },
];

const MOCK_SUB_SITES = [
  { id: 'ss-1', name: '上海浦东工厂仓库A', type: 'factory', address: '上海市浦东新区临港新片区', carrierCount: 180, contactName: '王仓管', contactPhone: '138****1001' },
  { id: 'ss-2', name: '上海浦东工厂仓库B', type: 'warehouse', address: '上海市浦东新区临港新片区', carrierCount: 140, contactName: '李仓管', contactPhone: '138****1002' },
  { id: 'ss-3', name: '宁波北仑生产基地仓库', type: 'factory', address: '浙江省宁波市北仑区', carrierCount: 260, contactName: '孙仓管', contactPhone: '138****1003' },
];

const MOCK_OPERATION_LOGS: OperationLog[] = [
  { id: 'log-1', action: '创建组织', operator: '系统管理员', time: '2023-01-15 10:30:00', detail: '创建了组织「宁德时代物流平台」' },
  { id: 'log-2', action: '编辑组织', operator: '系统管理员', time: '2023-03-10 14:20:00', detail: '为「宁德时代物流平台」添加了子组织「上海物流有限公司」' },
  { id: 'log-3', action: '启用组织', operator: '李总', time: '2023-05-20 09:15:00', detail: '启用了组织「上海浦东汽车工厂」' },
  { id: 'log-4', action: '停用组织', operator: '李总', time: '2023-10-15 16:45:00', detail: '停用了组织「杭州余杭中转站」' },
  { id: 'log-5', action: '更新权限', operator: '系统管理员', time: '2024-01-10 11:00:00', detail: '为「上海物流有限公司」开启了跨组织调拨权限' },
  { id: 'log-6', action: '编辑组织', operator: '张经理', time: '2024-06-20 10:30:00', detail: '更新了「上海嘉定零部件厂」的联系人信息' },
  { id: 'log-7', action: '创建组织', operator: '系统管理员', time: '2024-12-01 09:00:00', detail: '创建了组织「上海闵行物流中心」' },
];

// ─── Helpers ─────────────────────────────────────────────────────

function flattenOrgs(orgs: OrgItem[]): OrgItem[] {
  const result: OrgItem[] = [];
  const walk = (nodes: OrgItem[]) => {
    nodes.forEach((node) => {
      result.push(node);
      if (node.children && node.children.length > 0) {
        walk(node.children);
      }
    });
  };
  walk(orgs);
  return result;
}

function findOrgById(orgs: OrgItem[], id: string): OrgItem | undefined {
  const flat = flattenOrgs(orgs);
  return flat.find((o) => o.id === id);
}

function getParentName(org: OrgItem, allOrgs: OrgItem[]): string {
  if (!org.parentId) return '-';
  const parent = findOrgById(allOrgs, org.parentId);
  return parent ? parent.name : '-';
}

function getDescendantIds(org: OrgItem): string[] {
  const ids: string[] = [];
  const walk = (nodes: OrgItem[] | undefined) => {
    if (!nodes) return;
    nodes.forEach((n) => {
      ids.push(n.id);
      walk(n.children);
    });
  };
  walk(org.children);
  return ids;
}

// ─── Sub-components ──────────────────────────────────────────────

/** Status Tag */
function StatusTag({ status }: { status: OrgStatus }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium"
      style={{ color: cfg.color, backgroundColor: cfg.bg }}
    >
      <cfg.icon size={12} />
      {cfg.label}
    </span>
  );
}

/** Type Tag */
function TypeTag({ type }: { type: OrgType }) {
  const cfg = ORG_TYPE_CONFIG[type];
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium"
      style={{ color: cfg.color, backgroundColor: cfg.bg }}
    >
      <cfg.icon size={12} />
      {cfg.label}
    </span>
  );
}

/** KPI Card */
function KpiCard({
  title,
  value,
  color,
  icon: Icon,
  sub,
}: {
  title: string;
  value: string | number;
  color: string;
  icon: typeof Building2;
  sub?: string;
}) {
  return (
    <Card className="border-l-4 shadow-[0_1px_3px_rgba(0,0,0,0.06)]" style={{ borderLeftColor: color }}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-[#475569]">{title}</span>
          <Icon size={16} style={{ color }} />
        </div>
        <div className="mt-2 text-[28px] font-semibold text-[#0F172A] leading-tight">
          {value}
        </div>
        {sub && <div className="text-xs text-[#94A3B8] mt-1">{sub}</div>}
      </CardContent>
    </Card>
  );
}

/** Org Detail Dialog */
function OrgDetailDialog({
  org,
  allOrgs,
  open,
  onClose,
}: {
  org: OrgItem | null;
  allOrgs: OrgItem[];
  open: boolean;
  onClose: () => void;
}) {
  const [tab, setTab] = useState('basic');

  if (!org) return null;

  const typeCfg = ORG_TYPE_CONFIG[org.type];
  const hasChildren = org.children && org.children.length > 0;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader className="border-b border-[#E2E8F0] pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: typeCfg.bg }}
              >
                <typeCfg.icon size={20} style={{ color: typeCfg.color }} />
              </div>
              <div>
                <DialogTitle className="text-lg font-semibold">{org.name}</DialogTitle>
                <DialogDescription className="text-xs text-[#94A3B8]">
                  编码：{org.code} · 层级：{org.level}
                </DialogDescription>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center"
            >
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
        </DialogHeader>

        <Tabs value={tab} onValueChange={setTab} className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="w-full rounded-none border-b bg-transparent px-0 pt-2 gap-0 flex-wrap h-auto justify-start">
            {[
              { key: 'basic', label: '基本信息' },
              { key: 'users', label: '下属用户' },
              { key: 'carriers', label: '下属载具' },
              { key: 'sites', label: '下属网点' },
              { key: 'projects', label: '参与项目' },
              { key: 'logs', label: '操作记录' },
            ].map((t) => (
              <TabsTrigger
                key={t.key}
                value={t.key}
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563EB] data-[state=active]:shadow-none bg-transparent text-xs px-3 py-2 data-[state=active]:text-[#2563EB] text-[#475569]"
              >
                {t.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="flex-1 overflow-y-auto p-4">
            {/* ── Basic Info Tab ── */}
            <TabsContent value="basic" className="mt-0 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: '组织名称', value: org.name },
                  { label: '组织编码', value: org.code },
                  { label: '组织类型', value: <TypeTag type={org.type} /> },
                  { label: '上级组织', value: getParentName(org, allOrgs) },
                  { label: '组织层级', value: `第 ${org.level} 层` },
                  { label: '联系人', value: org.contactName },
                  { label: '联系电话', value: org.contactPhone },
                  { label: '地址', value: org.address },
                  { label: '状态', value: <StatusTag status={org.status} /> },
                  { label: '创建时间', value: org.createdAt },
                  { label: '跨组织调拨', value: org.crossTransferEnabled ? '已启用' : '未启用' },
                  { label: '下属组织数', value: hasChildren ? `${org.children!.length} 个` : '0 个' },
                ].map((item) => (
                  <div key={item.label as string} className="py-2">
                    <div className="text-xs text-[#94A3B8] mb-1">{item.label}</div>
                    <div className="text-sm text-[#0F172A] font-medium">{item.value}</div>
                  </div>
                ))}
              </div>
              {/* Resource summary */}
              <div className="grid grid-cols-4 gap-3 mt-2">
                {[
                  { label: '用户数量', value: org.userCount, icon: Users, color: '#2563EB' },
                  { label: '载具数量', value: org.carrierCount, icon: Truck, color: '#10B981' },
                  { label: '网点数量', value: org.siteCount, icon: Warehouse, color: '#F59E0B' },
                  { label: '设备数量', value: org.deviceCount, icon: Cpu, color: '#8B5CF6' },
                ].map((item) => (
                  <div key={item.label} className="bg-[#F8FAFC] rounded-lg p-3 text-center">
                    <item.icon size={14} style={{ color: item.color }} className="mx-auto mb-1" />
                    <div className="text-xs text-[#475569]">{item.label}</div>
                    <div className="text-lg font-semibold font-number mt-1" style={{ color: item.color }}>
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* ── Users Tab ── */}
            <TabsContent value="users" className="mt-0">
              <div className="bg-white rounded-lg border border-[#E2E8F0] overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#F8FAFC]">
                      <TableHead className="text-xs">姓名</TableHead>
                      <TableHead className="text-xs">账号</TableHead>
                      <TableHead className="text-xs">手机号</TableHead>
                      <TableHead className="text-xs">角色</TableHead>
                      <TableHead className="text-xs">状态</TableHead>
                      <TableHead className="text-xs">最后登录</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {MOCK_SUB_USERS.map((user) => (
                      <TableRow key={user.id} className="h-10">
                        <TableCell className="text-sm font-medium">{user.name}</TableCell>
                        <TableCell className="text-xs text-[#475569]">{user.account}</TableCell>
                        <TableCell className="text-xs text-[#475569]">{user.phone}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs bg-[#EFF6FF] text-[#2563EB] hover:bg-[#EFF6FF]">
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span
                            className={cn(
                              'text-xs px-1.5 py-0.5 rounded',
                              user.status === 'active'
                                ? 'bg-[#ECFDF5] text-[#10B981]'
                                : 'bg-[#F1F5F9] text-[#94A3B8]'
                            )}
                          >
                            {user.status === 'active' ? '启用' : '停用'}
                          </span>
                        </TableCell>
                        <TableCell className="text-xs text-[#94A3B8]">{user.lastLogin}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* ── Carriers Tab ── */}
            <TabsContent value="carriers" className="mt-0">
              <div className="bg-white rounded-lg border border-[#E2E8F0] overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#F8FAFC]">
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">类型</TableHead>
                      <TableHead className="text-xs">状态</TableHead>
                      <TableHead className="text-xs">当前位置</TableHead>
                      <TableHead className="text-xs">最近使用</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {MOCK_SUB_CARRIERS.map((carrier) => (
                      <TableRow key={carrier.id} className="h-10">
                        <TableCell className="text-sm font-mono">{carrier.code}</TableCell>
                        <TableCell className="text-xs">{carrier.type}</TableCell>
                        <TableCell>
                          <span
                            className={cn(
                              'text-xs px-1.5 py-0.5 rounded',
                              carrier.status === 'normal'
                                ? 'bg-[#ECFDF5] text-[#10B981]'
                                : carrier.status === 'in_transit'
                                  ? 'bg-[#EFF6FF] text-[#2563EB]'
                                  : 'bg-[#FFFBEB] text-[#F59E0B]'
                            )}
                          >
                            {carrier.status === 'normal' ? '正常' : carrier.status === 'in_transit' ? '在途' : '维修中'}
                          </span>
                        </TableCell>
                        <TableCell className="text-xs text-[#475569]">{carrier.location}</TableCell>
                        <TableCell className="text-xs text-[#94A3B8]">{carrier.lastUsed}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* ── Sites Tab ── */}
            <TabsContent value="sites" className="mt-0">
              <div className="bg-white rounded-lg border border-[#E2E8F0] overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#F8FAFC]">
                      <TableHead className="text-xs">网点名称</TableHead>
                      <TableHead className="text-xs">类型</TableHead>
                      <TableHead className="text-xs">地址</TableHead>
                      <TableHead className="text-xs">载具数量</TableHead>
                      <TableHead className="text-xs">联系人</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {MOCK_SUB_SITES.map((site) => (
                      <TableRow key={site.id} className="h-10">
                        <TableCell className="text-sm font-medium">{site.name}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">
                            {site.type === 'factory' ? '工厂' : '仓库'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-[#475569] max-w-[200px] truncate">{site.address}</TableCell>
                        <TableCell className="text-xs tabular-nums">{site.carrierCount}</TableCell>
                        <TableCell className="text-xs text-[#475569]">{site.contactName} {site.contactPhone}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* ── Projects Tab ── */}
            <TabsContent value="projects" className="mt-0">
              <div className="space-y-3">
                {[
                  { id: 'p-1', name: '宁德时代上海基地运输项目', code: 'PRJ-2024-001', status: '进行中', startDate: '2024-01-01', endDate: '2024-12-31' },
                  { id: 'p-2', name: '华东汽车零部件配送项目', code: 'PRJ-2024-002', status: '进行中', startDate: '2024-03-01', endDate: '2024-09-30' },
                  { id: 'p-3', name: '宁波北仑仓储周转项目', code: 'PRJ-2024-003', status: '已完结', startDate: '2023-06-01', endDate: '2023-12-31' },
                ].map((project) => (
                  <div
                    key={project.id}
                    className="border border-[#E2E8F0] rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FolderTree size={18} className="text-[#2563EB]" />
                        <div>
                          <div className="text-sm font-medium text-[#0F172A]">{project.name}</div>
                          <div className="text-xs text-[#94A3B8]">项目编码：{project.code}</div>
                        </div>
                      </div>
                      <Badge
                        variant="secondary"
                        className={cn(
                          'text-xs',
                          project.status === '进行中'
                            ? 'bg-[#ECFDF5] text-[#10B981] hover:bg-[#ECFDF5]'
                            : 'bg-[#F1F5F9] text-[#94A3B8] hover:bg-[#F1F5F9]'
                        )}
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <div className="mt-2 flex items-center gap-4 text-xs text-[#475569]">
                      <span className="flex items-center gap-1"><Clock size={12} /> 开始：{project.startDate}</span>
                      <span className="flex items-center gap-1"><Clock size={12} /> 结束：{project.endDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* ── Operation Logs Tab ── */}
            <TabsContent value="logs" className="mt-0">
              <div className="bg-white rounded-lg border border-[#E2E8F0] overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#F8FAFC]">
                      <TableHead className="text-xs">操作类型</TableHead>
                      <TableHead className="text-xs">操作人</TableHead>
                      <TableHead className="text-xs">操作时间</TableHead>
                      <TableHead className="text-xs">详情</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {MOCK_OPERATION_LOGS.map((log) => (
                      <TableRow key={log.id} className="h-10">
                        <TableCell>
                          <Badge variant="secondary" className="text-xs bg-[#EFF6FF] text-[#2563EB] hover:bg-[#EFF6FF]">
                            {log.action}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{log.operator}</TableCell>
                        <TableCell className="text-xs text-[#94A3B8]">{log.time}</TableCell>
                        <TableCell className="text-xs text-[#475569]">{log.detail}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

/** Add/Edit Org Dialog */
function OrgEditDialog({
  org,
  allOrgs,
  open,
  onClose,
  onSave,
}: {
  org: OrgItem | null;
  allOrgs: OrgItem[];
  open: boolean;
  onClose: () => void;
  onSave: (data: Partial<OrgItem>) => void;
}) {
  const isEdit = !!org;
  const [form, setForm] = useState<Partial<OrgItem>>(
    org || {
      name: '',
      code: '',
      type: 'user',
      parentId: '',
      contactName: '',
      contactPhone: '',
      address: '',
      status: 'active',
      crossTransferEnabled: false,
    }
  );

  const handleChange = (field: keyof OrgItem, value: unknown) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    onSave(form);
    onClose();
  };

  // Flat orgs for parent selection (exclude self and descendants)
  const flatOrgs = useMemo(() => flattenOrgs(allOrgs), [allOrgs]);
  const parentOptions = isEdit
    ? flatOrgs.filter((o) => o.id !== org!.id && !getDescendantIds(org!).includes(o.id))
    : flatOrgs;

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">{isEdit ? '编辑组织' : '新增组织'}</DialogTitle>
          <DialogDescription className="text-xs text-[#94A3B8]">
            {isEdit ? '修改组织的基本信息和权限配置' : '填写新组织的基本信息'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">
                组织名称 <span className="text-[#EF4444]">*</span>
              </label>
              <Input
                value={form.name || ''}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="请输入组织名称"
                className="h-9"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">
                组织编码 <span className="text-[#EF4444]">*</span>
              </label>
              <Input
                value={form.code || ''}
                onChange={(e) => handleChange('code', e.target.value)}
                placeholder="请输入组织编码"
                className="h-9"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">
                组织类型 <span className="text-[#EF4444]">*</span>
              </label>
              <Select
                value={form.type || 'user'}
                onValueChange={(v) => handleChange('type', v as OrgType)}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="选择类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="platform">平台方</SelectItem>
                  <SelectItem value="service">服务方</SelectItem>
                  <SelectItem value="user">用户方</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">上级组织</label>
              <Select
                value={form.parentId || ''}
                onValueChange={(v) => handleChange('parentId', v || null)}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="选择上级组织" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">无（顶级组织）</SelectItem>
                  {parentOptions.map((o) => (
                    <SelectItem key={o.id} value={o.id}>
                      {''.padStart((o.level - 1) * 2)} {o.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">联系人</label>
              <Input
                value={form.contactName || ''}
                onChange={(e) => handleChange('contactName', e.target.value)}
                placeholder="请输入联系人"
                className="h-9"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">联系电话</label>
              <Input
                value={form.contactPhone || ''}
                onChange={(e) => handleChange('contactPhone', e.target.value)}
                placeholder="请输入联系电话"
                className="h-9"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0F172A] mb-1">地址</label>
            <Input
              value={form.address || ''}
              onChange={(e) => handleChange('address', e.target.value)}
              placeholder="请输入地址"
              className="h-9"
            />
          </div>

          {/* Logo Upload (Simulated) */}
          <div>
            <label className="block text-sm font-medium text-[#0F172A] mb-1">组织Logo</label>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-lg bg-[#F1F5F9] border border-dashed border-[#CBD5E1] flex items-center justify-center">
                <ImagePlus size={20} className="text-[#94A3B8]" />
              </div>
              <Button variant="outline" size="sm" className="h-8 text-xs">
                <ImagePlus size={14} className="mr-1" /> 上传Logo
              </Button>
              <span className="text-xs text-[#94A3B8]">支持 JPG/PNG，最大 2MB</span>
            </div>
          </div>

          <div className="flex items-center justify-between py-2 border-t border-[#E2E8F0]">
            <div>
              <div className="text-sm font-medium text-[#0F172A]">跨组织调拨权限</div>
              <div className="text-xs text-[#94A3B8]">开启后该组织可与其它组织进行载具调拨</div>
            </div>
            <button
              onClick={() => handleChange('crossTransferEnabled', !form.crossTransferEnabled)}
              className="transition-colors"
            >
              {form.crossTransferEnabled ? (
                <ToggleRight size={36} className="text-[#2563EB]" />
              ) : (
                <ToggleLeft size={36} className="text-[#CBD5E1]" />
              )}
            </button>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#0F172A] mb-1">状态</label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  checked={form.status === 'active'}
                  onChange={() => handleChange('status', 'active')}
                  className="w-4 h-4 text-[#2563EB]"
                />
                <span className="text-sm text-[#475569]">启用</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="status"
                  checked={form.status === 'inactive'}
                  onChange={() => handleChange('status', 'inactive')}
                  className="w-4 h-4 text-[#2563EB]"
                />
                <span className="text-sm text-[#475569]">停用</span>
              </label>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} className="h-9">
            取消
          </Button>
          <Button onClick={handleSubmit} className="h-9 bg-[#2563EB] hover:bg-[#1D4ED8]">
            {isEdit ? '保存修改' : '确认创建'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Main Component ───────────────────────────────────────────────

export default function OrgManagementPage() {
  const [allOrgs, setAllOrgs] = useState<OrgItem[]>(MOCK_ORGS);
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [parentFilter, setParentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['org-platform']));
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const [detailOrg, setDetailOrg] = useState<OrgItem | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editOrg, setEditOrg] = useState<OrgItem | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  // Flatten all orgs for table display
  const flatOrgs = useMemo(() => flattenOrgs(allOrgs), [allOrgs]);

  // Filter orgs
  const filteredOrgs = useMemo(() => {
    return flatOrgs.filter((org) => {
      if (typeFilter !== 'all' && org.type !== typeFilter) return false;
      if (statusFilter !== 'all' && org.status !== statusFilter) return false;
      if (parentFilter !== 'all' && org.parentId !== parentFilter) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          org.name.toLowerCase().includes(q) ||
          org.code.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [flatOrgs, typeFilter, statusFilter, parentFilter, searchQuery]);

  // Pagination
  const totalPages = Math.ceil(filteredOrgs.length / pageSize);
  const paginatedOrgs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredOrgs.slice(start, start + pageSize);
  }, [filteredOrgs, currentPage]);

  // KPI Stats
  const kpi = useMemo(() => {
    const total = flatOrgs.length;
    const platform = flatOrgs.filter((o) => o.type === 'platform').length;
    const service = flatOrgs.filter((o) => o.type === 'service').length;
    const user = flatOrgs.filter((o) => o.type === 'user').length;
    const totalUsers = flatOrgs.reduce((sum, o) => sum + o.userCount, 0);
    const totalCarriers = flatOrgs.reduce((sum, o) => sum + o.carrierCount, 0);
    const totalSites = flatOrgs.reduce((sum, o) => sum + o.siteCount, 0);
    const totalDevices = flatOrgs.reduce((sum, o) => sum + o.deviceCount, 0);
    return { total, platform, service, user, totalUsers, totalCarriers, totalSites, totalDevices };
  }, [flatOrgs]);

  const toggleExpanded = useCallback((id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const openDetail = useCallback((org: OrgItem) => {
    setDetailOrg(org);
    setDetailOpen(true);
  }, []);

  const openEdit = useCallback((org: OrgItem) => {
    setEditOrg(org);
    setEditOpen(true);
  }, []);

  const handleSave = useCallback(
    (data: Partial<OrgItem>) => {
      if (editOrg) {
        // Update existing
        setAllOrgs((prev) => {
          const updateInTree = (nodes: OrgItem[]): OrgItem[] => {
            return nodes.map((n) => {
              if (n.id === editOrg.id) {
                return { ...n, ...data } as OrgItem;
              }
              if (n.children) {
                return { ...n, children: updateInTree(n.children) };
              }
              return n;
            });
          };
          return updateInTree(prev);
        });
      } else {
        // Create new
        const newOrg: OrgItem = {
          ...(data as OrgItem),
          id: `org-${Date.now()}`,
          level: data.parentId ? (findOrgById(allOrgs, data.parentId)?.level || 0) + 1 : 1,
          userCount: 0,
          carrierCount: 0,
          siteCount: 0,
          deviceCount: 0,
          projectCount: 0,
          createdAt: new Date().toISOString().split('T')[0],
        };
        if (!newOrg.parentId) {
          setAllOrgs((prev) => [...prev, newOrg]);
        } else {
          setAllOrgs((prev) => {
            const addToTree = (nodes: OrgItem[]): OrgItem[] => {
              return nodes.map((n) => {
                if (n.id === newOrg.parentId) {
                  return { ...n, children: [...(n.children || []), newOrg] };
                }
                if (n.children) {
                  return { ...n, children: addToTree(n.children) };
                }
                return n;
              });
            };
            return addToTree(prev);
          });
        }
      }
    },
    [editOrg, allOrgs]
  );

  return (
    <div className="space-y-5">
      {/* ═══════ Page Header ═══════ */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">组织管理</h1>
          <p className="text-sm text-[#475569] mt-1">
            共 {kpi.total} 个组织 · {kpi.platform} 个平台方 · {kpi.service} 个服务方 · {kpi.user} 个用户方
          </p>
        </div>
        <Button
          size="sm"
          className="gap-1.5 bg-[#2563EB] hover:bg-[#1D4ED8]"
          onClick={() => setAddOpen(true)}
        >
          <Plus size={14} />
          新增组织
        </Button>
      </div>

      {/* ═══════ KPI Cards ═══════ */}
      <div className="grid grid-cols-4 gap-4">
        <KpiCard
          title="组织总数"
          value={kpi.total}
          color="#7C3AED"
          icon={Network}
          sub={`平台${kpi.platform} · 服务${kpi.service} · 用户${kpi.user}`}
        />
        <KpiCard
          title="用户总数"
          value={kpi.totalUsers}
          color="#2563EB"
          icon={Users}
          sub="全部组织用户"
        />
        <KpiCard
          title="载具总数"
          value={kpi.totalCarriers}
          color="#10B981"
          icon={Truck}
          sub="全部组织载具"
        />
        <KpiCard
          title="网点与设备"
          value={`${kpi.totalSites} / ${kpi.totalDevices}`}
          color="#F59E0B"
          icon={Warehouse}
          sub="网点数 / 设备数"
        />
      </div>

      {/* ═══════ Filter Bar ═══════ */}
      <div className="bg-white rounded-lg p-3 shadow-[0_1px_3px_rgba(0,0,0,0.06)] flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          <Input
            placeholder="搜索组织名称、编码..."
            className="pl-8 h-8 text-sm"
            value={searchQuery}
            onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
          />
        </div>
        <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setCurrentPage(1); }}>
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue placeholder="组织类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="platform">平台方</SelectItem>
            <SelectItem value="service">服务方</SelectItem>
            <SelectItem value="user">用户方</SelectItem>
          </SelectContent>
        </Select>
        <Select value={parentFilter} onValueChange={(v) => { setParentFilter(v); setCurrentPage(1); }}>
          <SelectTrigger className="w-36 h-8 text-xs">
            <SelectValue placeholder="上级组织" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部上级</SelectItem>
            {flatOrgs.filter((o) => o.children && o.children.length > 0).map((o) => (
              <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1); }}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue placeholder="状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="active">启用</SelectItem>
            <SelectItem value="inactive">停用</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* ═══════ Data Table (Tree View) ═══════ */}
      <div className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="text-[#475569] text-[13px] font-medium w-10" />
                <TableHead className="text-[#475569] text-[13px] font-medium">组织名称</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">组织编码</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">类型</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">上级组织</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">层级</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">用户</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">载具</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">网点</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">设备</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">状态</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">创建时间</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium w-28">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedOrgs.map((org, idx) => {
                const typeCfg = ORG_TYPE_CONFIG[org.type];
                const hasChildren = org.children && org.children.length > 0;
                const isExpanded = expandedIds.has(org.id);
                const parentName = getParentName(org, allOrgs);

                return (
                  <motion.tr
                    key={org.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className={cn(
                      'border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group h-12',
                      idx % 2 === 1 && 'bg-[#F8FAFC]'
                    )}
                  >
                    <TableCell className="py-2">
                      {hasChildren ? (
                        <button
                          onClick={() => toggleExpanded(org.id)}
                          className="w-6 h-6 rounded hover:bg-[#E2E8F0] flex items-center justify-center"
                        >
                          {isExpanded ? (
                            <ChevronDown size={14} className="text-[#475569]" />
                          ) : (
                            <ChevronRight size={14} className="text-[#475569]" />
                          )}
                        </button>
                      ) : (
                        <span className="w-6" />
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2" style={{ paddingLeft: `${(org.level - 1) * 16}px` }}>
                        <div
                          className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: typeCfg.bg }}
                        >
                          <typeCfg.icon size={14} style={{ color: typeCfg.color }} />
                        </div>
                        <span className="text-sm font-medium text-[#0F172A]">{org.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-[#475569] font-mono">{org.code}</TableCell>
                    <TableCell>
                      <TypeTag type={org.type} />
                    </TableCell>
                    <TableCell className="text-sm text-[#475569]">{parentName}</TableCell>
                    <TableCell className="text-sm text-[#475569]">{org.level}</TableCell>
                    <TableCell className="text-sm tabular-nums">{org.userCount}</TableCell>
                    <TableCell className="text-sm tabular-nums">{org.carrierCount}</TableCell>
                    <TableCell className="text-sm tabular-nums">{org.siteCount}</TableCell>
                    <TableCell className="text-sm tabular-nums">{org.deviceCount}</TableCell>
                    <TableCell>
                      <StatusTag status={org.status} />
                    </TableCell>
                    <TableCell className="text-xs text-[#94A3B8]">{org.createdAt}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => openDetail(org)}
                          className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center"
                          title="详情"
                        >
                          <Eye size={13} className="text-[#475569]" />
                        </button>
                        <button
                          onClick={() => openEdit(org)}
                          className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center"
                          title="编辑"
                        >
                          <Edit3 size={13} className="text-[#475569]" />
                        </button>
                        <button
                          className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center"
                          title="更多"
                        >
                          <MoreHorizontal size={13} className="text-[#475569]" />
                        </button>
                      </div>
                    </TableCell>
                  </motion.tr>
                );
              })}
              {paginatedOrgs.length === 0 && (
                <TableRow>
                  <TableCell colSpan={13} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Network size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无组织数据</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        {filteredOrgs.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">
              共 <strong>{filteredOrgs.length}</strong> 条
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={cn(
                      'w-8 h-8 rounded-md text-sm font-medium transition-colors',
                      currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]'
                    )}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ═══════ Org Overview Cards ═══════ */}
      <div>
        <h3 className="text-base font-semibold text-[#0F172A] mb-4">组织数据概览</h3>
        <div className="grid grid-cols-3 gap-4">
          {flatOrgs.slice(0, 6).map((org) => {
            const typeCfg = ORG_TYPE_CONFIG[org.type];
            return (
              <motion.div
                key={org.id}
                whileHover={{ y: -2 }}
                className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] p-5 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => openDetail(org)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: typeCfg.bg }}
                    >
                      <typeCfg.icon size={20} style={{ color: typeCfg.color }} />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-[#0F172A]">{org.name}</h4>
                      <p className="text-xs text-[#94A3B8]">{org.code}</p>
                    </div>
                  </div>
                  <TypeTag type={org.type} />
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  {[
                    { label: '用户', value: org.userCount, icon: Users },
                    { label: '载具', value: org.carrierCount, icon: Truck },
                    { label: '网点', value: org.siteCount, icon: Warehouse },
                  ].map((item) => (
                    <div key={item.label} className="bg-[#F8FAFC] rounded-lg p-2">
                      <item.icon size={12} className="mx-auto mb-1 text-[#94A3B8]" />
                      <div className="text-xs text-[#475569]">{item.label}</div>
                      <div className="text-sm font-semibold text-[#0F172A]">{item.value}</div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex items-center justify-between text-xs text-[#94A3B8]">
                  <span className="flex items-center gap-1"><Cpu size={12} /> 设备 {org.deviceCount}</span>
                  <span className="flex items-center gap-1"><FolderTree size={12} /> 项目 {org.projectCount}</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ═══════ Dialogs ═══════ */}
      <OrgDetailDialog
        org={detailOrg}
        allOrgs={allOrgs}
        open={detailOpen}
        onClose={() => setDetailOpen(false)}
      />
      <OrgEditDialog
        org={editOrg}
        allOrgs={allOrgs}
        open={editOpen}
        onClose={() => { setEditOpen(false); setEditOrg(null); }}
        onSave={handleSave}
      />
      <OrgEditDialog
        org={null}
        allOrgs={allOrgs}
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={handleSave}
      />
    </div>
  );
}
