import { useState, useCallback, useMemo } from 'react';
import {
  SquareDashedMousePointer,
  MousePointerClick,
  Trash2,
  Download,
  ArrowLeftRight,
  ArrowDownToLine,
  ClipboardList,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  MapPin,
  Container,
  Layers,
  Clock,
  User,
  Send,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ─────────────────────────── types ─────────────────────────── */

interface GridCell {
  id: string;
  row: number;
  col: number;
  density: number;
}

interface Vehicle {
  id: string;
  type: string;
  status: string;
  location: string;
  cellId: string;
}

interface OperationRecord {
  id: string;
  time: string;
  operator: string;
  selectionType: string;
  count: number;
  opType: string;
  status: '成功' | '部分成功' | '失败';
}

/* ─────────────────────────── mock data ─────────────────────────── */

const GRID_ROWS = 6;
const GRID_COLS = 8;

const gridData: GridCell[] = Array.from({ length: GRID_ROWS * GRID_COLS }, (_, i) => ({
  id: `cell-${i}`,
  row: Math.floor(i / GRID_COLS),
  col: i % GRID_COLS,
  density: [0, 0, 1, 0, 2, 1, 0, 3, 0, 1, 2, 0, 0, 4, 1, 0, 2, 3, 0, 1, 0, 2, 0, 0, 1, 0, 3, 2, 0, 1, 0, 2, 0, 0, 1, 0, 4, 2, 0, 1, 0, 3, 0, 2, 1, 0, 0, 2][i] ?? 0,
}));

const allVehicles: Vehicle[] = [
  { id: 'VH-2025-001', type: '标准托盘', status: '在库', location: 'A1-03', cellId: 'cell-2' },
  { id: 'VH-2025-002', type: '折叠箱', status: '在途', location: 'B2-07', cellId: 'cell-4' },
  { id: 'VH-2025-003', type: '标准托盘', status: '在库', location: 'C3-01', cellId: 'cell-5' },
  { id: 'VH-2025-004', type: '冷链箱', status: '在库', location: 'D4-05', cellId: 'cell-7' },
  { id: 'VH-2025-005', type: '折叠箱', status: '维修中', location: 'A2-02', cellId: 'cell-9' },
  { id: 'VH-2025-006', type: '标准托盘', status: '在途', location: 'B3-04', cellId: 'cell-10' },
  { id: 'VH-2025-007', type: '冷链箱', status: '在库', location: 'E1-06', cellId: 'cell-13' },
  { id: 'VH-2025-008', type: '折叠箱', status: '在库', location: 'F2-01', cellId: 'cell-16' },
  { id: 'VH-2025-009', type: '标准托盘', status: '在途', location: 'G3-03', cellId: 'cell-17' },
  { id: 'VH-2025-010', type: '冷链箱', status: '在库', location: 'H1-02', cellId: 'cell-19' },
  { id: 'VH-2025-011', type: '折叠箱', status: '在库', location: 'A4-05', cellId: 'cell-21' },
  { id: 'VH-2025-012', type: '标准托盘', status: '维修中', location: 'B5-07', cellId: 'cell-25' },
  { id: 'VH-2025-013', type: '冷链箱', status: '在途', location: 'C6-04', cellId: 'cell-26' },
  { id: 'VH-2025-014', type: '折叠箱', status: '在库', location: 'D1-01', cellId: 'cell-27' },
  { id: 'VH-2025-015', type: '标准托盘', status: '在库', location: 'E2-06', cellId: 'cell-29' },
  { id: 'VH-2025-016', type: '冷链箱', status: '在途', location: 'F3-02', cellId: 'cell-31' },
  { id: 'VH-2025-017', type: '折叠箱', status: '在库', location: 'G4-05', cellId: 'cell-34' },
  { id: 'VH-2025-018', type: '标准托盘', status: '在库', location: 'H5-03', cellId: 'cell-37' },
  { id: 'VH-2025-019', type: '冷链箱', status: '维修中', location: 'A6-07', cellId: 'cell-39' },
  { id: 'VH-2025-020', type: '折叠箱', status: '在库', location: 'B1-04', cellId: 'cell-41' },
];

const historyData: OperationRecord[] = [
  { id: 'OP-20250601-001', time: '2025-06-01 09:23', operator: '张三', selectionType: '矩形', count: 12, opType: '调拨', status: '成功' },
  { id: 'OP-20250601-002', time: '2025-06-01 10:45', operator: '李四', selectionType: '多边形', count: 8, opType: '入库', status: '成功' },
  { id: 'OP-20250601-003', time: '2025-06-01 11:12', operator: '王五', selectionType: '矩形', count: 25, opType: '导出', status: '部分成功' },
  { id: 'OP-20250601-004', time: '2025-06-01 13:30', operator: '赵六', selectionType: '多边形', count: 5, opType: '调拨', status: '失败' },
  { id: 'OP-20250601-005', time: '2025-06-01 14:15', operator: '张三', selectionType: '矩形', count: 18, opType: '入库', status: '成功' },
  { id: 'OP-20250601-006', time: '2025-06-01 15:42', operator: '李四', selectionType: '矩形', count: 7, opType: '调拨', status: '成功' },
  { id: 'OP-20250601-007', time: '2025-06-01 16:20', operator: '王五', selectionType: '多边形', count: 14, opType: '导出', status: '成功' },
  { id: 'OP-20250601-008', time: '2025-06-01 17:05', operator: '赵六', selectionType: '矩形', count: 3, opType: '入库', status: '失败' },
];

const kpiData = [
  { label: '框选操作次数', value: '128', icon: SquareDashedMousePointer, color: 'text-primary' },
  { label: '批量调拨数', value: '86', icon: ArrowLeftRight, color: 'text-success' },
  { label: '批量入库数', value: '42', icon: ArrowDownToLine, color: 'text-info' },
  { label: '批量导出数', value: '35', icon: Download, color: 'text-purple' },
  { label: '选中载具数', value: '0', icon: Container, color: 'text-warning' },
];

/* ─────────────────────────── helpers ─────────────────────────── */

function getDensityColor(d: number): string {
  if (d === 0) return 'bg-slate-50';
  if (d === 1) return 'bg-blue-100';
  if (d === 2) return 'bg-blue-300';
  if (d === 3) return 'bg-blue-500';
  return 'bg-blue-700';
}

function getDensityTextColor(d: number): string {
  if (d >= 3) return 'text-white';
  return 'text-slate-700';
}

function statusBadgeClass(status: string): string {
  switch (status) {
    case '成功':
      return 'bg-success text-white';
    case '部分成功':
      return 'bg-warning text-white';
    case '失败':
      return 'bg-danger text-white';
    default:
      return 'bg-neutral-background text-neutral-textSecondary';
  }
}

/* ─────────────────────────── component ─────────────────────────── */

export default function MapBatchOpsPage() {
  const [activeTab, setActiveTab] = useState('selection');
  const [selectionMode, setSelectionMode] = useState<'rect' | 'poly' | null>(null);
  const [selectedCells, setSelectedCells] = useState<Set<string>>(new Set());
  const [rectAnchor, setRectAnchor] = useState<string | null>(null);
  const [vehicleStatusFilter, setVehicleStatusFilter] = useState('all');

  const selectedVehicles = useMemo(() => {
    return allVehicles.filter((v) => selectedCells.has(v.cellId));
  }, [selectedCells]);

  const selectedCount = selectedVehicles.length;

  const handleCellClick = useCallback(
    (cellId: string) => {
      if (!selectionMode) return;

      if (selectionMode === 'poly') {
        setSelectedCells((prev) => {
          const next = new Set(prev);
          if (next.has(cellId)) {
            next.delete(cellId);
          } else {
            next.add(cellId);
          }
          return next;
        });
      } else if (selectionMode === 'rect') {
        if (rectAnchor === null) {
          setRectAnchor(cellId);
          setSelectedCells(new Set([cellId]));
        } else {
          const anchorCell = gridData.find((c) => c.id === rectAnchor);
          const endCell = gridData.find((c) => c.id === cellId);
          if (anchorCell && endCell) {
            const minRow = Math.min(anchorCell.row, endCell.row);
            const maxRow = Math.max(anchorCell.row, endCell.row);
            const minCol = Math.min(anchorCell.col, endCell.col);
            const maxCol = Math.max(anchorCell.col, endCell.col);
            const next = new Set<string>();
            for (let r = minRow; r <= maxRow; r++) {
              for (let c = minCol; c <= maxCol; c++) {
                const idx = r * GRID_COLS + c;
                if (idx >= 0 && idx < gridData.length) {
                  next.add(gridData[idx].id);
                }
              }
            }
            setSelectedCells(next);
          }
          setRectAnchor(null);
        }
      }
    },
    [selectionMode, rectAnchor]
  );

  const clearSelection = useCallback(() => {
    setSelectedCells(new Set());
    setRectAnchor(null);
  }, []);

  const filteredVehicles = useMemo(() => {
    if (vehicleStatusFilter === 'all') return selectedVehicles;
    return selectedVehicles.filter((v) => v.status === vehicleStatusFilter);
  }, [selectedVehicles, vehicleStatusFilter]);

  return (
    <div className="min-h-[calc(100vh-3.5rem)] bg-[var(--neutral-surface)] p-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">地图框选批量操作</h1>
        <p className="text-sm text-neutral-textSecondary mt-1">
          矩形框选 · 多边形圈选 · 批量调拨 · 批量入库确认
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        {kpiData.map((kpi, idx) => (
          <Card key={idx} className="border-[var(--neutral-border)]">
            <CardContent className="p-4 flex items-center gap-3">
              <div className={cn('p-2 rounded-md bg-neutral-background', kpi.color)}>
                <kpi.icon size={20} />
              </div>
              <div>
                <p className="text-xs text-neutral-textSecondary">{kpi.label}</p>
                <p className="text-xl font-bold text-[var(--neutral-text-primary)]">
                  {kpi.label === '选中载具数' ? selectedCount : kpi.value}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="selection">框选操作</TabsTrigger>
          <TabsTrigger value="history">操作历史</TabsTrigger>
          <TabsTrigger value="transfer">批量调拨</TabsTrigger>
          <TabsTrigger value="inbound">批量入库确认</TabsTrigger>
        </TabsList>

        {/* ── Tab 1: 框选操作 ── */}
        <TabsContent value="selection" className="space-y-4">
          {/* Toolbar */}
          <div className="flex flex-wrap items-center gap-3 bg-neutral-background border border-[var(--neutral-border)] rounded-lg p-3">
            <Button
              variant={selectionMode === 'rect' ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setSelectionMode(selectionMode === 'rect' ? null : 'rect');
                clearSelection();
              }}
              className={cn(
                'gap-2',
                selectionMode === 'rect' ? 'bg-primary text-white' : 'border-[var(--neutral-border)]'
              )}
            >
              <SquareDashedMousePointer size={16} />
              矩形框选
            </Button>
            <Button
              variant={selectionMode === 'poly' ? 'default' : 'outline'}
              size="sm"
              onClick={() => {
                setSelectionMode(selectionMode === 'poly' ? null : 'poly');
                clearSelection();
              }}
              className={cn(
                'gap-2',
                selectionMode === 'poly' ? 'bg-primary text-white' : 'border-[var(--neutral-border)]'
              )}
            >
              <MousePointerClick size={16} />
              多边形圈选
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={clearSelection}
              className="gap-2 border-[var(--neutral-border)]"
            >
              <Trash2 size={16} />
              清除选择
            </Button>
            <div className="ml-auto flex items-center gap-2 text-sm text-[var(--neutral-text-primary)]">
              <Container size={16} className="text-neutral-textTertiary" />
              当前已选中
              <span className="font-bold text-primary">{selectedCount}</span>
              个载具
            </div>
          </div>

          {/* Map Grid */}
          <div className="bg-neutral-background border border-[var(--neutral-border)] rounded-lg p-4">
            <div className="grid grid-cols-8 gap-1">
              {gridData.map((cell) => {
                const isSelected = selectedCells.has(cell.id);
                const densityColor = getDensityColor(cell.density);
                const densityText = getDensityTextColor(cell.density);
                return (
                  <button
                    key={cell.id}
                    onClick={() => handleCellClick(cell.id)}
                    className={cn(
                      'h-12 rounded-sm flex items-center justify-center text-xs font-medium transition-all select-none',
                      densityColor,
                      densityText,
                      isSelected && 'ring-2 ring-primary ring-offset-1 z-10',
                      selectionMode && 'cursor-pointer hover:opacity-80',
                      !selectionMode && 'cursor-default'
                    )}
                    title={`区块 ${cell.row + 1}-${cell.col + 1} · 密度 ${cell.density}`}
                  >
                    {cell.density > 0 ? cell.density : ''}
                  </button>
                );
              })}
            </div>
            <div className="flex items-center gap-4 mt-3 text-xs text-neutral-textSecondary">
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-slate-50 border border-[var(--neutral-border)] rounded-sm inline-block" />
                空闲
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-blue-100 rounded-sm inline-block" />
                低密度
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-blue-300 rounded-sm inline-block" />
                中密度
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-blue-500 rounded-sm inline-block" />
                高密度
              </span>
              <span className="flex items-center gap-1">
                <span className="w-3 h-3 bg-blue-700 rounded-sm inline-block" />
                满载
              </span>
            </div>
          </div>

          {/* Selected Vehicle Preview */}
          <Card className="border-[var(--neutral-border)]">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <Layers size={18} className="text-primary" />
                  选中载具列表预览（前10条）
                </CardTitle>
                <Select value={vehicleStatusFilter} onValueChange={setVehicleStatusFilter}>
                  <SelectTrigger className="w-[140px] h-8 text-xs">
                    <SelectValue placeholder="全部状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="在库">在库</SelectItem>
                    <SelectItem value="在途">在途</SelectItem>
                    <SelectItem value="维修中">维修中</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredVehicles.length === 0 ? (
                <div className="text-sm text-neutral-textTertiary py-6 text-center">
                  暂无选中的载具，请在上方地图进行框选操作
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">类型</TableHead>
                      <TableHead className="text-xs">状态</TableHead>
                      <TableHead className="text-xs">位置</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVehicles.slice(0, 10).map((v) => (
                      <TableRow key={v.id} className="text-sm">
                        <TableCell className="font-medium">{v.id}</TableCell>
                        <TableCell>{v.type}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={cn(
                              'text-xs',
                              v.status === '在库' && 'border-success text-success',
                              v.status === '在途' && 'border-primary text-primary',
                              v.status === '维修中' && 'border-warning text-warning'
                            )}
                          >
                            {v.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="flex items-center gap-1 text-neutral-textSecondary">
                          <MapPin size={12} />
                          {v.location}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Batch Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button
              className="gap-2 bg-primary hover:bg-primary-hover"
              disabled={selectedCount === 0}
              onClick={() => setActiveTab('transfer')}
            >
              <ArrowLeftRight size={16} />
              批量调拨
            </Button>
            <Button
              className="gap-2 bg-success hover:bg-emerald-600"
              disabled={selectedCount === 0}
              onClick={() => setActiveTab('inbound')}
            >
              <ArrowDownToLine size={16} />
              批量入库确认
            </Button>
            <Button
              variant="outline"
              className="gap-2 border-[var(--neutral-border)]"
              disabled={selectedCount === 0}
            >
              <Download size={16} />
              批量导出
            </Button>
          </div>
        </TabsContent>

        {/* ── Tab 2: 操作历史 ── */}
        <TabsContent value="history">
          <Card className="border-[var(--neutral-border)]">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <ClipboardList size={18} className="text-primary" />
                操作历史记录
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-xs">操作编号</TableHead>
                    <TableHead className="text-xs">操作时间</TableHead>
                    <TableHead className="text-xs">操作人</TableHead>
                    <TableHead className="text-xs">框选方式</TableHead>
                    <TableHead className="text-xs">选中数量</TableHead>
                    <TableHead className="text-xs">操作类型</TableHead>
                    <TableHead className="text-xs">执行状态</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historyData.map((record) => (
                    <TableRow key={record.id} className="text-sm">
                      <TableCell className="font-medium">{record.id}</TableCell>
                      <TableCell className="flex items-center gap-1 text-neutral-textSecondary">
                        <Clock size={12} />
                        {record.time}
                      </TableCell>
                      <TableCell className="flex items-center gap-1 text-neutral-textSecondary">
                        <User size={12} />
                        {record.operator}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {record.selectionType}
                        </Badge>
                      </TableCell>
                      <TableCell>{record.count}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="text-xs">
                          {record.opType}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={cn('text-xs', statusBadgeClass(record.status))}>
                          {record.status === '成功' && <CheckCircle2 size={12} className="mr-1" />}
                          {record.status === '部分成功' && <AlertTriangle size={12} className="mr-1" />}
                          {record.status === '失败' && <XCircle size={12} className="mr-1" />}
                          {record.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab 3: 批量调拨 ── */}
        <TabsContent value="transfer">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left: Selected Vehicle List */}
            <Card className="border-[var(--neutral-border)]">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Container size={18} className="text-primary" />
                  已选择载具列表（{selectedCount}条）
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedVehicles.length === 0 ? (
                  <div className="text-sm text-neutral-textTertiary py-6 text-center">
                    暂无选中的载具，请先返回「框选操作」进行框选
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                    {selectedVehicles.map((v) => (
                      <div
                        key={v.id}
                        className="flex items-center justify-between p-2 rounded-md border border-[var(--neutral-border)] bg-neutral-background"
                      >
                        <div className="flex items-center gap-2">
                          <Container size={14} className="text-neutral-textTertiary" />
                          <span className="text-sm font-medium">{v.id}</span>
                          <Badge variant="outline" className="text-xs">
                            {v.type}
                          </Badge>
                        </div>
                        <span className="text-xs text-neutral-textSecondary">{v.location}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Right: Transfer Form */}
            <Card className="border-[var(--neutral-border)]">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <ArrowLeftRight size={18} className="text-success" />
                  调拨表单
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">目标网点</label>
                  <Select>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择目标网点" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beijing">北京朝阳网点</SelectItem>
                      <SelectItem value="shanghai">上海浦东网点</SelectItem>
                      <SelectItem value="guangzhou">广州天河网点</SelectItem>
                      <SelectItem value="shenzhen">深圳南山网点</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">调拨类型</label>
                  <Select>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择调拨类型" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="normal">正常调拨</SelectItem>
                      <SelectItem value="urgent">紧急调拨</SelectItem>
                      <SelectItem value="return">返厂调拨</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">备注</label>
                  <Textarea placeholder="请输入调拨备注信息..." rows={4} />
                </div>

                <Button className="w-full gap-2 bg-success hover:bg-emerald-600" disabled={selectedCount === 0}>
                  <Send size={16} />
                  提交调拨
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── Tab 4: 批量入库确认 ── */}
        <TabsContent value="inbound">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Left: Selected Vehicle List */}
            <Card className="border-[var(--neutral-border)]">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Container size={18} className="text-primary" />
                  已选择载具列表（{selectedCount}条）
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedVehicles.length === 0 ? (
                  <div className="text-sm text-neutral-textTertiary py-6 text-center">
                    暂无选中的载具，请先返回「框选操作」进行框选
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
                    {selectedVehicles.map((v) => (
                      <div
                        key={v.id}
                        className="flex items-center justify-between p-2 rounded-md border border-[var(--neutral-border)] bg-neutral-background"
                      >
                        <div className="flex items-center gap-2">
                          <Container size={14} className="text-neutral-textTertiary" />
                          <span className="text-sm font-medium">{v.id}</span>
                          <Badge variant="outline" className="text-xs">
                            {v.type}
                          </Badge>
                        </div>
                        <span className="text-xs text-neutral-textSecondary">{v.location}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Right: Inbound Form */}
            <Card className="border-[var(--neutral-border)]">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <ArrowDownToLine size={18} className="text-info" />
                  入库表单
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">目标网点</label>
                  <Select>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择目标网点" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beijing">北京朝阳网点</SelectItem>
                      <SelectItem value="shanghai">上海浦东网点</SelectItem>
                      <SelectItem value="guangzhou">广州天河网点</SelectItem>
                      <SelectItem value="shenzhen">深圳南山网点</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">入库原因</label>
                  <Select>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="请选择入库原因" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">新购入库</SelectItem>
                      <SelectItem value="repair">维修返库</SelectItem>
                      <SelectItem value="transfer">调拨入库</SelectItem>
                      <SelectItem value="return">退租入库</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-[var(--neutral-text-primary)]">备注</label>
                  <Textarea placeholder="请输入入库备注信息..." rows={4} />
                </div>

                <Button className="w-full gap-2 bg-info hover:bg-cyan-600" disabled={selectedCount === 0}>
                  <CheckCircle2 size={16} />
                  确认入库
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
