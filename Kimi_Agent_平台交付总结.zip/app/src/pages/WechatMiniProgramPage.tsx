import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import {
  Smartphone,
  QrCode,
  MessageSquare,
  Users,
  ScanLine,
  Download,
  CheckCircle,
  XCircle,
  Clock,
  MapPin,
  Settings,
  Eye,
  Ban,
  Play,
  Search,
  ChevronLeft,
  ChevronRight,
  Copy,
  ShieldCheck,
  Wifi,
  WifiOff,
  RefreshCw,
} from 'lucide-react';

// ==================== Types ====================
interface StatItem {
  title: string;
  value: string | number;
  color: string;
  icon: React.ElementType;
  change?: string;
}

interface MiniProgramConfig {
  name: string;
  appId: string;
  version: string;
  status: 'online' | 'offline' | 'review';
  scanBindEnabled: boolean;
  messagePushEnabled: boolean;
  locationEnabled: boolean;
  homePage: string;
  bindPage: string;
  queryPage: string;
}

interface WechatUser {
  id: string;
  nickname: string;
  phone: string;
  boundVehicleCount: number;
  lastActiveAt: string;
  status: 'active' | 'disabled';
}

interface ScanRecord {
  id: string;
  time: string;
  user: string;
  type: 'vehicle_bind' | 'carrier_bind' | 'site_checkin';
  result: 'success' | 'fail';
  location: string;
  detail?: string;
}

interface PushRecord {
  id: string;
  time: string;
  user: string;
  type: 'inbound' | 'outbound' | 'alarm' | 'task';
  status: 'delivered' | 'failed';
  content: string;
}

interface QrCodeItem {
  id: string;
  name: string;
  scene: string;
  description: string;
  usageCount: number;
  color: string;
}

// ==================== Mock Data ====================
const INITIAL_CONFIG: MiniProgramConfig = {
  name: '云载具智管',
  appId: 'wxa1b2c3d4e5f67890',
  version: 'v2.4.1',
  status: 'online',
  scanBindEnabled: true,
  messagePushEnabled: true,
  locationEnabled: false,
  homePage: 'pages/index/index',
  bindPage: 'pages/bind/bind',
  queryPage: 'pages/query/query',
};

const MOCK_USERS: WechatUser[] = [
  { id: 'wu-1', nickname: '张师傅', phone: '138****1234', boundVehicleCount: 3, lastActiveAt: '2024-12-20 09:30:00', status: 'active' },
  { id: 'wu-2', nickname: '李调度', phone: '139****5678', boundVehicleCount: 5, lastActiveAt: '2024-12-20 08:45:00', status: 'active' },
  { id: 'wu-3', nickname: '王仓管', phone: '137****9012', boundVehicleCount: 0, lastActiveAt: '2024-12-19 17:20:00', status: 'active' },
  { id: 'wu-4', nickname: '赵司机', phone: '136****3456', boundVehicleCount: 2, lastActiveAt: '2024-12-18 16:00:00', status: 'active' },
  { id: 'wu-5', nickname: '孙运营', phone: '135****7890', boundVehicleCount: 8, lastActiveAt: '2024-12-20 10:00:00', status: 'active' },
  { id: 'wu-6', nickname: '周检查', phone: '134****1122', boundVehicleCount: 1, lastActiveAt: '2024-11-30 14:00:00', status: 'disabled' },
  { id: 'wu-7', nickname: '吴物流', phone: '133****3344', boundVehicleCount: 4, lastActiveAt: '2024-12-19 09:15:00', status: 'active' },
  { id: 'wu-8', nickname: '郑管理', phone: '132****5566', boundVehicleCount: 6, lastActiveAt: '2024-12-20 07:30:00', status: 'active' },
  { id: 'wu-9', nickname: '钱巡检', phone: '131****7788', boundVehicleCount: 2, lastActiveAt: '2024-12-17 15:30:00', status: 'active' },
  { id: 'wu-10', nickname: '刘装卸', phone: '130****9900', boundVehicleCount: 0, lastActiveAt: '2024-12-16 11:20:00', status: 'disabled' },
  { id: 'wu-11', nickname: '陈司机', phone: '159****2233', boundVehicleCount: 3, lastActiveAt: '2024-12-19 18:30:00', status: 'active' },
  { id: 'wu-12', nickname: '杨调度', phone: '158****4455', boundVehicleCount: 7, lastActiveAt: '2024-12-18 09:00:00', status: 'active' },
];

const MOCK_SCAN_RECORDS: ScanRecord[] = [
  { id: 'sr-1', time: '2024-12-20 09:15:32', user: '张师傅', type: 'vehicle_bind', result: 'success', location: '上海浦东工厂A区' },
  { id: 'sr-2', time: '2024-12-20 08:42:10', user: '李调度', type: 'carrier_bind', result: 'success', location: '宁波生产基地仓库' },
  { id: 'sr-3', time: '2024-12-20 07:58:05', user: '孙运营', type: 'site_checkin', result: 'success', location: '广州仓储中心大门' },
  { id: 'sr-4', time: '2024-12-19 17:10:22', user: '王仓管', type: 'vehicle_bind', result: 'fail', location: '上海浦东工厂B区', detail: '车辆已被绑定' },
  { id: 'sr-5', time: '2024-12-19 16:35:48', user: '赵司机', type: 'carrier_bind', result: 'success', location: '天津港仓库装卸区' },
  { id: 'sr-6', time: '2024-12-19 14:22:15', user: '吴物流', type: 'site_checkin', result: 'fail', location: '青岛物流中心', detail: '网点不存在' },
  { id: 'sr-7', time: '2024-12-19 10:05:33', user: '郑管理', type: 'vehicle_bind', result: 'success', location: '北京运营中心停车场' },
  { id: 'sr-8', time: '2024-12-18 18:45:09', user: '陈司机', type: 'carrier_bind', result: 'success', location: '深圳配送中心分拣区' },
  { id: 'sr-9', time: '2024-12-18 15:30:27', user: '杨调度', type: 'site_checkin', result: 'success', location: '杭州运营中心' },
  { id: 'sr-10', time: '2024-12-18 11:12:44', user: '钱巡检', type: 'vehicle_bind', result: 'fail', location: '上海浦东工厂C区', detail: '二维码已过期' },
  { id: 'sr-11', time: '2024-12-17 09:20:18', user: '张师傅', type: 'carrier_bind', result: 'success', location: '上海浦东工厂A区' },
  { id: 'sr-12', time: '2024-12-17 08:05:56', user: '李调度', type: 'site_checkin', result: 'success', location: '宁波生产基地大门' },
];

const MOCK_PUSH_RECORDS: PushRecord[] = [
  { id: 'pr-1', time: '2024-12-20 09:30:00', user: '张师傅', type: 'inbound', status: 'delivered', content: '您的车辆沪A12345已完成入库' },
  { id: 'pr-2', time: '2024-12-20 08:45:00', user: '李调度', type: 'outbound', status: 'delivered', content: '载具CT-8823已出库，目的地：杭州' },
  { id: 'pr-3', time: '2024-12-20 07:15:00', user: '孙运营', type: 'alarm', status: 'delivered', content: '车辆沪B67890触发超速报警' },
  { id: 'pr-4', time: '2024-12-19 17:20:00', user: '赵司机', type: 'task', status: 'failed', content: '新任务分配：将CT-9901运送至浦东' },
  { id: 'pr-5', time: '2024-12-19 16:00:00', user: '吴物流', type: 'inbound', status: 'delivered', content: '载具CT-5544已到达天津港仓库' },
  { id: 'pr-6', time: '2024-12-19 14:30:00', user: '郑管理', type: 'outbound', status: 'delivered', content: '车辆沪C11111已完成出库手续' },
  { id: 'pr-7', time: '2024-12-19 10:00:00', user: '陈司机', type: 'alarm', status: 'delivered', content: '载具CT-2233低电量提醒' },
  { id: 'pr-8', time: '2024-12-18 18:30:00', user: '杨调度', type: 'task', status: 'failed', content: '任务变更：取消今日配送任务' },
  { id: 'pr-9', time: '2024-12-18 15:00:00', user: '钱巡检', type: 'inbound', status: 'delivered', content: '载具CT-6677已入库深圳配送中心' },
  { id: 'pr-10', time: '2024-12-18 09:00:00', user: '张师傅', type: 'outbound', status: 'delivered', content: '车辆沪A12345已出库' },
];

const MOCK_QR_CODES: QrCodeItem[] = [
  { id: 'qr-1', name: '车辆绑定码', scene: 'scene_vehicle_bind', description: '用于司机扫码绑定运输车辆', usageCount: 342, color: '#2563EB' },
  { id: 'qr-2', name: '载具查询码', scene: 'scene_carrier_query', description: '用于仓库人员扫码查询载具状态', usageCount: 568, color: '#10B981' },
  { id: 'qr-3', name: '网点签到码', scene: 'scene_site_checkin', description: '用于司机到达网点后扫码签到', usageCount: 189, color: '#F59E0B' },
];

// ==================== Helpers ====================
const STATUS_MAP: Record<string, { label: string; color: string; bg: string }> = {
  active: { label: '启用', color: '#10B981', bg: '#ECFDF5' },
  disabled: { label: '禁用', color: '#EF4444', bg: '#FEF2F2' },
};

const SCAN_TYPE_MAP: Record<string, { label: string; color: string; bg: string }> = {
  vehicle_bind: { label: '车辆绑定', color: '#2563EB', bg: '#EFF6FF' },
  carrier_bind: { label: '载具绑定', color: '#10B981', bg: '#ECFDF5' },
  site_checkin: { label: '网点签到', color: '#F59E0B', bg: '#FFFBEB' },
};

const PUSH_TYPE_MAP: Record<string, { label: string; color: string; bg: string }> = {
  inbound: { label: '入库通知', color: '#2563EB', bg: '#EFF6FF' },
  outbound: { label: '出库通知', color: '#10B981', bg: '#ECFDF5' },
  alarm: { label: '报警通知', color: '#EF4444', bg: '#FEF2F2' },
  task: { label: '任务提醒', color: '#8B5CF6', bg: '#F5F3FF' },
};

const MP_STATUS_MAP: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  online: { label: '运行中', color: '#10B981', bg: '#ECFDF5', icon: Wifi },
  offline: { label: '已下线', color: '#EF4444', bg: '#FEF2F2', icon: WifiOff },
  review: { label: '审核中', color: '#F59E0B', bg: '#FFFBEB', icon: Clock },
};

function Tag({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
      style={{ color, backgroundColor: bg }}
    >
      {label}
    </span>
  );
}

function Pagination({
  currentPage,
  totalPages,
  onChange,
  total,
}: {
  currentPage: number;
  totalPages: number;
  onChange: (p: number) => void;
  total: number;
}) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
      <span className="text-sm text-[#475569]">
        共 <strong>{total}</strong> 条
      </span>
      <div className="flex items-center gap-1">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
          className="h-8 px-3 text-xs"
        >
          <ChevronLeft size={14} className="mr-1" /> 上一页
        </Button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let page: number;
          if (totalPages <= 5) page = i + 1;
          else if (currentPage <= 3) page = i + 1;
          else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
          else page = currentPage - 2 + i;
          return (
            <Button
              key={page}
              variant={currentPage === page ? 'default' : 'outline'}
              size="sm"
              onClick={() => onChange(page)}
              className={cn(
                'w-8 h-8 text-xs p-0',
                currentPage === page && 'bg-[#2563EB] text-white hover:bg-[#1D4ED8]'
              )}
            >
              {page}
            </Button>
          );
        })}
        <Button
          variant="outline"
          size="sm"
          onClick={() => onChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
          className="h-8 px-3 text-xs"
        >
          下一页 <ChevronRight size={14} className="ml-1" />
        </Button>
      </div>
    </div>
  );
}

// ==================== Stat Cards ====================
function StatCards() {
  const stats: StatItem[] = [
    { title: '绑定用户总数', value: 1286, color: '#2563EB', icon: Users, change: '+12% 较上周' },
    { title: '今日活跃用户', value: 342, color: '#10B981', icon: Smartphone, change: '+8% 较昨日' },
    { title: '小程序码扫描次数', value: 5682, color: '#F59E0B', icon: ScanLine, change: '+23% 较昨日' },
    { title: '绑定载具数', value: 892, color: '#8B5CF6', icon: QrCode, change: '+5% 较上周' },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: idx * 0.08 }}
        >
          <Card className="border-0 shadow-card hover:shadow-card-hover transition-shadow duration-200">
            <CardContent className="p-4 flex items-start gap-4">
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: `${stat.color}15` }}
              >
                <stat.icon size={20} style={{ color: stat.color }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-[#475569] mb-1">{stat.title}</p>
                <p className="text-[28px] font-semibold text-[#0F172A] leading-tight font-number">
                  {stat.value}
                </p>
                {stat.change && (
                  <p className="text-xs text-[#10B981] mt-1">{stat.change}</p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

// ==================== Config Section ====================
function ConfigSection() {
  const [config, setConfig] = useState<MiniProgramConfig>(INITIAL_CONFIG);
  const [copied, setCopied] = useState(false);

  const toggleConfig = (key: keyof MiniProgramConfig) => {
    if (typeof config[key] === 'boolean') {
      setConfig((prev) => ({ ...prev, [key]: !prev[key as keyof MiniProgramConfig] }));
    }
  };

  const copyAppId = () => {
    navigator.clipboard.writeText(config.appId);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const statusCfg = MP_STATUS_MAP[config.status];

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.35 }}
    >
      <Card className="border-0 shadow-card">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Settings size={18} className="text-[#2563EB]" />
              <CardTitle className="text-base font-semibold text-[#0F172A]">小程序配置</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <statusCfg.icon size={14} style={{ color: statusCfg.color }} />
              <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-[#0F172A]">基本信息</h4>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs text-[#475569] mb-1">小程序名称</label>
                  <div className="flex items-center gap-2 h-9 px-3 bg-[#F8FAFC] rounded-md text-sm text-[#0F172A] border border-[#E2E8F0]">
                    <Smartphone size={14} className="text-[#94A3B8]" />
                    {config.name}
                  </div>
                </div>
                <div>
                  <label className="block text-xs text-[#475569] mb-1">AppID</label>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-9 px-3 bg-[#F8FAFC] rounded-md text-sm text-[#0F172A] border border-[#E2E8F0] font-mono truncate leading-9">
                      {config.appId}
                    </div>
                    <Button variant="outline" size="sm" className="h-9 px-3" onClick={copyAppId}>
                      {copied ? <CheckCircle size={14} className="text-[#10B981]" /> : <Copy size={14} />}
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#475569] mb-1">版本号</label>
                    <div className="h-9 px-3 bg-[#F8FAFC] rounded-md text-sm text-[#0F172A] border border-[#E2E8F0] leading-9">
                      {config.version}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-[#475569] mb-1">状态</label>
                    <div className="h-9 px-3 bg-[#F8FAFC] rounded-md text-sm text-[#0F172A] border border-[#E2E8F0] leading-9 flex items-center gap-2">
                      <ShieldCheck size={14} style={{ color: statusCfg.color }} />
                      {statusCfg.label}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 配置项 */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-[#0F172A]">功能配置</h4>
              <div className="space-y-3">
                {[
                  { key: 'scanBindEnabled' as const, label: '扫码绑定', desc: '允许用户通过扫码绑定车辆/载具' },
                  { key: 'messagePushEnabled' as const, label: '消息推送', desc: '向用户推送业务通知和报警' },
                  { key: 'locationEnabled' as const, label: '位置权限', desc: '获取用户位置用于网点签到' },
                ].map((item) => (
                  <div
                    key={item.key}
                    className="flex items-center justify-between p-3 rounded-lg border border-[#E2E8F0] hover:border-[#BFDBFE] transition-colors"
                  >
                    <div>
                      <p className="text-sm font-medium text-[#0F172A]">{item.label}</p>
                      <p className="text-xs text-[#94A3B8] mt-0.5">{item.desc}</p>
                    </div>
                    <Switch
                      checked={config[item.key]}
                      onCheckedChange={() => toggleConfig(item.key)}
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* 页面路径配置 */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-[#0F172A]">页面路径配置</h4>
              <div className="space-y-3">
                {[
                  { key: 'homePage' as const, label: '首页路径', placeholder: 'pages/index/index' },
                  { key: 'bindPage' as const, label: '绑定页路径', placeholder: 'pages/bind/bind' },
                  { key: 'queryPage' as const, label: '查询页路径', placeholder: 'pages/query/query' },
                ].map((item) => (
                  <div key={item.key}>
                    <label className="block text-xs text-[#475569] mb-1">{item.label}</label>
                    <Input
                      value={config[item.key]}
                      onChange={(e) =>
                        setConfig((prev) => ({ ...prev, [item.key]: e.target.value }))
                      }
                      placeholder={item.placeholder}
                      className="h-9 text-sm"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ==================== User Management Tab ====================
function UserManagementTab() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [users, setUsers] = useState<WechatUser[]>(MOCK_USERS);
  const [dialogUser, setDialogUser] = useState<WechatUser | null>(null);
  const pageSize = 8;

  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (search) {
        return u.nickname.includes(search) || u.phone.includes(search);
      }
      return true;
    });
  }, [users, statusFilter, search]);

  const totalPages = Math.ceil(filteredUsers.length / pageSize);
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, currentPage]);

  const toggleUserStatus = (user: WechatUser) => {
    setUsers((prev) =>
      prev.map((u) =>
        u.id === user.id ? { ...u, status: u.status === 'active' ? 'disabled' : 'active' } : u
      )
    );
    setDialogUser(null);
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setStatusFilter(v);
            setCurrentPage(1);
          }}
        >
          <SelectTrigger className="w-32 h-9 text-sm">
            <SelectValue placeholder="全部状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="active">启用</SelectItem>
            <SelectItem value="disabled">禁用</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="搜索昵称、手机号..."
              className="h-9 pl-9 text-sm"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="text-[13px] font-medium text-[#475569]">用户头像</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">昵称</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">手机号</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">绑定车辆数</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">最近活跃时间</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">状态</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedUsers.map((user, idx) => {
                const statusCfg = STATUS_MAP[user.status];
                return (
                  <motion.tr
                    key={user.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group"
                  >
                    <TableCell>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback
                          className="text-xs font-medium"
                          style={{
                            backgroundColor: `${statusCfg.color}15`,
                            color: statusCfg.color,
                          }}
                        >
                          {user.nickname.slice(0, 1)}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium text-[#0F172A]">{user.nickname}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-[#475569]">{user.phone}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-[#475569]">{user.boundVehicleCount}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs text-[#94A3B8] font-mono">{user.lastActiveAt}</span>
                    </TableCell>
                    <TableCell>
                      <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                          onClick={() => setDialogUser(user)}
                          title={user.status === 'active' ? '禁用' : '启用'}
                        >
                          {user.status === 'active' ? (
                            <Ban size={13} className="text-[#EF4444]" />
                          ) : (
                            <Play size={13} className="text-[#10B981]" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                );
              })}
              {paginatedUsers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Users size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无用户数据</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        {filteredUsers.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onChange={setCurrentPage}
            total={filteredUsers.length}
          />
        )}
      </div>

      {/* Confirm Dialog */}
      <Dialog open={!!dialogUser} onOpenChange={() => setDialogUser(null)}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">
              {dialogUser?.status === 'active' ? '禁用用户' : '启用用户'}
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <p className="text-sm text-[#475569]">
              确定要{dialogUser?.status === 'active' ? '禁用' : '启用'}用户
              <span className="font-medium text-[#0F172A]">「{dialogUser?.nickname}」</span>吗？
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogUser(null)}>
              取消
            </Button>
            <Button
              onClick={() => dialogUser && toggleUserStatus(dialogUser)}
              className={
                dialogUser?.status === 'active'
                  ? 'bg-[#EF4444] hover:bg-[#DC2626] text-white'
                  : 'bg-[#10B981] hover:bg-[#059669] text-white'
              }
            >
              确定
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ==================== Scan Record Tab ====================
function ScanRecordTab() {
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [resultFilter, setResultFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [detailRecord, setDetailRecord] = useState<ScanRecord | null>(null);
  const pageSize = 6;

  const filtered = useMemo(() => {
    return MOCK_SCAN_RECORDS.filter((r) => {
      if (typeFilter !== 'all' && r.type !== typeFilter) return false;
      if (resultFilter !== 'all' && r.result !== resultFilter) return false;
      if (search) {
        return r.user.includes(search) || r.location.includes(search);
      }
      return true;
    });
  }, [typeFilter, resultFilter, search]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <Select
          value={typeFilter}
          onValueChange={(v) => {
            setTypeFilter(v);
            setCurrentPage(1);
          }}
        >
          <SelectTrigger className="w-36 h-9 text-sm">
            <SelectValue placeholder="全部类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="vehicle_bind">车辆绑定</SelectItem>
            <SelectItem value="carrier_bind">载具绑定</SelectItem>
            <SelectItem value="site_checkin">网点签到</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={resultFilter}
          onValueChange={(v) => {
            setResultFilter(v);
            setCurrentPage(1);
          }}
        >
          <SelectTrigger className="w-32 h-9 text-sm">
            <SelectValue placeholder="全部结果" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部结果</SelectItem>
            <SelectItem value="success">成功</SelectItem>
            <SelectItem value="fail">失败</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="搜索用户、位置..."
              className="h-9 pl-9 text-sm"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="text-[13px] font-medium text-[#475569]">扫码时间</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">用户</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">扫码类型</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">结果</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">位置</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((record, idx) => {
                const typeCfg = SCAN_TYPE_MAP[record.type];
                return (
                  <motion.tr
                    key={record.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group"
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Clock size={14} className="text-[#94A3B8]" />
                        <span className="text-sm text-[#475569]">{record.time}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium text-[#0F172A]">{record.user}</span>
                    </TableCell>
                    <TableCell>
                      <Tag label={typeCfg.label} color={typeCfg.color} bg={typeCfg.bg} />
                    </TableCell>
                    <TableCell>
                      {record.result === 'success' ? (
                        <div className="flex items-center gap-1">
                          <CheckCircle size={14} className="text-[#10B981]" />
                          <span className="text-sm text-[#10B981]">成功</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <XCircle size={14} className="text-[#EF4444]" />
                          <span className="text-sm text-[#EF4444]">失败</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MapPin size={14} className="text-[#94A3B8]" />
                        <span className="text-sm text-[#475569]">{record.location}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 w-7 p-0"
                          onClick={() => setDetailRecord(record)}
                          title="查看详情"
                        >
                          <Eye size={13} className="text-[#475569]" />
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                );
              })}
              {paginated.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <ScanLine size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无扫码记录</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        {filtered.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onChange={setCurrentPage}
            total={filtered.length}
          />
        )}
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!detailRecord} onOpenChange={() => setDetailRecord(null)}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">扫码记录详情</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-3 gap-2 text-sm">
              <span className="text-[#94A3B8]">扫码时间</span>
              <span className="col-span-2 text-[#0F172A]">{detailRecord?.time}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm">
              <span className="text-[#94A3B8]">用户</span>
              <span className="col-span-2 text-[#0F172A]">{detailRecord?.user}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm">
              <span className="text-[#94A3B8]">扫码类型</span>
              <span className="col-span-2">
                {detailRecord && (
                  <Tag
                    label={SCAN_TYPE_MAP[detailRecord.type].label}
                    color={SCAN_TYPE_MAP[detailRecord.type].color}
                    bg={SCAN_TYPE_MAP[detailRecord.type].bg}
                  />
                )}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm">
              <span className="text-[#94A3B8]">结果</span>
              <span className="col-span-2">
                {detailRecord?.result === 'success' ? (
                  <span className="text-[#10B981] flex items-center gap-1">
                    <CheckCircle size={14} /> 成功
                  </span>
                ) : (
                  <span className="text-[#EF4444] flex items-center gap-1">
                    <XCircle size={14} /> 失败
                  </span>
                )}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-sm">
              <span className="text-[#94A3B8]">位置</span>
              <span className="col-span-2 text-[#0F172A]">{detailRecord?.location}</span>
            </div>
            {detailRecord?.detail && (
              <div className="grid grid-cols-3 gap-2 text-sm">
                <span className="text-[#94A3B8]">失败原因</span>
                <span className="col-span-2 text-[#EF4444]">{detailRecord.detail}</span>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button onClick={() => setDetailRecord(null)}>关闭</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ==================== Push Record Tab ====================
function PushRecordTab() {
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;

  const filtered = useMemo(() => {
    return MOCK_PUSH_RECORDS.filter((r) => {
      if (typeFilter !== 'all' && r.type !== typeFilter) return false;
      if (statusFilter !== 'all' && r.status !== statusFilter) return false;
      if (search) {
        return r.user.includes(search) || r.content.includes(search);
      }
      return true;
    });
  }, [typeFilter, statusFilter, search]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <Select
          value={typeFilter}
          onValueChange={(v) => {
            setTypeFilter(v);
            setCurrentPage(1);
          }}
        >
          <SelectTrigger className="w-36 h-9 text-sm">
            <SelectValue placeholder="全部类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="inbound">入库通知</SelectItem>
            <SelectItem value="outbound">出库通知</SelectItem>
            <SelectItem value="alarm">报警通知</SelectItem>
            <SelectItem value="task">任务提醒</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setStatusFilter(v);
            setCurrentPage(1);
          }}
        >
          <SelectTrigger className="w-32 h-9 text-sm">
            <SelectValue placeholder="全部状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="delivered">已送达</SelectItem>
            <SelectItem value="failed">失败</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="搜索用户、内容..."
              className="h-9 pl-9 text-sm"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="text-[13px] font-medium text-[#475569]">推送时间</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">接收用户</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">消息类型</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">状态</TableHead>
                <TableHead className="text-[13px] font-medium text-[#475569]">内容摘要</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((record, idx) => {
                const typeCfg = PUSH_TYPE_MAP[record.type];
                return (
                  <motion.tr
                    key={record.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors"
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Clock size={14} className="text-[#94A3B8]" />
                        <span className="text-sm text-[#475569]">{record.time}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-medium text-[#0F172A]">{record.user}</span>
                    </TableCell>
                    <TableCell>
                      <Tag label={typeCfg.label} color={typeCfg.color} bg={typeCfg.bg} />
                    </TableCell>
                    <TableCell>
                      {record.status === 'delivered' ? (
                        <div className="flex items-center gap-1">
                          <CheckCircle size={14} className="text-[#10B981]" />
                          <span className="text-sm text-[#10B981]">已送达</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <XCircle size={14} className="text-[#EF4444]" />
                          <span className="text-sm text-[#EF4444]">失败</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-[#475569] truncate max-w-[280px] block" title={record.content}>
                        {record.content}
                      </span>
                    </TableCell>
                  </motion.tr>
                );
              })}
              {paginated.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <MessageSquare size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无推送记录</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        {filtered.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onChange={setCurrentPage}
            total={filtered.length}
          />
        )}
      </div>
    </div>
  );
}

// ==================== QR Code Tab ====================
function QrCodeTab() {
  const [codes] = useState<QrCodeItem[]>(MOCK_QR_CODES);

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {codes.map((code, idx) => (
        <motion.div
          key={code.id}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, delay: idx * 0.1 }}
        >
          <Card className="border-0 shadow-card hover:shadow-card-hover transition-shadow duration-200 h-full">
            <CardContent className="p-5 flex flex-col h-full">
              <div className="flex items-center gap-3 mb-4">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${code.color}15` }}
                >
                  <QrCode size={20} style={{ color: code.color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold text-[#0F172A] truncate">{code.name}</h4>
                  <p className="text-xs text-[#94A3B8] mt-0.5">{code.scene}</p>
                </div>
              </div>
              <p className="text-sm text-[#475569] mb-4 flex-1">{code.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <ScanLine size={14} className="text-[#94A3B8]" />
                  <span className="text-xs text-[#475569]">已使用 {code.usageCount} 次</span>
                </div>
                <Button variant="outline" size="sm" className="h-8 px-3 text-xs gap-1">
                  <Download size={14} /> 下载
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

// ==================== Main Page ====================
export default function WechatMiniProgramPage() {
  const [activeTab, setActiveTab] = useState('users');

  const tabOptions = [
    { key: 'users', label: '用户管理', icon: Users },
    { key: 'scan', label: '扫码绑定记录', icon: ScanLine },
    { key: 'push', label: '消息推送记录', icon: MessageSquare },
    { key: 'qrcode', label: '小程序码管理', icon: QrCode },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1440px] mx-auto">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
            <Smartphone size={18} className="text-[#2563EB]" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-[#0F172A]">微信小程序管理</h1>
            <p className="text-xs text-[#94A3B8]">管理小程序用户、配置、扫码记录及消息推送</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="h-8 gap-1 text-xs">
          <RefreshCw size={14} /> 刷新数据
        </Button>
      </div>

      {/* Stat Cards */}
      <StatCards />

      {/* Config Section */}
      <ConfigSection />

      {/* Tabs Content */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.5 }}
      >
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-white border border-[#E2E8F0] shadow-card h-10 p-1">
            {tabOptions.map((tab) => (
              <TabsTrigger
                key={tab.key}
                value={tab.key}
                className={cn(
                  'px-4 py-1.5 text-sm font-medium rounded-md transition-all data-[state=active]:bg-[#EFF6FF] data-[state=active]:text-[#2563EB] data-[state=active]:shadow-sm',
                  'text-[#475569] hover:text-[#0F172A]'
                )}
              >
                <div className="flex items-center gap-1.5">
                  <tab.icon size={14} />
                  {tab.label}
                </div>
              </TabsTrigger>
            ))}
          </TabsList>

          <AnimatePresence mode="wait">
            <TabsContent value="users" className="mt-0">
              <motion.div
                key="users"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <UserManagementTab />
              </motion.div>
            </TabsContent>
            <TabsContent value="scan" className="mt-0">
              <motion.div
                key="scan"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <ScanRecordTab />
              </motion.div>
            </TabsContent>
            <TabsContent value="push" className="mt-0">
              <motion.div
                key="push"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <PushRecordTab />
              </motion.div>
            </TabsContent>
            <TabsContent value="qrcode" className="mt-0">
              <motion.div
                key="qrcode"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <QrCodeTab />
              </motion.div>
            </TabsContent>
          </AnimatePresence>
        </Tabs>
      </motion.div>
    </div>
  );
}
