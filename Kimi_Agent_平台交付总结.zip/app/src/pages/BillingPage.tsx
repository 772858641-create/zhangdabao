import { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Receipt,
  Calculator,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  Search,
  Plus,
  Edit,
  FileText,
  TrendingUp,
  PieChart,
} from 'lucide-react';
import {
  LineChart,
  Line,
  PieChart as RePieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';

/* ──────────────────────────── Types ──────────────────────────── */

interface BillingRule {
  id: string;
  name: string;
  method: '固定费率' | '阶梯费率' | '按里程' | '按载具类型';
  unitPrice: number;
  unit: string;
  period: string;
  vehicleTypes: string[];
  status: 'ACTIVE' | 'INACTIVE';
  description: string;
}

interface Bill {
  id: string;
  orgName: string;
  period: string;
  vehicleCount: number;
  totalFee: number;
  status: '待确认' | '已确认' | '有争议' | '已结算';
  ruleName: string;
  vehicleType: string;
  detailItems: BillDetailItem[];
}

interface BillDetailItem {
  itemName: string;
  quantity: number;
  unitPrice: number;
  amount: number;
}

interface Dispute {
  id: string;
  billId: string;
  orgName: string;
  period: string;
  diffAmount: number;
  reason: string;
  status: '处理中' | '待审核' | '已解决';
  createTime: string;
}

interface AllocationRule {
  id: string;
  name: string;
  method: '按使用时长' | '按周转次数' | '按载具数量' | '固定比例';
  ratio: string;
  orgList: string[];
  status: '生效中' | '已停用';
}

interface AllocationResult {
  id: string;
  orgName: string;
  period: string;
  totalFee: number;
  allocatedFee: number;
  method: string;
  proportion: string;
}

/* ──────────────────────────── Mock Data ──────────────────────────── */

const rulesMock: BillingRule[] = [
  {
    id: 'R-001',
    name: '标准调拨运输费',
    method: '固定费率',
    unitPrice: 520,
    unit: '元/车次',
    period: '月度',
    vehicleTypes: ['托盘', '周转箱'],
    status: 'ACTIVE',
    description: '跨园区标准调拨运输服务固定费用',
  },
  {
    id: 'R-002',
    name: '载具租赁阶梯费率',
    method: '阶梯费率',
    unitPrice: 85,
    unit: '元/天',
    period: '月度',
    vehicleTypes: ['托盘', '料架', 'EU箱'],
    status: 'ACTIVE',
    description: '载具租赁按使用天数阶梯计费',
  },
  {
    id: 'R-003',
    name: '按里程计费-长途',
    method: '按里程',
    unitPrice: 3.5,
    unit: '元/km',
    period: '月度',
    vehicleTypes: ['飞翼车', '厢式货车'],
    status: 'ACTIVE',
    description: '长途运输按实际里程计费',
  },
  {
    id: 'R-004',
    name: '特殊载具类型费',
    method: '按载具类型',
    unitPrice: 120,
    unit: '元/台',
    period: '季度',
    vehicleTypes: ['冷链箱', '危险品容器'],
    status: 'ACTIVE',
    description: '特殊载具按类型单独计费',
  },
  {
    id: 'R-005',
    name: '短途配送固定费',
    method: '固定费率',
    unitPrice: 280,
    unit: '元/车次',
    period: '月度',
    vehicleTypes: ['电叉车', '手推车'],
    status: 'INACTIVE',
    description: '园区内部短途配送服务',
  },
  {
    id: 'R-006',
    name: '高价值货物附加费',
    method: '固定费率',
    unitPrice: 150,
    unit: '元/车次',
    period: '月度',
    vehicleTypes: ['保险柜', '密封箱'],
    status: 'ACTIVE',
    description: '高价值货物运输附加保险费用',
  },
];

const billsMock: Bill[] = [
  {
    id: 'B-202506-001',
    orgName: '华东物流集团',
    period: '2025年6月',
    vehicleCount: 342,
    totalFee: 186520,
    status: '已结算',
    ruleName: '标准调拨运输费',
    vehicleType: '托盘',
    detailItems: [
      { itemName: '运输服务费', quantity: 156, unitPrice: 520, amount: 81120 },
      { itemName: '装卸作业费', quantity: 156, unitPrice: 180, amount: 28080 },
      { itemName: '保险费用', quantity: 156, unitPrice: 50, amount: 7800 },
      { itemName: '管理费', quantity: 342, unitPrice: 200, amount: 68400 },
      { itemName: '税费', quantity: 1, unitPrice: 1120, amount: 1120 },
    ],
  },
  {
    id: 'B-202506-002',
    orgName: '华南供应链公司',
    period: '2025年6月',
    vehicleCount: 215,
    totalFee: 124800,
    status: '已确认',
    ruleName: '载具租赁阶梯费率',
    vehicleType: '周转箱',
    detailItems: [
      { itemName: '租赁基础费', quantity: 215, unitPrice: 85, amount: 18275 },
      { itemName: '超期使用费', quantity: 48, unitPrice: 120, amount: 5760 },
      { itemName: '维护保养费', quantity: 215, unitPrice: 35, amount: 7525 },
      { itemName: '管理费', quantity: 215, unitPrice: 150, amount: 32250 },
      { itemName: '税费', quantity: 1, unitPrice: 60990, amount: 60990 },
    ],
  },
  {
    id: 'B-202506-003',
    orgName: '华北运输有限公司',
    period: '2025年6月',
    vehicleCount: 189,
    totalFee: 98350,
    status: '有争议',
    ruleName: '按里程计费-长途',
    vehicleType: '飞翼车',
    detailItems: [
      { itemName: '里程运输费', quantity: 5280, unitPrice: 3.5, amount: 18480 },
      { itemName: '燃油附加费', quantity: 5280, unitPrice: 1.2, amount: 6336 },
      { itemName: '司机费用', quantity: 189, unitPrice: 180, amount: 34020 },
      { itemName: '过路过桥费', quantity: 189, unitPrice: 85, amount: 16065 },
      { itemName: '管理费', quantity: 189, unitPrice: 120, amount: 22680 },
      { itemName: '税费', quantity: 1, unitPrice: 769, amount: 769 },
    ],
  },
  {
    id: 'B-202506-004',
    orgName: '西部物流枢纽',
    period: '2025年6月',
    vehicleCount: 128,
    totalFee: 76800,
    status: '待确认',
    ruleName: '特殊载具类型费',
    vehicleType: '冷链箱',
    detailItems: [
      { itemName: '特殊载具使用费', quantity: 128, unitPrice: 120, amount: 15360 },
      { itemName: '温控设备费', quantity: 128, unitPrice: 80, amount: 10240 },
      { itemName: '监控服务费', quantity: 128, unitPrice: 65, amount: 8320 },
      { itemName: '管理费', quantity: 128, unitPrice: 100, amount: 12800 },
      { itemName: '税费', quantity: 1, unitPrice: 30080, amount: 30080 },
    ],
  },
  {
    id: 'B-202506-005',
    orgName: '云智科技有限公司',
    period: '2025年6月',
    vehicleCount: 256,
    totalFee: 145600,
    status: '已结算',
    ruleName: '标准调拨运输费',
    vehicleType: '周转箱',
    detailItems: [
      { itemName: '运输服务费', quantity: 256, unitPrice: 520, amount: 133120 },
      { itemName: '装卸作业费', quantity: 256, unitPrice: 180, amount: 46080 },
      { itemName: '管理费', quantity: 256, unitPrice: 200, amount: 51200 },
      { itemName: '税费', quantity: 1, unitPrice: -84800, amount: -84800 },
    ],
  },
  {
    id: 'B-202506-006',
    orgName: '上汽集团物流部',
    period: '2025年6月',
    vehicleCount: 412,
    totalFee: 238900,
    status: '已确认',
    ruleName: '标准调拨运输费',
    vehicleType: '托盘',
    detailItems: [
      { itemName: '运输服务费', quantity: 412, unitPrice: 520, amount: 214240 },
      { itemName: '装卸作业费', quantity: 412, unitPrice: 180, amount: 74160 },
      { itemName: '管理费', quantity: 412, unitPrice: 200, amount: 82400 },
      { itemName: '税费', quantity: 1, unitPrice: -131900, amount: -131900 },
    ],
  },
  {
    id: 'B-202506-007',
    orgName: '宁德时代供应链',
    period: '2025年6月',
    vehicleCount: 178,
    totalFee: 96500,
    status: '有争议',
    ruleName: '载具租赁阶梯费率',
    vehicleType: 'EU箱',
    detailItems: [
      { itemName: '租赁基础费', quantity: 178, unitPrice: 85, amount: 15130 },
      { itemName: '超期使用费', quantity: 62, unitPrice: 120, amount: 7440 },
      { itemName: '维护保养费', quantity: 178, unitPrice: 35, amount: 6230 },
      { itemName: '管理费', quantity: 178, unitPrice: 150, amount: 26700 },
      { itemName: '税费', quantity: 1, unitPrice: 41000, amount: 41000 },
    ],
  },
  {
    id: 'B-202506-008',
    orgName: '比亚迪物流中心',
    period: '2025年6月',
    vehicleCount: 295,
    totalFee: 167200,
    status: '已结算',
    ruleName: '按里程计费-长途',
    vehicleType: '厢式货车',
    detailItems: [
      { itemName: '里程运输费', quantity: 8640, unitPrice: 3.5, amount: 30240 },
      { itemName: '燃油附加费', quantity: 8640, unitPrice: 1.2, amount: 10368 },
      { itemName: '司机费用', quantity: 295, unitPrice: 180, amount: 53100 },
      { itemName: '过路过桥费', quantity: 295, unitPrice: 85, amount: 25075 },
      { itemName: '管理费', quantity: 295, unitPrice: 120, amount: 35400 },
      { itemName: '税费', quantity: 1, unitPrice: 13017, amount: 13017 },
    ],
  },
];

const disputesMock: Dispute[] = [
  {
    id: 'DS-202506-001',
    billId: 'B-202506-003',
    orgName: '华北运输有限公司',
    period: '2025年6月',
    diffAmount: 12800,
    reason: '里程数统计与实际GPS轨迹存在偏差，实际里程应少于系统记录约3200公里',
    status: '处理中',
    createTime: '2025-06-18 14:30',
  },
  {
    id: 'DS-202506-002',
    billId: 'B-202506-007',
    orgName: '宁德时代供应链',
    period: '2025年6月',
    diffAmount: 8650,
    reason: '超期使用费计算有误，部分载具已提前归还但系统未更新归还时间',
    status: '待审核',
    createTime: '2025-06-20 09:15',
  },
  {
    id: 'DS-202506-003',
    billId: 'B-202506-003',
    orgName: '华北运输有限公司',
    period: '2025年6月',
    diffAmount: 3200,
    reason: '燃油附加费单价调整未及时生效，应按新费率1.0元/km计算',
    status: '处理中',
    createTime: '2025-06-21 16:45',
  },
  {
    id: 'DS-202506-004',
    billId: 'B-202506-007',
    orgName: '宁德时代供应链',
    period: '2025年6月',
    diffAmount: 4200,
    reason: 'EU箱数量核对差异，系统记录178个，实际盘点为165个',
    status: '已解决',
    createTime: '2025-06-15 11:20',
  },
];

const allocationRulesMock: AllocationRule[] = [
  {
    id: 'AR-001',
    name: '华东-华南线分摊',
    method: '按周转次数',
    ratio: '按实际周转',
    orgList: ['华东物流集团', '华南供应链公司', '上汽集团物流部'],
    status: '生效中',
  },
  {
    id: 'AR-002',
    name: '长途运输成本分摊',
    method: '按里程',
    ratio: '按实际里程',
    orgList: ['华北运输有限公司', '西部物流枢纽', '比亚迪物流中心'],
    status: '生效中',
  },
  {
    id: 'AR-003',
    name: '冷链专线固定分摊',
    method: '固定比例',
    ratio: '4:3:3',
    orgList: ['西部物流枢纽', '云智科技有限公司'],
    status: '生效中',
  },
  {
    id: 'AR-004',
    name: '租赁费用期间分摊',
    method: '按使用时长',
    ratio: '按实际天数',
    orgList: ['宁德时代供应链', '华南供应链公司'],
    status: '已停用',
  },
];

const allocationResultsMock: AllocationResult[] = [
  { id: 'RST-001', orgName: '华东物流集团', period: '2025年6月', totalFee: 186520, allocatedFee: 65282, method: '按周转次数', proportion: '35%' },
  { id: 'RST-002', orgName: '华南供应链公司', period: '2025年6月', totalFee: 124800, allocatedFee: 43680, method: '按周转次数', proportion: '35%' },
  { id: 'RST-003', orgName: '上汽集团物流部', period: '2025年6月', totalFee: 238900, allocatedFee: 77758, method: '按周转次数', proportion: '32.5%' },
  { id: 'RST-004', orgName: '华北运输有限公司', period: '2025年6月', totalFee: 98350, allocatedFee: 39340, method: '按里程', proportion: '40%' },
  { id: 'RST-005', orgName: '西部物流枢纽', period: '2025年6月', totalFee: 76800, allocatedFee: 30720, method: '按里程', proportion: '40%' },
  { id: 'RST-006', orgName: '比亚迪物流中心', period: '2025年6月', totalFee: 167200, allocatedFee: 58472, method: '按里程', proportion: '35%' },
  { id: 'RST-007', orgName: '云智科技有限公司', period: '2025年6月', totalFee: 145600, allocatedFee: 43680, method: '固定比例', proportion: '30%' },
  { id: 'RST-008', orgName: '宁德时代供应链', period: '2025年6月', totalFee: 96500, allocatedFee: 38600, method: '按使用时长', proportion: '40%' },
];

const trendMock = [
  { month: '2025年1月', receivable: 125000, received: 108000, disputed: 5200 },
  { month: '2025年2月', receivable: 138000, received: 122000, disputed: 8000 },
  { month: '2025年3月', receivable: 142000, received: 130000, disputed: 3500 },
  { month: '2025年4月', receivable: 156000, received: 141000, disputed: 6800 },
  { month: '2025年5月', receivable: 168000, received: 152000, disputed: 9500 },
  { month: '2025年6月', receivable: 186500, received: 142300, disputed: 12800 },
];

const orgPieMock = [
  { name: '华东物流集团', value: 186520, color: '#3b82f6' },
  { name: '华南供应链公司', value: 124800, color: '#10b981' },
  { name: '华北运输有限公司', value: 98350, color: '#f59e0b' },
  { name: '西部物流枢纽', value: 76800, color: '#ef4444' },
  { name: '云智科技有限公司', value: 145600, color: '#8b5cf6' },
  { name: '上汽集团物流部', value: 238900, color: '#06b6d4' },
  { name: '宁德时代供应链', value: 96500, color: '#f97316' },
  { name: '比亚迪物流中心', value: 167200, color: '#ec4899' },
];

/* ──────────────────────────── Helpers ──────────────────────────── */

function formatCurrency(n: number) {
  return `¥${n.toLocaleString()}`;
}

function StatusBadge({ status }: { status: string }) {
  const variantMap: Record<string, string> = {
    '已结算': 'bg-success/10 text-success border-success/20',
    '已确认': 'bg-primary/10 text-primary border-primary/20',
    '待确认': 'bg-warning/10 text-warning border-warning/20',
    '有争议': 'bg-danger/10 text-danger border-danger/20',
    'ACTIVE': 'bg-success/10 text-success border-success/20',
    'INACTIVE': 'bg-neutral-100 text-neutral-500 border-neutral-200',
    '生效中': 'bg-success/10 text-success border-success/20',
    '已停用': 'bg-neutral-100 text-neutral-500 border-neutral-200',
    '处理中': 'bg-warning/10 text-warning border-warning/20',
    '待审核': 'bg-primary/10 text-primary border-primary/20',
    '已解决': 'bg-success/10 text-success border-success/20',
  };
  const cls = variantMap[status] || 'bg-neutral-100 text-neutral-500 border-neutral-200';
  return (
    <Badge variant="outline" className={cls}>
      {status}
    </Badge>
  );
}

const PIE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316', '#ec4899'];

/* ──────────────────────────── Main Component ──────────────────────────── */

export default function BillingPage() {
  const [activeTab, setActiveTab] = useState('rules');

  /* Search & Filter states */
  const [ruleSearch, setRuleSearch] = useState('');
  const [billSearch, setBillSearch] = useState('');
  const [billStatusFilter, setBillStatusFilter] = useState('ALL');
  const [disputeStatusFilter, setDisputeStatusFilter] = useState('ALL');
  const [allocationSearch, setAllocationSearch] = useState('');

  /* Dialog states */
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<BillingRule | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);
  const [disputeDialogOpen, setDisputeDialogOpen] = useState(false);
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [allocationDialogOpen, setAllocationDialogOpen] = useState(false);
  const [selectedAllocation, setSelectedAllocation] = useState<AllocationResult | null>(null);

  /* KPI computed from mock */
  const kpiData = useMemo(() => {
    const totalReceivable = 186500;
    const totalReceived = 142300;
    const totalDisputed = 12800;
    const settleRate = totalReceivable > 0 ? ((totalReceived / totalReceivable) * 100).toFixed(1) : '0';
    return { totalReceivable, totalReceived, totalDisputed, settleRate };
  }, []);

  /* Filtered data */
  const filteredRules = useMemo(() => {
    return rulesMock.filter(r =>
      r.name.toLowerCase().includes(ruleSearch.toLowerCase()) ||
      r.id.toLowerCase().includes(ruleSearch.toLowerCase())
    );
  }, [ruleSearch]);

  const filteredBills = useMemo(() => {
    return billsMock.filter(b => {
      const matchSearch = b.orgName.toLowerCase().includes(billSearch.toLowerCase()) ||
        b.id.toLowerCase().includes(billSearch.toLowerCase());
      const matchStatus = billStatusFilter === 'ALL' || b.status === billStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [billSearch, billStatusFilter]);

  const filteredDisputes = useMemo(() => {
    return disputesMock.filter(d =>
      disputeStatusFilter === 'ALL' || d.status === disputeStatusFilter
    );
  }, [disputeStatusFilter]);

  const filteredAllocations = useMemo(() => {
    return allocationResultsMock.filter(a =>
      a.orgName.toLowerCase().includes(allocationSearch.toLowerCase())
    );
  }, [allocationSearch]);

  /* Handlers */
  function openRuleDialog(rule?: BillingRule) {
    setEditingRule(rule || null);
    setRuleDialogOpen(true);
  }

  function openBillDetail(bill: Bill) {
    setSelectedBill(bill);
    setDetailDialogOpen(true);
  }

  function openDisputeDetail(dispute: Dispute) {
    setSelectedDispute(dispute);
    setDisputeDialogOpen(true);
  }

  function openAllocationDetail(allocation: AllocationResult) {
    setSelectedAllocation(allocation);
    setAllocationDialogOpen(true);
  }

  /* ─────────────── Render ─────────────── */
  return (
    <div className="space-y-6 p-6 bg-[var(--neutral-surface)] min-h-screen">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-textPrimary flex items-center gap-2">
            <Receipt className="w-6 h-6 text-primary" />
            计费结算管理
          </h1>
          <p className="text-sm text-neutral-textSecondary mt-1">
            跨组织载具调拨费用核算、结算与分摊管理
          </p>
        </div>
        <Button onClick={() => openRuleDialog()}>
          <Plus className="w-4 h-4 mr-2" />
          新增计费规则
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-neutral-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <DollarSign className="w-6 h-6 text-primary" />
            </div>
            <div className="min-w-0">
              <div className="text-sm text-neutral-textSecondary truncate">本月应收金额</div>
              <div className="text-xl font-bold text-neutral-textPrimary mt-0.5">
                {formatCurrency(kpiData.totalReceivable)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center shrink-0">
              <CheckCircle className="w-6 h-6 text-success" />
            </div>
            <div className="min-w-0">
              <div className="text-sm text-neutral-textSecondary truncate">本月已收</div>
              <div className="text-xl font-bold text-neutral-textPrimary mt-0.5">
                {formatCurrency(kpiData.totalReceived)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-danger/10 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6 text-danger" />
            </div>
            <div className="min-w-0">
              <div className="text-sm text-neutral-textSecondary truncate">争议金额</div>
              <div className="text-xl font-bold text-neutral-textPrimary mt-0.5">
                {formatCurrency(kpiData.totalDisputed)}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-neutral-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Calculator className="w-6 h-6 text-primary" />
            </div>
            <div className="min-w-0">
              <div className="text-sm text-neutral-textSecondary truncate">结算率</div>
              <div className="text-xl font-bold text-neutral-textPrimary mt-0.5">
                {kpiData.settleRate}%
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-[var(--neutral-surface)] border border-neutral-border">
          <TabsTrigger value="rules" className="flex items-center gap-1.5">
            <Calculator className="w-3.5 h-3.5" />
            计费规则配置
          </TabsTrigger>
          <TabsTrigger value="bills" className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5" />
            费用账单
          </TabsTrigger>
          <TabsTrigger value="reconciliation" className="flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            对账与争议
          </TabsTrigger>
          <TabsTrigger value="allocation" className="flex items-center gap-1.5">
            <PieChart className="w-3.5 h-3.5" />
            费用分摊
          </TabsTrigger>
          <TabsTrigger value="statistics" className="flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5" />
            数据统计
          </TabsTrigger>
        </TabsList>

        {/* ─── Tab 1: 计费规则配置 ─── */}
        <TabsContent value="rules" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative w-[320px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textSecondary" />
              <Input
                placeholder="搜索规则名称或编号"
                className="pl-9 border-neutral-border"
                value={ruleSearch}
                onChange={e => setRuleSearch(e.target.value)}
              />
            </div>
          </div>

          <Card className="border-neutral-border">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-border bg-neutral-50/50">
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">规则编号</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">规则名称</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">计费方式</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">单价</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">计费周期</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">适用载具类型</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">状态</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRules.length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-neutral-textSecondary">
                          暂无匹配数据
                        </td>
                      </tr>
                    )}
                    {filteredRules.map((rule) => (
                      <tr
                        key={rule.id}
                        className="border-b border-neutral-border/60 hover:bg-neutral-50/50 transition-colors"
                      >
                        <td className="px-4 py-3 font-mono text-neutral-textPrimary">{rule.id}</td>
                        <td className="px-4 py-3 font-medium text-neutral-textPrimary">{rule.name}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className="text-xs">
                            {rule.method}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-neutral-textPrimary">
                          {rule.unitPrice} <span className="text-neutral-textSecondary text-xs">{rule.unit}</span>
                        </td>
                        <td className="px-4 py-3 text-neutral-textSecondary">{rule.period}</td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap gap-1">
                            {rule.vehicleTypes.map(vt => (
                              <span
                                key={vt}
                                className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-primary/5 text-primary"
                              >
                                {vt}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <StatusBadge status={rule.status === 'ACTIVE' ? '生效中' : '已停用'} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openRuleDialog(rule)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Tab 2: 费用账单 ─── */}
        <TabsContent value="bills" className="space-y-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative w-[280px]">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textSecondary" />
              <Input
                placeholder="搜索组织名称或账单编号"
                className="pl-9 border-neutral-border"
                value={billSearch}
                onChange={e => setBillSearch(e.target.value)}
              />
            </div>
            <Select value={billStatusFilter} onValueChange={setBillStatusFilter}>
              <SelectTrigger className="w-[140px] border-neutral-border">
                <SelectValue placeholder="全部状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">全部状态</SelectItem>
                <SelectItem value="待确认">待确认</SelectItem>
                <SelectItem value="已确认">已确认</SelectItem>
                <SelectItem value="有争议">有争议</SelectItem>
                <SelectItem value="已结算">已结算</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card className="border-neutral-border">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-border bg-neutral-50/50">
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">账单编号</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">组织名称</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">计费周期</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">载具数量</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">总费用</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">状态</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredBills.length === 0 && (
                      <tr>
                        <td colSpan={7} className="px-4 py-8 text-center text-neutral-textSecondary">
                          暂无匹配数据
                        </td>
                      </tr>
                    )}
                    {filteredBills.map((bill) => (
                      <tr
                        key={bill.id}
                        className="border-b border-neutral-border/60 hover:bg-neutral-50/50 transition-colors"
                      >
                        <td className="px-4 py-3 font-mono text-neutral-textPrimary">{bill.id}</td>
                        <td className="px-4 py-3 font-medium text-neutral-textPrimary">{bill.orgName}</td>
                        <td className="px-4 py-3 text-neutral-textSecondary">{bill.period}</td>
                        <td className="px-4 py-3 text-neutral-textPrimary">{bill.vehicleCount} 台</td>
                        <td className="px-4 py-3 text-right font-bold text-neutral-textPrimary">
                          {formatCurrency(bill.totalFee)}
                        </td>
                        <td className="px-4 py-3">
                          <StatusBadge status={bill.status} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openBillDetail(bill)}
                          >
                            <FileText className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Tab 3: 对账与争议 ─── */}
        <TabsContent value="reconciliation" className="space-y-4">
          <div className="flex items-center gap-3">
            <Select value={disputeStatusFilter} onValueChange={setDisputeStatusFilter}>
              <SelectTrigger className="w-[140px] border-neutral-border">
                <SelectValue placeholder="争议状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">全部状态</SelectItem>
                <SelectItem value="处理中">处理中</SelectItem>
                <SelectItem value="待审核">待审核</SelectItem>
                <SelectItem value="已解决">已解决</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 对账差异列表 */}
            <Card className="border-neutral-border">
              <CardContent className="p-4">
                <h3 className="text-base font-semibold text-neutral-textPrimary mb-3 flex items-center gap-2">
                  <Receipt className="w-4 h-4 text-primary" />
                  对账差异列表
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-neutral-border">
                        <th className="px-3 py-2 text-left font-medium text-neutral-textSecondary">差异编号</th>
                        <th className="px-3 py-2 text-left font-medium text-neutral-textSecondary">关联账单</th>
                        <th className="px-3 py-2 text-right font-medium text-neutral-textSecondary">差异金额</th>
                        <th className="px-3 py-2 text-left font-medium text-neutral-textSecondary">状态</th>
                        <th className="px-3 py-2 text-right font-medium text-neutral-textSecondary">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDisputes.map((d) => (
                        <tr
                          key={d.id}
                          className="border-b border-neutral-border/60 hover:bg-neutral-50/50"
                        >
                          <td className="px-3 py-2.5 font-mono text-neutral-textPrimary">{d.id}</td>
                          <td className="px-3 py-2.5 text-neutral-textSecondary">{d.billId}</td>
                          <td className="px-3 py-2.5 text-right text-danger font-medium">
                            {formatCurrency(d.diffAmount)}
                          </td>
                          <td className="px-3 py-2.5">
                            <StatusBadge status={d.status} />
                          </td>
                          <td className="px-3 py-2.5 text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openDisputeDetail(d)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* 争议处理面板 */}
            <Card className="border-neutral-border">
              <CardContent className="p-4">
                <h3 className="text-base font-semibold text-neutral-textPrimary mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-warning" />
                  争议处理
                </h3>
                <div className="space-y-3">
                  {filteredDisputes.slice(0, 3).map((d) => (
                    <div
                      key={d.id}
                      className="p-3 rounded-lg border border-neutral-border bg-[var(--neutral-surface)] hover:shadow-sm transition-shadow"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="font-medium text-neutral-textPrimary text-sm">{d.id}</div>
                          <div className="text-xs text-neutral-textSecondary mt-0.5">{d.orgName} · {d.period}</div>
                        </div>
                        <StatusBadge status={d.status} />
                      </div>
                      <p className="text-xs text-neutral-textSecondary mt-2 line-clamp-2">{d.reason}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs font-medium text-danger">
                          差异: {formatCurrency(d.diffAmount)}
                        </span>
                        <div className="flex gap-2">
                          {d.status !== '已解决' && (
                            <Button variant="outline" size="sm" className="h-7 text-xs">
                              处理
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs"
                            onClick={() => openDisputeDetail(d)}
                          >
                            详情
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 对账操作 */}
          <Card className="border-neutral-border">
            <CardContent className="p-4">
              <h3 className="text-base font-semibold text-neutral-textPrimary mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-success" />
                对账操作
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border border-neutral-border bg-neutral-50/30">
                  <div className="text-sm font-medium text-neutral-textPrimary mb-1">自动对账</div>
                  <div className="text-xs text-neutral-textSecondary mb-3">系统自动比对账单与调拨记录，识别差异项</div>
                  <Button size="sm" className="w-full text-xs">
                    启动自动对账
                  </Button>
                </div>
                <div className="p-3 rounded-lg border border-neutral-border bg-neutral-50/30">
                  <div className="text-sm font-medium text-neutral-textPrimary mb-1">批量确认</div>
                  <div className="text-xs text-neutral-textSecondary mb-3">批量确认无差异账单，快速推进结算流程</div>
                  <Button size="sm" variant="outline" className="w-full text-xs">
                    批量确认账单
                  </Button>
                </div>
                <div className="p-3 rounded-lg border border-neutral-border bg-neutral-50/30">
                  <div className="text-sm font-medium text-neutral-textPrimary mb-1">导出对账报告</div>
                  <div className="text-xs text-neutral-textSecondary mb-3">导出本期对账详细报告，包含差异明细</div>
                  <Button size="sm" variant="outline" className="w-full text-xs">
                    导出报告
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Tab 4: 费用分摊 ─── */}
        <TabsContent value="allocation" className="space-y-4">
          {/* 分摊规则 */}
          <Card className="border-neutral-border">
            <CardContent className="p-4">
              <h3 className="text-base font-semibold text-neutral-textPrimary mb-3 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-primary" />
                分摊规则配置
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-border bg-neutral-50/50">
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">规则编号</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">规则名称</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">分摊方式</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">分摊比例</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">适用组织</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">状态</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allocationRulesMock.map((ar) => (
                      <tr
                        key={ar.id}
                        className="border-b border-neutral-border/60 hover:bg-neutral-50/50 transition-colors"
                      >
                        <td className="px-4 py-3 font-mono text-neutral-textPrimary">{ar.id}</td>
                        <td className="px-4 py-3 font-medium text-neutral-textPrimary">{ar.name}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline">{ar.method}</Badge>
                        </td>
                        <td className="px-4 py-3 text-neutral-textSecondary">{ar.ratio}</td>
                        <td className="px-4 py-3">
                          <div className="flex flex-wrap gap-1">
                            {ar.orgList.map(org => (
                              <span
                                key={org}
                                className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-success/5 text-success"
                              >
                                {org}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <StatusBadge status={ar.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* 分摊结果表格 */}
          <Card className="border-neutral-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-semibold text-neutral-textPrimary flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-primary" />
                  分摊结果
                </h3>
                <div className="relative w-[240px]">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textSecondary" />
                  <Input
                    placeholder="搜索组织名称"
                    className="pl-9 border-neutral-border h-8 text-sm"
                    value={allocationSearch}
                    onChange={e => setAllocationSearch(e.target.value)}
                  />
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-border bg-neutral-50/50">
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">记录编号</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">组织名称</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">计费周期</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">总费用</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">分摊费用</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">分摊方式</th>
                      <th className="px-4 py-3 text-left font-medium text-neutral-textSecondary">分摊比例</th>
                      <th className="px-4 py-3 text-right font-medium text-neutral-textSecondary">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAllocations.length === 0 && (
                      <tr>
                        <td colSpan={8} className="px-4 py-8 text-center text-neutral-textSecondary">
                          暂无匹配数据
                        </td>
                      </tr>
                    )}
                    {filteredAllocations.map((a) => (
                      <tr
                        key={a.id}
                        className="border-b border-neutral-border/60 hover:bg-neutral-50/50 transition-colors"
                      >
                        <td className="px-4 py-3 font-mono text-neutral-textPrimary">{a.id}</td>
                        <td className="px-4 py-3 font-medium text-neutral-textPrimary">{a.orgName}</td>
                        <td className="px-4 py-3 text-neutral-textSecondary">{a.period}</td>
                        <td className="px-4 py-3 text-right text-neutral-textPrimary">
                          {formatCurrency(a.totalFee)}
                        </td>
                        <td className="px-4 py-3 text-right font-bold text-primary">
                          {formatCurrency(a.allocatedFee)}
                        </td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className="text-xs">{a.method}</Badge>
                        </td>
                        <td className="px-4 py-3 text-neutral-textSecondary">{a.proportion}</td>
                        <td className="px-4 py-3 text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openAllocationDetail(a)}
                          >
                            <FileText className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ─── Tab 5: 数据统计 ─── */}
        <TabsContent value="statistics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 近6个月费用趋势 */}
            <Card className="border-neutral-border">
              <CardContent className="p-4">
                <h3 className="text-base font-semibold text-neutral-textPrimary mb-4 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  近6个月费用趋势
                </h3>
                <div className="w-full" style={{ height: 320 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendMock} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis
                        dataKey="month"
                        tick={{ fontSize: 12, fill: '#6b7280' }}
                        stroke="#d1d5db"
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: '#6b7280' }}
                        stroke="#d1d5db"
                        tickFormatter={(v: number) => `¥${(v / 1000).toFixed(0)}k`}
                      />
                      <Tooltip
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }}
                      />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Line
                        type="monotone"
                        dataKey="receivable"
                        name="应收金额"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        dot={{ r: 4, fill: '#3b82f6' }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="received"
                        name="已收金额"
                        stroke="#10b981"
                        strokeWidth={2}
                        dot={{ r: 4, fill: '#10b981' }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="disputed"
                        name="争议金额"
                        stroke="#ef4444"
                        strokeWidth={2}
                        dot={{ r: 4, fill: '#ef4444' }}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* 各组织费用占比 */}
            <Card className="border-neutral-border">
              <CardContent className="p-4">
                <h3 className="text-base font-semibold text-neutral-textPrimary mb-4 flex items-center gap-2">
                  <PieChart className="w-4 h-4 text-primary" />
                  各组织费用占比
                </h3>
                <div className="w-full" style={{ height: 320 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <RePieChart>
                      <Pie
                        data={orgPieMock}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={110}
                        paddingAngle={2}
                        dataKey="value"
                        nameKey="name"
                        label={(entry: { name: string; percent: number }) =>
                          `${entry.name} ${(entry.percent * 100).toFixed(0)}%`
                        }
                      >
                        {orgPieMock.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }}
                      />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                    </RePieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 组织费用对比柱状图 */}
          <Card className="border-neutral-border">
            <CardContent className="p-4">
              <h3 className="text-base font-semibold text-neutral-textPrimary mb-4 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-primary" />
                各组织费用对比（本月）
              </h3>
              <div className="w-full" style={{ height: 300 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={orgPieMock} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11, fill: '#6b7280' }}
                      stroke="#d1d5db"
                      angle={-15}
                      textAnchor="end"
                      height={60}
                    />
                    <YAxis
                      tick={{ fontSize: 12, fill: '#6b7280' }}
                      stroke="#d1d5db"
                      tickFormatter={(v: number) => `¥${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(value: number) => formatCurrency(value)}
                      contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb' }}
                    />
                    <Bar dataKey="value" name="费用金额" radius={[4, 4, 0, 0]}>
                      {orgPieMock.map((entry, index) => (
                        <Cell key={`bar-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ═══════════════════════════════════════════
          Dialog: 新增/编辑计费规则
      ═══════════════════════════════════════════ */}
      <Dialog open={ruleDialogOpen} onOpenChange={setRuleDialogOpen}>
        <DialogContent className="max-w-lg border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-neutral-textPrimary flex items-center gap-2">
              <Calculator className="w-5 h-5 text-primary" />
              {editingRule ? '编辑计费规则' : '新增计费规则'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium text-neutral-textPrimary">规则名称</label>
              <Input
                placeholder="如：标准调拨运输费"
                className="mt-1 border-neutral-border"
                defaultValue={editingRule?.name || ''}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">计费方式</label>
                <Select defaultValue={editingRule?.method || '固定费率'}>
                  <SelectTrigger className="mt-1 border-neutral-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="固定费率">固定费率</SelectItem>
                    <SelectItem value="阶梯费率">阶梯费率</SelectItem>
                    <SelectItem value="按里程">按里程</SelectItem>
                    <SelectItem value="按载具类型">按载具类型</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">计费周期</label>
                <Select defaultValue={editingRule?.period || '月度'}>
                  <SelectTrigger className="mt-1 border-neutral-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="月度">月度</SelectItem>
                    <SelectItem value="季度">季度</SelectItem>
                    <SelectItem value="年度">年度</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">单价</label>
                <Input
                  type="number"
                  placeholder="如：520"
                  className="mt-1 border-neutral-border"
                  defaultValue={editingRule?.unitPrice || ''}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">单位</label>
                <Select defaultValue={editingRule?.unit || '元/车次'}>
                  <SelectTrigger className="mt-1 border-neutral-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="元/车次">元/车次</SelectItem>
                    <SelectItem value="元/天">元/天</SelectItem>
                    <SelectItem value="元/km">元/km</SelectItem>
                    <SelectItem value="元/台">元/台</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-neutral-textPrimary">适用载具类型</label>
              <Input
                placeholder="如：托盘, 周转箱, EU箱（用逗号分隔）"
                className="mt-1 border-neutral-border"
                defaultValue={editingRule?.vehicleTypes.join(', ') || ''}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-neutral-textPrimary">规则说明</label>
              <Input
                placeholder="请输入计费规则详细说明"
                className="mt-1 border-neutral-border"
                defaultValue={editingRule?.description || ''}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-neutral-textPrimary">状态</label>
              <Select defaultValue={editingRule?.status || 'ACTIVE'}>
                <SelectTrigger className="mt-1 border-neutral-border">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACTIVE">生效中</SelectItem>
                  <SelectItem value="INACTIVE">已停用</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRuleDialogOpen(false)}>
              取消
            </Button>
            <Button onClick={() => setRuleDialogOpen(false)}>
              <CheckCircle className="w-4 h-4 mr-2" />
              保存规则
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          Dialog: 费用明细
      ═══════════════════════════════════════════ */}
      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-2xl border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-neutral-textPrimary flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              费用明细 - {selectedBill?.id}
            </DialogTitle>
          </DialogHeader>
          {selectedBill && (
            <div className="py-4 space-y-4">
              <div className="grid grid-cols-2 gap-4 p-3 rounded-lg bg-neutral-50/50 border border-neutral-border">
                <div>
                  <div className="text-xs text-neutral-textSecondary">组织名称</div>
                  <div className="text-sm font-medium text-neutral-textPrimary">{selectedBill.orgName}</div>
                </div>
                <div>
                  <div className="text-xs text-neutral-textSecondary">计费周期</div>
                  <div className="text-sm font-medium text-neutral-textPrimary">{selectedBill.period}</div>
                </div>
                <div>
                  <div className="text-xs text-neutral-textSecondary">载具数量</div>
                  <div className="text-sm font-medium text-neutral-textPrimary">{selectedBill.vehicleCount} 台</div>
                </div>
                <div>
                  <div className="text-xs text-neutral-textSecondary">载具类型</div>
                  <div className="text-sm font-medium text-neutral-textPrimary">{selectedBill.vehicleType}</div>
                </div>
                <div>
                  <div className="text-xs text-neutral-textSecondary">适用规则</div>
                  <div className="text-sm font-medium text-neutral-textPrimary">{selectedBill.ruleName}</div>
                </div>
                <div>
                  <div className="text-xs text-neutral-textSecondary">账单状态</div>
                  <div className="mt-1">
                    <StatusBadge status={selectedBill.status} />
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-semibold text-neutral-textPrimary mb-2">费用项目明细</h4>
                <div className="overflow-x-auto rounded-lg border border-neutral-border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-neutral-50/50 border-b border-neutral-border">
                        <th className="px-4 py-2 text-left font-medium text-neutral-textSecondary">项目名称</th>
                        <th className="px-4 py-2 text-right font-medium text-neutral-textSecondary">数量</th>
                        <th className="px-4 py-2 text-right font-medium text-neutral-textSecondary">单价</th>
                        <th className="px-4 py-2 text-right font-medium text-neutral-textSecondary">金额</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedBill.detailItems.map((item, idx) => (
                        <tr key={idx} className="border-b border-neutral-border/60">
                          <td className="px-4 py-2 text-neutral-textPrimary">{item.itemName}</td>
                          <td className="px-4 py-2 text-right text-neutral-textSecondary">{item.quantity}</td>
                          <td className="px-4 py-2 text-right text-neutral-textSecondary">{formatCurrency(item.unitPrice)}</td>
                          <td className="px-4 py-2 text-right font-medium text-neutral-textPrimary">
                            {formatCurrency(item.amount)}
                          </td>
                        </tr>
                      ))}
                      <tr className="bg-neutral-50/50">
                        <td colSpan={3} className="px-4 py-2.5 text-right font-semibold text-neutral-textPrimary">
                          合计
                        </td>
                        <td className="px-4 py-2.5 text-right font-bold text-primary">
                          {formatCurrency(selectedBill.totalFee)}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          Dialog: 争议处理详情
      ═══════════════════════════════════════════ */}
      <Dialog open={disputeDialogOpen} onOpenChange={setDisputeDialogOpen}>
        <DialogContent className="max-w-lg border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-neutral-textPrimary flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-warning" />
              争议处理 - {selectedDispute?.id}
            </DialogTitle>
          </DialogHeader>
          {selectedDispute && (
            <div className="py-4 space-y-3">
              <div className="p-3 rounded-lg bg-neutral-50/50 border border-neutral-border space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">关联账单</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">{selectedDispute.billId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">争议组织</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">{selectedDispute.orgName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">计费周期</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">{selectedDispute.period}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">差异金额</span>
                  <span className="text-sm font-bold text-danger">{formatCurrency(selectedDispute.diffAmount)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-neutral-textSecondary">当前状态</span>
                  <StatusBadge status={selectedDispute.status} />
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">创建时间</span>
                  <span className="text-sm text-neutral-textPrimary">{selectedDispute.createTime}</span>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">争议原因</label>
                <div className="mt-1 p-3 rounded-lg border border-neutral-border bg-neutral-50/30 text-sm text-neutral-textPrimary">
                  {selectedDispute.reason}
                </div>
              </div>
              <div>
                <label className="text-sm font-medium text-neutral-textPrimary">处理备注</label>
                <Input
                  placeholder="请输入处理意见或备注信息"
                  className="mt-1 border-neutral-border"
                />
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDisputeDialogOpen(false)}>
              取消
            </Button>
            {selectedDispute?.status !== '已解决' && (
              <Button variant="outline" className="border-warning text-warning hover:bg-warning/10">
                驳回争议
              </Button>
            )}
            {selectedDispute?.status !== '已解决' && (
              <Button onClick={() => setDisputeDialogOpen(false)}>
                <CheckCircle className="w-4 h-4 mr-2" />
                确认解决
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          Dialog: 分摊结果详情
      ═══════════════════════════════════════════ */}
      <Dialog open={allocationDialogOpen} onOpenChange={setAllocationDialogOpen}>
        <DialogContent className="max-w-md border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-neutral-textPrimary flex items-center gap-2">
              <PieChart className="w-5 h-5 text-primary" />
              分摊详情 - {selectedAllocation?.id}
            </DialogTitle>
          </DialogHeader>
          {selectedAllocation && (
            <div className="py-4 space-y-3">
              <div className="p-3 rounded-lg bg-neutral-50/50 border border-neutral-border space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">组织名称</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">{selectedAllocation.orgName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">计费周期</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">{selectedAllocation.period}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">分摊方式</span>
                  <Badge variant="outline">{selectedAllocation.method}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">分摊比例</span>
                  <span className="text-sm font-medium text-primary">{selectedAllocation.proportion}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">总费用</span>
                  <span className="text-sm font-medium text-neutral-textPrimary">
                    {formatCurrency(selectedAllocation.totalFee)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-neutral-textSecondary">分摊费用</span>
                  <span className="text-sm font-bold text-primary">
                    {formatCurrency(selectedAllocation.allocatedFee)}
                  </span>
                </div>
              </div>
              <div className="p-3 rounded-lg border border-neutral-border">
                <div className="text-xs text-neutral-textSecondary mb-1">计算说明</div>
                <div className="text-sm text-neutral-textPrimary">
                  根据分摊规则 <span className="font-medium text-primary">{selectedAllocation.method}</span>，
                  按实际业务数据计算出该组织应承担费用比例为 <span className="font-medium">{selectedAllocation.proportion}</span>，
                  分摊金额 = 总费用 × 分摊比例 = {formatCurrency(selectedAllocation.allocatedFee)}。
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setAllocationDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
