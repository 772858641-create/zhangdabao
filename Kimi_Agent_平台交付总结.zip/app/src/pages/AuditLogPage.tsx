import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ClipboardList,
  Search,
  Filter,
  Download,
  Eye,
  ChevronDown,
  ChevronUp,
  Clock,
  Monitor,
  Smartphone,
  CheckCircle,
  XCircle,
  AlertTriangle,
  User,
  Building2,
  Activity,
  BarChart3,
  X,
  Calendar,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type AuditModule =
  | 'carrier'
  | 'transfer'
  | 'alarm'
  | 'user'
  | 'system'
  | 'site'
  | 'device'
  | 'billing'
  | 'project';

type AuditActionType =
  | 'create'
  | 'edit'
  | 'delete'
  | 'export'
  | 'login'
  | 'logout'
  | 'approve'
  | 'reject'
  | 'import'
  | 'enable'
  | 'disable';

type AuditResult = 'success' | 'fail';
type AuditTerminal = 'pc' | 'mobile';

interface AuditLog {
  id: string;
  operationTime: string;
  operatorName: string;
  operatorAccount: string;
  orgName: string;
  projectName: string;
  module: AuditModule;
  actionType: AuditActionType;
  objectType: string;
  objectId: string;
  objectName: string;
  beforeSnapshot: Record<string, unknown> | null;
  afterSnapshot: Record<string, unknown> | null;
  result: AuditResult;
  failReason: string | null;
  ipAddress: string;
  terminal: AuditTerminal;
  durationMs: number;
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const MODULE_CONFIG: Record<AuditModule, { label: string; color: string }> = {
  carrier: { label: '载具管理', color: '#2563EB' },
  transfer: { label: '调拨管理', color: '#8B5CF6' },
  alarm: { label: '报警中心', color: '#EF4444' },
  user: { label: '用户管理', color: '#F59E0B' },
  system: { label: '系统设置', color: '#06B6D4' },
  site: { label: '网点管理', color: '#10B981' },
  device: { label: '设备管理', color: '#EC4899' },
  billing: { label: '计费管理', color: '#6366F1' },
  project: { label: '项目管理', color: '#14B8A6' },
};

const ACTION_TYPE_CONFIG: Record<AuditActionType, { label: string; color: string; bg: string }> = {
  create: { label: '新增', color: '#10B981', bg: '#ECFDF5' },
  edit: { label: '编辑', color: '#2563EB', bg: '#EFF6FF' },
  delete: { label: '删除', color: '#EF4444', bg: '#FEF2F2' },
  export: { label: '导出', color: '#8B5CF6', bg: '#F5F3FF' },
  login: { label: '登录', color: '#06B6D4', bg: '#ECFEFF' },
  logout: { label: '登出', color: '#94A3B8', bg: '#F1F5F9' },
  approve: { label: '审批', color: '#10B981', bg: '#ECFDF5' },
  reject: { label: '驳回', color: '#F59E0B', bg: '#FFFBEB' },
  import: { label: '导入', color: '#6366F1', bg: '#EEF2FF' },
  enable: { label: '启用', color: '#10B981', bg: '#ECFDF5' },
  disable: { label: '停用', color: '#EF4444', bg: '#FEF2F2' },
};

const RESULT_CONFIG: Record<AuditResult, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  success: { label: '成功', color: '#10B981', bg: '#ECFDF5', icon: CheckCircle },
  fail: { label: '失败', color: '#EF4444', bg: '#FEF2F2', icon: XCircle },
};

const MODULE_OPTIONS: { key: AuditModule | 'all'; label: string }[] = [
  { key: 'all', label: '全部模块' },
  { key: 'carrier', label: '载具管理' },
  { key: 'transfer', label: '调拨管理' },
  { key: 'alarm', label: '报警中心' },
  { key: 'user', label: '用户管理' },
  { key: 'system', label: '系统设置' },
  { key: 'site', label: '网点管理' },
  { key: 'device', label: '设备管理' },
  { key: 'billing', label: '计费管理' },
  { key: 'project', label: '项目管理' },
];

const ACTION_TYPE_OPTIONS: { key: AuditActionType | 'all'; label: string }[] = [
  { key: 'all', label: '全部类型' },
  { key: 'create', label: '新增' },
  { key: 'edit', label: '编辑' },
  { key: 'delete', label: '删除' },
  { key: 'export', label: '导出' },
  { key: 'login', label: '登录' },
  { key: 'logout', label: '登出' },
  { key: 'approve', label: '审批' },
  { key: 'reject', label: '驳回' },
  { key: 'import', label: '导入' },
  { key: 'enable', label: '启用' },
  { key: 'disable', label: '停用' },
];

const RESULT_OPTIONS: { key: AuditResult | 'all'; label: string }[] = [
  { key: 'all', label: '全部结果' },
  { key: 'success', label: '成功' },
  { key: 'fail', label: '失败' },
];

const ORG_OPTIONS = [
  { key: 'all', label: '全部组织' },
  { key: '上海总部', label: '上海总部' },
  { key: '宁波分公司', label: '宁波分公司' },
  { key: '广州运营中心', label: '广州运营中心' },
  { key: '深圳配送中心', label: '深圳配送中心' },
  { key: '天津港务', label: '天津港务' },
  { key: '青岛物流', label: '青岛物流' },
];

const USER_OPTIONS = [
  { key: 'all', label: '全部用户' },
  { key: '系统管理员', label: '系统管理员' },
  { key: '张三', label: '张三' },
  { key: '李四', label: '李四' },
  { key: '王五', label: '王五' },
  { key: '赵六', label: '赵六' },
  { key: '孙七', label: '孙七' },
  { key: '周八', label: '周八' },
  { key: '吴九', label: '吴九' },
  { key: '郑十', label: '郑十' },
];

// ------------------------------------------------------------------
// Mock Data
// ------------------------------------------------------------------
const MODULES: AuditModule[] = ['carrier', 'transfer', 'alarm', 'user', 'system', 'site', 'device', 'billing', 'project'];
const ACTION_TYPES: AuditActionType[] = ['create', 'edit', 'delete', 'export', 'login', 'logout', 'approve', 'reject', 'import', 'enable', 'disable'];
const USERS = [
  { name: '系统管理员', account: 'admin' },
  { name: '张三', account: 'zhangsan' },
  { name: '李四', account: 'lisi' },
  { name: '王五', account: 'wangwu' },
  { name: '赵六', account: 'zhaoliu' },
  { name: '孙七', account: 'sunqi' },
  { name: '周八', account: 'zhouba' },
  { name: '吴九', account: 'wujiu' },
  { name: '郑十', account: 'zhengshi' },
];
const ORGS = ['上海总部', '宁波分公司', '广州运营中心', '深圳配送中心', '天津港务', '青岛物流'];
const PROJECTS = ['华东大区项目', '华南运输项目', '华北仓储项目', '智慧物流平台', '绿色供应链项目', '全国配送网络'];

function generateSnapshot(module: AuditModule, actionType: AuditActionType): { before: Record<string, unknown> | null; after: Record<string, unknown> | null } {
  const snapshots: Record<AuditModule, Record<string, unknown>> = {
    carrier: {
      id: 'CJ' + String(Math.floor(Math.random() * 9000) + 1000),
      name: '标准托盘-' + Math.floor(Math.random() * 100),
      type: '托盘',
      status: 'normal',
      site: '上海浦东工厂',
      lastLocation: 'A区-货架3',
    },
    transfer: {
      id: 'DB' + String(Math.floor(Math.random() * 9000) + 1000),
      fromSite: '上海浦东工厂',
      toSite: '宁波生产基地',
      carrierCount: Math.floor(Math.random() * 50) + 10,
      status: 'pending',
    },
    alarm: {
      id: 'BJ' + String(Math.floor(Math.random() * 90000) + 10000),
      type: '进库报警',
      level: 'important',
      status: 'unhandled',
      target: 'CJ' + String(Math.floor(Math.random() * 9000) + 1000),
    },
    user: {
      id: 'U' + String(Math.floor(Math.random() * 900) + 100),
      name: '新用户' + Math.floor(Math.random() * 100),
      role: 'operator',
      org: '上海总部',
      status: 'active',
    },
    system: {
      configKey: 'system.timeout',
      configValue: '30',
      description: '会话超时时间（分钟）',
    },
    site: {
      id: 'WD' + String(Math.floor(Math.random() * 900) + 100),
      name: '网点' + Math.floor(Math.random() * 100),
      address: '上海市浦东新区xx路xx号',
      status: 'active',
    },
    device: {
      id: 'SB' + String(Math.floor(Math.random() * 9000) + 1000),
      name: 'RFID读写器-' + Math.floor(Math.random() * 50),
      type: 'RFID',
      status: 'online',
      battery: Math.floor(Math.random() * 40) + 60,
    },
    billing: {
      id: 'JF' + String(Math.floor(Math.random() * 900) + 100),
      carrierType: '托盘',
      unitPrice: Math.floor(Math.random() * 50) + 10,
      billingCycle: 'monthly',
    },
    project: {
      id: 'PJ' + String(Math.floor(Math.random() * 900) + 100),
      name: '项目' + Math.floor(Math.random() * 100),
      manager: '张三',
      status: 'active',
      budget: Math.floor(Math.random() * 500000) + 100000,
    },
  };

  if (actionType === 'login' || actionType === 'logout' || actionType === 'export' || actionType === 'import') {
    return { before: null, after: null };
  }

  const base = snapshots[module];
  const before = { ...base };
  const after = { ...base };

  if (actionType === 'create') {
    return { before: null, after };
  }
  if (actionType === 'delete') {
    return { before, after: null };
  }
  if (actionType === 'edit') {
    // Modify a random field
    const keys = Object.keys(after).filter(k => k !== 'id');
    const key = keys[Math.floor(Math.random() * keys.length)];
    if (typeof after[key] === 'string') {
      after[key] = (after[key] as string) + '-已修改';
    } else if (typeof after[key] === 'number') {
      after[key] = (after[key] as number) + Math.floor(Math.random() * 10) + 1;
    }
    return { before, after };
  }
  if (actionType === 'approve' || actionType === 'reject') {
    after.status = actionType === 'approve' ? 'approved' : 'rejected';
    return { before, after };
  }
  if (actionType === 'enable' || actionType === 'disable') {
    after.status = actionType === 'enable' ? 'active' : 'inactive';
    return { before, after };
  }

  return { before, after };
}

function generateAuditLogs(): AuditLog[] {
  const logs: AuditLog[] = [];
  const baseDate = new Date('2024-12-20T00:00:00');

  for (let i = 0; i < 40; i++) {
    const idx = i + 1;
    const module = MODULES[i % MODULES.length];
    const actionType = ACTION_TYPES[i % ACTION_TYPES.length];
    const user = USERS[i % USERS.length];
    const result: AuditResult = Math.random() < 0.85 ? 'success' : 'fail';
    const dayOffset = Math.floor(Math.random() * 30);
    const hour = Math.floor(Math.random() * 24);
    const minute = Math.floor(Math.random() * 60);
    const second = Math.floor(Math.random() * 60);
    const date = new Date(baseDate);
    date.setDate(date.getDate() - dayOffset);
    const operationTime = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`;

    const { before, after } = generateSnapshot(module, actionType);
    const durationMs = Math.floor(Math.random() * 3000) + 50;

    const objectTypes: Record<AuditModule, string> = {
      carrier: '载具',
      transfer: '调拨单',
      alarm: '报警',
      user: '用户',
      system: '配置项',
      site: '网点',
      device: '设备',
      billing: '计费规则',
      project: '项目',
    };

    logs.push({
      id: `AUD${String(idx).padStart(8, '0')}`,
      operationTime,
      operatorName: user.name,
      operatorAccount: user.account,
      orgName: ORGS[i % ORGS.length],
      projectName: PROJECTS[i % PROJECTS.length],
      module,
      actionType,
      objectType: objectTypes[module],
      objectId: `OBJ${String(Math.floor(Math.random() * 90000) + 10000)}`,
      objectName: `${objectTypes[module]}-${String(Math.floor(Math.random() * 1000))}`,
      beforeSnapshot: before,
      afterSnapshot: after,
      result,
      failReason: result === 'fail' ? ['数据库连接超时', '权限不足', '参数校验失败', '对象不存在', '并发冲突'][Math.floor(Math.random() * 5)] : null,
      ipAddress: `192.168.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`,
      terminal: Math.random() < 0.8 ? 'pc' : 'mobile',
      durationMs,
    });
  }

  // Sort by time descending
  return logs.sort((a, b) => new Date(b.operationTime).getTime() - new Date(a.operationTime).getTime());
}

const MOCK_LOGS = generateAuditLogs();

// ------------------------------------------------------------------
// Utility functions
// ------------------------------------------------------------------
function formatDateTime(dt: string): string {
  return dt;
}

// ------------------------------------------------------------------
// Components
// ------------------------------------------------------------------

/** Tag component */
function Tag({ label, color, bg, className }: { label: string; color: string; bg: string; className?: string }) {
  return (
    <span
      className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', className)}
      style={{ color, backgroundColor: bg }}
    >
      {label}
    </span>
  );
}

/** KPI Card */
function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4 hover:shadow-card-hover transition-shadow duration-200">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-[#475569] mb-1">{title}</p>
        <p className="text-[28px] font-semibold leading-tight" style={{ color: '#0F172A' }}>{value}</p>
        {subtext && <p className="text-xs text-[#94A3B8] mt-1">{subtext}</p>}
      </div>
    </div>
  );
}

/** JSON Syntax Highlight Viewer */
function JsonViewer({ data, title }: { data: Record<string, unknown> | null; title: string }) {
  if (!data) {
    return (
      <div className="bg-[#F8FAFC] rounded-lg p-4">
        <p className="text-xs font-medium text-[#475569] mb-2">{title}</p>
        <p className="text-sm text-[#94A3B8] italic">无数据</p>
      </div>
    );
  }

  const jsonStr = JSON.stringify(data, null, 2);

  // Simple syntax highlighting
  const highlighted = jsonStr
    .replace(/"([^"]+)":/g, '<span class="text-[#2563EB]">"$1"</span>:')
    .replace(/: "([^"]*)"/g, ': <span class="text-[#10B981]">"$1"</span>')
    .replace(/: (\d+)/g, ': <span class="text-[#F59E0B]">$1</span>')
    .replace(/: (true|false)/g, ': <span class="text-[#8B5CF6]">$1</span>')
    .replace(/: (null)/g, ': <span class="text-[#94A3B8]">$1</span>');

  return (
    <div className="bg-[#F8FAFC] rounded-lg p-4 overflow-auto max-h-64">
      <p className="text-xs font-medium text-[#475569] mb-2">{title}</p>
      <pre
        className="text-xs font-mono leading-relaxed whitespace-pre-wrap"
        dangerouslySetInnerHTML={{ __html: highlighted }}
      />
    </div>
  );
}

/** Snapshot Diff View */
function SnapshotDiff({ before, after }: { before: Record<string, unknown> | null; after: Record<string, unknown> | null }) {
  if (!before && !after) {
    return <p className="text-sm text-[#94A3B8] italic">无数据变更记录</p>;
  }
  if (!before) {
    return (
      <div>
        <p className="text-xs font-medium text-[#10B981] mb-2">新增数据</p>
        <JsonViewer data={after} title="操作后快照" />
      </div>
    );
  }
  if (!after) {
    return (
      <div>
        <p className="text-xs font-medium text-[#EF4444] mb-2">删除数据</p>
        <JsonViewer data={before} title="操作前快照" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      <JsonViewer data={before} title="操作前快照" />
      <JsonViewer data={after} title="操作后快照" />
    </div>
  );
}

/** Detail Drawer */
function AuditDetailDrawer({ log, onClose }: { log: AuditLog | null; onClose: () => void }) {
  if (!log) return null;
  const moduleCfg = MODULE_CONFIG[log.module];
  const actionCfg = ACTION_TYPE_CONFIG[log.actionType];
  const resultCfg = RESULT_CONFIG[log.result];
  const ResultIcon = resultCfg.icon;

  return (
    <AnimatePresence>
      {log && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed right-0 top-14 bottom-0 w-[640px] bg-white shadow-modal z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-3">
                <span className="text-base font-semibold text-[#0F172A]">审计日志详情</span>
                <Tag label={moduleCfg.label} color={moduleCfg.color} bg={`${moduleCfg.color}15`} />
                <Tag label={actionCfg.label} color={actionCfg.color} bg={actionCfg.bg} />
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center transition-colors">
                <X size={18} className="text-[#94A3B8]" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Basic Info */}
              <div>
                <h3 className="text-sm font-semibold text-[#0F172A] mb-3">基本信息</h3>
                <div className="bg-[#F8FAFC] rounded-lg p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">日志编号</span>
                    <span className="text-sm font-mono text-[#0F172A]">{log.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作时间</span>
                    <span className="text-sm text-[#0F172A]">{log.operationTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作人</span>
                    <span className="text-sm text-[#0F172A]">{log.operatorName}（{log.operatorAccount}）</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">所属组织</span>
                    <span className="text-sm text-[#0F172A]">{log.orgName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">所属项目</span>
                    <span className="text-sm text-[#0F172A]">{log.projectName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作模块</span>
                    <span className="text-sm text-[#0F172A]">{moduleCfg.label}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作类型</span>
                    <Tag label={actionCfg.label} color={actionCfg.color} bg={actionCfg.bg} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作对象</span>
                    <span className="text-sm text-[#0F172A]">{log.objectType}：{log.objectName}（{log.objectId}）</span>
                  </div>
                </div>
              </div>

              {/* Operation Result */}
              <div>
                <h3 className="text-sm font-semibold text-[#0F172A] mb-3">操作结果</h3>
                <div className="bg-[#F8FAFC] rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-[#475569]">执行结果</span>
                    <div className="flex items-center gap-1.5">
                      <ResultIcon size={14} style={{ color: resultCfg.color }} />
                      <Tag label={resultCfg.label} color={resultCfg.color} bg={resultCfg.bg} />
                    </div>
                  </div>
                  {log.failReason && (
                    <div className="flex justify-between">
                      <span className="text-sm text-[#475569]">失败原因</span>
                      <span className="text-sm text-[#EF4444]">{log.failReason}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">IP地址</span>
                    <span className="text-sm font-mono text-[#0F172A]">{log.ipAddress}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作终端</span>
                    <div className="flex items-center gap-1.5">
                      {log.terminal === 'pc' ? <Monitor size={14} className="text-[#475569]" /> : <Smartphone size={14} className="text-[#475569]" />}
                      <span className="text-sm text-[#0F172A]">{log.terminal === 'pc' ? 'PC端' : '移动端'}</span>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">操作耗时</span>
                    <span className="text-sm text-[#0F172A]">{log.durationMs} ms</span>
                  </div>
                </div>
              </div>

              {/* Data Snapshots */}
              <div>
                <h3 className="text-sm font-semibold text-[#0F172A] mb-3">数据变更</h3>
                <SnapshotDiff before={log.beforeSnapshot} after={log.afterSnapshot} />
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ------------------------------------------------------------------
// Charts
// ------------------------------------------------------------------
function ModuleDistributionChart({ logs }: { logs: AuditLog[] }) {
  const data = useMemo(() => {
    const counts: Record<string, number> = {};
    logs.forEach(log => {
      counts[log.module] = (counts[log.module] || 0) + 1;
    });
    return Object.entries(counts).map(([key, value]) => ({
      name: MODULE_CONFIG[key as AuditModule].label,
      value,
      color: MODULE_CONFIG[key as AuditModule].color,
    }));
  }, [logs]);

  return (
    <div className="bg-white rounded-lg shadow-card p-4">
      <h3 className="text-sm font-semibold text-[#0F172A] mb-4 flex items-center gap-2">
        <BarChart3 size={16} className="text-[#2563EB]" />
        操作模块分布
      </h3>
      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            paddingAngle={3}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              borderRadius: '8px',
              border: '1px solid #E2E8F0',
              boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
              fontSize: '12px',
            }}
          />
          <Legend
            verticalAlign="bottom"
            height={36}
            iconType="circle"
            iconSize={8}
            formatter={(value: string) => <span className="text-xs text-[#475569]">{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

function OperationTrendChart({ logs }: { logs: AuditLog[] }) {
  const data = useMemo(() => {
    const dayCounts: Record<string, number> = {};
    const today = new Date('2024-12-20');
    for (let i = 29; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const key = `${d.getMonth() + 1}/${d.getDate()}`;
      dayCounts[key] = 0;
    }
    logs.forEach(log => {
      const date = new Date(log.operationTime);
      const key = `${date.getMonth() + 1}/${date.getDate()}`;
      if (dayCounts[key] !== undefined) {
        dayCounts[key]++;
      }
    });
    return Object.entries(dayCounts).map(([name, value]) => ({ name, value }));
  }, [logs]);

  return (
    <div className="bg-white rounded-lg shadow-card p-4">
      <h3 className="text-sm font-semibold text-[#0F172A] mb-4 flex items-center gap-2">
        <Activity size={16} className="text-[#10B981]" />
        近30天操作趋势
      </h3>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
          <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
          <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} allowDecimals={false} />
          <Tooltip
            contentStyle={{
              borderRadius: '8px',
              border: '1px solid #E2E8F0',
              boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
              fontSize: '12px',
            }}
          />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#2563EB"
            strokeWidth={2}
            dot={{ fill: '#2563EB', r: 3 }}
            activeDot={{ r: 5 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function AuditLogPage() {
  const { users: _users } = useMockData();
  void _users;

  const [logs] = useState<AuditLog[]>(MOCK_LOGS);
  const [timeRange, setTimeRange] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [operatorFilter, setOperatorFilter] = useState<string>('all');
  const [moduleFilter, setModuleFilter] = useState<AuditModule | 'all'>('all');
  const [actionTypeFilter, setActionTypeFilter] = useState<AuditActionType | 'all'>('all');
  const [resultFilter, setResultFilter] = useState<AuditResult | 'all'>('all');
  const [orgFilter, setOrgFilter] = useState<string>('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [detailLog, setDetailLog] = useState<AuditLog | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // Time range
      if (timeRange !== 'all') {
        const logDate = new Date(log.operationTime);
        const today = new Date('2024-12-20');
        if (timeRange === 'today') {
          if (logDate.getDate() !== today.getDate() || logDate.getMonth() !== today.getMonth()) return false;
        } else if (timeRange === 'week') {
          const weekAgo = new Date(today);
          weekAgo.setDate(weekAgo.getDate() - 7);
          if (logDate < weekAgo) return false;
        } else if (timeRange === 'month') {
          const monthAgo = new Date(today);
          monthAgo.setDate(monthAgo.getDate() - 30);
          if (logDate < monthAgo) return false;
        }
      }
      if (operatorFilter !== 'all' && log.operatorName !== operatorFilter) return false;
      if (moduleFilter !== 'all' && log.module !== moduleFilter) return false;
      if (actionTypeFilter !== 'all' && log.actionType !== actionTypeFilter) return false;
      if (resultFilter !== 'all' && log.result !== resultFilter) return false;
      if (orgFilter !== 'all' && log.orgName !== orgFilter) return false;
      if (searchKeyword) {
        const kw = searchKeyword.toLowerCase();
        return (
          log.id.toLowerCase().includes(kw) ||
          log.objectName.toLowerCase().includes(kw) ||
          log.objectId.toLowerCase().includes(kw) ||
          log.operatorName.toLowerCase().includes(kw)
        );
      }
      return true;
    });
  }, [logs, timeRange, operatorFilter, moduleFilter, actionTypeFilter, resultFilter, orgFilter, searchKeyword]);

  // Pagination
  const totalPages = Math.ceil(filteredLogs.length / pageSize);
  const paginatedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredLogs.slice(start, start + pageSize);
  }, [filteredLogs, currentPage]);

  // KPI data
  const kpiData = useMemo(() => {
    const today = new Date('2024-12-20');
    const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    const todayCount = logs.filter(l => l.operationTime.startsWith(todayStr)).length;

    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekCount = logs.filter(l => new Date(l.operationTime) >= weekAgo).length;

    const abnormalCount = logs.filter(l => l.result === 'fail').length;
    const activeUserCount = new Set(logs.map(l => l.operatorAccount)).size;

    return { todayCount, weekCount, abnormalCount, activeUserCount };
  }, [logs]);

  const toggleExpandRow = (id: string) => {
    const next = new Set(expandedRows);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setExpandedRows(next);
  };

  const handleExport = () => {
    alert(`导出 ${filteredLogs.length} 条审计日志（模拟）`);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-[#0F172A]">操作审计日志</h1>
          <span className="text-sm text-[#94A3B8]">共 {filteredLogs.length} 条记录</span>
        </div>
        <button
          onClick={handleExport}
          className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors"
        >
          <Download size={15} /> 导出审计日志
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        <KPICard
          title="今日操作次数"
          value={kpiData.todayCount}
          subtext="24小时内操作记录"
          color="#2563EB"
          icon={Clock}
        />
        <KPICard
          title="本周操作次数"
          value={kpiData.weekCount}
          subtext="近7天累计"
          color="#10B981"
          icon={Activity}
        />
        <KPICard
          title="异常操作次数"
          value={kpiData.abnormalCount}
          subtext="失败操作记录"
          color="#EF4444"
          icon={AlertTriangle}
        />
        <KPICard
          title="活跃用户数"
          value={kpiData.activeUserCount}
          subtext="有操作记录的用户"
          color="#F59E0B"
          icon={User}
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-4">
        <ModuleDistributionChart logs={logs} />
        <OperationTrendChart logs={logs} />
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        {/* Time Range */}
        <div className="flex items-center gap-2">
          <Calendar size={14} className="text-[#94A3B8]" />
          <select
            value={timeRange}
            onChange={(e) => { setTimeRange(e.target.value as typeof timeRange); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            <option value="all">全部时间</option>
            <option value="today">今天</option>
            <option value="week">近7天</option>
            <option value="month">近30天</option>
          </select>
        </div>

        {/* Operator */}
        <div className="flex items-center gap-2">
          <User size={14} className="text-[#94A3B8]" />
          <select
            value={operatorFilter}
            onChange={(e) => { setOperatorFilter(e.target.value); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {USER_OPTIONS.map(u => <option key={u.key} value={u.key}>{u.label}</option>)}
          </select>
        </div>

        {/* Module */}
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select
            value={moduleFilter}
            onChange={(e) => { setModuleFilter(e.target.value as AuditModule | 'all'); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {MODULE_OPTIONS.map(m => <option key={m.key} value={m.key}>{m.label}</option>)}
          </select>
        </div>

        {/* Action Type */}
        <select
          value={actionTypeFilter}
          onChange={(e) => { setActionTypeFilter(e.target.value as AuditActionType | 'all'); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          {ACTION_TYPE_OPTIONS.map(a => <option key={a.key} value={a.key}>{a.label}</option>)}
        </select>

        {/* Result */}
        <select
          value={resultFilter}
          onChange={(e) => { setResultFilter(e.target.value as AuditResult | 'all'); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          {RESULT_OPTIONS.map(r => <option key={r.key} value={r.key}>{r.label}</option>)}
        </select>

        {/* Org */}
        <div className="flex items-center gap-2">
          <Building2 size={14} className="text-[#94A3B8]" />
          <select
            value={orgFilter}
            onChange={(e) => { setOrgFilter(e.target.value); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {ORG_OPTIONS.map(o => <option key={o.key} value={o.key}>{o.label}</option>)}
          </select>
        </div>

        {/* Search */}
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => { setSearchKeyword(e.target.value); setCurrentPage(1); }}
              placeholder="搜索对象名称、对象ID..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="w-8 px-3 py-2.5" />
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">日志编号</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作时间</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作人</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">所属组织</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作模块</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作类型</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作对象</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">结果</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">IP / 终端</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">耗时</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedLogs.map((log, idx) => {
                const moduleCfg = MODULE_CONFIG[log.module];
                const actionCfg = ACTION_TYPE_CONFIG[log.actionType];
                const resultCfg = RESULT_CONFIG[log.result];
                const ResultIcon = resultCfg.icon;
                const isExpanded = expandedRows.has(log.id);

                return (
                  <>
                    <motion.tr
                      key={log.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: idx * 0.03 }}
                      className={cn(
                        'group border-b border-[#E2E8F0] transition-colors duration-150',
                        log.result === 'fail' ? 'bg-[#FEF2F2]' : 'hover:bg-[#F8FAFC]'
                      )}
                    >
                      <td className="px-3 py-3">
                        <button
                          onClick={() => toggleExpandRow(log.id)}
                          className="w-6 h-6 rounded hover:bg-[#F1F5F9] flex items-center justify-center transition-colors"
                        >
                          {isExpanded ? <ChevronUp size={14} className="text-[#475569]" /> : <ChevronDown size={14} className="text-[#475569]" />}
                        </button>
                      </td>
                      <td className="px-3 py-3">
                        <span className="text-xs font-mono text-[#0F172A]">{log.id}</span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="text-xs text-[#475569] font-mono">{formatDateTime(log.operationTime)}</span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex flex-col">
                          <span className="text-sm text-[#0F172A]">{log.operatorName}</span>
                          <span className="text-xs text-[#94A3B8]">{log.operatorAccount}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <span className="text-sm text-[#475569]">{log.orgName}</span>
                      </td>
                      <td className="px-3 py-3">
                        <Tag label={moduleCfg.label} color={moduleCfg.color} bg={`${moduleCfg.color}15`} />
                      </td>
                      <td className="px-3 py-3">
                        <Tag label={actionCfg.label} color={actionCfg.color} bg={actionCfg.bg} />
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex flex-col">
                          <span className="text-sm text-[#0F172A]">{log.objectName}</span>
                          <span className="text-xs text-[#94A3B8]">{log.objectType} · {log.objectId}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1.5">
                          <ResultIcon size={14} style={{ color: resultCfg.color }} />
                          <Tag label={resultCfg.label} color={resultCfg.color} bg={resultCfg.bg} />
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1.5">
                          {log.terminal === 'pc' ? <Monitor size={12} className="text-[#94A3B8]" /> : <Smartphone size={12} className="text-[#94A3B8]" />}
                          <span className="text-xs text-[#475569] font-mono">{log.ipAddress}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3">
                        <span className="text-xs text-[#94A3B8]">{log.durationMs}ms</span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => setDetailLog(log)}
                            className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center"
                            title="查看详情"
                          >
                            <Eye size={14} className="text-[#475569]" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                    {/* Expanded Row */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.tr
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <td colSpan={12} className="px-6 py-4 bg-[#F8FAFC] border-b border-[#E2E8F0]">
                            <div className="space-y-4">
                              {log.failReason && (
                                <div className="flex items-center gap-2 text-sm text-[#EF4444]">
                                  <AlertTriangle size={14} />
                                  <span>失败原因：{log.failReason}</span>
                                </div>
                              )}
                              <SnapshotDiff before={log.beforeSnapshot} after={log.afterSnapshot} />
                            </div>
                          </td>
                        </motion.tr>
                      )}
                    </AnimatePresence>
                  </>
                );
              })}
              {paginatedLogs.length === 0 && (
                <tr>
                  <td colSpan={12} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <ClipboardList size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无审计日志</p>
                      <p className="text-sm text-[#94A3B8]">当前筛选条件下没有符合条件的审计日志</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredLogs.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">
              共 <strong>{filteredLogs.length}</strong> 条，第 <strong>{currentPage}</strong> / {totalPages} 页
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={cn(
                      'w-8 h-8 rounded-md text-sm font-medium transition-colors',
                      currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]'
                    )}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      <AuditDetailDrawer log={detailLog} onClose={() => setDetailLog(null)} />
    </div>
  );
}
