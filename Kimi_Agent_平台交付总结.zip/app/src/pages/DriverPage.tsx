import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { User, Truck, Phone, CreditCard, Calendar, Search, Plus, Edit, Eye, MapPin, Star, Award } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

/* ─────────────── 类型定义 ─────────────── */
interface Driver {
  id: string;
  name: string;
  phone: string;
  org: string;
  idCard: string;
  licenseNo: string;
  licenseType: string;
  joinDate: string;
  status: string;
  remark: string;
  licenseExpire: string;
  bindVehicle: string | null;
  trips30d: number;
  mileage30d: number;
  safetyMileage: number;
  rating: number;
}

interface DriverFormData {
  name: string;
  phone: string;
  idCard: string;
  licenseNo: string;
  licenseType: string;
  org: string;
  joinDate: string;
  status: string;
  remark: string;
}

/* ─────────────── 常量 ─────────────── */
const LICENSE_TYPES = ['A1', 'A2', 'B1', 'B2', 'C1'];
const ORGS = ['华东运营中心', '华南运营中心', '华北运营中心', '西南运营中心'];
const STATUSES = ['在职', '离职', '休假'];

const PIE_COLORS = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
const BAR_COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'];

/* ─────────────── 30 条 Mock 数据 ─────────────── */
const driversMock: Driver[] = [
  { id: 'D001', name: '王强', phone: '13800138001', org: '华东运营中心', idCard: '310101198501011234', licenseNo: '310101198501011234', licenseType: 'B2', joinDate: '2019-03-15', status: '在职', remark: '资深司机，零事故', licenseExpire: '2027-08-15', bindVehicle: '沪A12345', trips30d: 48, mileage30d: 3200, safetyMileage: 125000, rating: 5 },
  { id: 'D002', name: '李明', phone: '13800138002', org: '华东运营中心', idCard: '310102199001022345', licenseNo: '310102199001022345', licenseType: 'A2', joinDate: '2020-06-01', status: '在职', remark: '长途运输经验丰富', licenseExpire: '2026-03-20', bindVehicle: '沪B67890', trips30d: 42, mileage30d: 2800, safetyMileage: 89000, rating: 4 },
  { id: 'D003', name: '张伟', phone: '13800138003', org: '华南运营中心', idCard: '440103198802033456', licenseNo: '440103198802033456', licenseType: 'B2', joinDate: '2021-01-10', status: '在职', remark: '', licenseExpire: '2025-06-10', bindVehicle: '粤B11111', trips30d: 35, mileage30d: 2100, safetyMileage: 56000, rating: 4 },
  { id: 'D004', name: '刘洋', phone: '13800138004', org: '华北运营中心', idCard: '110104199203044567', licenseNo: '110104199203044567', licenseType: 'A1', joinDate: '2018-11-20', status: '在职', remark: '大巴驾驶专业', licenseExpire: '2028-01-25', bindVehicle: '京A00001', trips30d: 52, mileage30d: 4100, safetyMileage: 210000, rating: 5 },
  { id: 'D005', name: '陈刚', phone: '13800138005', org: '西南运营中心', idCard: '500105198510055678', licenseNo: '500105198510055678', licenseType: 'C1', joinDate: '2022-04-05', status: '在职', remark: '城市配送', licenseExpire: '2027-09-18', bindVehicle: '渝A22222', trips30d: 60, mileage30d: 1800, safetyMileage: 32000, rating: 4 },
  { id: 'D006', name: '赵磊', phone: '13800138006', org: '华东运营中心', idCard: '310106198707066789', licenseNo: '310106198707066789', licenseType: 'B1', joinDate: '2020-09-12', status: '在职', remark: '', licenseExpire: '2026-12-01', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 78000, rating: 3 },
  { id: 'D007', name: '孙涛', phone: '13800138007', org: '华南运营中心', idCard: '440107199308077890', licenseNo: '440107199308077890', licenseType: 'A2', joinDate: '2021-07-18', status: '在职', remark: '冷链运输专长', licenseExpire: '2029-04-22', bindVehicle: '粤B33333', trips30d: 38, mileage30d: 2900, safetyMileage: 67000, rating: 5 },
  { id: 'D008', name: '周杰', phone: '13800138008', org: '华北运营中心', idCard: '110108198909088901', licenseNo: '110108198909088901', licenseType: 'B2', joinDate: '2019-05-22', status: '休假', remark: '年休假中', licenseExpire: '2027-07-30', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 95000, rating: 4 },
  { id: 'D009', name: '吴辉', phone: '13800138009', org: '西南运营中心', idCard: '500109199010099012', licenseNo: '500109199010099012', licenseType: 'C1', joinDate: '2023-02-14', status: '在职', remark: '新入职司机', licenseExpire: '2028-11-05', bindVehicle: '渝B44444', trips30d: 45, mileage30d: 1500, safetyMileage: 18000, rating: 4 },
  { id: 'D010', name: '郑峰', phone: '13800138010', org: '华东运营中心', idCard: '310110198411101123', licenseNo: '310110198411101123', licenseType: 'A1', joinDate: '2017-08-30', status: '在职', remark: '车队长', licenseExpire: '2025-10-12', bindVehicle: '沪C55555', trips30d: 55, mileage30d: 3800, safetyMileage: 156000, rating: 5 },
  { id: 'D011', name: '钱波', phone: '13800138011', org: '华南运营中心', idCard: '440111198612112234', licenseNo: '440111198612112234', licenseType: 'B2', joinDate: '2020-03-08', status: '在职', remark: '', licenseExpire: '2026-08-20', bindVehicle: '粤C66666', trips30d: 40, mileage30d: 2600, safetyMileage: 82000, rating: 4 },
  { id: 'D012', name: '冯伟', phone: '13800138012', org: '华北运营中心', idCard: '110112199411223345', licenseNo: '110112199411223345', licenseType: 'C1', joinDate: '2023-06-01', status: '在职', remark: '实习期', licenseExpire: '2029-06-15', bindVehicle: '京B77777', trips30d: 50, mileage30d: 1200, safetyMileage: 12000, rating: 3 },
  { id: 'D013', name: '许鹏', phone: '13800138013', org: '西南运营中心', idCard: '500113198713334456', licenseNo: '500113198713334456', licenseType: 'A2', joinDate: '2019-12-25', status: '离职', remark: '已离职，需交接', licenseExpire: '2026-02-28', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 45000, rating: 3 },
  { id: 'D014', name: '韩冬', phone: '13800138014', org: '华东运营中心', idCard: '310114198814445567', licenseNo: '310114198814445567', licenseType: 'B1', joinDate: '2021-05-17', status: '在职', remark: '', licenseExpire: '2028-05-22', bindVehicle: '沪D88888', trips30d: 33, mileage30d: 1900, safetyMileage: 54000, rating: 4 },
  { id: 'D015', name: '杨帆', phone: '13800138015', org: '华南运营中心', idCard: '440115198915556678', licenseNo: '440115198915556678', licenseType: 'B2', joinDate: '2022-08-09', status: '在职', remark: '危险品运输资质', licenseExpire: '2027-03-18', bindVehicle: '粤D99999', trips30d: 28, mileage30d: 2200, safetyMileage: 41000, rating: 5 },
  { id: 'D016', name: '朱军', phone: '13800138016', org: '华北运营中心', idCard: '110116199016667789', licenseNo: '110116199016667789', licenseType: 'A1', joinDate: '2018-04-03', status: '在职', remark: '安全标兵', licenseExpire: '2029-08-08', bindVehicle: '京C00000', trips30d: 58, mileage30d: 4300, safetyMileage: 230000, rating: 5 },
  { id: 'D017', name: '秦勇', phone: '13800138017', org: '西南运营中心', idCard: '500117198117778890', licenseNo: '500117198117778890', licenseType: 'C1', joinDate: '2023-10-11', status: '在职', remark: '兼职司机', licenseExpire: '2028-12-25', bindVehicle: null, trips30d: 20, mileage30d: 800, safetyMileage: 9000, rating: 3 },
  { id: 'D018', name: '尤龙', phone: '13800138018', org: '华东运营中心', idCard: '310118198218889901', licenseNo: '310118198218889901', licenseType: 'A2', joinDate: '2020-01-06', status: '休假', remark: '病假', licenseExpire: '2026-07-14', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 76000, rating: 4 },
  { id: 'D019', name: '何兵', phone: '13800138019', org: '华南运营中心', idCard: '440119198319990012', licenseNo: '440119198319990012', licenseType: 'B2', joinDate: '2021-11-23', status: '在职', remark: '', licenseExpire: '2027-01-30', bindVehicle: '粤E11111', trips30d: 36, mileage30d: 2400, safetyMileage: 63000, rating: 4 },
  { id: 'D020', name: '罗林', phone: '13800138020', org: '华北运营中心', idCard: '110120198420001123', licenseNo: '110120198420001123', licenseType: 'B1', joinDate: '2019-09-14', status: '在职', remark: '夜间配送', licenseExpire: '2028-04-16', bindVehicle: '京D22222', trips30d: 44, mileage30d: 2100, safetyMileage: 88000, rating: 4 },
  { id: 'D021', name: '高峰', phone: '13800138021', org: '西南运营中心', idCard: '500121198521112234', licenseNo: '500121198521112234', licenseType: 'A1', joinDate: '2017-06-28', status: '在职', remark: '客运专线', licenseExpire: '2025-09-09', bindVehicle: '渝C33333', trips30d: 62, mileage30d: 4600, safetyMileage: 198000, rating: 5 },
  { id: 'D022', name: '林涛', phone: '13800138022', org: '华东运营中心', idCard: '310122198622223345', licenseNo: '310122198622223345', licenseType: 'C1', joinDate: '2022-12-01', status: '在职', remark: '', licenseExpire: '2029-03-03', bindVehicle: '沪E44444', trips30d: 55, mileage30d: 1600, safetyMileage: 27000, rating: 4 },
  { id: 'D023', name: '谢峰', phone: '13800138023', org: '华南运营中心', idCard: '440123198723334456', licenseNo: '440123198723334456', licenseType: 'A2', joinDate: '2020-07-07', status: '在职', remark: '跨省长途', licenseExpire: '2027-06-28', bindVehicle: '粤F55555', trips30d: 30, mileage30d: 3100, safetyMileage: 105000, rating: 5 },
  { id: 'D024', name: '马汉', phone: '13800138024', org: '华北运营中心', idCard: '110124198824445567', licenseNo: '110124198824445567', licenseType: 'B2', joinDate: '2021-03-19', status: '离职', remark: '合同到期未续', licenseExpire: '2026-11-11', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 38000, rating: 3 },
  { id: 'D025', name: '唐明', phone: '13800138025', org: '西南运营中心', idCard: '500125198925556678', licenseNo: '500125198925556678', licenseType: 'B1', joinDate: '2022-05-26', status: '在职', remark: '', licenseExpire: '2028-08-02', bindVehicle: '渝D66666', trips30d: 41, mileage30d: 2000, safetyMileage: 49000, rating: 4 },
  { id: 'D026', name: '宋凯', phone: '13800138026', org: '华东运营中心', idCard: '310126199026667789', licenseNo: '310126199026667789', licenseType: 'C1', joinDate: '2023-08-15', status: '在职', remark: '新员工培训中', licenseExpire: '2029-01-20', bindVehicle: '沪F77777', trips30d: 38, mileage30d: 1100, safetyMileage: 15000, rating: 3 },
  { id: 'D027', name: '曹阳', phone: '13800138027', org: '华南运营中心', idCard: '440127198127778890', licenseNo: '440127198127778890', licenseType: 'A1', joinDate: '2018-10-02', status: '在职', remark: '旅游专线司机', licenseExpire: '2029-05-25', bindVehicle: '粤G88888', trips30d: 50, mileage30d: 3900, safetyMileage: 175000, rating: 5 },
  { id: 'D028', name: '彭亮', phone: '13800138028', org: '华北运营中心', idCard: '110128198228889901', licenseNo: '110128198228889901', licenseType: 'B2', joinDate: '2020-02-11', status: '休假', remark: '陪产假', licenseExpire: '2026-09-14', bindVehicle: null, trips30d: 0, mileage30d: 0, safetyMileage: 72000, rating: 4 },
  { id: 'D029', name: '邓飞', phone: '13800138029', org: '西南运营中心', idCard: '500129198329990012', licenseNo: '500129198329990012', licenseType: 'A2', joinDate: '2019-07-23', status: '在职', remark: '大件运输', licenseExpire: '2028-02-08', bindVehicle: '渝E99999', trips30d: 25, mileage30d: 2800, safetyMileage: 98000, rating: 5 },
  { id: 'D030', name: '肖雷', phone: '13800138030', org: '华东运营中心', idCard: '310130198430001123', licenseNo: '310130198430001123', licenseType: 'C1', joinDate: '2023-04-01', status: '在职', remark: '', licenseExpire: '2029-07-17', bindVehicle: '沪G00000', trips30d: 46, mileage30d: 1400, safetyMileage: 22000, rating: 4 },
];

/* ─────────────── 工具函数 ─────────────── */
function maskIdCard(idCard: string): string {
  if (idCard.length < 10) return idCard;
  return idCard.slice(0, 6) + '****' + idCard.slice(-4);
}

function getStatusColor(status: string): string {
  switch (status) {
    case '在职': return 'bg-[#ECFDF5] text-[#10B981] border-[#10B981]';
    case '离职': return 'bg-[#FEF2F2] text-[#EF4444] border-[#EF4444]';
    case '休假': return 'bg-[#FFFBEB] text-[#F59E0B] border-[#F59E0B]';
    default: return 'bg-[#F3F4F6] text-[#6B7280] border-[#6B7280]';
  }
}

function getLicenseExpireStatus(expire: string): { label: string; cls: string } {
  const now = new Date();
  const exp = new Date(expire);
  const diffMs = exp.getTime() - now.getTime();
  const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  if (diffDays < 0) return { label: '已过期', cls: 'text-[#EF4444] font-semibold' };
  if (diffDays <= 90) return { label: `即将到期（${diffDays}天）`, cls: 'text-[#F59E0B] font-semibold' };
  return { label: `有效期至 ${expire}`, cls: 'text-[#10B981]' };
}

function calcDrivingYears(joinDate: string): number {
  const now = new Date();
  const join = new Date(joinDate);
  return now.getFullYear() - join.getFullYear();
}

/* ─────────────── 主组件 ─────────────── */
export default function DriverPage() {
  const [drivers, setDrivers] = useState<Driver[]>(driversMock);

  /* 搜索 & 筛选 */
  const [searchText, setSearchText] = useState('');
  const [filterOrg, setFilterOrg] = useState('all');
  const [filterLicense, setFilterLicense] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  /* 分页 */
  const [page, setPage] = useState(1);
  const pageSize = 10;

  /* 弹窗状态 */
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailDriver, setDetailDriver] = useState<Driver | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);

  const [formData, setFormData] = useState<DriverFormData>({
    name: '', phone: '', idCard: '', licenseNo: '', licenseType: 'C1',
    org: ORGS[0], joinDate: '', status: '在职', remark: '',
  });

  /* 筛选逻辑 */
  const filteredDrivers = useMemo(() => {
    return drivers.filter(d => {
      const matchSearch = !searchText || d.name.includes(searchText) || d.phone.includes(searchText);
      const matchOrg = filterOrg === 'all' || d.org === filterOrg;
      const matchLicense = filterLicense === 'all' || d.licenseType === filterLicense;
      const matchStatus = filterStatus === 'all' || d.status === filterStatus;
      return matchSearch && matchOrg && matchLicense && matchStatus;
    });
  }, [drivers, searchText, filterOrg, filterLicense, filterStatus]);

  const totalPages = Math.max(1, Math.ceil(filteredDrivers.length / pageSize));
  const pagedDrivers = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredDrivers.slice(start, start + pageSize);
  }, [filteredDrivers, page]);

  /* 统计数据 */
  const stats = useMemo(() => {
    const total = drivers.length;
    const active = drivers.filter(d => d.status === '在职').length;
    const avgYears = drivers.length > 0
      ? (drivers.reduce((sum, d) => sum + calcDrivingYears(d.joinDate), 0) / drivers.length).toFixed(1)
      : '0';
    const thisMonth = new Date().toISOString().slice(0, 7);
    const monthNew = drivers.filter(d => d.joinDate.startsWith(thisMonth)).length;
    return { total, active, avgYears, monthNew };
  }, [drivers]);

  /* 准驾车型分布（饼图数据） */
  const licensePieData = useMemo(() => {
    const map: Record<string, number> = {};
    drivers.forEach(d => { map[d.licenseType] = (map[d.licenseType] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [drivers]);

  /* 各组织司机分布（柱状图数据） */
  const orgBarData = useMemo(() => {
    return ORGS.map(org => ({
      name: org.replace('运营中心', ''),
      value: drivers.filter(d => d.org === org).length,
    }));
  }, [drivers]);

  /* 操作：打开详情 */
  function openDetail(driver: Driver) {
    setDetailDriver(driver);
    setDetailOpen(true);
  }

  /* 操作：打开新增 */
  function openAdd() {
    setEditingDriver(null);
    setFormData({
      name: '', phone: '', idCard: '', licenseNo: '', licenseType: 'C1',
      org: ORGS[0], joinDate: new Date().toISOString().slice(0, 10), status: '在职', remark: '',
    });
    setFormOpen(true);
  }

  /* 操作：打开编辑 */
  function openEdit(driver: Driver) {
    setEditingDriver(driver);
    setFormData({
      name: driver.name, phone: driver.phone, idCard: driver.idCard,
      licenseNo: driver.licenseNo, licenseType: driver.licenseType,
      org: driver.org, joinDate: driver.joinDate, status: driver.status, remark: driver.remark,
    });
    setFormOpen(true);
  }

  /* 操作：保存表单 */
  function saveForm() {
    if (!formData.name || !formData.phone) return;
    if (editingDriver) {
      setDrivers(prev => prev.map(d => d.id === editingDriver.id ? { ...d, ...formData } : d));
    } else {
      const newId = 'D' + String(drivers.length + 1).padStart(3, '0');
      setDrivers(prev => [...prev, {
        id: newId, ...formData,
        licenseExpire: '', bindVehicle: null, trips30d: 0, mileage30d: 0,
        safetyMileage: 0, rating: 0,
      }]);
    }
    setFormOpen(false);
  }

  /* ─────────────── KPI 卡片 ─────────────── */
  function KpiCards() {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="border-l-4 border-l-[#2563EB]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#EFF6FF] flex items-center justify-center">
              <User className="w-5 h-5 text-[#2563EB]" />
            </div>
            <div>
              <div className="text-sm text-[#6B7280]">司机总数</div>
              <div className="text-2xl font-bold text-[#111827]">{stats.total}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-[#10B981]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#ECFDF5] flex items-center justify-center">
              <Award className="w-5 h-5 text-[#10B981]" />
            </div>
            <div>
              <div className="text-sm text-[#6B7280]">在职司机</div>
              <div className="text-2xl font-bold text-[#111827]">{stats.active}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-[#F59E0B]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#FFFBEB] flex items-center justify-center">
              <Star className="w-5 h-5 text-[#F59E0B]" />
            </div>
            <div>
              <div className="text-sm text-[#6B7280]">平均驾龄</div>
              <div className="text-2xl font-bold text-[#111827]">{stats.avgYears} 年</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-[#8B5CF6]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#F5F3FF] flex items-center justify-center">
              <Plus className="w-5 h-5 text-[#8B5CF6]" />
            </div>
            <div>
              <div className="text-sm text-[#6B7280]">本月新增</div>
              <div className="text-2xl font-bold text-[#111827]">{stats.monthNew}</div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ─────────────── 图表区域 ─────────────── */
  function ChartsSection() {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold text-[#111827]">准驾车型分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={licensePieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  dataKey="value"
                  label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}
                >
                  {licensePieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold text-[#111827]">各组织司机分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={orgBarData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="value" name="司机人数" radius={[6, 6, 0, 0]}>
                  {orgBarData.map((entry, index) => (
                    <Cell key={`bar-${index}`} fill={BAR_COLORS[index % BAR_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    );
  }

  /* ─────────────── 搜索筛选栏 ─────────────── */
  function FilterBar() {
    return (
      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-[#6B7280]" />
          <Input
            placeholder="搜索姓名 / 手机号"
            value={searchText}
            onChange={e => { setSearchText(e.target.value); setPage(1); }}
            className="flex-1"
          />
        </div>
        <div className="w-40">
          <Select value={filterOrg} onValueChange={v => { setFilterOrg(v); setPage(1); }}>
            <SelectTrigger>
              <SelectValue placeholder="所属组织" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部组织</SelectItem>
              {ORGS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="w-36">
          <Select value={filterLicense} onValueChange={v => { setFilterLicense(v); setPage(1); }}>
            <SelectTrigger>
              <SelectValue placeholder="准驾车型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部车型</SelectItem>
              {LICENSE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="w-32">
          <Select value={filterStatus} onValueChange={v => { setFilterStatus(v); setPage(1); }}>
            <SelectTrigger>
              <SelectValue placeholder="状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={openAdd} className="ml-auto bg-[#2563EB] hover:bg-[#1D4ED8] text-white">
          <Plus className="w-4 h-4 mr-1" />
          新增司机
        </Button>
      </div>
    );
  }

  /* ─────────────── 司机表格 ─────────────── */
  function DriverTable() {
    return (
      <div className="rounded-lg border border-[#E5E7EB] overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-[#F9FAFB]">
              <TableHead className="text-[#6B7280] font-medium">司机编号</TableHead>
              <TableHead className="text-[#6B7280] font-medium">姓名</TableHead>
              <TableHead className="text-[#6B7280] font-medium">手机号</TableHead>
              <TableHead className="text-[#6B7280] font-medium">所属组织</TableHead>
              <TableHead className="text-[#6B7280] font-medium">身份证号</TableHead>
              <TableHead className="text-[#6B7280] font-medium">驾驶证号</TableHead>
              <TableHead className="text-[#6B7280] font-medium">准驾车型</TableHead>
              <TableHead className="text-[#6B7280] font-medium">入职日期</TableHead>
              <TableHead className="text-[#6B7280] font-medium">状态</TableHead>
              <TableHead className="text-[#6B7280] font-medium text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {pagedDrivers.map(driver => (
              <TableRow key={driver.id} className="hover:bg-[#F9FAFB]">
                <TableCell className="font-mono text-sm text-[#111827]">{driver.id}</TableCell>
                <TableCell className="text-[#111827] font-medium">{driver.name}</TableCell>
                <TableCell className="text-[#374151]">{driver.phone}</TableCell>
                <TableCell className="text-[#374151]">{driver.org}</TableCell>
                <TableCell className="font-mono text-sm text-[#374151]">{maskIdCard(driver.idCard)}</TableCell>
                <TableCell className="font-mono text-sm text-[#374151]">{maskIdCard(driver.licenseNo)}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="font-mono text-xs">
                    {driver.licenseType}
                  </Badge>
                </TableCell>
                <TableCell className="text-[#374151]">{driver.joinDate}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={getStatusColor(driver.status)}>
                    {driver.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="ghost" size="sm" className="h-8 px-2 text-[#2563EB] hover:text-[#1D4ED8] hover:bg-[#EFF6FF]" onClick={() => openDetail(driver)}>
                      <Eye className="w-4 h-4 mr-1" />
                      查看
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 px-2 text-[#F59E0B] hover:text-[#D97706] hover:bg-[#FFFBEB]" onClick={() => openEdit(driver)}>
                      <Edit className="w-4 h-4 mr-1" />
                      编辑
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
            {pagedDrivers.length === 0 && (
              <TableRow>
                <TableCell colSpan={10} className="text-center py-12 text-[#9CA3AF]">
                  暂无符合条件的司机数据
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    );
  }

  /* ─────────────── 分页 ─────────────── */
  function Pagination() {
    return (
      <div className="flex items-center justify-between mt-4">
        <div className="text-sm text-[#6B7280]">
          共 <span className="font-medium text-[#111827]">{filteredDrivers.length}</span> 条记录，第 <span className="font-medium text-[#111827]">{page}</span> / {totalPages} 页
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setPage(1)} disabled={page === 1}>
            首页
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>
            上一页
          </Button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
            <Button
              key={p}
              variant={p === page ? 'default' : 'outline'}
              size="sm"
              className={p === page ? 'bg-[#2563EB] text-white hover:bg-[#1D4ED8]' : ''}
              onClick={() => setPage(p)}
            >
              {p}
            </Button>
          ))}
          <Button variant="outline" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>
            下一页
          </Button>
          <Button variant="outline" size="sm" onClick={() => setPage(totalPages)} disabled={page === totalPages}>
            末页
          </Button>
        </div>
      </div>
    );
  }

  /* ─────────────── 司机详情弹窗 ─────────────── */
  function DetailDialog() {
    if (!detailDriver) return null;
    const d = detailDriver;
    const expireStatus = getLicenseExpireStatus(d.licenseExpire);

    return (
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg text-[#111827]">
              <User className="w-5 h-5 text-[#2563EB]" />
              司机详情 — {d.name}
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="basic" className="mt-2">
            <TabsList className="grid w-full grid-cols-3 bg-[#F3F4F6]">
              <TabsTrigger value="basic" className="data-[state=active]:bg-white data-[state=active]:text-[#2563EB]">基本信息</TabsTrigger>
              <TabsTrigger value="vehicle" className="data-[state=active]:bg-white data-[state=active]:text-[#2563EB]">绑定车辆</TabsTrigger>
              <TabsTrigger value="transport" className="data-[state=active]:bg-white data-[state=active]:text-[#2563EB]">运输记录</TabsTrigger>
            </TabsList>

            {/* 基本信息 */}
            <TabsContent value="basic" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                <Card className="col-span-2">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-14 h-14 rounded-full bg-[#EFF6FF] flex items-center justify-center">
                        <User className="w-7 h-7 text-[#2563EB]" />
                      </div>
                      <div>
                        <div className="text-xl font-bold text-[#111827]">{d.name}</div>
                        <div className="text-sm text-[#6B7280]">{d.id}</div>
                      </div>
                      <Badge variant="outline" className={getStatusColor(d.status) + ' ml-auto'}>
                        {d.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-y-3 gap-x-6 text-sm">
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">手机号：</span>
                        <span className="text-[#111827]">{d.phone}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">所属组织：</span>
                        <span className="text-[#111827]">{d.org}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">身份证号：</span>
                        <span className="text-[#111827] font-mono">{maskIdCard(d.idCard)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">驾驶证号：</span>
                        <span className="text-[#111827] font-mono">{maskIdCard(d.licenseNo)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Truck className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">准驾车型：</span>
                        <span className="text-[#111827] font-mono">{d.licenseType}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">入职日期：</span>
                        <span className="text-[#111827]">{d.joinDate}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Star className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">安全里程：</span>
                        <span className="text-[#111827]">{(d.safetyMileage / 10000).toFixed(1)} 万公里</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Award className="w-4 h-4 text-[#6B7280]" />
                        <span className="text-[#6B7280]">评分：</span>
                        <span className="text-[#111827]">{d.rating > 0 ? d.rating + ' 星' : '暂无'}</span>
                      </div>
                    </div>
                    {d.remark && (
                      <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-sm text-[#374151]">
                        <span className="text-[#6B7280]">备注：</span>{d.remark}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* 资质证书 */}
                <Card className="col-span-2">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-semibold text-[#111827] flex items-center gap-2">
                      <Award className="w-4 h-4 text-[#8B5CF6]" />
                      资质证书
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="flex items-center justify-between py-2 border-b border-[#E5E7EB]">
                      <span className="text-sm text-[#6B7280]">驾驶证有效期</span>
                      <span className={`text-sm ${expireStatus.cls}`}>{expireStatus.label}</span>
                    </div>
                    <div className="flex items-center justify-between py-2 border-b border-[#E5E7EB]">
                      <span className="text-sm text-[#6B7280]">准驾车型</span>
                      <span className="text-sm text-[#111827] font-mono">{d.licenseType}</span>
                    </div>
                    <div className="flex items-center justify-between py-2">
                      <span className="text-sm text-[#6B7280]">驾龄</span>
                      <span className="text-sm text-[#111827]">{calcDrivingYears(d.joinDate)} 年</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* 绑定车辆 */}
            <TabsContent value="vehicle" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  {d.bindVehicle ? (
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
                        <Truck className="w-6 h-6 text-[#2563EB]" />
                      </div>
                      <div>
                        <div className="text-base font-semibold text-[#111827]">当前绑定车辆</div>
                        <div className="text-sm text-[#6B7280]">车牌号：<span className="font-mono text-[#111827]">{d.bindVehicle}</span></div>
                      </div>
                      <Badge variant="outline" className="ml-auto bg-[#ECFDF5] text-[#10B981] border-[#10B981]">
                        运行中
                      </Badge>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-[#9CA3AF]">
                      <Truck className="w-10 h-10 mx-auto mb-2 opacity-40" />
                      <div>当前未绑定车辆</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* 运输记录 */}
            <TabsContent value="transport" className="mt-4">
              <Card>
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-[#F9FAFB] text-center">
                      <div className="text-3xl font-bold text-[#2563EB]">{d.trips30d}</div>
                      <div className="text-sm text-[#6B7280] mt-1">近30天运输次数</div>
                    </div>
                    <div className="p-4 rounded-lg bg-[#F9FAFB] text-center">
                      <div className="text-3xl font-bold text-[#10B981]">{(d.mileage30d / 1000).toFixed(1)}</div>
                      <div className="text-sm text-[#6B7280] mt-1">近30天运输里程（千公里）</div>
                    </div>
                  </div>
                  {d.trips30d === 0 && (
                    <div className="text-center py-6 text-[#9CA3AF] mt-4">
                      <Calendar className="w-8 h-8 mx-auto mb-2 opacity-40" />
                      <div className="text-sm">近30天内暂无运输记录</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailOpen(false)}>关闭</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  /* ─────────────── 新增/编辑弹窗 ─────────────── */
  function FormDialog() {
    const isEdit = !!editingDriver;

    return (
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg text-[#111827]">
              {isEdit ? <Edit className="w-5 h-5 text-[#F59E0B]" /> : <Plus className="w-5 h-5 text-[#2563EB]" />}
              {isEdit ? '编辑司机' : '新增司机'}
            </DialogTitle>
          </DialogHeader>

          <div className="grid grid-cols-2 gap-4 mt-2">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-[#374151] mb-1">姓名 <span className="text-[#EF4444]">*</span></label>
              <Input
                value={formData.name}
                onChange={e => setFormData(f => ({ ...f, name: e.target.value }))}
                placeholder="请输入司机姓名"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-[#374151] mb-1">手机号 <span className="text-[#EF4444]">*</span></label>
              <Input
                value={formData.phone}
                onChange={e => setFormData(f => ({ ...f, phone: e.target.value }))}
                placeholder="请输入手机号"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-[#374151] mb-1">身份证号</label>
              <Input
                value={formData.idCard}
                onChange={e => setFormData(f => ({ ...f, idCard: e.target.value }))}
                placeholder="请输入身份证号"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-[#374151] mb-1">驾驶证号</label>
              <Input
                value={formData.licenseNo}
                onChange={e => setFormData(f => ({ ...f, licenseNo: e.target.value }))}
                placeholder="请输入驾驶证号"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#374151] mb-1">准驾车型</label>
              <Select value={formData.licenseType} onValueChange={v => setFormData(f => ({ ...f, licenseType: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="选择准驾车型" />
                </SelectTrigger>
                <SelectContent>
                  {LICENSE_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#374151] mb-1">所属组织</label>
              <Select value={formData.org} onValueChange={v => setFormData(f => ({ ...f, org: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="选择组织" />
                </SelectTrigger>
                <SelectContent>
                  {ORGS.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#374151] mb-1">入职日期</label>
              <Input
                type="date"
                value={formData.joinDate}
                onChange={e => setFormData(f => ({ ...f, joinDate: e.target.value }))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[#374151] mb-1">状态</label>
              <Select value={formData.status} onValueChange={v => setFormData(f => ({ ...f, status: v }))}>
                <SelectTrigger>
                  <SelectValue placeholder="选择状态" />
                </SelectTrigger>
                <SelectContent>
                  {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <label className="block text-sm font-medium text-[#374151] mb-1">备注</label>
              <textarea
                value={formData.remark}
                onChange={e => setFormData(f => ({ ...f, remark: e.target.value }))}
                placeholder="请输入备注信息"
                className="w-full rounded-md border border-[#E5E7EB] px-3 py-2 text-sm text-[#111827] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#2563EB] focus:border-transparent min-h-[80px] resize-none"
              />
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setFormOpen(false)}>取消</Button>
            <Button onClick={saveForm} className="bg-[#2563EB] hover:bg-[#1D4ED8] text-white">
              {isEdit ? '保存修改' : '确认新增'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  /* ─────────────── 页面主体 ─────────────── */
  return (
    <div className="p-6 min-h-screen bg-[#F3F4F6]">
      {/* 页面标题 */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-9 h-9 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
          <User className="w-5 h-5 text-[#2563EB]" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-[#111827]">司机管理</h1>
          <p className="text-sm text-[#6B7280]">管理司机档案、查看运输记录与资质信息</p>
        </div>
      </div>

      {/* KPI 卡片 */}
      <KpiCards />

      {/* 图表 */}
      <ChartsSection />

      {/* 列表卡片 */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold text-[#111827]">司机档案列表</CardTitle>
        </CardHeader>
        <CardContent>
          <FilterBar />
          <DriverTable />
          <Pagination />
        </CardContent>
      </Card>

      {/* 弹窗 */}
      <DetailDialog />
      <FormDialog />
    </div>
  );
}
