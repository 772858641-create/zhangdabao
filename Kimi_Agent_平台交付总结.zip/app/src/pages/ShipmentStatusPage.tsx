import { useState, useMemo, type ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerFooter,
  DrawerClose,
} from '@/components/ui/drawer';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Truck,
  Package,
  CheckCircle,
  AlertCircle,
  Clock,
  Search,
  Plus,
  Eye,
  ClipboardList,
  MapPin,
  Phone,
  User,
  X,
  Filter,
  CalendarDays,
  Box,
} from 'lucide-react';

/* ─── Types ─── */
interface ShipmentCargo {
  containerId: string;
  type: string;
  quantity: number;
  unit: string;
}

interface TrackingEvent {
  time: string;
  location: string;
  status: string;
  description: string;
}

interface SignInfo {
  signer: string;
  signTime: string;
  signMethod: string;
  photoUrl?: string;
}

interface Shipment {
  id: string;
  orderNo: string;
  receiver: string;
  receiverAddress: string;
  receiverContact: string;
  logisticsCompany: string;
  driverName: string;
  driverPhone: string;
  vehicleNo: string;
  shipTime: string;
  estimatedArrival: string;
  actualArrival?: string;
  status: '待发运' | '运输中' | '已签收' | '异常';
  cargoList: ShipmentCargo[];
  trackingList: TrackingEvent[];
  signInfo?: SignInfo;
  remark?: string;
}

/* ─── Mock Data ─── */
const shipmentsMock: Shipment[] = [
  {
    id: 'S001',
    orderNo: 'FY-20240601-001',
    receiver: '华东仓（上海）',
    receiverAddress: '上海市浦东新区张江高科技园区科苑路88号',
    receiverContact: '张经理 13800138001',
    logisticsCompany: '顺丰速运',
    driverName: '王师傅',
    driverPhone: '13800138011',
    vehicleNo: '沪A12345',
    shipTime: '2024-06-01 08:30',
    estimatedArrival: '2024-06-02 14:00',
    status: '已签收',
    cargoList: [
      { containerId: 'CT-1001', type: '标准托盘', quantity: 20, unit: '个' },
      { containerId: 'CT-1002', type: '折叠周转箱', quantity: 50, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-01 08:30', location: '上海浦东发货点', status: '已发货', description: '货物已装车，准备发出' },
      { time: '2024-06-01 14:20', location: '苏州转运中心', status: '运输中', description: '货物到达转运中心' },
      { time: '2024-06-02 09:00', location: '华东仓', status: '派送中', description: '货物正在派送' },
      { time: '2024-06-02 13:30', location: '华东仓', status: '已签收', description: '货物已签收' },
    ],
    signInfo: { signer: '张经理', signTime: '2024-06-02 13:30', signMethod: '电子签收' },
  },
  {
    id: 'S002',
    orderNo: 'FY-20240602-002',
    receiver: '华南仓（广州）',
    receiverAddress: '广州市白云区物流大道168号',
    receiverContact: '李主管 13800138002',
    logisticsCompany: '德邦物流',
    driverName: '刘师傅',
    driverPhone: '13800138012',
    vehicleNo: '粤A67890',
    shipTime: '2024-06-02 10:00',
    estimatedArrival: '2024-06-04 16:00',
    status: '运输中',
    cargoList: [
      { containerId: 'CT-2001', type: '金属周转箱', quantity: 30, unit: '个' },
      { containerId: 'CT-2002', type: '标准托盘', quantity: 15, unit: '个' },
      { containerId: 'CT-2003', type: '塑料卡板箱', quantity: 25, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-02 10:00', location: '广州白云发货点', status: '已发货', description: '货物已装车' },
      { time: '2024-06-03 06:30', location: '韶关中转站', status: '运输中', description: '货物中转中' },
      { time: '2024-06-03 20:00', location: '长沙转运中心', status: '运输中', description: '货物已发往下一站' },
    ],
  },
  {
    id: 'S003',
    orderNo: 'FY-20240603-003',
    receiver: '华北仓（北京）',
    receiverAddress: '北京市通州区物流园区兴贸三街18号',
    receiverContact: '赵经理 13800138003',
    logisticsCompany: '中通快运',
    driverName: '孙师傅',
    driverPhone: '13800138013',
    vehicleNo: '京B11111',
    shipTime: '',
    estimatedArrival: '2024-06-05 12:00',
    status: '待发运',
    cargoList: [
      { containerId: 'CT-3001', type: '折叠周转箱', quantity: 40, unit: '个' },
      { containerId: 'CT-3002', type: '金属周转箱', quantity: 20, unit: '个' },
    ],
    trackingList: [],
  },
  {
    id: 'S004',
    orderNo: 'FY-20240603-004',
    receiver: '西南仓（成都）',
    receiverAddress: '成都市双流区西航港大道中四段999号',
    receiverContact: '陈主管 13800138004',
    logisticsCompany: '韵达快运',
    driverName: '周师傅',
    driverPhone: '13800138014',
    vehicleNo: '川A22222',
    shipTime: '2024-06-03 09:00',
    estimatedArrival: '2024-06-05 18:00',
    status: '运输中',
    cargoList: [
      { containerId: 'CT-4001', type: '标准托盘', quantity: 35, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-03 09:00', location: '成都双流发货点', status: '已发货', description: '货物已揽收' },
      { time: '2024-06-03 22:00', location: '重庆转运中心', status: '运输中', description: '货物中转中' },
    ],
  },
  {
    id: 'S005',
    orderNo: 'FY-20240604-005',
    receiver: '华东仓（南京）',
    receiverAddress: '南京市江宁区空港经济开发区苍穹路66号',
    receiverContact: '吴经理 13800138005',
    logisticsCompany: '顺丰速运',
    driverName: '赵师傅',
    driverPhone: '13800138015',
    vehicleNo: '苏A33333',
    shipTime: '2024-06-04 07:30',
    estimatedArrival: '2024-06-04 20:00',
    status: '异常',
    cargoList: [
      { containerId: 'CT-5001', type: '塑料卡板箱', quantity: 60, unit: '个' },
      { containerId: 'CT-5002', type: '折叠周转箱', quantity: 30, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-04 07:30', location: '南京江宁发货点', status: '已发货', description: '货物已装车' },
      { time: '2024-06-04 12:00', location: '镇江服务区', status: '异常', description: '车辆故障，预计延误6小时' },
    ],
    remark: '车辆在高速服务区发生故障，已安排备用车辆转运',
  },
  {
    id: 'S006',
    orderNo: 'FY-20240604-006',
    receiver: '华中仓（武汉）',
    receiverAddress: '武汉市东西湖区物流大道77号',
    receiverContact: '郑主管 13800138006',
    logisticsCompany: '德邦物流',
    driverName: '钱师傅',
    driverPhone: '13800138016',
    vehicleNo: '鄂A44444',
    shipTime: '2024-06-04 14:00',
    estimatedArrival: '2024-06-06 10:00',
    actualArrival: '2024-06-06 09:30',
    status: '已签收',
    cargoList: [
      { containerId: 'CT-6001', type: '标准托盘', quantity: 25, unit: '个' },
      { containerId: 'CT-6002', type: '金属周转箱', quantity: 18, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-04 14:00', location: '武汉东西湖发货点', status: '已发货', description: '货物已发出' },
      { time: '2024-06-05 08:00', location: '郑州转运中心', status: '运输中', description: '货物中转' },
      { time: '2024-06-06 06:30', location: '华中仓', status: '派送中', description: '货物派送中' },
      { time: '2024-06-06 09:30', location: '华中仓', status: '已签收', description: '货物已签收' },
    ],
    signInfo: { signer: '郑主管', signTime: '2024-06-06 09:30', signMethod: '纸质签收' },
  },
  {
    id: 'S007',
    orderNo: 'FY-20240605-007',
    receiver: '华南仓（深圳）',
    receiverAddress: '深圳市宝安区福永街道怀德南路88号',
    receiverContact: '何经理 13800138007',
    logisticsCompany: '中通快运',
    driverName: '李师傅',
    driverPhone: '13800138017',
    vehicleNo: '粤B55555',
    shipTime: '',
    estimatedArrival: '2024-06-07 14:00',
    status: '待发运',
    cargoList: [
      { containerId: 'CT-7001', type: '折叠周转箱', quantity: 45, unit: '个' },
      { containerId: 'CT-7002', type: '塑料卡板箱', quantity: 22, unit: '个' },
      { containerId: 'CT-7003', type: '标准托盘', quantity: 10, unit: '个' },
    ],
    trackingList: [],
  },
  {
    id: 'S008',
    orderNo: 'FY-20240605-008',
    receiver: '东北仓（沈阳）',
    receiverAddress: '沈阳市沈北新区蒲河路199号',
    receiverContact: '林主管 13800138008',
    logisticsCompany: '韵达快运',
    driverName: '吴师傅',
    driverPhone: '13800138018',
    vehicleNo: '辽A66666',
    shipTime: '2024-06-05 11:00',
    estimatedArrival: '2024-06-07 16:00',
    status: '运输中',
    cargoList: [
      { containerId: 'CT-8001', type: '金属周转箱', quantity: 28, unit: '个' },
      { containerId: 'CT-8002', type: '标准托盘', quantity: 12, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-05 11:00', location: '沈阳沈北发货点', status: '已发货', description: '货物已装车' },
      { time: '2024-06-05 22:00', location: '铁岭中转站', status: '运输中', description: '货物中转' },
      { time: '2024-06-06 14:00', location: '长春转运中心', status: '运输中', description: '已发往下一站点' },
    ],
  },
  {
    id: 'S009',
    orderNo: 'FY-20240605-009',
    receiver: '华东仓（杭州）',
    receiverAddress: '杭州市萧山区靖江街道保税路66号',
    receiverContact: '黄经理 13800138009',
    logisticsCompany: '顺丰速运',
    driverName: '郑师傅',
    driverPhone: '13800138019',
    vehicleNo: '浙A77777',
    shipTime: '2024-06-05 16:00',
    estimatedArrival: '2024-06-06 12:00',
    status: '已签收',
    cargoList: [
      { containerId: 'CT-9001', type: '塑料卡板箱', quantity: 35, unit: '个' },
    ],
    trackingList: [
      { time: '2024-06-05 16:00', location: '杭州萧山发货点', status: '已发货', description: '货物已揽收装车' },
      { time: '2024-06-05 20:30', location: '绍兴中转站', status: '运输中', description: '货物中转' },
      { time: '2024-06-06 08:00', location: '华东仓（杭州）', status: '派送中', description: '货物派送中' },
      { time: '2024-06-06 11:30', location: '华东仓（杭州）', status: '已签收', description: '货物已签收，签收人：黄经理' },
    ],
    signInfo: { signer: '黄经理', signTime: '2024-06-06 11:30', signMethod: '电子签收' },
  },
  {
    id: 'S010',
    orderNo: 'FY-20240606-010',
    receiver: '西北仓（西安）',
    receiverAddress: '西安市未央区草滩八路666号',
    receiverContact: '杨主管 13800138010',
    logisticsCompany: '德邦物流',
    driverName: '冯师傅',
    driverPhone: '13800138020',
    vehicleNo: '陕A88888',
    shipTime: '',
    estimatedArrival: '2024-06-08 18:00',
    status: '待发运',
    cargoList: [
      { containerId: 'CT-10001', type: '标准托盘', quantity: 30, unit: '个' },
      { containerId: 'CT-10002', type: '折叠周转箱', quantity: 55, unit: '个' },
      { containerId: 'CT-10003', type: '金属周转箱', quantity: 15, unit: '个' },
    ],
    trackingList: [],
  },
];

/* ─── Helpers ─── */
const statusConfig: Record<string, { color: string; bg: string; icon: ReactNode }> = {
  '待发运': { color: 'text-amber-700', bg: 'bg-amber-50', icon: <Clock className="w-3.5 h-3.5" /> },
  '运输中': { color: 'text-blue-700', bg: 'bg-blue-50', icon: <Truck className="w-3.5 h-3.5" /> },
  '已签收': { color: 'text-emerald-700', bg: 'bg-emerald-50', icon: <CheckCircle className="w-3.5 h-3.5" /> },
  '异常': { color: 'text-red-700', bg: 'bg-red-50', icon: <AlertCircle className="w-3.5 h-3.5" /> },
};

function StatusBadge({ status }: { status: Shipment['status'] }) {
  const cfg = statusConfig[status];
  return (
    <Badge variant="outline" className={`${cfg.bg} ${cfg.color} border-transparent flex items-center gap-1 font-medium`}>
      {cfg.icon}
      {status}
    </Badge>
  );
}

/* ─── Main Component ─── */
export default function ShipmentStatusPage() {
  const [activeTab, setActiveTab] = useState('all');
  const [searchOrderNo, setSearchOrderNo] = useState('');
  const [searchReceiver, setSearchReceiver] = useState('');
  const [searchLogistics, setSearchLogistics] = useState('all');
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailShipment, setDetailShipment] = useState<Shipment | null>(null);
  const [createOpen, setCreateOpen] = useState(false);

  /* Derived stats */
  const stats = useMemo(() => {
    const pending = shipmentsMock.filter((s) => s.status === '待发运').length;
    const transit = shipmentsMock.filter((s) => s.status === '运输中').length;
    const signed = shipmentsMock.filter((s) => s.status === '已签收').length;
    const abnormal = shipmentsMock.filter((s) => s.status === '异常').length;
    return { pending, transit, signed, abnormal, total: shipmentsMock.length };
  }, []);

  /* Filtered data */
  const filteredData = useMemo(() => {
    let data = [...shipmentsMock];
    if (activeTab !== 'all') {
      const tabMap: Record<string, string> = { pending: '待发运', transit: '运输中', signed: '已签收', abnormal: '异常' };
      data = data.filter((s) => s.status === tabMap[activeTab]);
    }
    if (searchOrderNo.trim()) {
      data = data.filter((s) => s.orderNo.toLowerCase().includes(searchOrderNo.trim().toLowerCase()));
    }
    if (searchReceiver.trim()) {
      data = data.filter((s) => s.receiver.toLowerCase().includes(searchReceiver.trim().toLowerCase()));
    }
    if (searchLogistics !== 'all') {
      data = data.filter((s) => s.logisticsCompany === searchLogistics);
    }
    return data;
  }, [activeTab, searchOrderNo, searchReceiver, searchLogistics]);

  /* Handlers */
  const openDetail = (s: Shipment) => {
    setDetailShipment(s);
    setDetailOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* ─── Page Header ─── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">发运状态管理</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">载具发运单全生命周期跟踪与状态管理</p>
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          新建发运单
        </Button>
      </div>

      {/* ─── Stat Cards ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-[var(--neutral-border)]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center">
              <Clock className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">待发运</div>
              <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{stats.pending}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[var(--neutral-border)]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
              <Truck className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">运输中</div>
              <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{stats.transit}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[var(--neutral-border)]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">已签收</div>
              <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{stats.signed}</div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[var(--neutral-border)]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-50 flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">异常</div>
              <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{stats.abnormal}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ─── Filter & Search ─── */}
      <Card className="border-[var(--neutral-border)]">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-[var(--neutral-text-tertiary)]" />
              <span className="text-sm font-medium text-[var(--neutral-text-secondary)]">筛选：</span>
            </div>
            <div className="w-52">
              <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">发运单号</label>
              <Input
                placeholder="输入发运单号"
                value={searchOrderNo}
                onChange={(e) => setSearchOrderNo(e.target.value)}
                className="h-9"
              />
            </div>
            <div className="w-52">
              <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">收货方</label>
              <Input
                placeholder="输入收货方名称"
                value={searchReceiver}
                onChange={(e) => setSearchReceiver(e.target.value)}
                className="h-9"
              />
            </div>
            <div className="w-44">
              <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">物流公司</label>
              <Select value={searchLogistics} onValueChange={setSearchLogistics}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="顺丰速运">顺丰速运</SelectItem>
                  <SelectItem value="德邦物流">德邦物流</SelectItem>
                  <SelectItem value="中通快运">中通快运</SelectItem>
                  <SelectItem value="韵达快运">韵达快运</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="w-44">
              <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">状态</label>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="h-9">
                  <TabsTrigger value="all" className="text-xs px-2.5">全部</TabsTrigger>
                  <TabsTrigger value="pending" className="text-xs px-2.5">待发运</TabsTrigger>
                  <TabsTrigger value="transit" className="text-xs px-2.5">运输中</TabsTrigger>
                  <TabsTrigger value="signed" className="text-xs px-2.5">已签收</TabsTrigger>
                  <TabsTrigger value="abnormal" className="text-xs px-2.5">异常</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ─── Shipment Table ─── */}
      <Card className="border-[var(--neutral-border)]">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-[var(--neutral-background)]">
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium w-[160px]">发运单号</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">收货方</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">物流公司</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">司机 / 车辆</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">发运时间</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">预计到达</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium">状态</TableHead>
                  <TableHead className="text-[var(--neutral-text-secondary)] text-xs font-medium text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-12 text-[var(--neutral-text-secondary)]">
                      <Filter className="w-10 h-10 mx-auto mb-3 text-[var(--neutral-text-tertiary)]" />
                      暂无符合条件的发运记录
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((s) => (
                    <TableRow key={s.id} className="hover:bg-[var(--neutral-background)] transition-colors">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)] text-sm">
                        <div className="flex items-center gap-1.5">
                          <ClipboardList className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)]" />
                          {s.orderNo}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-[var(--neutral-text-primary)]">{s.receiver}</TableCell>
                      <TableCell className="text-sm text-[var(--neutral-text-secondary)]">{s.logisticsCompany}</TableCell>
                      <TableCell className="text-sm">
                        <div className="text-[var(--neutral-text-primary)]">{s.driverName}</div>
                        <div className="text-xs text-[var(--neutral-text-tertiary)]">{s.vehicleNo}</div>
                      </TableCell>
                      <TableCell className="text-sm text-[var(--neutral-text-secondary)]">
                        {s.shipTime || <span className="text-[var(--neutral-text-tertiary)]">--</span>}
                      </TableCell>
                      <TableCell className="text-sm text-[var(--neutral-text-secondary)]">{s.estimatedArrival}</TableCell>
                      <TableCell>
                        <StatusBadge status={s.status} />
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 text-[var(--neutral-text-secondary)] hover:text-[var(--neutral-text-primary)]"
                          onClick={() => openDetail(s)}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ─── Detail Drawer ─── */}
      {detailShipment && (
        <Drawer open={detailOpen} onOpenChange={setDetailOpen} direction="right">
          <DrawerContent className="w-full sm:max-w-lg overflow-y-auto bg-[var(--neutral-surface)] border-l border-[var(--neutral-border)]">
            <DrawerHeader className="border-b border-[var(--neutral-border)] pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <DrawerTitle className="text-lg text-[var(--neutral-text-primary)]">
                    发运单详情
                  </DrawerTitle>
                  <StatusBadge status={detailShipment.status} />
                </div>
                <DrawerClose asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <X className="w-4 h-4 text-[var(--neutral-text-secondary)]" />
                  </Button>
                </DrawerClose>
              </div>
              <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">{detailShipment.orderNo}</p>
            </DrawerHeader>

            <div className="p-4 space-y-5">
              {/* Basic Info */}
              <section>
                <h3 className="text-sm font-semibold text-[var(--neutral-text-primary)] mb-3 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-[var(--neutral-text-secondary)]" />
                  发运基本信息
                </h3>
                <div className="rounded-lg border border-[var(--neutral-border)] bg-[var(--neutral-background)] p-3 space-y-2.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">收货方</span>
                    <span className="text-[var(--neutral-text-primary)] font-medium">{detailShipment.receiver}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">收货地址</span>
                    <span className="text-[var(--neutral-text-primary)] text-right max-w-[260px]">{detailShipment.receiverAddress}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">收货联系人</span>
                    <span className="text-[var(--neutral-text-primary)]">{detailShipment.receiverContact}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">物流公司</span>
                    <span className="text-[var(--neutral-text-primary)] font-medium">{detailShipment.logisticsCompany}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">司机</span>
                    <span className="text-[var(--neutral-text-primary)] flex items-center gap-1">
                      <User className="w-3 h-3 text-[var(--neutral-text-tertiary)]" />
                      {detailShipment.driverName}
                      <Phone className="w-3 h-3 text-[var(--neutral-text-tertiary)] ml-1" />
                      {detailShipment.driverPhone}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">车辆</span>
                    <span className="text-[var(--neutral-text-primary)] flex items-center gap-1">
                      <Truck className="w-3 h-3 text-[var(--neutral-text-tertiary)]" />
                      {detailShipment.vehicleNo}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">发运时间</span>
                    <span className="text-[var(--neutral-text-primary)]">
                      {detailShipment.shipTime || <span className="text-[var(--neutral-text-tertiary)]">未发运</span>}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--neutral-text-secondary)]">预计到达</span>
                    <span className="text-[var(--neutral-text-primary)]">{detailShipment.estimatedArrival}</span>
                  </div>
                  {detailShipment.actualArrival && (
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--neutral-text-secondary)]">实际到达</span>
                      <span className="text-emerald-600 font-medium">{detailShipment.actualArrival}</span>
                    </div>
                  )}
                  {detailShipment.remark && (
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--neutral-text-secondary)]">备注</span>
                      <span className="text-red-500 max-w-[260px] text-right">{detailShipment.remark}</span>
                    </div>
                  )}
                </div>
              </section>

              {/* Cargo List */}
              <section>
                <h3 className="text-sm font-semibold text-[var(--neutral-text-primary)] mb-3 flex items-center gap-1.5">
                  <Box className="w-4 h-4 text-[var(--neutral-text-secondary)]" />
                  货物明细
                </h3>
                <div className="rounded-lg border border-[var(--neutral-border)] overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[var(--neutral-background)]">
                        <TableHead className="text-xs text-[var(--neutral-text-secondary)] h-8">载具编号</TableHead>
                        <TableHead className="text-xs text-[var(--neutral-text-secondary)] h-8">类型</TableHead>
                        <TableHead className="text-xs text-[var(--neutral-text-secondary)] h-8 text-right">数量</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {detailShipment.cargoList.map((cargo, idx) => (
                        <TableRow key={idx} className="border-b border-[var(--neutral-border)] last:border-0">
                          <TableCell className="text-sm text-[var(--neutral-text-primary)] h-8 py-1.5">{cargo.containerId}</TableCell>
                          <TableCell className="text-sm text-[var(--neutral-text-secondary)] h-8 py-1.5">{cargo.type}</TableCell>
                          <TableCell className="text-sm text-[var(--neutral-text-primary)] h-8 py-1.5 text-right font-medium">
                            {cargo.quantity} {cargo.unit}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </section>

              {/* Tracking Timeline */}
              <section>
                <h3 className="text-sm font-semibold text-[var(--neutral-text-primary)] mb-3 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[var(--neutral-text-secondary)]" />
                  物流轨迹
                </h3>
                {detailShipment.trackingList.length === 0 ? (
                  <div className="rounded-lg border border-[var(--neutral-border)] bg-[var(--neutral-background)] p-6 text-center text-sm text-[var(--neutral-text-secondary)]">
                    暂无物流轨迹信息
                  </div>
                ) : (
                  <div className="rounded-lg border border-[var(--neutral-border)] bg-[var(--neutral-background)] p-4">
                    <div className="space-y-0">
                      {detailShipment.trackingList.map((track, idx) => {
                        const isLast = idx === detailShipment.trackingList.length - 1;
                        return (
                          <div key={idx} className="flex gap-3">
                            <div className="flex flex-col items-center">
                              <div className={`w-2.5 h-2.5 rounded-full ${
                                isLast
                                  ? track.status === '异常'
                                    ? 'bg-red-400'
                                    : 'bg-blue-400'
                                  : 'bg-[var(--neutral-border-strong)]'
                              }`} />
                              {!isLast && <div className="w-px h-full bg-[var(--neutral-border)] my-1" />}
                            </div>
                            <div className="pb-5 -mt-0.5">
                              <div className="text-xs text-[var(--neutral-text-tertiary)]">{track.time}</div>
                              <div className="text-sm text-[var(--neutral-text-primary)] font-medium mt-0.5">{track.location}</div>
                              <div className="text-xs text-[var(--neutral-text-secondary)] mt-0.5">{track.description}</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </section>

              {/* Sign Info */}
              {detailShipment.signInfo && (
                <section>
                  <h3 className="text-sm font-semibold text-[var(--neutral-text-primary)] mb-3 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    签收信息
                  </h3>
                  <div className="rounded-lg border border-[var(--neutral-border)] bg-[var(--neutral-background)] p-3 space-y-2.5">
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--neutral-text-secondary)]">签收人</span>
                      <span className="text-[var(--neutral-text-primary)] font-medium">{detailShipment.signInfo.signer}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--neutral-text-secondary)]">签收时间</span>
                      <span className="text-[var(--neutral-text-primary)]">{detailShipment.signInfo.signTime}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[var(--neutral-text-secondary)]">签收方式</span>
                      <span className="text-[var(--neutral-text-primary)]">{detailShipment.signInfo.signMethod}</span>
                    </div>
                    {/* Photo placeholder */}
                    <div className="mt-2">
                      <span className="text-xs text-[var(--neutral-text-secondary)] block mb-1.5">签收照片</span>
                      <div className="grid grid-cols-3 gap-2">
                        {[1, 2, 3].map((i) => (
                          <div
                            key={i}
                            className="aspect-square rounded-md bg-[var(--neutral-surface-elevated)] border border-[var(--neutral-border)] flex flex-col items-center justify-center text-[var(--neutral-text-tertiary)]"
                          >
                            <Package className="w-6 h-6 mb-1" />
                            <span className="text-xs">照片{i}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>
              )}
            </div>

            <DrawerFooter className="border-t border-[var(--neutral-border)]">
              <DrawerClose asChild>
                <Button variant="outline" className="w-full">关闭</Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      )}

      {/* ─── Create Shipment Dialog ─── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg text-[var(--neutral-text-primary)] flex items-center gap-2">
              <Plus className="w-5 h-5 text-[var(--neutral-text-secondary)]" />
              新建发运单
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Receiver Info */}
            <section className="space-y-3">
              <h4 className="text-sm font-semibold text-[var(--neutral-text-primary)] border-b border-[var(--neutral-border)] pb-1 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-blue-500" />
                收货信息
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">收货方 <span className="text-red-400">*</span></label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="选择收货方" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="华东仓（上海）">华东仓（上海）</SelectItem>
                      <SelectItem value="华东仓（南京）">华东仓（南京）</SelectItem>
                      <SelectItem value="华东仓（杭州）">华东仓（杭州）</SelectItem>
                      <SelectItem value="华南仓（广州）">华南仓（广州）</SelectItem>
                      <SelectItem value="华南仓（深圳）">华南仓（深圳）</SelectItem>
                      <SelectItem value="华北仓（北京）">华北仓（北京）</SelectItem>
                      <SelectItem value="华中仓（武汉）">华中仓（武汉）</SelectItem>
                      <SelectItem value="西南仓（成都）">西南仓（成都）</SelectItem>
                      <SelectItem value="东北仓（沈阳）">东北仓（沈阳）</SelectItem>
                      <SelectItem value="西北仓（西安）">西北仓（西安）</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">收货联系人 <span className="text-red-400">*</span></label>
                  <Input placeholder="姓名 + 手机号" />
                </div>
              </div>
              <div>
                <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">收货地址 <span className="text-red-400">*</span></label>
                <Input placeholder="详细收货地址" />
              </div>
            </section>

            {/* Logistics Info */}
            <section className="space-y-3">
              <h4 className="text-sm font-semibold text-[var(--neutral-text-primary)] border-b border-[var(--neutral-border)] pb-1 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-blue-500" />
                物流信息
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">物流公司 <span className="text-red-400">*</span></label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="选择物流公司" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="顺丰速运">顺丰速运</SelectItem>
                      <SelectItem value="德邦物流">德邦物流</SelectItem>
                      <SelectItem value="中通快运">中通快运</SelectItem>
                      <SelectItem value="韵达快运">韵达快运</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">车辆 <span className="text-red-400">*</span></label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="选择车辆" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="沪A12345">沪A12345（王师傅）</SelectItem>
                      <SelectItem value="沪B67890">沪B67890（李师傅）</SelectItem>
                      <SelectItem value="粤A67890">粤A67890（刘师傅）</SelectItem>
                      <SelectItem value="京B11111">京B11111（孙师傅）</SelectItem>
                      <SelectItem value="川A22222">川A22222（周师傅）</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">司机信息</label>
                <Input placeholder="司机姓名 + 手机号" />
              </div>
            </section>

            {/* Schedule Info */}
            <section className="space-y-3">
              <h4 className="text-sm font-semibold text-[var(--neutral-text-primary)] border-b border-[var(--neutral-border)] pb-1 flex items-center gap-1.5">
                <CalendarDays className="w-4 h-4 text-blue-500" />
                时间信息
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">发运时间</label>
                  <Input type="datetime-local" />
                </div>
                <div>
                  <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">预计到达 <span className="text-red-400">*</span></label>
                  <Input type="datetime-local" />
                </div>
              </div>
            </section>

            {/* Cargo Info */}
            <section className="space-y-3">
              <h4 className="text-sm font-semibold text-[var(--neutral-text-primary)] border-b border-[var(--neutral-border)] pb-1 flex items-center gap-1.5">
                <Package className="w-4 h-4 text-blue-500" />
                货物信息
              </h4>
              <div className="rounded-lg border border-[var(--neutral-border)] p-3 space-y-3">
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">载具编号</label>
                    <Input placeholder="如 CT-0001" />
                  </div>
                  <div>
                    <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">载具类型</label>
                    <Select>
                      <SelectTrigger><SelectValue placeholder="选择类型" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="标准托盘">标准托盘</SelectItem>
                        <SelectItem value="折叠周转箱">折叠周转箱</SelectItem>
                        <SelectItem value="金属周转箱">金属周转箱</SelectItem>
                        <SelectItem value="塑料卡板箱">塑料卡板箱</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">数量</label>
                    <Input type="number" placeholder="数量" />
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full text-xs">
                  <Plus className="w-3.5 h-3.5 mr-1" />
                  添加货物行
                </Button>
              </div>
            </section>

            {/* Remark */}
            <section>
              <label className="text-xs text-[var(--neutral-text-secondary)] mb-1 block">备注</label>
              <Input placeholder="发运备注信息（选填）" />
            </section>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              取消
            </Button>
            <Button onClick={() => setCreateOpen(false)}>
              <CheckCircle className="w-4 h-4 mr-1.5" />
              确认创建
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
