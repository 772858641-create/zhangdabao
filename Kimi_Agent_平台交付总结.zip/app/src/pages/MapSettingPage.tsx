import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  
  
  
  Layers,
  Route,
  Shield,
  AlertTriangle,
  Settings,
  RotateCcw,
  Save,
  ChevronRight,
  
  
  
  
  
  Upload,
  CheckCircle2,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type MapSettingTab = 'basic' | 'cluster' | 'track' | 'fence' | 'alarm';

interface AlarmStyle {
  icon: string;
  color: string;
  size: number;
  blink: boolean;
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const NAV_ITEMS: { key: MapSettingTab; label: string; icon: React.ElementType }[] = [
  { key: 'basic', label: '基础设置', icon: Settings },
  { key: 'cluster', label: '聚合设置', icon: Layers },
  { key: 'track', label: '轨迹回放', icon: Route },
  { key: 'fence', label: '地理围栏', icon: Shield },
  { key: 'alarm', label: '报警标记', icon: AlertTriangle },
];

const ALARM_TYPES = [
  { key: 'device-offline', label: '设备离线' },
  { key: 'tag-separation', label: '标签分离' },
  { key: 'transit-timeout', label: '在途超时' },
  { key: 'inventory-idle', label: '在库呆滞' },
  { key: 'temp-abnormal', label: '温度异常' },
  { key: 'fence-breach', label: '围栏越界' },
  { key: 'low-battery', label: '低电量' },
  { key: 'weak-signal', label: '信号弱' },
  { key: 'transfer-timeout', label: '调拨超时' },
  { key: 'cycle-overdue', label: '流转循环超期' },
  { key: 'vehicle-stuck', label: '车辆滞留' },
  { key: 'unauthorized-move', label: '未授权移动' },
  { key: 'carrier-lost', label: '载具丢失' },
  { key: 'gateway-offline', label: '网关离线' },
  { key: 'beacon-offline', label: '信标离线' },
  { key: 'ship-status-abnormal', label: '发运状态异常' },
  { key: 'route-deviation', label: '路线偏离' },
];

const ALARM_PRESET_COLORS: Record<string, string> = {
  'device-offline': '#EF4444',
  'tag-separation': '#F59E0B',
  'transit-timeout': '#F59E0B',
  'inventory-idle': '#8B5CF6',
  'temp-abnormal': '#EF4444',
  'fence-breach': '#EF4444',
  'low-battery': '#F59E0B',
  'weak-signal': '#06B6D4',
  'transfer-timeout': '#8B5CF6',
  'cycle-overdue': '#8B5CF6',
  'vehicle-stuck': '#F59E0B',
  'unauthorized-move': '#EF4444',
  'carrier-lost': '#EF4444',
  'gateway-offline': '#EF4444',
  'beacon-offline': '#EF4444',
  'ship-status-abnormal': '#F59E0B',
  'route-deviation': '#06B6D4',
};

// ------------------------------------------------------------------
// Reusable UI Components
// ------------------------------------------------------------------

function SectionCard({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('bg-white rounded-lg shadow-card p-6', className)}>
      <h3 className="text-base font-semibold text-[#0F172A] mb-4">{title}</h3>
      {children}
    </div>
  );
}

function FormRow({ label, children, description }: { label: string; children: React.ReactNode; description?: string }) {
  return (
    <div className="flex items-start gap-4 py-3">
      <label className="w-40 text-sm text-[#475569] flex-shrink-0 text-right pt-1.5">{label}</label>
      <div className="flex-1">
        <div className="flex items-center gap-2">{children}</div>
        {description && <p className="text-xs text-[#94A3B8] mt-1">{description}</p>}
      </div>
    </div>
  );
}

function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn('relative w-9 h-5 rounded-full transition-colors flex-shrink-0', checked ? 'bg-[#2563EB]' : 'bg-[#CBD5E1]')}
    >
      <span className={cn('absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform', checked ? 'translate-x-4' : 'translate-x-0')} />
    </button>
  );
}

function NumberInput({ value, onChange, min, max, suffix }: { value: number; onChange: (v: number) => void; min?: number; max?: number; suffix?: string }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-9 w-28 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
      />
      {suffix && <span className="text-sm text-[#475569]">{suffix}</span>}
    </div>
  );
}

function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white min-w-[140px]"
    >
      {options.map((opt) => (
        <option key={opt} value={opt}>
          {opt}
        </option>
      ))}
    </select>
  );
}

function RadioGroup({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { key: string; label: string }[] }) {
  return (
    <div className="flex flex-wrap gap-3">
      {options.map((opt) => (
        <button
          key={opt.key}
          onClick={() => onChange(opt.key)}
          className={cn(
            'h-9 px-4 rounded-md text-sm border transition-colors',
            value === opt.key ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]' : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

function ActionButtons({ onSave, onReset }: { onSave: () => void; onReset: () => void }) {
  return (
    <div className="flex items-center justify-end gap-3 pt-2">
      <button
        onClick={onReset}
        className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors"
      >
        <RotateCcw size={14} /> 重置为默认
      </button>
      <button
        onClick={onSave}
        className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors"
      >
        <Save size={14} /> 保存配置
      </button>
    </div>
  );
}

// ------------------------------------------------------------------
// Save Success Toast
// ------------------------------------------------------------------
function SaveToast({ visible }: { visible: boolean }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-2 bg-[#10B981] text-white px-4 py-2.5 rounded-lg shadow-lg text-sm font-medium"
        >
          <CheckCircle2 size={16} />
          配置保存成功
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ------------------------------------------------------------------
// Tab 1: Basic Settings
// ------------------------------------------------------------------
function BasicSettingsTab({ showToast }: { showToast: () => void }) {
  const [settings, setSettings] = useState({
    longitude: 121.4737,
    latitude: 31.2304,
    zoom: 12,
    provider: '高德地图',
    language: '中文',
    showZoomControl: true,
    showScaleControl: true,
    showOverviewMap: false,
    showRotateControl: false,
  });

  const update = (key: string, value: unknown) => setSettings((prev) => ({ ...prev, [key]: value }));

  const handleSave = () => showToast();
  const handleReset = () => {
    if (confirm('确定恢复基础设置为默认值？')) {
      setSettings({
        longitude: 121.4737,
        latitude: 31.2304,
        zoom: 12,
        provider: '高德地图',
        language: '中文',
        showZoomControl: true,
        showScaleControl: true,
        showOverviewMap: false,
        showRotateControl: false,
      });
      showToast();
    }
  };

  return (
    <div className="space-y-6">
      <SectionCard title="地图中心与视图">
        <FormRow label="默认经度" description="默认地图中心点经度坐标">
          <NumberInput value={settings.longitude} onChange={(v) => update('longitude', v)} />
        </FormRow>
        <FormRow label="默认纬度" description="默认地图中心点纬度坐标">
          <NumberInput value={settings.latitude} onChange={(v) => update('latitude', v)} />
        </FormRow>
        <FormRow label="默认缩放级别" description="地图初始加载时的缩放级别，范围1-18">
          <div className="flex items-center gap-3">
            <NumberInput value={settings.zoom} onChange={(v) => update('zoom', Math.max(1, Math.min(18, v)))} min={1} max={18} />
            <span className="text-xs text-[#94A3B8]">当前级别：{settings.zoom}</span>
          </div>
        </FormRow>
      </SectionCard>

      <SectionCard title="底图配置">
        <FormRow label="底图服务商" description="选择地图底图数据来源">
          <RadioGroup
            value={settings.provider}
            onChange={(v) => update('provider', v)}
            options={[
              { key: '高德地图', label: '高德地图' },
              { key: '天地图', label: '天地图' },
            ]}
          />
        </FormRow>
        <FormRow label="地图语言" description="地图标签和控件显示语言">
          <RadioGroup
            value={settings.language}
            onChange={(v) => update('language', v)}
            options={[
              { key: '中文', label: '中文' },
              { key: '英文', label: '英文' },
            ]}
          />
        </FormRow>
      </SectionCard>

      <SectionCard title="地图控件">
        <FormRow label="缩放控件" description="显示地图放大/缩小按钮">
          <Switch checked={settings.showZoomControl} onChange={(v) => update('showZoomControl', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.showZoomControl ? '显示' : '隐藏'}</span>
        </FormRow>
        <FormRow label="比例尺" description="显示地图比例尺参考线">
          <Switch checked={settings.showScaleControl} onChange={(v) => update('showScaleControl', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.showScaleControl ? '显示' : '隐藏'}</span>
        </FormRow>
        <FormRow label="鹰眼图" description="右下角显示缩略地图">
          <Switch checked={settings.showOverviewMap} onChange={(v) => update('showOverviewMap', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.showOverviewMap ? '显示' : '隐藏'}</span>
        </FormRow>
        <FormRow label="旋转控件" description="允许用户旋转地图视角">
          <Switch checked={settings.showRotateControl} onChange={(v) => update('showRotateControl', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.showRotateControl ? '显示' : '隐藏'}</span>
        </FormRow>
      </SectionCard>

      <ActionButtons onSave={handleSave} onReset={handleReset} />
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 2: Cluster Settings
// ------------------------------------------------------------------
function ClusterSettingsTab({ showToast }: { showToast: () => void }) {
  const [settings, setSettings] = useState({
    clusterThreshold: '100m',
    maxClusterCount: '100',
    clusterStyle: '圆形',
    clusterColorMode: '按状态着色',
    showClusterNumber: true,
  });

  const update = (key: string, value: unknown) => setSettings((prev) => ({ ...prev, [key]: value }));

  const handleSave = () => showToast();
  const handleReset = () => {
    if (confirm('确定恢复聚合设置为默认值？')) {
      setSettings({
        clusterThreshold: '100m',
        maxClusterCount: '100',
        clusterStyle: '圆形',
        clusterColorMode: '按状态着色',
        showClusterNumber: true,
      });
      showToast();
    }
  };

  return (
    <div className="space-y-6">
      <SectionCard title="聚合规则">
        <FormRow label="聚合显示阈值" description="多少米范围内的标记点会被聚合为一个">
          <Select
            value={settings.clusterThreshold}
            onChange={(v) => update('clusterThreshold', v)}
            options={['50m', '100m', '200m', '500m']}
          />
        </FormRow>
        <FormRow label="最大聚合数量" description="单个聚合点最多聚合多少个载具">
          <Select
            value={settings.maxClusterCount}
            onChange={(v) => update('maxClusterCount', v)}
            options={['50', '100', '200']}
          />
        </FormRow>
      </SectionCard>

      <SectionCard title="聚合样式">
        <FormRow label="聚合形状" description="聚合标记点在地图上的形状样式">
          <RadioGroup
            value={settings.clusterStyle}
            onChange={(v) => update('clusterStyle', v)}
            options={[
              { key: '圆形', label: '圆形' },
              { key: '方形', label: '方形' },
              { key: '水滴形', label: '水滴形' },
            ]}
          />
        </FormRow>
        <FormRow label="聚合颜色" description="聚合标记点的着色规则">
          <RadioGroup
            value={settings.clusterColorMode}
            onChange={(v) => update('clusterColorMode', v)}
            options={[
              { key: '按状态着色', label: '按状态着色' },
              { key: '按类型着色', label: '按类型着色' },
              { key: '统一颜色', label: '统一颜色' },
            ]}
          />
        </FormRow>
        <FormRow label="聚合数字显示" description="是否在聚合标记上显示数量">
          <Switch checked={settings.showClusterNumber} onChange={(v) => update('showClusterNumber', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.showClusterNumber ? '显示数量' : '仅显示图标'}</span>
        </FormRow>
      </SectionCard>

      <ActionButtons onSave={handleSave} onReset={handleReset} />
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 3: Track Playback Settings
// ------------------------------------------------------------------
function TrackSettingsTab({ showToast }: { showToast: () => void }) {
  const [settings, setSettings] = useState({
    lineStyle: '实线',
    lineColor: '蓝色',
    customColor: '#2563EB',
    lineWidth: '2px',
    playSpeed: '1x',
    pointDisplay: '仅显示关键点',
    loopPlayback: true,
  });

  const update = (key: string, value: unknown) => setSettings((prev) => ({ ...prev, [key]: value }));

  const handleSave = () => showToast();
  const handleReset = () => {
    if (confirm('确定恢复轨迹回放设置为默认值？')) {
      setSettings({
        lineStyle: '实线',
        lineColor: '蓝色',
        customColor: '#2563EB',
        lineWidth: '2px',
        playSpeed: '1x',
        pointDisplay: '仅显示关键点',
        loopPlayback: true,
      });
      showToast();
    }
  };

  const colorOptions = [
    { key: '蓝色', label: '蓝色', color: '#2563EB' },
    { key: '红色', label: '红色', color: '#EF4444' },
    { key: '绿色', label: '绿色', color: '#10B981' },
    { key: '自定义', label: '自定义', color: settings.customColor },
  ];

  return (
    <div className="space-y-6">
      <SectionCard title="轨迹线样式">
        <FormRow label="连线样式" description="轨迹点之间的连线类型">
          <RadioGroup
            value={settings.lineStyle}
            onChange={(v) => update('lineStyle', v)}
            options={[
              { key: '实线', label: '实线' },
              { key: '虚线', label: '虚线' },
              { key: '点线', label: '点线' },
            ]}
          />
        </FormRow>
        <FormRow label="轨迹线颜色" description="选择轨迹线的颜色">
          <div className="flex flex-wrap gap-3">
            {colorOptions.map((opt) => (
              <button
                key={opt.key}
                onClick={() => update('lineColor', opt.key)}
                className={cn(
                  'h-9 px-4 rounded-md text-sm border transition-colors flex items-center gap-2',
                  settings.lineColor === opt.key ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]' : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                )}
              >
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: opt.color }} />
                {opt.label}
              </button>
            ))}
          </div>
          {settings.lineColor === '自定义' && (
            <div className="flex items-center gap-2 mt-2">
              <input
                type="color"
                value={settings.customColor}
                onChange={(e) => update('customColor', e.target.value)}
                className="w-9 h-9 border border-[#CBD5E1] rounded-md cursor-pointer"
              />
              <span className="text-sm text-[#475569]">{settings.customColor}</span>
            </div>
          )}
        </FormRow>
        <FormRow label="轨迹线宽度" description="轨迹线的像素宽度">
          <Select
            value={settings.lineWidth}
            onChange={(v) => update('lineWidth', v)}
            options={['1px', '2px', '3px', '5px']}
          />
        </FormRow>
      </SectionCard>

      <SectionCard title="播放控制">
        <FormRow label="播放速度" description="轨迹回放的速度倍率">
          <RadioGroup
            value={settings.playSpeed}
            onChange={(v) => update('playSpeed', v)}
            options={[
              { key: '1x', label: '1x' },
              { key: '2x', label: '2x' },
              { key: '5x', label: '5x' },
              { key: '10x', label: '10x' },
            ]}
          />
        </FormRow>
        <FormRow label="轨迹点标记" description="回放过程中轨迹点的显示方式">
          <Select
            value={settings.pointDisplay}
            onChange={(v) => update('pointDisplay', v)}
            options={['显示全部点', '仅显示关键点', '不显示点']}
          />
        </FormRow>
        <FormRow label="回放循环" description="播放完成后是否自动重新开始">
          <Switch checked={settings.loopPlayback} onChange={(v) => update('loopPlayback', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.loopPlayback ? '自动循环' : '单次播放'}</span>
        </FormRow>
      </SectionCard>

      <ActionButtons onSave={handleSave} onReset={handleReset} />
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 4: Geo-fence Settings
// ------------------------------------------------------------------
function FenceSettingsTab({ showToast }: { showToast: () => void }) {
  const [settings, setSettings] = useState({
    drawPrecision: '中（5米）',
    enterBuffer: 10,
    leaveBuffer: 20,
    alarmDelay: '5秒',
    lineStyle: '虚线',
    lineColor: '#F59E0B',
    opacity: 60,
  });

  const update = (key: string, value: unknown) => setSettings((prev) => ({ ...prev, [key]: value }));

  const handleSave = () => showToast();
  const handleReset = () => {
    if (confirm('确定恢复地理围栏设置为默认值？')) {
      setSettings({
        drawPrecision: '中（5米）',
        enterBuffer: 10,
        leaveBuffer: 20,
        alarmDelay: '5秒',
        lineStyle: '虚线',
        lineColor: '#F59E0B',
        opacity: 60,
      });
      showToast();
    }
  };

  const handleImport = () => {
    alert('模拟：已选择围栏坐标Excel文件，正在解析...\n成功导入 12 个地理围栏');
  };

  return (
    <div className="space-y-6">
      <SectionCard title="围栏判定规则">
        <FormRow label="绘制精度" description="围栏边界坐标的精度等级">
          <Select
            value={settings.drawPrecision}
            onChange={(v) => update('drawPrecision', v)}
            options={['高（1米）', '中（5米）', '低（10米）']}
          />
        </FormRow>
        <FormRow label="进入缓冲距离" description="进入围栏前的判定缓冲范围">
          <NumberInput value={settings.enterBuffer} onChange={(v) => update('enterBuffer', v)} suffix="米" />
        </FormRow>
        <FormRow label="离开缓冲距离" description="离开围栏后的判定缓冲范围">
          <NumberInput value={settings.leaveBuffer} onChange={(v) => update('leaveBuffer', v)} suffix="米" />
        </FormRow>
        <FormRow label="越界报警延迟" description="进入/离开围栏后延迟判定时间">
          <Select
            value={settings.alarmDelay}
            onChange={(v) => update('alarmDelay', v)}
            options={['0秒', '5秒', '10秒', '30秒']}
          />
        </FormRow>
      </SectionCard>

      <SectionCard title="围栏显示样式">
        <FormRow label="围栏边线样式" description="围栏边界线在地图上的显示样式">
          <RadioGroup
            value={settings.lineStyle}
            onChange={(v) => update('lineStyle', v)}
            options={[
              { key: '实线', label: '实线' },
              { key: '虚线', label: '虚线' },
            ]}
          />
        </FormRow>
        <FormRow label="围栏边线颜色" description="围栏边界线颜色">
          <div className="flex items-center gap-3">
            <input
              type="color"
              value={settings.lineColor}
              onChange={(e) => update('lineColor', e.target.value)}
              className="w-9 h-9 border border-[#CBD5E1] rounded-md cursor-pointer"
            />
            <span className="text-sm text-[#475569]">{settings.lineColor}</span>
          </div>
        </FormRow>
        <FormRow label="填充透明度" description="围栏区域的填充不透明度">
          <div className="flex items-center gap-3">
            <input
              type="range"
              min={0}
              max={100}
              value={settings.opacity}
              onChange={(e) => update('opacity', Number(e.target.value))}
              className="w-40 accent-[#2563EB]"
            />
            <span className="text-sm text-[#475569]">{settings.opacity}%</span>
          </div>
        </FormRow>
      </SectionCard>

      <SectionCard title="批量围栏导入">
        <div className="flex items-center gap-4 py-3">
          <div className="w-40 text-sm text-[#475569] flex-shrink-0 text-right">围栏坐标导入</div>
          <div className="flex-1">
            <button
              onClick={handleImport}
              className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors"
            >
              <Upload size={14} /> 选择 Excel 文件
            </button>
            <p className="text-xs text-[#94A3B8] mt-2">支持 .xlsx 格式，需包含：围栏名称、类型、坐标点列表（WGS84）</p>
          </div>
        </div>
      </SectionCard>

      <ActionButtons onSave={handleSave} onReset={handleReset} />
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 5: Alarm Marker Settings
// ------------------------------------------------------------------
function AlarmSettingsTab({ showToast }: { showToast: () => void }) {
  const [alarmStyles, setAlarmStyles] = useState<Record<string, AlarmStyle>>(() => {
    const initial: Record<string, AlarmStyle> = {};
    ALARM_TYPES.forEach((t) => {
      initial[t.key] = {
        icon: '默认',
        color: ALARM_PRESET_COLORS[t.key] || '#EF4444',
        size: 24,
        blink: ['设备离线', '围栏越界', '载具丢失', '网关离线', '信标离线', '未授权移动'].includes(t.label),
      };
    });
    return initial;
  });

  const [clusterAlarms, setClusterAlarms] = useState(true);
  const [autoClear, setAutoClear] = useState(true);

  const updateStyle = (key: string, field: keyof AlarmStyle, value: unknown) => {
    setAlarmStyles((prev) => ({ ...prev, [key]: { ...prev[key], [field]: value } }));
  };

  const handleSave = () => showToast();
  const handleReset = () => {
    if (confirm('确定恢复报警标记设置为默认值？')) {
      const reset: Record<string, AlarmStyle> = {};
      ALARM_TYPES.forEach((t) => {
        reset[t.key] = {
          icon: '默认',
          color: ALARM_PRESET_COLORS[t.key] || '#EF4444',
          size: 24,
          blink: ['设备离线', '围栏越界', '载具丢失', '网关离线', '信标离线', '未授权移动'].includes(t.label),
        };
      });
      setAlarmStyles(reset);
      setClusterAlarms(true);
      setAutoClear(true);
      showToast();
    }
  };

  return (
    <div className="space-y-6">
      <SectionCard title="全局报警标记设置">
        <FormRow label="报警聚合显示" description="同一区域多个报警是否聚合显示">
          <Switch checked={clusterAlarms} onChange={setClusterAlarms} />
          <span className="ml-2 text-sm text-[#475569]">{clusterAlarms ? '同区域聚合' : '单独显示'}</span>
        </FormRow>
        <FormRow label="报警自动清除" description="报警恢复后地图标记是否自动消失">
          <Switch checked={autoClear} onChange={setAutoClear} />
          <span className="ml-2 text-sm text-[#475569]">{autoClear ? '自动清除' : '手动清除'}</span>
        </FormRow>
      </SectionCard>

      <SectionCard title="报警类型标记样式">
        <div className="space-y-4">
          {ALARM_TYPES.map((alarm) => {
            const style = alarmStyles[alarm.key];
            if (!style) return null;
            return (
              <div
                key={alarm.key}
                className="flex items-center gap-4 py-3 px-4 rounded-lg border border-[#E2E8F0] hover:border-[#CBD5E1] transition-colors"
              >
                {/* Alarm name */}
                <div className="w-32 flex-shrink-0">
                  <span className="text-sm font-medium text-[#0F172A]">{alarm.label}</span>
                </div>

                {/* Color picker */}
                <div className="flex items-center gap-2 w-28">
                  <input
                    type="color"
                    value={style.color}
                    onChange={(e) => updateStyle(alarm.key, 'color', e.target.value)}
                    className="w-7 h-7 border border-[#CBD5E1] rounded cursor-pointer flex-shrink-0"
                  />
                  <span className="text-xs text-[#475569] font-mono">{style.color}</span>
                </div>

                {/* Size */}
                <div className="flex items-center gap-2 w-28">
                  <span className="text-xs text-[#94A3B8]">大小</span>
                  <select
                    value={style.size}
                    onChange={(e) => updateStyle(alarm.key, 'size', Number(e.target.value))}
                    className="h-7 w-16 px-1 border border-[#CBD5E1] rounded text-xs focus:outline-none"
                  >
                    {[16, 20, 24, 28, 32].map((s) => (
                      <option key={s} value={s}>
                        {s}px
                      </option>
                    ))}
                  </select>
                </div>

                {/* Blink */}
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Switch checked={style.blink} onChange={(v) => updateStyle(alarm.key, 'blink', v)} />
                  <span className="text-xs text-[#475569]">{style.blink ? '闪烁' : '常亮'}</span>
                </div>

                {/* Preview */}
                <div className="ml-auto flex items-center justify-center w-10 h-10 flex-shrink-0">
                  <div
                    className={cn(
                      'rounded-full flex items-center justify-center',
                      style.blink && 'animate-pulse'
                    )}
                    style={{
                      width: style.size,
                      height: style.size,
                      backgroundColor: style.color,
                    }}
                  >
                    <AlertTriangle size={Math.max(10, style.size - 10)} className="text-white" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </SectionCard>

      <ActionButtons onSave={handleSave} onReset={handleReset} />
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function MapSettingPage() {
  const [activeTab, setActiveTab] = useState<MapSettingTab>('basic');
  const [showToast, setShowToast] = useState(false);

  const triggerToast = () => {
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#0F172A]">地图设置</h1>
          <p className="text-sm text-[#94A3B8] mt-1">配置地图看板的显示规则、聚合策略、轨迹回放及地理围栏参数</p>
        </div>
      </div>

      {/* Two-column layout: nav + content */}
      <div className="flex gap-5">
        {/* Left Navigation */}
        <nav className="w-[200px] bg-white rounded-lg shadow-card flex-shrink-0 self-start overflow-hidden">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors text-left',
                activeTab === item.key ? 'bg-[#EFF6FF] text-[#2563EB]' : 'text-[#475569] hover:bg-[#F8FAFC]'
              )}
              style={
                activeTab === item.key
                  ? { borderLeft: '3px solid #2563EB' }
                  : { borderLeft: '3px solid transparent' }
              }
            >
              <item.icon size={18} />
              {item.label}
              {activeTab === item.key && <ChevronRight size={14} className="ml-auto" />}
            </button>
          ))}
        </nav>

        {/* Right Content */}
        <div className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'basic' && <BasicSettingsTab showToast={triggerToast} />}
              {activeTab === 'cluster' && <ClusterSettingsTab showToast={triggerToast} />}
              {activeTab === 'track' && <TrackSettingsTab showToast={triggerToast} />}
              {activeTab === 'fence' && <FenceSettingsTab showToast={triggerToast} />}
              {activeTab === 'alarm' && <AlarmSettingsTab showToast={triggerToast} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <SaveToast visible={showToast} />
    </div>
  );
}
