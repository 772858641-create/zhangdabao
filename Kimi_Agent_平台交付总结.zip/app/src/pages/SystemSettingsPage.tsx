import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Bell,
  SlidersHorizontal,
  ClipboardList,
  Database,
  Save,
  RotateCcw,
  Search,
  ChevronDown,
  ChevronUp,
  Download,
  Upload,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  X,
  Clock,
  MapPin,
  Calendar,
  Image,
  Plus,
  Server,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type SettingsTab = 'alarm-threshold' | 'system-params' | 'operation-logs' | 'data-backup';

interface LogEntry {
  id: string;
  time: string;
  operator: string;
  orgName: string;
  module: string;
  type: string;
  target: string;
  description: string;
  result: 'success' | 'failure';
  ip: string;
  before?: Record<string, unknown>;
  after?: Record<string, unknown>;
}

interface BackupItem {
  id: string;
  name: string;
  type: 'full' | 'incremental';
  scope: string;
  time: string;
  size: string;
  status: 'success' | 'in_progress' | 'failed';
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const NAV_ITEMS: { key: SettingsTab; label: string; icon: React.ElementType }[] = [
  { key: 'alarm-threshold', label: '报警阈值配置', icon: Bell },
  { key: 'system-params', label: '系统参数配置', icon: SlidersHorizontal },
  { key: 'operation-logs', label: '操作日志', icon: ClipboardList },
  { key: 'data-backup', label: '数据备份', icon: Database },
];

const LOG_TYPE_COLORS: Record<string, { color: string; bg: string }> = {
  '登录': { color: '#06B6D4', bg: '#ECFEFF' },
  '登出': { color: '#06B6D4', bg: '#ECFEFF' },
  '新增': { color: '#10B981', bg: '#ECFDF5' },
  '编辑': { color: '#2563EB', bg: '#EFF6FF' },
  '删除': { color: '#EF4444', bg: '#FEF2F2' },
  '导出': { color: '#8B5CF6', bg: '#F5F3FF' },
  '审核': { color: '#F59E0B', bg: '#FFFBEB' },
  '配置': { color: '#475569', bg: '#F1F5F9' },
};

// ------------------------------------------------------------------
// Mock Data
// ------------------------------------------------------------------
const MOCK_LOGS: LogEntry[] = [
  { id: 'log-1', time: '2024-12-20 14:32:15', operator: 'admin', orgName: '云载科技（总部）', module: '载具管理', type: '编辑', target: 'CJ000123', description: '修改载具状态为维修中', result: 'success', ip: '192.168.1.105', before: { status: 'normal', siteId: 'site-1' }, after: { status: 'repairing', siteId: 'site-2' } },
  { id: 'log-2', time: '2024-12-20 13:10:22', operator: 'zhangsan', orgName: '上海运营中心', module: '调拨管理', type: '新增', target: 'DB000045', description: '创建调拨单', result: 'success', ip: '192.168.1.112' },
  { id: 'log-3', time: '2024-12-20 12:05:08', operator: 'lisi', orgName: '上海运营中心', module: '报警中心', type: '配置', target: 'RULE-003', description: '修改温度报警阈值', result: 'success', ip: '192.168.1.115' },
  { id: 'log-4', time: '2024-12-20 11:48:33', operator: 'admin', orgName: '云载科技（总部）', module: '用户管理', type: '删除', target: 'u-15', description: '删除用户账号', result: 'failure', ip: '192.168.1.105' },
  { id: 'log-5', time: '2024-12-20 10:22:45', operator: 'wangwu', orgName: '上海浦东工厂', module: '设备管理', type: '导出', target: 'devices', description: '导出设备列表', result: 'success', ip: '192.168.2.201' },
  { id: 'log-6', time: '2024-12-20 09:15:10', operator: 'admin', orgName: '云载科技（总部）', module: '系统设置', type: '配置', target: 'settings', description: '修改系统参数', result: 'success', ip: '192.168.1.105' },
  { id: 'log-7', time: '2024-12-19 18:30:05', operator: 'zhaoliu', orgName: '华东汽车制造有限公司', module: '调拨管理', type: '审核', target: 'DB000044', description: '审核通过调拨单', result: 'success', ip: '192.168.3.105' },
  { id: 'log-8', time: '2024-12-19 16:45:22', operator: 'admin', orgName: '云载科技（总部）', module: '用户管理', type: '新增', target: 'u-16', description: '新增用户账号', result: 'success', ip: '192.168.1.105' },
  { id: 'log-9', time: '2024-12-19 14:20:18', operator: 'sunqi', orgName: '广州仓储中心', module: '载具管理', type: '编辑', target: 'CJ000456', description: '修改载具归属网点', result: 'success', ip: '192.168.4.88' },
  { id: 'log-10', time: '2024-12-19 09:00:00', operator: 'admin', orgName: '云载科技（总部）', module: '系统', type: '登录', target: 'system', description: '用户登录系统', result: 'success', ip: '192.168.1.105' },
  { id: 'log-11', time: '2024-12-18 17:30:45', operator: 'zhouba', orgName: '北方供应链管理', module: '车辆管理', type: '新增', target: '沪A56789', description: '新增车辆信息', result: 'success', ip: '192.168.5.22' },
  { id: 'log-12', time: '2024-12-18 15:12:33', operator: 'admin', orgName: '云载科技（总部）', module: '系统设置', type: '配置', target: 'backup', description: '配置自动备份策略', result: 'success', ip: '192.168.1.105' },
];

const MOCK_BACKUPS: BackupItem[] = [
  { id: 'bk-1', name: '全量备份_20241220_020000', type: 'full', scope: '全部数据', time: '2024-12-20 02:00:00', size: '2.3 GB', status: 'success' },
  { id: 'bk-2', name: '增量备份_20241219_020000', type: 'incremental', scope: '全部数据', time: '2024-12-19 02:00:00', size: '156 MB', status: 'success' },
  { id: 'bk-3', name: '全量备份_20241218_020000', type: 'full', scope: '全部数据', time: '2024-12-18 02:00:00', size: '2.2 GB', status: 'success' },
  { id: 'bk-4', name: '增量备份_20241217_020000', type: 'incremental', scope: '全部数据', time: '2024-12-17 02:00:00', size: '128 MB', status: 'success' },
  { id: 'bk-5', name: '手动备份_20241216_143022', type: 'full', scope: '载具数据,设备数据', time: '2024-12-16 14:30:22', size: '890 MB', status: 'success' },
  { id: 'bk-6', name: '增量备份_20241216_020000', type: 'incremental', scope: '全部数据', time: '2024-12-16 02:00:00', size: '95 MB', status: 'failed' },
  { id: 'bk-7', name: '全量备份_20241215_020000', type: 'full', scope: '全部数据', time: '2024-12-15 02:00:00', size: '2.1 GB', status: 'success' },
];

// ------------------------------------------------------------------
// Components
// ------------------------------------------------------------------

function Tag({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

/** Section Card */
function SectionCard({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={cn('bg-white rounded-lg shadow-card p-6', className)}>
      <h3 className="text-base font-semibold text-[#0F172A] mb-4">{title}</h3>
      {children}
    </div>
  );
}

/** Form Row */
function FormRow({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div className="flex items-center gap-4 py-2">
      <label className="w-40 text-sm text-[#475569] flex-shrink-0 text-right">
        {label}
        {required && <span className="text-[#EF4444] ml-0.5">*</span>}
      </label>
      <div className="flex-1">{children}</div>
    </div>
  );
}

/** Switch */
function Switch({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn('relative w-9 h-5 rounded-full transition-colors', checked ? 'bg-[#2563EB]' : 'bg-[#CBD5E1]')}
    >
      <span className={cn('absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform', checked ? 'translate-x-4' : 'translate-x-0')} />
    </button>
  );
}

/** Number Input */
function NumberInput({ value, onChange, min, max, suffix }: { value: number; onChange: (v: number) => void; min?: number; max?: number; suffix?: string }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="number"
        value={value}
        min={min}
        max={max}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-9 w-28 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
      />
      {suffix && <span className="text-sm text-[#475569]">{suffix}</span>}
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 1: Alarm Threshold
// ------------------------------------------------------------------
function AlarmThresholdTab() {
  const [settings, setSettings] = useState({
    idleAlert: 72,
    transitTimeout: 48,
    emptyFullCheck: false,
    emptyThreshold: 10,
    fullThreshold: 90,
    tagSeparation: true,
    tagSepTime: 30,
    lostAlert: true,
    lostTime: 24,
    deviceOffline: true,
    offlineTime: 30,
    lowBattery: true,
    batteryThreshold: 20,
    temperature: true,
    tempMax: 60,
    tempMin: -20,
    fenceAlert: true,
    fenceRange: 500,
    routeTimeout: true,
    cycleTimeout: true,
    cycleDays: 30,
    routeDeviation: true,
    deviationRange: 2,
    inventoryWarning: 80,
    inventoryLimit: 95,
    duplicateAlert: true,
    suppressTime: 30,
    escalateTime: 2,
    notifyMethods: ['站内消息'] as string[],
    urgentNotify: ['站内消息', '短信'] as string[],
  });

  const update = (key: string, value: unknown) => setSettings(prev => ({ ...prev, [key]: value }));

  const handleSave = () => alert('配置已保存');
  const handleReset = () => { if (confirm('确定恢复所有阈值为默认值？')) alert('已恢复默认值'); };

  return (
    <div className="space-y-6">
      {/* Carrier Alarm */}
      <SectionCard title="载具报警阈值">
        <FormRow label="呆滞报警阈值"><NumberInput value={settings.idleAlert} onChange={(v) => update('idleAlert', v)} suffix="小时" /></FormRow>
        <FormRow label="在途超时阈值"><NumberInput value={settings.transitTimeout} onChange={(v) => update('transitTimeout', v)} suffix="小时" /></FormRow>
        <FormRow label="空满载检测">
          <Switch checked={settings.emptyFullCheck} onChange={(v) => update('emptyFullCheck', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.emptyFullCheck ? '开启' : '关闭'}</span>
        </FormRow>
        {settings.emptyFullCheck && (
          <>
            <FormRow label="空载判定标准"><NumberInput value={settings.emptyThreshold} onChange={(v) => update('emptyThreshold', v)} suffix="%" /></FormRow>
            <FormRow label="满载判定标准"><NumberInput value={settings.fullThreshold} onChange={(v) => update('fullThreshold', v)} suffix="%" /></FormRow>
          </>
        )}
        <FormRow label="标签分离报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.tagSeparation} onChange={(v) => update('tagSeparation', v)} />
            <span className="text-sm text-[#475569]">{settings.tagSeparation ? '开启' : '关闭'}</span>
            {settings.tagSeparation && <NumberInput value={settings.tagSepTime} onChange={(v) => update('tagSepTime', v)} suffix="分钟" />}
          </div>
        </FormRow>
        <FormRow label="丢失报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.lostAlert} onChange={(v) => update('lostAlert', v)} />
            <span className="text-sm text-[#475569]">{settings.lostAlert ? '开启' : '关闭'}</span>
            {settings.lostAlert && <NumberInput value={settings.lostTime} onChange={(v) => update('lostTime', v)} suffix="小时" />}
          </div>
        </FormRow>
      </SectionCard>

      {/* Device Alarm */}
      <SectionCard title="设备报警阈值">
        <FormRow label="设备离线报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.deviceOffline} onChange={(v) => update('deviceOffline', v)} />
            <span className="text-sm text-[#475569]">{settings.deviceOffline ? '开启' : '关闭'}</span>
            {settings.deviceOffline && <NumberInput value={settings.offlineTime} onChange={(v) => update('offlineTime', v)} suffix="分钟" />}
          </div>
        </FormRow>
        <FormRow label="设备低电量报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.lowBattery} onChange={(v) => update('lowBattery', v)} />
            <span className="text-sm text-[#475569]">{settings.lowBattery ? '开启' : '关闭'}</span>
            {settings.lowBattery && <NumberInput value={settings.batteryThreshold} onChange={(v) => update('batteryThreshold', v)} suffix="%" />}
          </div>
        </FormRow>
        <FormRow label="温度报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.temperature} onChange={(v) => update('temperature', v)} />
            <span className="text-sm text-[#475569]">{settings.temperature ? '开启' : '关闭'}</span>
          </div>
        </FormRow>
        {settings.temperature && (
          <>
            <FormRow label="温度上限"><NumberInput value={settings.tempMax} onChange={(v) => update('tempMax', v)} suffix="°C" /></FormRow>
            <FormRow label="温度下限"><NumberInput value={settings.tempMin} onChange={(v) => update('tempMin', v)} suffix="°C" /></FormRow>
          </>
        )}
      </SectionCard>

      {/* Vehicle Alarm */}
      <SectionCard title="车辆报警阈值">
        <FormRow label="车辆围栏报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.fenceAlert} onChange={(v) => update('fenceAlert', v)} />
            <span className="text-sm text-[#475569]">{settings.fenceAlert ? '开启' : '关闭'}</span>
            {settings.fenceAlert && <NumberInput value={settings.fenceRange} onChange={(v) => update('fenceRange', v)} suffix="米" />}
          </div>
        </FormRow>
      </SectionCard>

      {/* Transfer Alarm */}
      <SectionCard title="流转报警阈值">
        <FormRow label="路线超时报警">
          <Switch checked={settings.routeTimeout} onChange={(v) => update('routeTimeout', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.routeTimeout ? '开启' : '关闭'}</span>
        </FormRow>
        <FormRow label="循环超期报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.cycleTimeout} onChange={(v) => update('cycleTimeout', v)} />
            <span className="text-sm text-[#475569]">{settings.cycleTimeout ? '开启' : '关闭'}</span>
            {settings.cycleTimeout && <NumberInput value={settings.cycleDays} onChange={(v) => update('cycleDays', v)} suffix="天" />}
          </div>
        </FormRow>
        <FormRow label="路线偏离报警">
          <div className="flex items-center gap-4">
            <Switch checked={settings.routeDeviation} onChange={(v) => update('routeDeviation', v)} />
            <span className="text-sm text-[#475569]">{settings.routeDeviation ? '开启' : '关闭'}</span>
            {settings.routeDeviation && <NumberInput value={settings.deviationRange} onChange={(v) => update('deviationRange', v)} suffix="公里" />}
          </div>
        </FormRow>
      </SectionCard>

      {/* Inventory Alarm */}
      <SectionCard title="库存报警阈值">
        <FormRow label="库存预警百分比"><NumberInput value={settings.inventoryWarning} onChange={(v) => update('inventoryWarning', v)} suffix="%" /></FormRow>
        <FormRow label="库存超限百分比"><NumberInput value={settings.inventoryLimit} onChange={(v) => update('inventoryLimit', v)} suffix="%" /></FormRow>
        <FormRow label="跨网点重复入库报警">
          <Switch checked={settings.duplicateAlert} onChange={(v) => update('duplicateAlert', v)} />
          <span className="ml-2 text-sm text-[#475569]">{settings.duplicateAlert ? '开启' : '关闭'}</span>
        </FormRow>
      </SectionCard>

      {/* Notification Settings */}
      <SectionCard title="通知设置">
        <FormRow label="报警重复抑制时间"><NumberInput value={settings.suppressTime} onChange={(v) => update('suppressTime', v)} suffix="分钟" /></FormRow>
        <FormRow label="报警升级时间"><NumberInput value={settings.escalateTime} onChange={(v) => update('escalateTime', v)} suffix="小时" /></FormRow>
        <FormRow label="默认通知方式">
          <div className="flex gap-3">
            {['站内消息', '短信', '邮件', '微信'].map(m => (
              <label key={m} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked={settings.notifyMethods.includes(m)} className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]" />
                <span className="text-sm text-[#475569]">{m}</span>
              </label>
            ))}
          </div>
        </FormRow>
        <FormRow label="紧急报警强制通知">
          <div className="flex gap-3">
            {['站内消息', '短信', '邮件', '微信'].map(m => (
              <label key={m} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" defaultChecked={settings.urgentNotify.includes(m)} className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]" />
                <span className="text-sm text-[#475569]">{m}</span>
              </label>
            ))}
          </div>
        </FormRow>
      </SectionCard>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3">
        <button onClick={handleReset} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <RotateCcw size={14} /> 重置为默认
        </button>
        <button onClick={handleSave} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors">
          <Save size={14} /> 保存配置
        </button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 2: System Params
// ------------------------------------------------------------------
function SystemParamsTab() {
  const [params, setParams] = useState({
    platformName: '载具数字化管理平台',
    language: '简体中文',
    timezone: 'Asia/Shanghai',
    dateFormat: 'YYYY-MM-DD',
    mapCenter: '105.0, 35.0',
    mapZoom: 5,
    mapProvider: '高德地图',
    mapApiKey: '',
    trackInterval: 30,
    locationExpire: 10,
    dataRetention: 365,
    trackRetention: 90,
    alarmRetention: 180,
    logRetention: 90,
    pageSize: 20,
    exportLimit: 10000,
    loginLock: true,
    maxFailures: 5,
    lockDuration: 30,
    passwordExpiry: 90,
    sessionTimeout: 30,
    forceMfa: false,
  });

  const update = (key: string, value: unknown) => setParams(prev => ({ ...prev, [key]: value }));

  return (
    <div className="space-y-6">
      {/* Basic Params */}
      <SectionCard title="基础参数">
        <FormRow label="系统名称" required>
          <input value={params.platformName} onChange={e => update('platformName', e.target.value)} className="h-9 w-80 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" />
        </FormRow>
        <FormRow label="系统 Logo">
          <div className="flex items-center gap-3">
            <div className="w-16 h-16 rounded-lg border border-dashed border-[#CBD5E1] flex items-center justify-center bg-[#F8FAFC]">
              <Image size={20} className="text-[#94A3B8]" />
            </div>
            <button className="h-9 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC]">上传 Logo</button>
          </div>
        </FormRow>
        <FormRow label="登录页背景">
          <div className="flex items-center gap-3">
            <div className="w-32 h-20 rounded-lg border border-dashed border-[#CBD5E1] flex items-center justify-center bg-[#F8FAFC]">
              <Image size={20} className="text-[#94A3B8]" />
            </div>
            <button className="h-9 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC]">上传背景图</button>
          </div>
        </FormRow>
        <FormRow label="默认语言">
          <select value={params.language} onChange={e => update('language', e.target.value)} className="h-9 w-48 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
            <option>简体中文</option>
            <option>繁體中文</option>
            <option>English</option>
          </select>
        </FormRow>
        <FormRow label="时区">
          <select value={params.timezone} onChange={e => update('timezone', e.target.value)} className="h-9 w-56 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
            <option>Asia/Shanghai</option>
            <option>Asia/Hong_Kong</option>
            <option>Asia/Tokyo</option>
            <option>UTC</option>
          </select>
        </FormRow>
        <FormRow label="日期格式">
          <select value={params.dateFormat} onChange={e => update('dateFormat', e.target.value)} className="h-9 w-48 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
            <option>YYYY-MM-DD</option>
            <option>YYYY/MM/DD</option>
            <option>DD-MM-YYYY</option>
          </select>
        </FormRow>
      </SectionCard>

      {/* Map Params */}
      <SectionCard title="地图参数">
        <FormRow label="默认地图中心">
          <div className="flex items-center gap-2">
            <MapPin size={16} className="text-[#94A3B8]" />
            <input value={params.mapCenter} onChange={e => update('mapCenter', e.target.value)} className="h-9 w-48 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" placeholder="经度, 纬度" />
          </div>
        </FormRow>
        <FormRow label="默认缩放级别">
          <NumberInput value={params.mapZoom} onChange={v => update('mapZoom', v)} min={1} max={18} />
        </FormRow>
        <FormRow label="地图服务商">
          <select value={params.mapProvider} onChange={e => update('mapProvider', e.target.value)} className="h-9 w-48 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]">
            <option>高德地图</option>
            <option>腾讯地图</option>
            <option>百度地图</option>
          </select>
        </FormRow>
        <FormRow label="地图 API Key">
          <input value={params.mapApiKey} onChange={e => update('mapApiKey', e.target.value)} placeholder="请输入地图 API Key" className="h-9 w-80 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" />
        </FormRow>
        <FormRow label="轨迹点间隔"><NumberInput value={params.trackInterval} onChange={v => update('trackInterval', v)} suffix="秒" /></FormRow>
        <FormRow label="位置过期时间"><NumberInput value={params.locationExpire} onChange={v => update('locationExpire', v)} suffix="分钟" /></FormRow>
      </SectionCard>

      {/* Data Params */}
      <SectionCard title="数据参数">
        <FormRow label="数据保留时长"><NumberInput value={params.dataRetention} onChange={v => update('dataRetention', v)} suffix="天" /></FormRow>
        <FormRow label="轨迹数据保留"><NumberInput value={params.trackRetention} onChange={v => update('trackRetention', v)} suffix="天" /></FormRow>
        <FormRow label="报警数据保留"><NumberInput value={params.alarmRetention} onChange={v => update('alarmRetention', v)} suffix="天" /></FormRow>
        <FormRow label="日志数据保留"><NumberInput value={params.logRetention} onChange={v => update('logRetention', v)} suffix="天" /></FormRow>
        <FormRow label="默认分页大小"><NumberInput value={params.pageSize} onChange={v => update('pageSize', v)} suffix="条/页" /></FormRow>
        <FormRow label="导出最大条数"><NumberInput value={params.exportLimit} onChange={v => update('exportLimit', v)} suffix="条" /></FormRow>
      </SectionCard>

      {/* Security Params */}
      <SectionCard title="安全参数">
        <FormRow label="登录失败锁定">
          <Switch checked={params.loginLock} onChange={v => update('loginLock', v)} />
          <span className="ml-2 text-sm text-[#475569]">{params.loginLock ? '开启' : '关闭'}</span>
        </FormRow>
        {params.loginLock && (
          <>
            <FormRow label="最大失败次数"><NumberInput value={params.maxFailures} onChange={v => update('maxFailures', v)} suffix="次" /></FormRow>
            <FormRow label="锁定时长"><NumberInput value={params.lockDuration} onChange={v => update('lockDuration', v)} suffix="分钟" /></FormRow>
          </>
        )}
        <FormRow label="密码有效期"><NumberInput value={params.passwordExpiry} onChange={v => update('passwordExpiry', v)} suffix="天（0表示永不过期）" /></FormRow>
        <FormRow label="会话超时"><NumberInput value={params.sessionTimeout} onChange={v => update('sessionTimeout', v)} suffix="分钟" /></FormRow>
        <FormRow label="强制 MFA">
          <Switch checked={params.forceMfa} onChange={v => update('forceMfa', v)} />
          <span className="ml-2 text-sm text-[#475569]">{params.forceMfa ? '开启' : '关闭'}</span>
        </FormRow>
      </SectionCard>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3">
        <button className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <RotateCcw size={14} /> 重置为默认
        </button>
        <button className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors">
          <Save size={14} /> 保存配置
        </button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 3: Operation Logs
// ------------------------------------------------------------------
function OperationLogsTab() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const LOG_TYPES = ['全部', '登录', '登出', '新增', '编辑', '删除', '导出', '审核', '配置'];

  const filteredLogs = useMemo(() => {
    return MOCK_LOGS.filter((log) => {
      if (typeFilter !== 'all' && typeFilter !== '全部' && log.type !== typeFilter) return false;
      if (search) {
        return log.operator.includes(search) || log.target.includes(search) || log.description.includes(search);
      }
      return true;
    });
  }, [typeFilter, search]);

  const totalPages = Math.ceil(filteredLogs.length / pageSize);
  const paginatedLogs = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredLogs.slice(start, start + pageSize);
  }, [filteredLogs, currentPage]);

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <select
          value={typeFilter}
          onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          {LOG_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              placeholder="搜索操作人、操作对象..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
      </div>

      {/* Log Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="w-8 px-3 py-2.5" />
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作时间</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作人</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">所属组织</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作类型</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作对象</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作描述</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">IP 地址</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">结果</th>
              </tr>
            </thead>
            <tbody>
              {paginatedLogs.map((log) => {
                const typeCfg = LOG_TYPE_COLORS[log.type] || { color: '#475569', bg: '#F1F5F9' };
                const isExpanded = expandedRow === log.id;
                return (
                  <>
                    <tr
                      key={log.id}
                      className={cn('border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors cursor-pointer')}
                      onClick={() => setExpandedRow(isExpanded ? null : log.id)}
                    >
                      <td className="px-3 py-3">
                        {isExpanded ? <ChevronUp size={14} className="text-[#94A3B8]" /> : <ChevronDown size={14} className="text-[#94A3B8]" />}
                      </td>
                      <td className="px-3 py-3 text-xs text-[#475569] font-mono">{log.time}</td>
                      <td className="px-3 py-3 text-sm text-[#0F172A]">{log.operator}</td>
                      <td className="px-3 py-3 text-sm text-[#475569]">{log.orgName}</td>
                      <td className="px-3 py-3">
                        <Tag label={log.type} color={typeCfg.color} bg={typeCfg.bg} />
                      </td>
                      <td className="px-3 py-3 text-sm text-[#0F172A]">{log.target}</td>
                      <td className="px-3 py-3 text-sm text-[#475569]">{log.description}</td>
                      <td className="px-3 py-3 text-xs text-[#475569] font-mono">{log.ip}</td>
                      <td className="px-3 py-3">
                        {log.result === 'success'
                          ? <Tag label="成功" color="#10B981" bg="#ECFDF5" />
                          : <Tag label="失败" color="#EF4444" bg="#FEF2F2" />
                        }
                      </td>
                    </tr>
                    <AnimatePresence>
                      {isExpanded && (log.before || log.after) && (
                        <motion.tr
                          initial={{ height: 0 }}
                          animate={{ height: 'auto' }}
                          exit={{ height: 0 }}
                          transition={{ duration: 0.25 }}
                        >
                          <td colSpan={9} className="px-6 py-4 bg-[#F8FAFC]">
                            <div className="grid grid-cols-2 gap-6">
                              {log.before && (
                                <div>
                                  <h4 className="text-xs font-medium text-[#94A3B8] mb-2">变更前</h4>
                                  <pre className="bg-white rounded-lg p-3 text-xs text-[#475569] border border-[#E2E8F0] overflow-auto">
                                    {JSON.stringify(log.before, null, 2)}
                                  </pre>
                                </div>
                              )}
                              {log.after && (
                                <div>
                                  <h4 className="text-xs font-medium text-[#94A3B8] mb-2">变更后</h4>
                                  <pre className="bg-white rounded-lg p-3 text-xs text-[#475569] border border-[#E2E8F0] overflow-auto">
                                    {JSON.stringify(log.after, null, 2)}
                                  </pre>
                                </div>
                              )}
                            </div>
                          </td>
                        </motion.tr>
                      )}
                    </AnimatePresence>
                  </>
                );
              })}
              {paginatedLogs.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-16 text-center">
                    <ClipboardList size={48} className="text-[#CBD5E1] mx-auto mb-3" />
                    <p className="text-base text-[#475569]">暂无操作日志</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {filteredLogs.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">共 <strong>{filteredLogs.length}</strong> 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">上一页</button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return <button key={page} onClick={() => setCurrentPage(page)} className={cn('w-8 h-8 rounded-md text-sm font-medium transition-colors', currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]')}>{page}</button>;
              })}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">下一页</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// Tab 4: Data Backup
// ------------------------------------------------------------------
function DataBackupTab() {
  const [backups] = useState<BackupItem[]>(MOCK_BACKUPS);
  const [autoBackup, setAutoBackup] = useState(true);
  const [backupCycle, setBackupCycle] = useState('daily');
  const [backupType, setBackupType] = useState<'full' | 'incremental'>('incremental');
  const [retentionCount, setRetentionCount] = useState(30);
  const [showRestoreModal, setShowRestoreModal] = useState<BackupItem | null>(null);
  const [restoreConfirmText, setRestoreConfirmText] = useState('');
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [isBackingUp, setIsBackingUp] = useState(false);

  const handleBackup = () => {
    setShowBackupModal(true);
    setIsBackingUp(true);
    setBackupProgress(0);
    const interval = setInterval(() => {
      setBackupProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setIsBackingUp(false);
          return 100;
        }
        return p + 10;
      });
    }, 300);
  };

  const handleRestore = () => {
    if (restoreConfirmText !== '确认恢复') {
      alert('请输入"确认恢复"以继续');
      return;
    }
    setShowRestoreModal(null);
    setRestoreConfirmText('');
    alert('数据恢复已启动');
  };

  const totalSize = '7.9 GB';
  const lastBackup = '2024-12-20 02:00:00';
  const nextBackup = '2024-12-21 02:00:00';

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { title: '备份总数', value: backups.length, color: '#2563EB', icon: Database },
          { title: '最近备份', value: lastBackup.split(' ')[0], sub: lastBackup.split(' ')[1], color: '#10B981', icon: Clock },
          { title: '存储大小', value: totalSize, color: '#8B5CF6', icon: Server },
          { title: '下次备份', value: nextBackup.split(' ')[0], sub: nextBackup.split(' ')[1], color: '#F59E0B', icon: Calendar },
        ].map((kpi) => (
          <div key={kpi.title} className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${kpi.color}15` }}>
              <kpi.icon size={20} style={{ color: kpi.color }} />
            </div>
            <div>
              <p className="text-xs text-[#475569] mb-1">{kpi.title}</p>
              <p className="text-xl font-semibold text-[#0F172A]">{kpi.value}</p>
              {kpi.sub && <p className="text-xs text-[#94A3B8]">{kpi.sub}</p>}
            </div>
          </div>
        ))}
      </div>

      {/* Backup Actions */}
      <div className="bg-white rounded-lg shadow-card p-4 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-[#0F172A]">手动备份</h3>
          <p className="text-xs text-[#94A3B8] mt-0.5">立即创建一份新的数据备份</p>
        </div>
        <button onClick={handleBackup} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors">
          <Plus size={15} /> 立即备份
        </button>
      </div>

      {/* Backup List */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="px-6 py-4 border-b border-[#E2E8F0]">
          <h3 className="text-sm font-semibold text-[#0F172A]">备份任务列表</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">备份名称</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">备份类型</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">数据范围</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">备份时间</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">文件大小</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-4 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {backups.map((bk) => (
                <tr key={bk.id} className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group">
                  <td className="px-4 py-3 text-sm text-[#0F172A]">{bk.name}</td>
                  <td className="px-4 py-3">
                    <Tag label={bk.type === 'full' ? '全量' : '增量'} color={bk.type === 'full' ? '#8B5CF6' : '#06B6D4'} bg={bk.type === 'full' ? '#F5F3FF' : '#ECFEFF'} />
                  </td>
                  <td className="px-4 py-3 text-sm text-[#475569]">{bk.scope}</td>
                  <td className="px-4 py-3 text-xs text-[#475569] font-mono">{bk.time}</td>
                  <td className="px-4 py-3 text-sm text-[#475569]">{bk.size}</td>
                  <td className="px-4 py-3">
                    {bk.status === 'success' && <Tag label="成功" color="#10B981" bg="#ECFDF5" />}
                    {bk.status === 'in_progress' && <Tag label="进行中" color="#2563EB" bg="#EFF6FF" />}
                    {bk.status === 'failed' && <Tag label="失败" color="#EF4444" bg="#FEF2F2" />}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="下载">
                        <Download size={13} className="text-[#475569]" />
                      </button>
                      <button onClick={() => setShowRestoreModal(bk)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="恢复">
                        <Upload size={13} className="text-[#2563EB]" />
                      </button>
                      <button className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="删除">
                        <Trash2 size={13} className="text-[#EF4444]" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Backup Strategy */}
      <SectionCard title="备份策略配置">
        <FormRow label="自动备份">
          <Switch checked={autoBackup} onChange={setAutoBackup} />
          <span className="ml-2 text-sm text-[#475569]">{autoBackup ? '开启' : '关闭'}</span>
        </FormRow>
        {autoBackup && (
          <>
            <FormRow label="备份周期">
              <div className="flex gap-3">
                {[
                  { key: 'daily', label: '每天' },
                  { key: 'weekly', label: '每周' },
                  { key: 'monthly', label: '每月' },
                ].map((opt) => (
                  <button
                    key={opt.key}
                    onClick={() => setBackupCycle(opt.key)}
                    className={cn(
                      'h-9 px-4 rounded-md text-sm border transition-colors',
                      backupCycle === opt.key
                        ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                        : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </FormRow>
            <FormRow label="备份时间">
              <input type="time" defaultValue="02:00" className="h-9 w-32 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]" />
            </FormRow>
            <FormRow label="备份类型">
              <div className="flex gap-3">
                {[
                  { key: 'full' as const, label: '全量' },
                  { key: 'incremental' as const, label: '增量' },
                ].map((opt) => (
                  <button
                    key={opt.key}
                    onClick={() => setBackupType(opt.key)}
                    className={cn(
                      'h-9 px-4 rounded-md text-sm border transition-colors',
                      backupType === opt.key
                        ? 'border-[#2563EB] bg-[#EFF6FF] text-[#2563EB]'
                        : 'border-[#E2E8F0] text-[#475569] hover:border-[#CBD5E1]'
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </FormRow>
            <FormRow label="保留数量">
              <NumberInput value={retentionCount} onChange={setRetentionCount} suffix="次" />
            </FormRow>
            <FormRow label="备份范围">
              <div className="flex flex-wrap gap-3">
                {['全部', '载具数据', '设备数据', '调拨数据', '报警数据', '用户数据', '系统配置'].map((scope) => (
                  <label key={scope} className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked={scope === '全部'} className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]" />
                    <span className="text-sm text-[#475569]">{scope}</span>
                  </label>
                ))}
              </div>
            </FormRow>
          </>
        )}
      </SectionCard>

      {/* Backup Progress Modal */}
      <AnimatePresence>
        {showBackupModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
              onClick={() => !isBackingUp && setShowBackupModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] bg-white rounded-xl shadow-modal z-50 p-6"
            >
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-[#EFF6FF] flex items-center justify-center mx-auto mb-4">
                  {isBackingUp ? <Database size={24} className="text-[#2563EB] animate-pulse" /> : <CheckCircle2 size={24} className="text-[#10B981]" />}
                </div>
                <h3 className="text-base font-semibold text-[#0F172A] mb-2">
                  {isBackingUp ? '正在备份...' : '备份完成'}
                </h3>
                <p className="text-sm text-[#94A3B8] mb-4">
                  {isBackingUp ? '请勿关闭页面，备份进行中' : '数据备份已成功完成'}
                </p>
                {/* Progress bar */}
                <div className="w-full h-2 bg-[#E2E8F0] rounded-full overflow-hidden mb-2">
                  <motion.div
                    className="h-full bg-[#2563EB] rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${backupProgress}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
                <p className="text-xs text-[#94A3B8]">{backupProgress}%</p>
                {!isBackingUp && (
                  <button
                    onClick={() => setShowBackupModal(false)}
                    className="mt-4 h-9 px-6 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] transition-colors"
                  >
                    确定
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Restore Confirm Modal */}
      <AnimatePresence>
        {showRestoreModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
              onClick={() => setShowRestoreModal(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[480px] bg-white rounded-xl shadow-modal z-50 flex flex-col"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
                <h3 className="text-base font-semibold text-[#0F172A]">数据恢复确认</h3>
                <button onClick={() => setShowRestoreModal(null)} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
                  <X size={18} className="text-[#94A3B8]" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="flex items-start gap-3 bg-[#FEF2F2] border border-[#FECACA] rounded-lg p-4">
                  <AlertTriangle size={20} className="text-[#EF4444] flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-[#EF4444]">警告：此操作不可撤销</p>
                    <p className="text-xs text-[#EF4444] mt-1">
                      恢复备份将覆盖当前系统中的所有数据。请在执行前确保已备份当前数据。
                    </p>
                  </div>
                </div>
                <div className="bg-[#F8FAFC] rounded-lg p-4">
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-[#475569]">备份名称</span>
                    <span className="text-sm text-[#0F172A]">{showRestoreModal.name}</span>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-[#475569]">备份时间</span>
                    <span className="text-sm text-[#0F172A]">{showRestoreModal.time}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-[#475569]">文件大小</span>
                    <span className="text-sm text-[#0F172A]">{showRestoreModal.size}</span>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#0F172A] mb-2">
                    请输入"确认恢复"以继续
                  </label>
                  <input
                    value={restoreConfirmText}
                    onChange={(e) => setRestoreConfirmText(e.target.value)}
                    placeholder="确认恢复"
                    className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                  />
                </div>
              </div>
              <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
                <button onClick={() => setShowRestoreModal(null)} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
                <button onClick={handleRestore} className="h-9 px-4 rounded-md bg-[#EF4444] text-white text-sm hover:bg-[#DC2626] flex items-center gap-2 transition-colors">
                  <Upload size={14} /> 确认恢复
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function SystemSettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>('alarm-threshold');

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-[#0F172A]">系统管理</h1>
      </div>

      {/* Two-column layout: nav + content */}
      <div className="flex gap-5">
        {/* Left Navigation */}
        <nav className="w-[200px] bg-white rounded-lg shadow-card flex-shrink-0 self-start overflow-hidden">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors text-left',
                activeTab === item.key
                  ? 'bg-[#EFF6FF] text-[#2563EB]'
                  : 'text-[#475569] hover:bg-[#F8FAFC]'
              )}
              style={activeTab === item.key ? { borderLeft: '3px solid #2563EB' } : { borderLeft: '3px solid transparent' }}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right Content */}
        <div className="flex-1 min-w-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'alarm-threshold' && <AlarmThresholdTab />}
              {activeTab === 'system-params' && <SystemParamsTab />}
              {activeTab === 'operation-logs' && <OperationLogsTab />}
              {activeTab === 'data-backup' && <DataBackupTab />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
