import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Smartphone, Upload, CheckCircle, TrendingUp,
  Percent, FileCode, Layers, Server, Shield, Activity,
} from 'lucide-react';
import {
  firmwareVersions, deviceTypes,
} from './iot-ota/types';
import FirmwareLibrary from './iot-ota/FirmwareLibrary';
import UpgradeTaskManager from './iot-ota/UpgradeTaskManager';
import DiffUpgradePanel from './iot-ota/DiffUpgradePanel';
import UpgradeMonitoring from './iot-ota/UpgradeMonitoring';

export default function IotOTAMgmtTab() {
  const [activeTab, setActiveTab] = useState('firmware');

  // KPI Calculations
  const totalFirmwares = firmwareVersions.length;
  const todayUpgraded = 47;
  const upgradeSuccessRate = 98.2;
  const pendingDevices = 1568;

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0 }}
        >
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-neutral-textSecondary mb-1">固件版本总数</p>
                  <p className="text-2xl font-bold text-neutral-textPrimary font-number">{totalFirmwares}</p>
                  <p className="text-xs text-neutral-textTertiary mt-1">覆盖 {deviceTypes.length} 种设备类型</p>
                </div>
                <div className="w-11 h-11 rounded-lg bg-primary-light flex items-center justify-center">
                  <FileCode size={20} className="text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-neutral-textSecondary mb-1">今日升级设备数</p>
                  <p className="text-2xl font-bold text-neutral-textPrimary font-number">{todayUpgraded}</p>
                  <p className="text-xs text-success mt-1 flex items-center gap-1">
                    <TrendingUp size={10} /> +12 较昨日
                  </p>
                </div>
                <div className="w-11 h-11 rounded-lg bg-success-light flex items-center justify-center">
                  <Smartphone size={20} className="text-success" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-neutral-textSecondary mb-1">升级成功率</p>
                  <p className="text-2xl font-bold text-neutral-textPrimary font-number">{upgradeSuccessRate}%</p>
                  <p className="text-xs text-success mt-1 flex items-center gap-1">
                    <CheckCircle size={10} /> 行业领先
                  </p>
                </div>
                <div className="w-11 h-11 rounded-lg bg-success-light flex items-center justify-center">
                  <Percent size={20} className="text-success" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-neutral-textSecondary mb-1">待升级设备数</p>
                  <p className="text-2xl font-bold text-warning font-number">{pendingDevices.toLocaleString()}</p>
                  <p className="text-xs text-neutral-textTertiary mt-1">分布于 4 个升级任务</p>
                </div>
                <div className="w-11 h-11 rounded-lg bg-warning-light flex items-center justify-center">
                  <Upload size={20} className="text-warning" />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-neutral-surface border border-neutral-border h-9">
          <TabsTrigger value="firmware" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-white">
            <Layers size={13} className="mr-1" />
            固件版本库
          </TabsTrigger>
          <TabsTrigger value="tasks" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-white">
            <Server size={13} className="mr-1" />
            升级任务
          </TabsTrigger>
          <TabsTrigger value="diff" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-white">
            <Shield size={13} className="mr-1" />
            差分与保护
          </TabsTrigger>
          <TabsTrigger value="monitor" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-white">
            <Activity size={13} className="mr-1" />
            升级监控
          </TabsTrigger>
        </TabsList>

        <TabsContent value="firmware">
          <FirmwareLibrary />
        </TabsContent>

        <TabsContent value="tasks">
          <UpgradeTaskManager />
        </TabsContent>

        <TabsContent value="diff">
          <DiffUpgradePanel />
        </TabsContent>

        <TabsContent value="monitor">
          <UpgradeMonitoring />
        </TabsContent>
      </Tabs>
    </div>
  );
}
