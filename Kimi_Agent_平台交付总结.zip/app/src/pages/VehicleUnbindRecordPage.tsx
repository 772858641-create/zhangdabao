import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter, DrawerClose,
} from "@/components/ui/drawer";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Truck, ClipboardList, CheckCircle, XCircle, Clock, RotateCcw,
  Search, Plus, Eye, History, FileText, AlertTriangle, TrendingUp,
  Filter, Calendar, User, MapPin, Shield,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ==================== Types ====================
interface BindHistoryItem {
  id: string;
  carrierName: string;
  carrierNo: string;
  bindTime: string;
  unbindTime?: string;
  status: string;
}

interface AuditRecord {
  id: string;
  auditor: string;
  auditTime: string;
  result: "approved" | "rejected";
  remark: string;
}

interface VehicleUnbindRecord {
  id: string;
  applyNo: string;
  plateNo: string;
  vehicleType: string;
  brand: string;
  model: string;
  vin: string;
  currentCarrier: string;
  carrierNo: string;
  reason: string;
  remark: string;
  applicant: string;
  applyTime: string;
  status: "pending" | "approved" | "rejected" | "revoked";
  auditTime?: string;
  auditor?: string;
  auditRemark?: string;
  bindHistory: BindHistoryItem[];
  auditRecords: AuditRecord[];
}

// ==================== Mock Data ====================
const mockRecords: VehicleUnbindRecord[] = [
  {
    id: "UB001",
    applyNo: "UB-20250601-001",
    plateNo: "沪A·B12345",
    vehicleType: "厢式货车",
    brand: "东风",
    model: "天锦KR 6.8米",
    vin: "LGAX2B130K1001234",
    currentCarrier: "华东物流-上海仓",
    carrierNo: "CAR-2024-0892",
    reason: "车辆报废",
    remark: "车辆行驶里程已达80万公里，发动机严重老化，维修成本过高，申请报废解绑。",
    applicant: "王建国",
    applyTime: "2025-06-01 09:30",
    status: "pending",
    bindHistory: [
      { id: "BH001", carrierName: "华东物流-上海仓", carrierNo: "CAR-2024-0892", bindTime: "2024-03-15 10:00", status: "当前绑定" },
      { id: "BH002", carrierName: "华东物流-杭州分仓", carrierNo: "CAR-2023-0156", bindTime: "2023-01-10 09:00", unbindTime: "2024-03-14 18:00", status: "已解绑" },
    ],
    auditRecords: [],
  },
  {
    id: "UB002",
    applyNo: "UB-20250601-002",
    plateNo: "京C·D67890",
    vehicleType: "冷藏车",
    brand: "福田",
    model: "欧马可S5 4.2米",
    vin: "LVBV3JBB5KY012345",
    currentCarrier: "华北冷链-北京仓",
    carrierNo: "CAR-2024-1023",
    reason: "车辆出售",
    remark: "因业务调整，将该冷藏车出售给第三方物流公司，需解除与现有载具绑定。",
    applicant: "李明辉",
    applyTime: "2025-06-01 11:15",
    status: "pending",
    bindHistory: [
      { id: "BH003", carrierName: "华北冷链-北京仓", carrierNo: "CAR-2024-1023", bindTime: "2024-06-01 08:30", status: "当前绑定" },
    ],
    auditRecords: [],
  },
  {
    id: "UB003",
    applyNo: "UB-20250601-003",
    plateNo: "粤B·E24680",
    vehicleType: "平板车",
    brand: "解放",
    model: "J6P 9.6米",
    vin: "LFWNDULD8K1A23456",
    currentCarrier: "华南运输-深圳仓",
    carrierNo: "CAR-2024-0556",
    reason: "合同到期",
    remark: "与华南运输公司的合作协议于2025-05-31到期，不再续约，申请解绑。",
    applicant: "张伟",
    applyTime: "2025-06-01 14:00",
    status: "pending",
    bindHistory: [
      { id: "BH004", carrierName: "华南运输-深圳仓", carrierNo: "CAR-2024-0556", bindTime: "2024-01-01 00:00", status: "当前绑定" },
      { id: "BH005", carrierName: "华南运输-东莞仓", carrierNo: "CAR-2023-0321", bindTime: "2022-07-15 10:00", unbindTime: "2023-12-31 18:00", status: "已解绑" },
    ],
    auditRecords: [],
  },
  {
    id: "UB004",
    applyNo: "UB-20250528-004",
    plateNo: "苏D·F13579",
    vehicleType: "集装箱车",
    brand: "重汽",
    model: "汕德卡C7H",
    vin: "LZZ1BBSF8KW345678",
    currentCarrier: "华东港口-宁波仓",
    carrierNo: "CAR-2024-0678",
    reason: "故障停用",
    remark: "车辆变速箱损坏，预计维修周期2个月，期间暂停运营，申请临时解绑。",
    applicant: "陈秀英",
    applyTime: "2025-05-28 10:20",
    status: "approved",
    auditTime: "2025-05-29 09:00",
    auditor: "刘审批",
    auditRemark: "同意临时解绑，维修完成后需重新申请绑定。",
    bindHistory: [
      { id: "BH006", carrierName: "华东港口-宁波仓", carrierNo: "CAR-2024-0678", bindTime: "2024-02-20 11:00", status: "当前绑定" },
    ],
    auditRecords: [
      { id: "AR001", auditor: "刘审批", auditTime: "2025-05-29 09:00", result: "approved", remark: "同意临时解绑，维修完成后需重新申请绑定。" },
    ],
  },
  {
    id: "UB005",
    applyNo: "UB-20250528-005",
    plateNo: "浙A·G97531",
    vehicleType: "厢式货车",
    brand: "江淮",
    model: "格尔发K7 7.8米",
    vin: "LJ11R4BD8K9012345",
    currentCarrier: "华东物流-杭州仓",
    carrierNo: "CAR-2024-0789",
    reason: "调配其他项目",
    remark: "因公司新中标西南物流项目，需将该车辆调配至成都分公司运营。",
    applicant: "赵磊",
    applyTime: "2025-05-28 16:45",
    status: "approved",
    auditTime: "2025-05-29 11:30",
    auditor: "王审批",
    auditRemark: "同意调配，请做好交接手续。",
    bindHistory: [
      { id: "BH007", carrierName: "华东物流-杭州仓", carrierNo: "CAR-2024-0789", bindTime: "2024-04-10 09:00", status: "当前绑定" },
      { id: "BH008", carrierName: "华东物流-苏州仓", carrierNo: "CAR-2023-0456", bindTime: "2023-03-01 10:00", unbindTime: "2024-04-09 18:00", status: "已解绑" },
    ],
    auditRecords: [
      { id: "AR002", auditor: "王审批", auditTime: "2025-05-29 11:30", result: "approved", remark: "同意调配，请做好交接手续。" },
    ],
  },
  {
    id: "UB006",
    applyNo: "UB-20250527-006",
    plateNo: "鲁B·H86420",
    vehicleType: "冷藏车",
    brand: "东风",
    model: "天龙KL 6.8米冷藏",
    vin: "LGAX4B357K1009876",
    currentCarrier: "华北冷链-青岛仓",
    carrierNo: "CAR-2024-0912",
    reason: "车辆报废",
    remark: "车龄已满8年，冷藏机组制冷效果严重下降，无法满足药品运输温控要求。",
    applicant: "孙丽",
    applyTime: "2025-05-27 08:00",
    status: "approved",
    auditTime: "2025-05-28 10:00",
    auditor: "钱审批",
    auditRemark: "符合报废条件，同意解绑。",
    bindHistory: [
      { id: "BH009", carrierName: "华北冷链-青岛仓", carrierNo: "CAR-2024-0912", bindTime: "2024-05-01 08:00", status: "当前绑定" },
    ],
    auditRecords: [
      { id: "AR003", auditor: "钱审批", auditTime: "2025-05-28 10:00", result: "approved", remark: "符合报废条件，同意解绑。" },
    ],
  },
  {
    id: "UB007",
    applyNo: "UB-20250527-007",
    plateNo: "川A·J54321",
    vehicleType: "平板车",
    brand: "陕汽",
    model: "德龙X5000 8.6米",
    vin: "LZGJL4M43K0123456",
    currentCarrier: "西南运输-成都仓",
    carrierNo: "CAR-2024-0334",
    reason: "合同到期",
    remark: "与客户的年度运输合同已到期，客户不再续约，申请解绑该车。",
    applicant: "周杰",
    applyTime: "2025-05-27 13:20",
    status: "approved",
    auditTime: "2025-05-28 14:00",
    auditor: "吴审批",
    auditRemark: "合同到期属实，同意解绑。",
    bindHistory: [
      { id: "BH010", carrierName: "西南运输-成都仓", carrierNo: "CAR-2024-0334", bindTime: "2024-01-15 09:00", status: "当前绑定" },
      { id: "BH011", carrierName: "西南运输-重庆仓", carrierNo: "CAR-2023-0112", bindTime: "2022-08-20 10:00", unbindTime: "2023-12-31 18:00", status: "已解绑" },
    ],
    auditRecords: [
      { id: "AR004", auditor: "吴审批", auditTime: "2025-05-28 14:00", result: "approved", remark: "合同到期属实，同意解绑。" },
    ],
  },
  {
    id: "UB008",
    applyNo: "UB-20250526-008",
    plateNo: "闽C·K98765",
    vehicleType: "集装箱车",
    brand: "解放",
    model: "JH6 6×4牵引车",
    vin: "LFWNJ9DN8K1234567",
    currentCarrier: "东南港口-厦门仓",
    carrierNo: "CAR-2024-0445",
    reason: "故障停用",
    remark: "车辆发生严重交通事故，车架变形，经评估不具备修复价值。",
    applicant: "吴敏",
    applyTime: "2025-05-26 15:00",
    status: "rejected",
    auditTime: "2025-05-27 09:30",
    auditor: "郑审批",
    auditRemark: "建议先走保险理赔流程，暂不解绑。",
    bindHistory: [
      { id: "BH012", carrierName: "东南港口-厦门仓", carrierNo: "CAR-2024-0445", bindTime: "2024-02-01 08:00", status: "当前绑定" },
    ],
    auditRecords: [
      { id: "AR005", auditor: "郑审批", auditTime: "2025-05-27 09:30", result: "rejected", remark: "建议先走保险理赔流程，暂不解绑。" },
    ],
  },
  {
    id: "UB009",
    applyNo: "UB-20250525-009",
    plateNo: "津A·L11111",
    vehicleType: "厢式货车",
    brand: "福田",
    model: "奥铃CTS 4.2米",
    vin: "LVBV3PBB2KY123456",
    currentCarrier: "华北物流-天津仓",
    carrierNo: "CAR-2024-0567",
    reason: "车辆出售",
    remark: "车辆性能良好，因业务转型不再需要该吨位车辆，拟对外出售。",
    applicant: "郑华",
    applyTime: "2025-05-25 11:00",
    status: "rejected",
    auditTime: "2025-05-26 10:00",
    auditor: "陈审批",
    auditRemark: "该车辆使用频率较高，建议内部调拨而非出售，驳回。",
    bindHistory: [
      { id: "BH013", carrierName: "华北物流-天津仓", carrierNo: "CAR-2024-0567", bindTime: "2024-03-10 09:00", status: "当前绑定" },
      { id: "BH014", carrierName: "华北物流-北京仓", carrierNo: "CAR-2023-0789", bindTime: "2023-02-15 10:00", unbindTime: "2024-03-09 18:00", status: "已解绑" },
    ],
    auditRecords: [
      { id: "AR006", auditor: "陈审批", auditTime: "2025-05-26 10:00", result: "rejected", remark: "该车辆使用频率较高，建议内部调拨而非出售，驳回。" },
    ],
  },
  {
    id: "UB010",
    applyNo: "UB-20250524-010",
    plateNo: "鄂A·M22222",
    vehicleType: "冷藏车",
    brand: "重汽",
    model: "豪沃T7H 7.6米冷藏",
    vin: "LZZ1BBSF0KW765432",
    currentCarrier: "华中冷链-武汉仓",
    carrierNo: "CAR-2024-0234",
    reason: "调配其他项目",
    remark: "因个人原因申请撤销解绑申请，继续原项目运营。",
    applicant: "刘洋",
    applyTime: "2025-05-24 09:00",
    status: "revoked",
    bindHistory: [
      { id: "BH015", carrierName: "华中冷链-武汉仓", carrierNo: "CAR-2024-0234", bindTime: "2024-01-20 08:00", status: "当前绑定" },
    ],
    auditRecords: [],
  },
  {
    id: "UB011",
    applyNo: "UB-20250523-011",
    plateNo: "陕A·N33333",
    vehicleType: "平板车",
    brand: "东风",
    model: "天龙旗舰 8.6米",
    vin: "LGAX2B130K1005678",
    currentCarrier: "西北运输-西安仓",
    carrierNo: "CAR-2024-0123",
    reason: "合同到期",
    remark: "与承运商的代理协议到期，收回自营，申请解绑原绑定关系。",
    applicant: "钱七",
    applyTime: "2025-05-23 14:30",
    status: "approved",
    auditTime: "2025-05-24 11:00",
    auditor: "赵审批",
    auditRemark: "同意解绑，请做好自营交接准备。",
    bindHistory: [
      { id: "BH016", carrierName: "西北运输-西安仓", carrierNo: "CAR-2024-0123", bindTime: "2024-02-10 09:00", status: "当前绑定" },
    ],
    auditRecords: [
      { id: "AR007", auditor: "赵审批", auditTime: "2025-05-24 11:00", result: "approved", remark: "同意解绑，请做好自营交接准备。" },
    ],
  },
];

const availableVehicles = [
  { plateNo: "沪A·B12345", brand: "东风", model: "天锦KR 6.8米", type: "厢式货车" },
  { plateNo: "京C·D67890", brand: "福田", model: "欧马可S5 4.2米", type: "冷藏车" },
  { plateNo: "粤B·E24680", brand: "解放", model: "J6P 9.6米", type: "平板车" },
  { plateNo: "苏D·F13579", brand: "重汽", model: "汕德卡C7H", type: "集装箱车" },
  { plateNo: "浙A·G97531", brand: "江淮", model: "格尔发K7 7.8米", type: "厢式货车" },
  { plateNo: "鲁B·H86420", brand: "东风", model: "天龙KL 6.8米冷藏", type: "冷藏车" },
];

// ==================== Helpers ====================
function getStatusBadge(status: string) {
  switch (status) {
    case "pending":
      return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">待审批</Badge>;
    case "approved":
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">已通过</Badge>;
    case "rejected":
      return <Badge className="bg-red-100 text-red-700 hover:bg-red-100 border-red-200">已拒绝</Badge>;
    case "revoked":
      return <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100 border-slate-200">已撤销</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case "pending": return Clock;
    case "approved": return CheckCircle;
    case "rejected": return XCircle;
    case "revoked": return RotateCcw;
    default: return FileText;
  }
}

function getStatusColor(status: string) {
  switch (status) {
    case "pending": return "text-amber-600 bg-amber-50 border-amber-200";
    case "approved": return "text-emerald-600 bg-emerald-50 border-emerald-200";
    case "rejected": return "text-red-600 bg-red-50 border-red-200";
    case "revoked": return "text-slate-500 bg-slate-50 border-slate-200";
    default: return "text-slate-500 bg-slate-50";
  }
}

function getReasonLabel(reason: string) {
  const map: Record<string, string> = {
    "车辆报废": "车辆报废",
    "车辆出售": "车辆出售",
    "合同到期": "合同到期",
    "故障停用": "故障停用",
    "调配其他项目": "调配其他项目",
  };
  return map[reason] || reason;
}

// ==================== Main Component ====================
export default function VehicleUnbindRecordPage() {
  const [records, setRecords] = useState<VehicleUnbindRecord[]>(mockRecords);
  const [searchPlate, setSearchPlate] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterReason, setFilterReason] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  // Detail drawer
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<VehicleUnbindRecord | null>(null);

  // Audit dialogs
  const [approveOpen, setApproveOpen] = useState(false);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [auditRemark, setAuditRemark] = useState("");

  // Create dialog
  const [createOpen, setCreateOpen] = useState(false);
  const [newVehicle, setNewVehicle] = useState("");
  const [newReason, setNewReason] = useState("");
  const [newRemark, setNewRemark] = useState("");

  // Stats
  const stats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const monthCount = records.filter(r => {
      const d = new Date(r.applyTime);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    }).length;
    const pendingCount = records.filter(r => r.status === "pending").length;
    const total = records.length;
    const approvedCount = records.filter(r => r.status === "approved").length;
    const rate = total > 0 ? Math.round((approvedCount / total) * 100) : 0;
    return { total, monthCount, pendingCount, rate };
  }, [records]);

  // Filtered records
  const filtered = useMemo(() => {
    return records.filter(r => {
      const matchPlate = !searchPlate || r.plateNo.includes(searchPlate);
      const matchStatus = filterStatus === "all" || r.status === filterStatus;
      const matchReason = filterReason === "all" || r.reason === filterReason;
      const matchDate = (!dateFrom || r.applyTime >= dateFrom) && (!dateTo || r.applyTime <= dateTo + " 23:59");
      return matchPlate && matchStatus && matchReason && matchDate;
    });
  }, [records, searchPlate, filterStatus, filterReason, dateFrom, dateTo]);

  const openDetail = (r: VehicleUnbindRecord) => {
    setSelectedRecord(r);
    setDetailOpen(true);
  };

  const openApprove = (r: VehicleUnbindRecord) => {
    setSelectedRecord(r);
    setAuditRemark("");
    setApproveOpen(true);
  };

  const openReject = (r: VehicleUnbindRecord) => {
    setSelectedRecord(r);
    setAuditRemark("");
    setRejectOpen(true);
  };

  const confirmApprove = () => {
    if (!selectedRecord) return;
    setRecords(prev => prev.map(r => {
      if (r.id !== selectedRecord.id) return r;
      return {
        ...r,
        status: "approved" as const,
        auditTime: new Date().toISOString().slice(0, 16).replace("T", " "),
        auditor: "当前用户",
        auditRemark: auditRemark || "同意",
        auditRecords: [
          ...r.auditRecords,
          { id: `AR-${Date.now()}`, auditor: "当前用户", auditTime: new Date().toISOString().slice(0, 16).replace("T", " "), result: "approved" as const, remark: auditRemark || "同意" },
        ],
      };
    }));
    setApproveOpen(false);
  };

  const confirmReject = () => {
    if (!selectedRecord) return;
    setRecords(prev => prev.map(r => {
      if (r.id !== selectedRecord.id) return r;
      return {
        ...r,
        status: "rejected" as const,
        auditTime: new Date().toISOString().slice(0, 16).replace("T", " "),
        auditor: "当前用户",
        auditRemark: auditRemark || "驳回",
        auditRecords: [
          ...r.auditRecords,
          { id: `AR-${Date.now()}`, auditor: "当前用户", auditTime: new Date().toISOString().slice(0, 16).replace("T", " "), result: "rejected" as const, remark: auditRemark || "驳回" },
        ],
      };
    }));
    setRejectOpen(false);
  };

  const submitCreate = () => {
    if (!newVehicle || !newReason) return;
    const vehicle = availableVehicles.find(v => v.plateNo === newVehicle);
    const newRecord: VehicleUnbindRecord = {
      id: `UB${Date.now()}`,
      applyNo: `UB-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${String(records.length + 1).padStart(3, "0")}`,
      plateNo: vehicle?.plateNo || newVehicle,
      vehicleType: vehicle?.type || "厢式货车",
      brand: vehicle?.brand || "未知",
      model: vehicle?.model || "未知",
      vin: `VIN${Date.now()}`,
      currentCarrier: "待分配",
      carrierNo: "-",
      reason: newReason,
      remark: newRemark,
      applicant: "当前用户",
      applyTime: new Date().toISOString().slice(0, 16).replace("T", " "),
      status: "pending",
      bindHistory: [],
      auditRecords: [],
    };
    setRecords(prev => [newRecord, ...prev]);
    setCreateOpen(false);
    setNewVehicle("");
    setNewReason("");
    setNewRemark("");
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--color-text-primary)]">车辆解绑记录</h1>
          <p className="text-sm text-[var(--color-text-secondary)] mt-1">解绑申请 · 审批管理 · 历史查询 · 详情追溯</p>
        </div>
        <Button size="sm" onClick={() => { setNewVehicle(""); setNewReason(""); setNewRemark(""); setCreateOpen(true); }}>
          <Plus className="w-4 h-4 mr-1" />新建解绑申请
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "总解绑记录", value: stats.total, icon: ClipboardList, color: "text-blue-600", bg: "bg-blue-50", border: "border-blue-100" },
          { label: "本月解绑", value: stats.monthCount, icon: Calendar, color: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-100" },
          { label: "待审批", value: stats.pendingCount, icon: Clock, color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-100" },
          { label: "解绑通过率", value: `${stats.rate}%`, icon: TrendingUp, color: "text-purple-600", bg: "bg-purple-50", border: "border-purple-100" },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}>
            <Card className={cn("border", s.border)}>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center shrink-0", s.bg)}>
                  <s.icon className={cn("w-5 h-5", s.color)} />
                </div>
                <div className="min-w-0">
                  <div className="text-sm text-[var(--color-text-secondary)]">{s.label}</div>
                  <div className={cn("text-xl font-bold font-number tracking-tight", s.color)}>{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Filter & Search */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.4 }}>
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div className="flex-1 min-w-[200px] max-w-xs">
                <Label className="text-xs text-[var(--color-text-secondary)] mb-1.5 block">车牌号</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--color-text-tertiary)]" />
                  <Input placeholder="搜索车牌号..." value={searchPlate} onChange={e => setSearchPlate(e.target.value)} className="pl-9 h-9" />
                </div>
              </div>
              <div className="w-40">
                <Label className="text-xs text-[var(--color-text-secondary)] mb-1.5 block">申请时间（起）</Label>
                <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="h-9" />
              </div>
              <div className="w-40">
                <Label className="text-xs text-[var(--color-text-secondary)] mb-1.5 block">申请时间（止）</Label>
                <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="h-9" />
              </div>
              <div className="w-44">
                <Label className="text-xs text-[var(--color-text-secondary)] mb-1.5 block">解绑原因</Label>
                <Select value={filterReason} onValueChange={setFilterReason}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="全部原因" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部原因</SelectItem>
                    <SelectItem value="车辆报废">车辆报废</SelectItem>
                    <SelectItem value="车辆出售">车辆出售</SelectItem>
                    <SelectItem value="合同到期">合同到期</SelectItem>
                    <SelectItem value="故障停用">故障停用</SelectItem>
                    <SelectItem value="调配其他项目">调配其他项目</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-40">
                <Label className="text-xs text-[var(--color-text-secondary)] mb-1.5 block">状态</Label>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="全部状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="pending">待审批</SelectItem>
                    <SelectItem value="approved">已通过</SelectItem>
                    <SelectItem value="rejected">已拒绝</SelectItem>
                    <SelectItem value="revoked">已撤销</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button variant="outline" size="sm" className="h-9" onClick={() => { setSearchPlate(""); setDateFrom(""); setDateTo(""); setFilterReason("all"); setFilterStatus("all"); }}>
                <Filter className="w-4 h-4 mr-1" />重置
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.4 }}>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-[var(--color-text-secondary)]" />
              解绑申请列表
              <span className="text-xs font-normal text-[var(--color-text-tertiary)] ml-1">共 {filtered.length} 条</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--color-surface-elevated)] hover:bg-[var(--color-surface-elevated)]">
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">申请编号</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">车牌号</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">车辆类型</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">当前绑定载具</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">申请原因</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">申请人</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">申请时间</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap">状态</TableHead>
                    <TableHead className="text-[var(--color-text-secondary)] text-xs font-medium whitespace-nowrap text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <AnimatePresence>
                    {filtered.map((r, idx) => (
                        <motion.tr
                          key={r.id}
                          initial={{ opacity: 0, y: 6 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -6 }}
                          transition={{ delay: idx * 0.03, duration: 0.25 }}
                          className="border-b hover:bg-[var(--color-surface-elevated)] transition-colors"
                        >
                          <TableCell className="font-medium text-[var(--color-text-primary)] text-sm whitespace-nowrap">{r.applyNo}</TableCell>
                          <TableCell className="text-[var(--color-text-primary)] text-sm whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <Truck className="w-3.5 h-3.5 text-[var(--color-text-tertiary)]" />
                              {r.plateNo}
                            </div>
                          </TableCell>
                          <TableCell className="text-[var(--color-text-secondary)] text-sm whitespace-nowrap">{r.vehicleType}</TableCell>
                          <TableCell className="text-[var(--color-text-secondary)] text-sm whitespace-nowrap">
                            <div className="flex flex-col">
                              <span>{r.currentCarrier}</span>
                              <span className="text-xs text-[var(--color-text-tertiary)]">{r.carrierNo}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-[var(--color-text-secondary)] text-sm whitespace-nowrap">
                            <Badge variant="outline" className="font-normal">{getReasonLabel(r.reason)}</Badge>
                          </TableCell>
                          <TableCell className="text-[var(--color-text-secondary)] text-sm whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-[var(--color-text-tertiary)]" />
                              {r.applicant}
                            </div>
                          </TableCell>
                          <TableCell className="text-[var(--color-text-secondary)] text-sm whitespace-nowrap">{r.applyTime}</TableCell>
                          <TableCell className="whitespace-nowrap">{getStatusBadge(r.status)}</TableCell>
                          <TableCell className="text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1">
                              <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => openDetail(r)}>
                                <Eye className="w-3.5 h-3.5 mr-1" />详情
                              </Button>
                              {r.status === "pending" && (
                                <>
                                  <Button variant="ghost" size="sm" className="h-7 px-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50" onClick={() => openApprove(r)}>
                                    <CheckCircle className="w-3.5 h-3.5 mr-1" />通过
                                  </Button>
                                  <Button variant="ghost" size="sm" className="h-7 px-2 text-red-500 hover:text-red-600 hover:bg-red-50" onClick={() => openReject(r)}>
                                    <XCircle className="w-3.5 h-3.5 mr-1" />拒绝
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </motion.tr>
                    ))}
                  </AnimatePresence>
                  {filtered.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center py-12 text-[var(--color-text-tertiary)]">
                        <FileText className="w-10 h-10 mx-auto mb-2 opacity-40" />
                        <p>暂无符合条件的解绑记录</p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* ========== Detail Drawer ========== */}
      <Drawer open={detailOpen} onOpenChange={setDetailOpen} direction="right">
        <DrawerContent className="w-full sm:max-w-lg">
          <DrawerHeader className="border-b pb-4">
            <DrawerTitle className="flex items-center gap-2 text-lg">
              <FileText className="w-5 h-5 text-[var(--color-primary)]" />
              解绑申请详情
            </DrawerTitle>
            <DrawerDescription className="text-[var(--color-text-secondary)]">
              {selectedRecord?.applyNo}
            </DrawerDescription>
          </DrawerHeader>
          {selectedRecord && (
            <ScrollArea className="flex-1 overflow-y-auto">
              <div className="p-5 space-y-6">
                {/* Status banner */}
                <div className={cn("flex items-center gap-3 rounded-lg border p-3", getStatusColor(selectedRecord.status))}>
                  {(() => {
                    const Icon = getStatusIcon(selectedRecord.status);
                    return <Icon className="w-5 h-5 shrink-0" />;
                  })()}
                  <div>
                    <div className="text-sm font-medium">
                      {selectedRecord.status === "pending" && "待审批"}
                      {selectedRecord.status === "approved" && "已通过"}
                      {selectedRecord.status === "rejected" && "已拒绝"}
                      {selectedRecord.status === "revoked" && "已撤销"}
                    </div>
                    <div className="text-xs opacity-80">
                      {selectedRecord.status === "pending" && "该申请正在等待审批，请尽快处理"}
                      {selectedRecord.status === "approved" && `审批人：${selectedRecord.auditor} · ${selectedRecord.auditTime}`}
                      {selectedRecord.status === "rejected" && `审批人：${selectedRecord.auditor} · ${selectedRecord.auditTime}`}
                      {selectedRecord.status === "revoked" && "该申请已由申请人主动撤销"}
                    </div>
                  </div>
                </div>

                {/* Vehicle basic info */}
                <div>
                  <h3 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2 mb-3">
                    <Truck className="w-4 h-4 text-[var(--color-text-secondary)]" />车辆基本信息
                  </h3>
                  <div className="grid grid-cols-2 gap-3 rounded-lg border bg-[var(--color-surface)] p-4">
                    <div>
                      <div className="text-xs text-[var(--color-text-tertiary)]">车牌号</div>
                      <div className="text-sm font-medium text-[var(--color-text-primary)]">{selectedRecord.plateNo}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--color-text-tertiary)]">车辆类型</div>
                      <div className="text-sm font-medium text-[var(--color-text-primary)]">{selectedRecord.vehicleType}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--color-text-tertiary)]">品牌</div>
                      <div className="text-sm font-medium text-[var(--color-text-primary)]">{selectedRecord.brand}</div>
                    </div>
                    <div>
                      <div className="text-xs text-[var(--color-text-tertiary)]">型号</div>
                      <div className="text-sm font-medium text-[var(--color-text-primary)]">{selectedRecord.model}</div>
                    </div>
                    <div className="col-span-2">
                      <div className="text-xs text-[var(--color-text-tertiary)]">VIN码</div>
                      <div className="text-sm font-medium text-[var(--color-text-primary)] font-mono">{selectedRecord.vin}</div>
                    </div>
                  </div>
                </div>

                {/* Current carrier */}
                <div>
                  <h3 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2 mb-3">
                    <MapPin className="w-4 h-4 text-[var(--color-text-secondary)]" />当前绑定载具信息
                  </h3>
                  <div className="rounded-lg border bg-[var(--color-surface)] p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[var(--color-text-tertiary)]">载具名称</span>
                      <span className="text-sm font-medium text-[var(--color-text-primary)]">{selectedRecord.currentCarrier}</span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[var(--color-text-tertiary)]">载具编号</span>
                      <span className="text-sm font-medium text-[var(--color-text-primary)] font-mono">{selectedRecord.carrierNo}</span>
                    </div>
                  </div>
                </div>

                {/* Bind history timeline */}
                <div>
                  <h3 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2 mb-3">
                    <History className="w-4 h-4 text-[var(--color-text-secondary)]" />绑定历史
                  </h3>
                  <div className="space-y-0">
                    {selectedRecord.bindHistory.length === 0 && (
                      <div className="text-sm text-[var(--color-text-tertiary)] py-2">暂无绑定历史记录</div>
                    )}
                    {selectedRecord.bindHistory.map((h, i) => (
                      <div key={h.id} className="relative pl-5 pb-4 last:pb-0">
                        {i !== selectedRecord.bindHistory.length - 1 && (
                          <div className="absolute left-[7px] top-3 bottom-0 w-px bg-[var(--color-border)]" />
                        )}
                        <div className={cn("absolute left-0 top-1.5 w-[15px] h-[15px] rounded-full border-2", h.status === "当前绑定" ? "bg-emerald-500 border-emerald-200" : "bg-slate-300 border-slate-200")} />
                        <div className="text-sm font-medium text-[var(--color-text-primary)]">{h.carrierName}</div>
                        <div className="text-xs text-[var(--color-text-tertiary)] mt-0.5">编号：{h.carrierNo}</div>
                        <div className="text-xs text-[var(--color-text-tertiary)] mt-0.5">
                          绑定：{h.bindTime}
                          {h.unbindTime && ` · 解绑：${h.unbindTime}`}
                        </div>
                        <Badge variant="outline" className="mt-1 text-xs h-5 px-1.5">
                          {h.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Unbind reason */}
                <div>
                  <h3 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-4 h-4 text-[var(--color-text-secondary)]" />解绑原因说明
                  </h3>
                  <div className="rounded-lg border bg-[var(--color-surface)] p-4 space-y-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{getReasonLabel(selectedRecord.reason)}</Badge>
                    </div>
                    <p className="text-sm text-[var(--color-text-secondary)] leading-relaxed">{selectedRecord.remark}</p>
                  </div>
                </div>

                {/* Audit records */}
                {selectedRecord.auditRecords.length > 0 && (
                  <div>
                    <h3 className="text-sm font-semibold text-[var(--color-text-primary)] flex items-center gap-2 mb-3">
                      <Shield className="w-4 h-4 text-[var(--color-text-secondary)]" />审批记录
                    </h3>
                    <div className="space-y-3">
                      {selectedRecord.auditRecords.map((ar) => (
                        <div key={ar.id} className="rounded-lg border bg-[var(--color-surface)] p-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <User className="w-3.5 h-3.5 text-[var(--color-text-tertiary)]" />
                              <span className="text-sm font-medium text-[var(--color-text-primary)]">{ar.auditor}</span>
                            </div>
                            {ar.result === "approved" ? (
                              <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">通过</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-700 hover:bg-red-100">拒绝</Badge>
                            )}
                          </div>
                          <div className="text-xs text-[var(--color-text-tertiary)] mt-1">{ar.auditTime}</div>
                          <p className="text-sm text-[var(--color-text-secondary)] mt-2">{ar.remark}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
          <DrawerFooter className="border-t pt-4">
            <DrawerClose asChild>
              <Button variant="outline" className="w-full">关闭</Button>
            </DrawerClose>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>

      {/* ========== Approve Dialog ========== */}
      <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              审批通过
            </DialogTitle>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg border bg-[var(--color-surface-elevated)] p-3 space-y-1.5">
                <div className="text-sm text-[var(--color-text-secondary)]">
                  申请编号：<span className="font-medium text-[var(--color-text-primary)]">{selectedRecord.applyNo}</span>
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                  车牌号：<span className="font-medium text-[var(--color-text-primary)]">{selectedRecord.plateNo}</span>
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                  解绑原因：<span className="font-medium text-[var(--color-text-primary)]">{getReasonLabel(selectedRecord.reason)}</span>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">审批意见</Label>
                <Textarea
                  value={auditRemark}
                  onChange={e => setAuditRemark(e.target.value)}
                  placeholder="请输入审批意见（可选）"
                  className="mt-1.5"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setApproveOpen(false)}>取消</Button>
                <Button onClick={confirmApprove} className="bg-emerald-600 hover:bg-emerald-700">确认通过</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ========== Reject Dialog ========== */}
      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="w-5 h-5 text-red-500" />
              审批拒绝
            </DialogTitle>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg border bg-[var(--color-surface-elevated)] p-3 space-y-1.5">
                <div className="text-sm text-[var(--color-text-secondary)]">
                  申请编号：<span className="font-medium text-[var(--color-text-primary)]">{selectedRecord.applyNo}</span>
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                  车牌号：<span className="font-medium text-[var(--color-text-primary)]">{selectedRecord.plateNo}</span>
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                  解绑原因：<span className="font-medium text-[var(--color-text-primary)]">{getReasonLabel(selectedRecord.reason)}</span>
                </div>
              </div>
              <div>
                <Label className="text-sm font-medium">拒绝原因 <span className="text-red-500">*</span></Label>
                <Textarea
                  value={auditRemark}
                  onChange={e => setAuditRemark(e.target.value)}
                  placeholder="请输入拒绝原因"
                  className="mt-1.5"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setRejectOpen(false)}>取消</Button>
                <Button variant="destructive" onClick={confirmReject} disabled={!auditRemark.trim()}>确认拒绝</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* ========== Create Dialog ========== */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-[var(--color-primary)]" />
              新建解绑申请
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-sm font-medium">选择车辆 <span className="text-red-500">*</span></Label>
              <Select value={newVehicle} onValueChange={setNewVehicle}>
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="请选择车辆" />
                </SelectTrigger>
                <SelectContent>
                  {availableVehicles.map(v => (
                    <SelectItem key={v.plateNo} value={v.plateNo}>
                      {v.plateNo} · {v.brand} {v.model} · {v.type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">解绑原因 <span className="text-red-500">*</span></Label>
              <Select value={newReason} onValueChange={setNewReason}>
                <SelectTrigger className="mt-1.5">
                  <SelectValue placeholder="请选择解绑原因" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="车辆报废">车辆报废</SelectItem>
                  <SelectItem value="车辆出售">车辆出售</SelectItem>
                  <SelectItem value="合同到期">合同到期</SelectItem>
                  <SelectItem value="故障停用">故障停用</SelectItem>
                  <SelectItem value="调配其他项目">调配其他项目</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">备注说明</Label>
              <Textarea
                value={newRemark}
                onChange={e => setNewRemark(e.target.value)}
                placeholder="请填写解绑原因说明、后续安排等..."
                className="mt-1.5"
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateOpen(false)}>取消</Button>
              <Button onClick={submitCreate} disabled={!newVehicle || !newReason}>提交申请</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
