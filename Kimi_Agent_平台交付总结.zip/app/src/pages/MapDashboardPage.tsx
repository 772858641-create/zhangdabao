import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronLeft,
  ChevronRight,
  Search,
  Layers,
  X,
  Container,
  Truck,
  Warehouse,
  AlertTriangle,
  Maximize,
  Minimize,
  RotateCcw,
  Filter,
  Map,
  Satellite,
  Map as MapIcon,
  CircleDot,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';

// --- Types ---
interface MapMarker {
  id: string;
  name: string;
  type: 'vehicle' | 'truck' | 'site' | 'alarm';
  lat: number;
  lng: number;
  status: string;
  details: Record<string, string>;
}

type BaseMap = 'standard' | 'satellite' | 'light';
type MapLayer = 'vehicle' | 'truck' | 'site' | 'alarm' | 'route' | 'fence';

// --- Simulated map background gradient per baseMap ---
const mapBackgrounds: Record<BaseMap, string> = {
  standard: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 25%, #93c5fd 50%, #bfdbfe 75%, #dbeafe 100%)',
  satellite: 'linear-gradient(135deg, #1e3a5f 0%, #2d5016 25%, #1e3a5f 50%, #4a3728 75%, #1e3a5f 100%)',
  light: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%, #f8fafc 100%)',
};

const mapBgPatterns: Record<BaseMap, string> = {
  standard: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.2'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
  satellite: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000000' fill-opacity='0.08' fill-rule='evenodd'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/svg%3E")`,
  light: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2394a3b8' fill-opacity='0.08' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='1'/%3E%3Ccircle cx='13' cy='13' r='1'/%3E%3C/g%3E%3C/svg%3E")`,
};

const layerConfig: { key: MapLayer; label: string; color: string; icon: React.ReactNode }[] = [
  { key: 'vehicle', label: '在途载具', color: '#2563EB', icon: <Container size={14} /> },
  { key: 'truck', label: '在途车辆', color: '#10B981', icon: <Truck size={14} /> },
  { key: 'site', label: '网点', color: '#8B5CF6', icon: <Warehouse size={14} /> },
  { key: 'alarm', label: '报警', color: '#EF4444', icon: <AlertTriangle size={14} /> },
];

// --- Marker SVG Icons ---
function VehicleMarkerIcon({ color }: { color: string }) {
  return (
    <svg width="24" height="32" viewBox="0 0 24 32" fill="none">
      <path
        d="M12 2C8 2 4 5 4 10c0 5 8 20 8 20s8-15 8-20c0-5-4-8-8-8z"
        fill={color}
        stroke="white"
        strokeWidth="2"
      />
      <circle cx="12" cy="10" r="4" fill="white" />
    </svg>
  );
}

function TruckMarkerIcon({ color }: { color: string }) {
  return (
    <svg width="28" height="36" viewBox="0 0 28 36" fill="none">
      <path
        d="M14 2C9 2 5 6 5 11c0 6 9 23 9 23s9-17 9-23c0-5-4-9-9-9z"
        fill={color}
        stroke="white"
        strokeWidth="2"
      />
      <rect x="9" y="8" width="10" height="8" rx="2" fill="white" />
    </svg>
  );
}

function SiteMarkerIcon({ color }: { color: string }) {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="8" width="18" height="13" rx="2" fill={color} stroke="white" strokeWidth="2" />
      <path d="M7 8V5a5 5 0 0110 0v3" stroke={color} strokeWidth="2" fill="none" />
    </svg>
  );
}

function AlarmMarkerIcon() {
  return (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
      <circle cx="16" cy="16" r="14" fill="#EF4444" fillOpacity="0.2" />
      <circle cx="16" cy="16" r="10" fill="#EF4444" fillOpacity="0.4" />
      <circle cx="16" cy="16" r="6" fill="#EF4444" />
      <path d="M14 11h4v6h-4zM14 19h4v2h-4z" fill="white" />
    </svg>
  );
}

// --- Pulsing ring for alarm markers ---
function PulseRing() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      <div className="w-8 h-8 rounded-full bg-danger/30 animate-pulse-ring" />
    </div>
  );
}

// --- Info Popup ---
function InfoPopup({
  marker,
  onClose,
}: {
  marker: MapMarker;
  onClose: () => void;
}) {
  const statusColorMap: Record<string, string> = {
    normal: '#10B981',
    idle: '#10B981',
    in_transit: '#2563EB',
    repairing: '#F59E0B',
    cleaning: '#06B6D4',
    damaged: '#EF4444',
    scrapped: '#94A3B8',
    inactive: '#94A3B8',
    unhandled: '#EF4444',
    handling: '#F59E0B',
    resolved: '#10B981',
  };

  const statusLabels: Record<string, string> = {
    normal: '正常',
    idle: '空闲',
    in_transit: '在途中',
    repairing: '维修中',
    cleaning: '清洁中',
    damaged: '已损坏',
    scrapped: '已报废',
    inactive: '已停用',
    unhandled: '未处理',
    handling: '处理中',
    resolved: '已解决',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 8, scale: 0.95 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="absolute z-40 bg-white rounded-lg shadow-modal border border-neutral-border w-[280px]"
      style={{ bottom: '100%', left: '50%', transform: 'translateX(-50%) translateY(-8px)' }}
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-border">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-neutral-textPrimary">{marker.name}</span>
          <span
            className="text-[11px] px-1.5 py-0.5 rounded text-white font-medium"
            style={{ backgroundColor: statusColorMap[marker.status] || '#94A3B8' }}
          >
            {statusLabels[marker.status] || marker.status}
          </span>
        </div>
        <button
          onClick={onClose}
          className="w-6 h-6 flex items-center justify-center rounded hover:bg-neutral-surface-elevated text-neutral-textTertiary hover:text-neutral-textPrimary transition-colors"
        >
          <X size={14} />
        </button>
      </div>
      <div className="px-4 py-3 space-y-2">
        {Object.entries(marker.details).map(([key, value]) => (
          <div key={key} className="flex justify-between">
            <span className="text-xs text-neutral-textSecondary">{key}</span>
            <span className="text-xs font-medium text-neutral-textPrimary">{value}</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2 px-4 py-3 border-t border-neutral-border">
        <button className="flex-1 h-8 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors">
          查看详情
        </button>
        <button className="flex-1 h-8 text-xs bg-white border border-neutral-border text-neutral-textPrimary rounded-md hover:bg-neutral-surface-elevated transition-colors">
          轨迹回放
        </button>
      </div>
      <div
        className="absolute left-1/2 -translate-x-1/2 w-3 h-3 bg-white border-b border-r border-neutral-border rotate-45"
        style={{ bottom: '-6px' }}
      />
    </motion.div>
  );
}

// --- Main Map Dashboard Page ---
export default function MapDashboardPage() {
  const { carriers, sites, vehicles, alarms } = useMockData();

  const [leftPanelOpen, setLeftPanelOpen] = useState(true);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);
  const [baseMap, setBaseMap] = useState<BaseMap>('standard');
  const [activeLayers, setActiveLayers] = useState<Record<MapLayer, boolean>>({
    vehicle: true,
    truck: true,
    site: true,
    alarm: true,
    route: false,
    fence: false,
  });
  const [selectedMarker, setSelectedMarker] = useState<MapMarker | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mapZoom, setMapZoom] = useState(5);
  const [activeRightTab, setActiveRightTab] = useState<'vehicle' | 'truck' | 'site' | 'alarm'>('vehicle');
  const [showLayerPanel, setShowLayerPanel] = useState(false);

  // Map pan offset (simulated)
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  // Generate markers from mock data
  const mapMarkers = useMemo<MapMarker[]>(() => {
    const markers: MapMarker[] = [];

    // Vehicle markers (carriers in transit)
    carriers
      .filter((c) => c.status === 'normal' || c.status === 'cleaning')
      .slice(0, 15)
      .forEach((c) => {
        const site = sites.find((s) => s.id === c.siteId);
        markers.push({
          id: `vehicle-${c.id}`,
          name: c.name,
          type: 'vehicle',
          lat: (site?.lat || 31) + (Math.random() - 0.5) * 0.8,
          lng: (site?.lng || 121) + (Math.random() - 0.5) * 0.8,
          status: c.status,
          details: {
            编号: c.code,
            类型: c.type,
            当前网点: c.siteName,
            绑定设备: c.deviceName || '无',
            状态: c.status === 'normal' ? '正常' : '清洁中',
          },
        });
      });

    // Truck markers
    vehicles
      .filter((v) => v.status === 'in_transit' || v.status === 'idle')
      .slice(0, 10)
      .forEach((v) => {
        markers.push({
          id: `truck-${v.id}`,
          name: v.plateNumber,
          type: 'truck',
          lat: 25 + Math.random() * 14,
          lng: 110 + Math.random() * 14,
          status: v.status,
          details: {
            车牌: v.plateNumber,
            类型: v.type,
            司机: v.driverName || '未分配',
            品牌: v.brand,
            状态: v.status === 'in_transit' ? '在途中' : '空闲',
          },
        });
      });

    // Site markers
    sites.forEach((s) => {
      markers.push({
        id: `site-${s.id}`,
        name: s.name,
        type: 'site',
        lat: s.lat,
        lng: s.lng,
        status: 'normal',
        details: {
          类型: s.type === 'warehouse' ? '仓库' : s.type === 'factory' ? '工厂' : '配送中心',
          地址: s.address,
          载具数: `${s.carrierCount}个`,
          联系人: s.contactName,
          电话: s.contactPhone,
        },
      });
    });

    // Alarm markers
    alarms
      .filter((a) => a.status === 'unhandled')
      .slice(0, 6)
      .forEach((a) => {
        markers.push({
          id: `alarm-${a.id}`,
          name: a.targetName,
          type: 'alarm',
          lat: 22 + Math.random() * 16,
          lng: 108 + Math.random() * 16,
          status: a.status,
          details: {
            类型: a.type,
            级别: a.level === 'urgent' ? '紧急' : a.level === 'important' ? '重要' : a.level === 'normal' ? '一般' : '提示',
            位置: a.location,
            时间: a.createdAt,
            消息: a.message.slice(0, 30) + '...',
          },
        });
      });

    return markers;
  }, [carriers, sites, vehicles, alarms]);

  // Filtered markers
  const visibleMarkers = useMemo(() => {
    return mapMarkers.filter((m) => {
      if (!activeLayers[m.type]) return false;
      if (searchQuery) {
        return m.name.toLowerCase().includes(searchQuery.toLowerCase());
      }
      return true;
    });
  }, [mapMarkers, activeLayers, searchQuery]);

  const toggleLayer = useCallback((layer: MapLayer) => {
    setActiveLayers((prev) => ({ ...prev, [layer]: !prev[layer] }));
  }, []);

  const handleMarkerClick = useCallback(
    (marker: MapMarker) => {
      if (selectedMarker?.id === marker.id) {
        setSelectedMarker(null);
      } else {
        setSelectedMarker(marker);
      }
    },
    [selectedMarker]
  );

  // Map bounds (simulated China coordinates)
  const mapBounds = { minLat: 18, maxLat: 42, minLng: 98, maxLng: 128 };

  // Convert lat/lng to screen position within map container
  const latLngToScreen = useCallback(
    (lat: number, lng: number) => {
      const x = ((lng - mapBounds.minLng) / (mapBounds.maxLng - mapBounds.minLng)) * 100;
      const y = ((mapBounds.maxLat - lat) / (mapBounds.maxLat - mapBounds.minLat)) * 100;
      return { x, y };
    },
    [mapBounds]
  );

  // Mouse drag handlers
  const handleMapMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
  };

  const handleMapMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPanOffset({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
  };

  const handleMapMouseUp = () => {
    setIsDragging(false);
  };

  // Stats for right panel
  const inTransitCarriers = carriers.filter((c) => c.status === 'normal').length;
  const inTransitVehicles = vehicles.filter((v) => v.status === 'in_transit').length;
  const totalSites = sites.length;
  const unhandledAlarms = alarms.filter((a) => a.status === 'unhandled').length;

  // Panel animation config
  const panelEase = [0.16, 1, 0.3, 1] as [number, number, number, number];

  return (
    <div className={cn('relative w-full overflow-hidden bg-neutral-background', isFullscreen ? 'fixed inset-0 z-50' : 'h-[calc(100vh-56px)]')}>
      {/* Top Toolbar */}
      <div className="absolute top-0 left-0 right-0 h-[52px] bg-white/95 backdrop-blur-md shadow-topbar z-30 flex items-center px-4 gap-3">
        {/* Base map switcher */}
        <div className="flex items-center bg-neutral-surface-elevated rounded-md p-0.5">
          {[
            { key: 'standard' as BaseMap, label: '标准', icon: <MapIcon size={14} /> },
            { key: 'satellite' as BaseMap, label: '卫星', icon: <Satellite size={14} /> },
            { key: 'light' as BaseMap, label: '浅色', icon: <Map size={14} /> },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => setBaseMap(opt.key)}
              className={cn(
                'flex items-center gap-1 px-2.5 h-7 text-[12px] rounded-md transition-all',
                baseMap === opt.key
                  ? 'bg-neutral-textPrimary text-white'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
              )}
            >
              {opt.icon}
              {opt.label}
            </button>
          ))}
        </div>

        {/* Layer control */}
        <div className="relative">
          <button
            onClick={() => setShowLayerPanel(!showLayerPanel)}
            className={cn(
              'flex items-center gap-1.5 h-8 px-3 text-[13px] rounded-md border transition-all',
              showLayerPanel
                ? 'border-primary bg-primary-light text-primary'
                : 'border-neutral-border text-neutral-textSecondary hover:text-neutral-textPrimary'
            )}
          >
            <Layers size={14} />
            图层
          </button>
          <AnimatePresence>
            {showLayerPanel && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowLayerPanel(false)} />
                <motion.div
                  initial={{ opacity: 0, y: -4, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -4, scale: 0.96 }}
                  transition={{ duration: 0.15, ease: panelEase }}
                  className="absolute top-full left-0 mt-2 w-[200px] bg-white rounded-lg shadow-dropdown border border-neutral-border z-20 py-2"
                >
                  {layerConfig.map((layer) => (
                    <label
                      key={layer.key}
                      className="flex items-center gap-2.5 px-3 py-2 cursor-pointer hover:bg-neutral-surface-elevated transition-colors"
                    >
                      <input
                        type="checkbox"
                        checked={activeLayers[layer.key]}
                        onChange={() => toggleLayer(layer.key)}
                        className="w-4 h-4 rounded border-neutral-border-strong text-primary focus:ring-primary"
                      />
                      <span style={{ color: layer.color }}>{layer.icon}</span>
                      <span className="text-[13px] text-neutral-textPrimary flex-1">{layer.label}</span>
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: layer.color }} />
                    </label>
                  ))}
                  <div className="border-t border-neutral-border mt-1 pt-1 px-3 flex gap-2">
                    <button
                      onClick={() =>
                        setActiveLayers({
                          vehicle: true,
                          truck: true,
                          site: true,
                          alarm: true,
                          route: true,
                          fence: true,
                        })
                      }
                      className="text-[11px] text-primary hover:underline"
                    >
                      全部显示
                    </button>
                    <button
                      onClick={() =>
                        setActiveLayers({
                          vehicle: false,
                          truck: false,
                          site: false,
                          alarm: false,
                          route: false,
                          fence: false,
                        })
                      }
                      className="text-[11px] text-neutral-textSecondary hover:underline"
                    >
                      全部隐藏
                    </button>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>

        {/* Search */}
        <div className="relative w-[280px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
          <input
            type="text"
            placeholder="搜索载具编号、网点名称..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-8 pl-8 pr-4 text-[13px] border border-neutral-border-strong rounded-md bg-white text-neutral-textPrimary placeholder:text-neutral-textTertiary focus:outline-none focus:border-primary focus:shadow-focus transition-all"
          />
        </div>

        <div className="flex-1" />

        {/* Zoom controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setMapZoom((z) => Math.min(z + 1, 18))}
            className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-surface-elevated text-neutral-textSecondary transition-colors"
          >
            +
          </button>
          <span className="text-xs text-neutral-textTertiary w-8 text-center font-number">{mapZoom}</span>
          <button
            onClick={() => setMapZoom((z) => Math.max(z - 1, 3))}
            className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-surface-elevated text-neutral-textSecondary transition-colors"
          >
            -
          </button>
        </div>

        {/* Fullscreen */}
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-surface-elevated text-neutral-textSecondary transition-colors"
        >
          {isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
        </button>

        {/* Refresh */}
        <button className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-surface-elevated text-neutral-textSecondary transition-colors">
          <RotateCcw size={14} />
        </button>
      </div>

      {/* Left Filter Panel */}
      <AnimatePresence initial={false}>
        {leftPanelOpen ? (
          <motion.div
            key="left-panel-open"
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 300, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: panelEase }}
            className="absolute left-0 top-[52px] bottom-0 bg-white/95 backdrop-blur-md border-r border-neutral-border z-20 overflow-hidden flex flex-col"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-border">
              <h3 className="text-sm font-medium text-neutral-textPrimary">筛选条件</h3>
              <button
                onClick={() => setLeftPanelOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-neutral-surface-elevated text-neutral-textTertiary hover:text-neutral-textPrimary transition-colors"
              >
                <ChevronLeft size={16} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-5">
              {/* Vehicle filter */}
              <div>
                <h4 className="text-xs font-medium text-neutral-textSecondary mb-2">载具筛选</h4>
                <div className="space-y-2">
                  <label className="text-xs text-neutral-textSecondary block mb-1">类型</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['托盘', '周转箱', '料架', '集装箱', '笼车'].map((t) => (
                      <button
                        key={t}
                        className="px-2.5 h-6 text-[11px] rounded-md bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="mt-2">
                  <label className="text-xs text-neutral-textSecondary block mb-1">状态</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['正常', '维修中', '清洁中'].map((s) => (
                      <button
                        key={s}
                        className="px-2.5 h-6 text-[11px] rounded-md bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Vehicle filter */}
              <div>
                <h4 className="text-xs font-medium text-neutral-textSecondary mb-2">车辆筛选</h4>
                <div className="space-y-2">
                  <label className="text-xs text-neutral-textSecondary block mb-1">状态</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['空闲', '在途中', '维修中'].map((s) => (
                      <button
                        key={s}
                        className="px-2.5 h-6 text-[11px] rounded-md bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Site filter */}
              <div>
                <h4 className="text-xs font-medium text-neutral-textSecondary mb-2">网点筛选</h4>
                <div className="space-y-2">
                  <label className="text-xs text-neutral-textSecondary block mb-1">类型</label>
                  <div className="flex flex-wrap gap-1.5">
                    {['仓库', '工厂', '配送中心'].map((t) => (
                      <button
                        key={t}
                        className="px-2.5 h-6 text-[11px] rounded-md bg-neutral-surface-elevated text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Org filter */}
              <div>
                <h4 className="text-xs font-medium text-neutral-textSecondary mb-2">组织</h4>
                <select className="w-full h-8 px-2 text-[12px] border border-neutral-border-strong rounded-md bg-white text-neutral-textPrimary focus:outline-none focus:border-primary">
                  <option>全部组织</option>
                  <option>华东汽车制造有限公司</option>
                  <option>南方物流集团</option>
                  <option>北方供应链管理有限公司</option>
                </select>
              </div>
            </div>
            <div className="p-4 border-t border-neutral-border flex gap-2">
              <button className="flex-1 h-8 text-[12px] border border-neutral-border text-neutral-textSecondary rounded-md hover:bg-neutral-surface-elevated transition-colors">
                重置
              </button>
              <button className="flex-1 h-8 text-[12px] bg-primary text-white rounded-md hover:bg-primary-hover transition-colors">
                应用
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="left-panel-closed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute left-0 top-[52px] bottom-0 w-[44px] bg-white/95 backdrop-blur-md border-r border-neutral-border z-20 flex flex-col items-center py-2 gap-1"
          >
            {[
              { icon: <Filter size={16} />, label: '筛选', onClick: () => setLeftPanelOpen(true) },
              { icon: <Container size={16} />, label: '载具', onClick: () => { toggleLayer('vehicle'); } },
              { icon: <Truck size={16} />, label: '车辆', onClick: () => { toggleLayer('truck'); } },
              { icon: <Warehouse size={16} />, label: '网点', onClick: () => { toggleLayer('site'); } },
              { icon: <AlertTriangle size={16} />, label: '报警', onClick: () => { toggleLayer('alarm'); } },
            ].map((item) => (
              <button
                key={item.label}
                onClick={item.onClick}
                title={item.label}
                className="w-9 h-9 flex items-center justify-center rounded-md text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
              >
                {item.icon}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Right Stats Panel */}
      <AnimatePresence initial={false}>
        {rightPanelOpen ? (
          <motion.div
            key="right-panel-open"
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 320, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: panelEase }}
            className="absolute right-0 top-[52px] bottom-0 bg-white/95 backdrop-blur-md border-l border-neutral-border z-20 overflow-hidden flex flex-col"
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-border">
              <h3 className="text-sm font-medium text-neutral-textPrimary">数据统计</h3>
              <button
                onClick={() => setRightPanelOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-neutral-surface-elevated text-neutral-textTertiary hover:text-neutral-textPrimary transition-colors"
              >
                <ChevronRight size={16} />
              </button>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-2 gap-2 p-3">
              {[
                { label: '在途载具', value: inTransitCarriers, color: '#2563EB', icon: <Container size={14} /> },
                { label: '在途车辆', value: inTransitVehicles, color: '#10B981', icon: <Truck size={14} /> },
                { label: '网点总数', value: totalSites, color: '#8B5CF6', icon: <Warehouse size={14} /> },
                { label: '未处理报警', value: unhandledAlarms, color: '#EF4444', icon: <AlertTriangle size={14} /> },
              ].map((kpi) => (
                <div
                  key={kpi.label}
                  className="rounded-lg p-3 border border-neutral-border"
                  style={{ backgroundColor: `${kpi.color}08` }}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <span style={{ color: kpi.color }}>{kpi.icon}</span>
                    <span className="text-[11px] text-neutral-textSecondary">{kpi.label}</span>
                  </div>
                  <span className="text-xl font-semibold font-number" style={{ color: kpi.color }}>
                    {kpi.value}
                  </span>
                </div>
              ))}
            </div>

            {/* Tabs */}
            <div className="flex border-b border-neutral-border px-3">
              {[
                { key: 'vehicle' as const, label: '载具' },
                { key: 'truck' as const, label: '车辆' },
                { key: 'site' as const, label: '网点' },
                { key: 'alarm' as const, label: '报警' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveRightTab(tab.key)}
                  className={cn(
                    'flex-1 py-2 text-[12px] font-medium border-b-2 transition-colors',
                    activeRightTab === tab.key
                      ? 'border-primary text-primary'
                      : 'border-transparent text-neutral-textSecondary hover:text-neutral-textPrimary'
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="flex-1 overflow-y-auto p-3">
              {activeRightTab === 'vehicle' && (
                <div className="space-y-2">
                  {mapMarkers
                    .filter((m) => m.type === 'vehicle')
                    .slice(0, 8)
                    .map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleMarkerClick(m)}
                        className="w-full flex items-center gap-2.5 p-2.5 rounded-lg hover:bg-neutral-surface-elevated transition-colors text-left"
                      >
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: '#2563EB15' }}
                        >
                          <Container size={14} style={{ color: '#2563EB' }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-neutral-textPrimary truncate">{m.name}</p>
                          <p className="text-[11px] text-neutral-textTertiary truncate">
                            {m.details.当前网点 || m.details.状态}
                          </p>
                        </div>
                        <CircleDot size={10} style={{ color: '#2563EB' }} />
                      </button>
                    ))}
                </div>
              )}
              {activeRightTab === 'truck' && (
                <div className="space-y-2">
                  {mapMarkers
                    .filter((m) => m.type === 'truck')
                    .slice(0, 8)
                    .map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleMarkerClick(m)}
                        className="w-full flex items-center gap-2.5 p-2.5 rounded-lg hover:bg-neutral-surface-elevated transition-colors text-left"
                      >
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: '#10B98115' }}
                        >
                          <Truck size={14} style={{ color: '#10B981' }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-neutral-textPrimary truncate">{m.name}</p>
                          <p className="text-[11px] text-neutral-textTertiary truncate">{m.details.司机}</p>
                        </div>
                        <CircleDot size={10} style={{ color: '#10B981' }} />
                      </button>
                    ))}
                </div>
              )}
              {activeRightTab === 'site' && (
                <div className="space-y-2">
                  {mapMarkers
                    .filter((m) => m.type === 'site')
                    .map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleMarkerClick(m)}
                        className="w-full flex items-center gap-2.5 p-2.5 rounded-lg hover:bg-neutral-surface-elevated transition-colors text-left"
                      >
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{ backgroundColor: '#8B5CF615' }}
                        >
                          <Warehouse size={14} style={{ color: '#8B5CF6' }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-neutral-textPrimary truncate">{m.name}</p>
                          <p className="text-[11px] text-neutral-textTertiary truncate">
                            {m.details.载具数} · {m.details.类型}
                          </p>
                        </div>
                      </button>
                    ))}
                </div>
              )}
              {activeRightTab === 'alarm' && (
                <div className="space-y-2">
                  {mapMarkers
                    .filter((m) => m.type === 'alarm')
                    .map((m) => (
                      <button
                        key={m.id}
                        onClick={() => handleMarkerClick(m)}
                        className="w-full flex items-start gap-2.5 p-2.5 rounded-lg hover:bg-danger-light transition-colors text-left border-l-2 border-danger"
                      >
                        <AlertTriangle size={14} className="text-danger flex-shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-danger truncate">{m.name}</p>
                          <p className="text-[11px] text-neutral-textTertiary truncate">{m.details.类型}</p>
                          <p className="text-[11px] text-neutral-textTertiary">{m.details.时间}</p>
                        </div>
                      </button>
                    ))}
                </div>
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="right-panel-closed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute right-0 top-[52px] bottom-0 w-[44px] bg-white/95 backdrop-blur-md border-l border-neutral-border z-20 flex flex-col items-center py-2 gap-1"
          >
            <button
              onClick={() => setRightPanelOpen(true)}
              title="展开统计面板"
              className="w-9 h-9 flex items-center justify-center rounded-md text-neutral-textSecondary hover:bg-primary-light hover:text-primary transition-colors"
            >
              <ChevronLeft size={16} />
            </button>
            {[
              { icon: <Container size={16} />, label: '在途载具', count: inTransitCarriers, color: '#2563EB' },
              { icon: <Truck size={16} />, label: '在途车辆', count: inTransitVehicles, color: '#10B981' },
              { icon: <Warehouse size={16} />, label: '网点', count: totalSites, color: '#8B5CF6' },
              { icon: <AlertTriangle size={16} />, label: '报警', count: unhandledAlarms, color: '#EF4444' },
            ].map((item) => (
              <button
                key={item.label}
                onClick={() => { setActiveRightTab(item.label === '在途载具' ? 'vehicle' : item.label === '在途车辆' ? 'truck' : item.label === '网点' ? 'site' : 'alarm'); setRightPanelOpen(true); }}
                title={item.label}
                className="w-9 h-9 flex flex-col items-center justify-center rounded-md hover:bg-primary-light hover:text-primary transition-colors relative"
              >
                <span style={{ color: item.color }}>{item.icon}</span>
                {item.count > 0 && (
                  <span
                    className="absolute -top-0.5 -right-0.5 min-w-[14px] h-[14px] flex items-center justify-center text-[9px] font-medium rounded-full text-white px-0.5"
                    style={{ backgroundColor: item.color }}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Map Canvas Area */}
      <div
        className={cn(
          'absolute inset-0 cursor-grab',
          isDragging && 'cursor-grabbing'
        )}
        style={{
          top: 52,
          left: leftPanelOpen ? 300 : 44,
          right: rightPanelOpen ? 320 : 44,
          bottom: 36,
          background: mapBackgrounds[baseMap],
          backgroundImage: mapBgPatterns[baseMap],
          backgroundBlendMode: baseMap === 'satellite' ? 'overlay' : 'normal',
        }}
        onMouseDown={handleMapMouseDown}
        onMouseMove={handleMapMouseMove}
        onMouseUp={handleMapMouseUp}
        onMouseLeave={handleMapMouseUp}
      >
        {/* Simulated map tiles / grid lines */}
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            transform: `translate(${panOffset.x}px, ${panOffset.y}px)`,
          }}
        >
          {/* Grid lines */}
          <svg className="absolute inset-0 w-full h-full" style={{ opacity: baseMap === 'light' ? 0.15 : 0.08 }}>
            {Array.from({ length: 20 }, (_, i) => (
              <g key={i}>
                <line
                  x1={`${(i / 20) * 100}%`}
                  y1="0"
                  x2={`${(i / 20) * 100}%`}
                  y2="100%"
                  stroke={baseMap === 'satellite' ? '#fff' : '#94A3B8'}
                  strokeWidth="0.5"
                  strokeDasharray="4 4"
                />
                <line
                  x1="0"
                  y1={`${(i / 20) * 100}%`}
                  x2="100%"
                  y2={`${(i / 20) * 100}%`}
                  stroke={baseMap === 'satellite' ? '#fff' : '#94A3B8'}
                  strokeWidth="0.5"
                  strokeDasharray="4 4"
                />
              </g>
            ))}
          </svg>

          {/* Simulated city labels */}
          {[
            { name: '上海', x: 72, y: 52 },
            { name: '北京', x: 68, y: 22 },
            { name: '广州', x: 60, y: 78 },
            { name: '深圳', x: 63, y: 82 },
            { name: '成都', x: 35, y: 55 },
            { name: '武汉', x: 55, y: 58 },
            { name: '西安', x: 45, y: 42 },
            { name: '杭州', x: 70, y: 58 },
            { name: '青岛', x: 74, y: 35 },
            { name: '天津', x: 69, y: 25 },
          ].map((city) => (
            <div
              key={city.name}
              className="absolute text-xs font-medium pointer-events-none select-none"
              style={{
                left: `${city.x}%`,
                top: `${city.y}%`,
                color: baseMap === 'satellite' ? 'rgba(255,255,255,0.5)' : '#94A3B8',
                transform: 'translate(-50%, -50%)',
              }}
            >
              {city.name}
            </div>
          ))}

          {/* Markers */}
          {visibleMarkers.map((marker) => {
            const pos = latLngToScreen(marker.lat, marker.lng);
            const isSelected = selectedMarker?.id === marker.id;
            return (
              <div
                key={marker.id}
                className="absolute"
                style={{
                  left: `${pos.x}%`,
                  top: `${pos.y}%`,
                  transform: 'translate(-50%, -50%)',
                  zIndex: isSelected ? 20 : marker.type === 'alarm' ? 15 : 10,
                }}
              >
                <div className="relative">
                  {marker.type === 'alarm' && <PulseRing />}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleMarkerClick(marker);
                    }}
                    className={cn(
                      'relative transition-transform duration-150 hover:scale-125',
                      isSelected && 'scale-125'
                    )}
                  >
                    {marker.type === 'vehicle' && <VehicleMarkerIcon color="#2563EB" />}
                    {marker.type === 'truck' && <TruckMarkerIcon color="#10B981" />}
                    {marker.type === 'site' && <SiteMarkerIcon color="#8B5CF6" />}
                    {marker.type === 'alarm' && <AlarmMarkerIcon />}
                  </button>
                  {/* Info popup */}
                  <AnimatePresence>
                    {isSelected && (
                      <InfoPopup
                        marker={marker}
                        onClose={() => setSelectedMarker(null)}
                      />
                    )}
                  </AnimatePresence>
                </div>
              </div>
            );
          })}
        </div>

        {/* Zoom indicator */}
        <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur rounded-md px-2.5 py-1.5 shadow-card text-[11px] text-neutral-textSecondary z-10">
          缩放: {mapZoom}级
        </div>

        {/* Map Legend */}
        <div className="absolute bottom-3 right-3 bg-white/90 backdrop-blur rounded-lg shadow-card border border-neutral-border px-3 py-2 z-10">
          <p className="text-[11px] font-medium text-neutral-textSecondary mb-1.5">图例</p>
          <div className="space-y-1">
            {layerConfig.map((layer) => (
              <div key={layer.key} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: layer.color }} />
                <span className="text-[11px] text-neutral-textSecondary">{layer.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Status Bar */}
      <div className="absolute bottom-0 left-0 right-0 h-[36px] bg-neutral-textPrimary/85 flex items-center px-4 justify-between z-20">
        <span className="text-[11px] text-white/80">
          视图范围: {mapBounds.minLng.toFixed(1)}°E - {mapBounds.maxLng.toFixed(1)}°E, {mapBounds.minLat.toFixed(1)}°N - {mapBounds.maxLat.toFixed(1)}°N
        </span>
        <span className="text-[11px] text-white/80">
          可见: 载具 {visibleMarkers.filter((m) => m.type === 'vehicle').length} / 车辆 {visibleMarkers.filter((m) => m.type === 'truck').length} / 网点 {visibleMarkers.filter((m) => m.type === 'site').length}
        </span>
        <span className="text-[11px] text-white/80 flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
          数据实时更新
        </span>
      </div>
    </div>
  );
}
