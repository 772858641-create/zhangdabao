import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Shield, Search, Plus, Edit3, Trash2, Copy, Eye, CheckSquare, Square, MinusSquare,
  Users, CheckCircle, XCircle, ChevronRight, ChevronDown, Lock, Unlock,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
type RoleStatus = 'active' | 'inactive';

type PermissionLevel = 'none' | 'view' | 'edit';

interface FieldPermission {
  field: string;
  label: string;
  level: PermissionLevel;
}

interface ModulePermission {
  module: string;
  label: string;
  view: boolean;
  create: boolean;
  edit: boolean;
  delete: boolean;
  export: boolean;
  approve: boolean;
}

interface RoleItem {
  id: string;
  name: string;
  code: string;
  description: string;
  userCount: number;
  permissionCount?: number;
  builtin: boolean;
  status: RoleStatus;
  createdAt: string;
  modulePermissions: Record<string, ModulePermission>;
  fieldPermissions: Record<string, FieldPermission[]>;
}

interface UserRef {
  id: string;
  name: string;
  account: string;
  orgName: string;
  status: RoleStatus;
  assignedAt: string;
}

// ==================== Constants ====================
const PERMISSION_MODULES = [
  { key: 'dashboard', label: '数据看板' },
  { key: 'map', label: '地图看板' },
  { key: 'carrier', label: '载具管理' },
  { key: 'fleet', label: '车辆管理' },
  { key: 'device', label: '设备管理' },
  { key: 'site', label: '网点管理' },
  { key: 'transfer', label: '调拨管理' },
  { key: 'route', label: '流转线路' },
  { key: 'alarm', label: '报警中心' },
  { key: 'user', label: '用户管理' },
  { key: 'role', label: '角色管理' },
  { key: 'settings', label: '系统设置' },
];

const FIELD_PERMISSION_TEMPLATES: Record<string, FieldPermission[]> = {
  carrier: [
    { field: 'carrierNo', label: '载具编号', level: 'edit' },
    { field: 'type', label: '载具类型', level: 'edit' },
    { field: 'owner', label: '所属方', level: 'view' },
    { field: 'currentSite', label: '当前网点', level: 'view' },
    { field: 'status', label: '状态', level: 'edit' },
    { field: 'bindDevice', label: '绑定设备', level: 'edit' },
    { field: 'remark', label: '备注', level: 'edit' },
  ],
  transfer: [
    { field: 'transferNo', label: '调拨单号', level: 'view' },
    { field: 'fromSite', label: '出发网点', level: 'view' },
    { field: 'toSite', label: '目的网点', level: 'view' },
    { field: 'carrierCount', label: '载具数量', level: 'view' },
    { field: 'status', label: '状态', level: 'edit' },
    { field: 'driver', label: '司机', level: 'edit' },
    { field: 'vehicle', label: '车辆', level: 'edit' },
    { field: 'planTime', label: '计划时间', level: 'view' },
    { field: 'actualTime', label: '实际时间', level: 'view' },
    { field: 'cost', label: '费用', level: 'edit' },
  ],
};

const STATUS_CONFIG: Record<RoleStatus, { color: string; bg: string; label: string; icon: typeof CheckCircle }> = {
  active: { color: '#10B981', bg: '#ECFDF5', label: '启用', icon: CheckCircle },
  inactive: { color: '#94A3B8', bg: '#F1F5F9', label: '停用', icon: XCircle },
};

// ==================== Helpers ====================
function createModulePerms(builtinMap?: Record<string, Partial<ModulePermission>>): Record<string, ModulePermission> {
  const result: Record<string, ModulePermission> = {};
  PERMISSION_MODULES.forEach((mod) => {
    const preset = builtinMap?.[mod.key];
    result[mod.key] = {
      module: mod.key,
      label: mod.label,
      view: preset?.view ?? false,
      create: preset?.create ?? false,
      edit: preset?.edit ?? false,
      delete: preset?.delete ?? false,
      export: preset?.export ?? false,
      approve: preset?.approve ?? false,
    };
  });
  return result;
}

function createFieldPerms(): Record<string, FieldPermission[]> {
  const result: Record<string, FieldPermission[]> = {};
  Object.entries(FIELD_PERMISSION_TEMPLATES).forEach(([key, fields]) => {
    result[key] = fields.map(f => ({ ...f }));
  });
  return result;
}

function countPermissions(modulePerms: Record<string, ModulePermission>): number {
  let count = 0;
  Object.values(modulePerms).forEach((m) => {
    if (m.view) count++;
    if (m.create) count++;
    if (m.edit) count++;
    if (m.delete) count++;
    if (m.export) count++;
    if (m.approve) count++;
  });
  return count;
}

// ==================== Mock Data ====================
const MOCK_ROLES: RoleItem[] = [
  {
    id: 'role-sysadmin', name: '系统管理员', code: 'SYS_ADMIN',
    description: '平台最高权限，可管理所有模块和功能',
    userCount: 1, builtin: true, status: 'active', createdAt: '2024-01-01',
    modulePermissions: createModulePerms(Object.fromEntries(PERMISSION_MODULES.map(m => [m.key, { view: true, create: true, edit: true, delete: true, export: true, approve: true }]))),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-orgadmin', name: '组织管理员', code: 'ORG_ADMIN',
    description: '组织级管理权限，可管理本组织及下级组织的用户和资源',
    userCount: 3, builtin: true, status: 'active', createdAt: '2024-01-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, carrier: { view: true, create: true, edit: true, export: true },
      fleet: { view: true, create: true, edit: true, export: true }, device: { view: true, create: true, edit: true, export: true },
      site: { view: true, create: true, edit: true, export: true }, transfer: { view: true, create: true, edit: true, export: true, approve: true },
      route: { view: true, create: true, edit: true, export: true }, alarm: { view: true, export: true },
      user: { view: true, create: true, edit: true }, role: { view: true }, settings: { view: true, edit: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-project', name: '项目管理员', code: 'PROJ_ADMIN',
    description: '项目管理权限，可管理项目内所有载具和流转',
    userCount: 2, builtin: true, status: 'active', createdAt: '2024-01-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, carrier: { view: true, create: true, edit: true, export: true },
      fleet: { view: true, export: true }, device: { view: true, export: true }, site: { view: true, export: true },
      transfer: { view: true, create: true, edit: true, export: true }, route: { view: true, create: true, edit: true, export: true },
      alarm: { view: true, export: true }, user: { view: true }, settings: { view: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-dispatcher', name: '调度员', code: 'DISPATCHER',
    description: '运输调度权限，负责调拨单管理和线路规划',
    userCount: 4, builtin: true, status: 'active', createdAt: '2024-01-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, carrier: { view: true }, fleet: { view: true },
      site: { view: true }, transfer: { view: true, create: true, edit: true, export: true },
      route: { view: true, create: true, edit: true, export: true }, alarm: { view: true, export: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-auditor', name: '审计员', code: 'AUDITOR',
    description: '审计查看权限，可查看所有模块数据但不可操作',
    userCount: 2, builtin: true, status: 'active', createdAt: '2024-01-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, carrier: { view: true, export: true },
      fleet: { view: true, export: true }, device: { view: true, export: true }, site: { view: true, export: true },
      transfer: { view: true, export: true }, route: { view: true, export: true },
      alarm: { view: true, export: true }, user: { view: true, export: true },
      role: { view: true }, settings: { view: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-whmanager', name: '仓库管理员', code: 'WH_MANAGER',
    description: '仓储管理权限，负责网点出入库和载具盘点',
    userCount: 5, builtin: false, status: 'active', createdAt: '2024-03-15',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, carrier: { view: true, create: true, edit: true, export: true },
      site: { view: true, create: true, edit: true }, transfer: { view: true, create: true, edit: true },
      alarm: { view: true, export: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-fleet', name: '车队管理员', code: 'FLEET_MGR',
    description: '车队管理权限，负责车辆、司机和调度',
    userCount: 3, builtin: false, status: 'active', createdAt: '2024-04-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, fleet: { view: true, create: true, edit: true, export: true },
      carrier: { view: true }, transfer: { view: true, create: true, edit: true },
      route: { view: true, export: true }, alarm: { view: true, export: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-device', name: '设备管理员', code: 'DEVICE_MGR',
    description: '设备运维权限，负责定位器和传感器的维护',
    userCount: 2, builtin: false, status: 'active', createdAt: '2024-04-20',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, device: { view: true, create: true, edit: true, delete: true, export: true },
      carrier: { view: true }, alarm: { view: true, export: true }, settings: { view: true, edit: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-viewer', name: '观察员', code: 'VIEWER',
    description: '只读权限，可查看指定模块的数据报表',
    userCount: 4, builtin: false, status: 'inactive', createdAt: '2024-05-10',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, carrier: { view: true }, transfer: { view: true },
      alarm: { view: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-driver', name: '司机', code: 'DRIVER',
    description: '移动端角色，仅可查看本人任务和上报异常',
    userCount: 12, builtin: false, status: 'active', createdAt: '2024-05-20',
    modulePermissions: createModulePerms({
      transfer: { view: true, edit: true }, map: { view: true }, alarm: { view: true, create: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-finance', name: '财务专员', code: 'FINANCE',
    description: '财务审核权限，负责调拨费用核对和成本分析',
    userCount: 2, builtin: false, status: 'active', createdAt: '2024-06-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, transfer: { view: true, export: true, approve: true },
      carrier: { view: true, export: true }, route: { view: true, export: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-security', name: '安全管理员', code: 'SECURITY',
    description: '安全管理权限，负责报警处理和电子围栏配置',
    userCount: 1, builtin: false, status: 'active', createdAt: '2024-06-15',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, map: { view: true }, alarm: { view: true, edit: true, export: true },
      carrier: { view: true }, site: { view: true, edit: true }, settings: { view: true, edit: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
  {
    id: 'role-report', name: '报表专员', code: 'REPORTER',
    description: '数据报表权限，负责导出各类运营报表',
    userCount: 1, builtin: false, status: 'inactive', createdAt: '2024-07-01',
    modulePermissions: createModulePerms({
      dashboard: { view: true }, carrier: { view: true, export: true },
      fleet: { view: true, export: true }, transfer: { view: true, export: true },
      route: { view: true, export: true }, device: { view: true, export: true },
      alarm: { view: true, export: true },
    }),
    fieldPermissions: createFieldPerms(),
  },
];

// 关联用户Mock数据
const MOCK_ROLE_USERS: Record<string, UserRef[]> = {
  'role-sysadmin': [
    { id: 'u-1', name: '系统管理员', account: 'admin', orgName: '云载科技（总部）', status: 'active', assignedAt: '2024-01-01' },
  ],
  'role-orgadmin': [
    { id: 'u-2', name: '张三', account: 'zhangsan', orgName: '上海运营中心', status: 'active', assignedAt: '2024-02-15' },
    { id: 'u-5', name: '赵六', account: 'zhaoliu', orgName: '华东汽车制造有限公司', status: 'active', assignedAt: '2024-04-01' },
    { id: 'u-7', name: '周八', account: 'zhouba', orgName: '北方供应链管理有限公司', status: 'active', assignedAt: '2024-06-01' },
  ],
  'role-project': [
    { id: 'u-8', name: '吴九', account: 'wujiu', orgName: '北京运营中心', status: 'active', assignedAt: '2024-06-15' },
    { id: 'u-14', name: '林二十', account: 'lin20', orgName: '杭州运营中心', status: 'active', assignedAt: '2024-08-01' },
  ],
  'role-dispatcher': [
    { id: 'u-3', name: '李四', account: 'lisi', orgName: '上海运营中心', status: 'active', assignedAt: '2024-03-01' },
    { id: 'u-10', name: '钱十一', account: 'qian11', orgName: '深圳配送中心', status: 'active', assignedAt: '2024-08-01' },
    { id: 'u-15', name: '黄二十一', account: 'huang21', orgName: '广州仓储中心', status: 'active', assignedAt: '2024-09-01' },
    { id: 'u-16', name: '何二十二', account: 'he22', orgName: '苏州昆山仓库', status: 'inactive', assignedAt: '2024-09-15' },
  ],
  'role-auditor': [
    { id: 'u-12', name: '陈十三', account: 'chen13', orgName: '天津港仓库', status: 'active', assignedAt: '2024-09-01' },
    { id: 'u-17', name: '高二十三', account: 'gao23', orgName: '云载科技（总部）', status: 'active', assignedAt: '2024-10-01' },
  ],
};

// ==================== Sub-components ====================

/** Status Tag */
function StatusTag({ status }: { status: RoleStatus }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium" style={{ color: cfg.color, backgroundColor: cfg.bg }}>
      <cfg.icon size={12} /> {cfg.label}
    </span>
  );
}

/** Builtin Tag */
function BuiltinTag({ builtin }: { builtin: boolean }) {
  if (builtin) {
    return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[10px]">系统预置</Badge>;
  }
  return <Badge variant="outline" className="text-[10px] text-[var(--neutral-text-secondary)]">自定义</Badge>;
}

/** Permission Matrix Cell */
function PermCell({ checked, onClick, disabled }: { checked: boolean; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={() => !disabled && onClick()}
      className={cn('flex items-center justify-center w-full h-full py-2', disabled && 'cursor-default opacity-40')}
    >
      {checked ? (
        <CheckSquare size={16} className="text-[#2563EB]" />
      ) : (
        <Square size={16} className="text-[#CBD5E1]" />
      )}
    </button>
  );
}

/** Permission Matrix Editor */
function PermissionMatrixEditor({
  permissions,
  onChange,
}: {
  permissions: Record<string, ModulePermission>;
  onChange: (perms: Record<string, ModulePermission>) => void;
}) {
  const toggle = (module: string, key: keyof Omit<ModulePermission, 'module' | 'label'>) => {
    const perm = permissions[module];
    if (!perm) return;
    const next: Record<string, ModulePermission> = {
      ...permissions,
      [module]: { ...perm, [key]: !perm[key] },
    };
    // Auto-check view when other perms checked
    if (key !== 'view' && next[module][key]) {
      next[module].view = true;
    }
    onChange(next);
  };

  const toggleModuleAll = (module: string) => {
    const perm = permissions[module];
    if (!perm) return;
    const allChecked = perm.view && perm.create && perm.edit && perm.delete && perm.export && perm.approve;
    const nextVal = !allChecked;
    onChange({
      ...permissions,
      [module]: { ...perm, view: nextVal, create: nextVal, edit: nextVal, delete: nextVal, export: nextVal, approve: nextVal },
    });
  };

  const permKeys: (keyof Omit<ModulePermission, 'module' | 'label'>)[] = ['view', 'create', 'edit', 'delete', 'export', 'approve'];
  const permLabels = ['查看', '新增', '编辑', '删除', '导出', '审批'];

  return (
    <div className="overflow-x-auto border border-[#E2E8F0] rounded-lg">
      <table className="w-full">
        <thead>
          <tr className="bg-[#F1F5F9]">
            <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] min-w-[140px]">功能模块</th>
            {permLabels.map((label) => (
              <th key={label} className="px-3 py-2.5 text-center text-[13px] font-medium text-[#475569] w-16">{label}</th>
            ))}
            <th className="px-3 py-2.5 text-center text-[13px] font-medium text-[#475569] w-20">全选</th>
          </tr>
        </thead>
        <tbody>
          {PERMISSION_MODULES.map((mod) => {
            const perm = permissions[mod.key];
            if (!perm) return null;
            const allChecked = perm.view && perm.create && perm.edit && perm.delete && perm.export && perm.approve;
            const someChecked = [perm.create, perm.edit, perm.delete, perm.export, perm.approve].some(Boolean) && !allChecked;
            return (
              <tr key={mod.key} className="border-b border-[#E2E8F0] hover:bg-[#F8FAFC]">
                <td className="px-3 py-2 text-sm font-medium text-[#0F172A]">{mod.label}</td>
                {permKeys.map((key) => (
                  <td key={key} className="px-1 py-1 text-center border-l border-[#F1F5F9]">
                    <PermCell checked={perm[key]} onClick={() => toggle(mod.key, key)} />
                  </td>
                ))}
                <td className="px-3 py-2 text-center border-l border-[#F1F5F9]">
                  <button onClick={() => toggleModuleAll(mod.key)} className="flex items-center justify-center w-full">
                    {allChecked ? <CheckSquare size={16} className="text-[#2563EB]" /> : someChecked ? <MinusSquare size={16} className="text-[#2563EB]" /> : <Square size={16} className="text-[#CBD5E1]" />}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/** Field Permission Editor */
function FieldPermissionEditor({
  fieldPermissions,
  onChange,
}: {
  fieldPermissions: Record<string, FieldPermission[]>;
  onChange: (perms: Record<string, FieldPermission[]>) => void;
}) {
  const [expandedModule, setExpandedModule] = useState<string | null>('carrier');

  const modules = Object.keys(FIELD_PERMISSION_TEMPLATES);

  const setLevel = (module: string, field: string, level: PermissionLevel) => {
    const list = fieldPermissions[module] || [];
    const next = {
      ...fieldPermissions,
      [module]: list.map((f) => (f.field === field ? { ...f, level } : f)),
    };
    onChange(next);
  };

  return (
    <div className="space-y-3">
      {modules.map((moduleKey) => {
        const fields = fieldPermissions[moduleKey] || [];
        const label = FIELD_PERMISSION_TEMPLATES[moduleKey]?.[0]?.label ? `${moduleKey === 'carrier' ? '载具管理' : '调拨管理'}` : moduleKey;
        const isExpanded = expandedModule === moduleKey;
        return (
          <div key={moduleKey} className="border border-[#E2E8F0] rounded-lg overflow-hidden">
            <button
              onClick={() => setExpandedModule(isExpanded ? null : moduleKey)}
              className="flex items-center justify-between w-full px-4 py-3 bg-[#F8FAFC] hover:bg-[#F1F5F9] transition-colors"
            >
              <span className="text-sm font-medium text-[#0F172A]">{label}</span>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[#94A3B8]">{fields.length} 个字段</span>
                {isExpanded ? <ChevronDown size={16} className="text-[#475569]" /> : <ChevronRight size={16} className="text-[#475569]" />}
              </div>
            </button>
            {isExpanded && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#F1F5F9]">
                      <th className="px-4 py-2 text-left text-[12px] font-medium text-[#475569]">字段名称</th>
                      <th className="px-4 py-2 text-center text-[12px] font-medium text-[#475569] w-28">可见且可编辑</th>
                      <th className="px-4 py-2 text-center text-[12px] font-medium text-[#475569] w-28">仅可见</th>
                      <th className="px-4 py-2 text-center text-[12px] font-medium text-[#475569] w-28">隐藏</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fields.map((f) => (
                      <tr key={f.field} className="border-t border-[#F1F5F9]">
                        <td className="px-4 py-2.5 text-sm text-[#475569]">{f.label}</td>
                        {(['edit', 'view', 'none'] as PermissionLevel[]).map((level) => (
                          <td key={level} className="px-4 py-2.5 text-center">
                            <button
                              onClick={() => setLevel(moduleKey, f.field, level)}
                              className="flex items-center justify-center w-full"
                            >
                              {f.level === level ? (
                                <CheckSquare size={16} className="text-[#2563EB]" />
                              ) : (
                                <Square size={16} className="text-[#CBD5E1]" />
                              )}
                            </button>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </motion.div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/** Role Users Tab */
function RoleUsersTab({ roleId }: { roleId: string }) {
  const users = MOCK_ROLE_USERS[roleId] || [];
  return (
    <div className="space-y-3">
      {users.length > 0 ? (
        <div className="overflow-x-auto border border-[#E2E8F0] rounded-lg">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">姓名</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">账号</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">所属组织</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">分配时间</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b border-[#E2E8F0] hover:bg-[#F8FAFC]">
                  <td className="px-3 py-3 text-sm font-medium text-[#0F172A]">{u.name}</td>
                  <td className="px-3 py-3 text-sm text-[#475569]">{u.account}</td>
                  <td className="px-3 py-3 text-sm text-[#475569]">{u.orgName}</td>
                  <td className="px-3 py-3"><StatusTag status={u.status} /></td>
                  <td className="px-3 py-3 text-xs text-[#94A3B8] font-mono">{u.assignedAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3 py-12">
          <Users size={48} className="text-[#CBD5E1]" />
          <p className="text-sm text-[#475569]">暂无用户关联此角色</p>
        </div>
      )}
    </div>
  );
}

/** Role Edit/Detail Dialog */
function RoleEditDialog({
  role,
  onClose,
  onSave,
}: {
  role: RoleItem | null;
  onClose: () => void;
  onSave: (role: RoleItem) => void;
}) {
  const isCreate = !role;
  const [activeTab, setActiveTab] = useState('basic');
  const [form, setForm] = useState<Partial<RoleItem>>(() => {
    if (role) return { ...role };
    return {
      name: '', code: '', description: '', status: 'active',
      modulePermissions: createModulePerms(),
      fieldPermissions: createFieldPerms(),
    };
  });

  const handleSave = () => {
    const next: RoleItem = {
      id: role?.id || `role-${Date.now()}`,
      name: form.name || '未命名角色',
      code: form.code || `ROLE_${Date.now()}`,
      description: form.description || '',
      userCount: role?.userCount || 0,
      permissionCount: countPermissions(form.modulePermissions || {}),
      builtin: false,
      status: (form.status as RoleStatus) || 'active',
      createdAt: role?.createdAt || new Date().toISOString().split('T')[0],
      modulePermissions: form.modulePermissions || createModulePerms(),
      fieldPermissions: form.fieldPermissions || createFieldPerms(),
    };
    onSave(next);
    onClose();
  };

  const updateModulePerms = (perms: Record<string, ModulePermission>) => {
    setForm(prev => ({ ...prev, modulePermissions: perms }));
  };

  const updateFieldPerms = (perms: Record<string, FieldPermission[]>) => {
    setForm(prev => ({ ...prev, fieldPermissions: perms }));
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield size={18} className="text-[#2563EB]" />
            {isCreate ? '新建角色' : `编辑角色 - ${role?.name}`}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-2">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">基本信息</TabsTrigger>
            <TabsTrigger value="permissions">权限配置</TabsTrigger>
            <TabsTrigger value="fields">字段权限</TabsTrigger>
            {!isCreate && <TabsTrigger value="users">关联用户</TabsTrigger>}
            {isCreate && <TabsTrigger value="users" disabled>关联用户</TabsTrigger>}
          </TabsList>

          <TabsContent value="basic" className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>角色名称 <span className="text-red-500">*</span></Label>
                <Input
                  value={form.name || ''}
                  onChange={(e) => setForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="请输入角色名称"
                />
              </div>
              <div className="space-y-2">
                <Label>角色编码 <span className="text-red-500">*</span></Label>
                <Input
                  value={form.code || ''}
                  onChange={(e) => setForm(prev => ({ ...prev, code: e.target.value }))}
                  placeholder="请输入角色编码"
                  disabled={role?.builtin}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>描述</Label>
              <Textarea
                value={form.description || ''}
                onChange={(e) => setForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="请输入角色描述"
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>状态</Label>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={form.status === 'active'}
                    onCheckedChange={(v) => setForm(prev => ({ ...prev, status: v ? 'active' : 'inactive' }))}
                  />
                  <span className="text-sm text-[#475569]">{form.status === 'active' ? '启用' : '停用'}</span>
                </div>
                {role?.builtin && (
                  <span className="text-xs text-[#94A3B8]">系统预置角色不可删除</span>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="permissions" className="space-y-4 pt-4">
            <p className="text-sm text-[#94A3B8]">配置角色在各功能模块中的操作权限，勾选"查看"后该模块在菜单中可见。</p>
            <PermissionMatrixEditor permissions={form.modulePermissions || {}} onChange={updateModulePerms} />
          </TabsContent>

          <TabsContent value="fields" className="space-y-4 pt-4">
            <p className="text-sm text-[#94A3B8]">配置角色在各模块中的字段可见性，可选择"可见且可编辑"、"仅可见"或"隐藏"。</p>
            <FieldPermissionEditor fieldPermissions={form.fieldPermissions || {}} onChange={updateFieldPerms} />
          </TabsContent>

          <TabsContent value="users" className="space-y-4 pt-4">
            {!isCreate && role && <RoleUsersTab roleId={role.id} />}
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSave} className="bg-[#2563EB] hover:bg-[#1D4ED8]">
            <CheckSquare size={16} className="mr-1" />保存
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Delete Confirm Dialog */
function DeleteDialog({ role, onClose, onConfirm }: { role: RoleItem; onClose: () => void; onConfirm: () => void }) {
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <Trash2 size={18} /> 删除角色
          </DialogTitle>
        </DialogHeader>
        <div className="py-4">
          <p className="text-sm text-[#475569]">
            确认删除角色 <strong className="text-[#0F172A]">{role.name}</strong> 吗？
          </p>
          {role.userCount > 0 && (
            <p className="text-sm text-red-500 mt-2">该角色下还有 {role.userCount} 个用户，请先移除关联用户后再删除。</p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button
            variant="destructive"
            onClick={onConfirm}
            disabled={role.userCount > 0}
          >
            确认删除
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Copy Role Dialog */
function CopyRoleDialog({ role, onClose, onSave }: { role: RoleItem; onClose: () => void; onSave: (r: RoleItem) => void }) {
  const [name, setName] = useState(`${role.name}（副本）`);
  const [code, setCode] = useState(`${role.code}_COPY`);
  const [description, setDescription] = useState(role.description);

  const handleSave = () => {
    const next: RoleItem = {
      ...role,
      id: `role-${Date.now()}`,
      name,
      code,
      description,
      builtin: false,
      userCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'active',
      modulePermissions: JSON.parse(JSON.stringify(role.modulePermissions)),
      fieldPermissions: JSON.parse(JSON.stringify(role.fieldPermissions)),
    };
    onSave(next);
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy size={18} className="text-[#2563EB]" /> 复制角色
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>新角色名称 <span className="text-red-500">*</span></Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>新角色编码 <span className="text-red-500">*</span></Label>
            <Input value={code} onChange={(e) => setCode(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>描述</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
          </div>
          <p className="text-xs text-[#94A3B8]">复制后将继承原角色的所有权限配置，可进行修改。</p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSave} className="bg-[#2563EB] hover:bg-[#1D4ED8]">确认复制</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Permission Matrix Preview (read-only) */
function PermissionPreviewDialog({ role, onClose }: { role: RoleItem; onClose: () => void }) {
  const permKeys: (keyof Omit<ModulePermission, 'module' | 'label'>)[] = ['view', 'create', 'edit', 'delete', 'export', 'approve'];
  const permLabels = ['查看', '新增', '编辑', '删除', '导出', '审批'];

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye size={18} className="text-[#2563EB]" /> 权限预览 - {role.name}
          </DialogTitle>
        </DialogHeader>
        <div className="overflow-x-auto border border-[#E2E8F0] rounded-lg mt-4">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] min-w-[140px]">功能模块</th>
                {permLabels.map((label) => (
                  <th key={label} className="px-3 py-2.5 text-center text-[13px] font-medium text-[#475569] w-16">{label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PERMISSION_MODULES.map((mod) => {
                const perm = role.modulePermissions[mod.key];
                if (!perm) return null;
                return (
                  <tr key={mod.key} className="border-b border-[#E2E8F0] hover:bg-[#F8FAFC]">
                    <td className="px-3 py-2 text-sm font-medium text-[#0F172A]">{mod.label}</td>
                    {permKeys.map((key) => (
                      <td key={key} className="px-1 py-2 text-center border-l border-[#F1F5F9]">
                        {perm[key] ? (
                          <CheckSquare size={16} className="text-[#2563EB] mx-auto" />
                        ) : (
                          <span className="text-[#CBD5E1]">—</span>
                        )}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={onClose}>关闭</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ==================== Main Page ====================
export default function RoleManagementPage() {
  const [roles, setRoles] = useState<RoleItem[]>(MOCK_ROLES.map(r => ({ ...r })));
  const [search, setSearch] = useState('');
  const [builtinFilter, setBuiltinFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Dialogs
  const [editRole, setEditRole] = useState<RoleItem | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [deleteRole, setDeleteRole] = useState<RoleItem | null>(null);
  const [copyRole, setCopyRole] = useState<RoleItem | null>(null);
  const [previewRole, setPreviewRole] = useState<RoleItem | null>(null);

  // Filtered roles
  const filteredRoles = useMemo(() => {
    return roles.filter((r) => {
      if (builtinFilter !== 'all') {
        const isBuiltin = builtinFilter === 'builtin';
        if (r.builtin !== isBuiltin) return false;
      }
      if (statusFilter !== 'all' && r.status !== statusFilter) return false;
      if (search) {
        const q = search.toLowerCase();
        return r.name.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.description.toLowerCase().includes(q);
      }
      return true;
    });
  }, [roles, builtinFilter, statusFilter, search]);

  const totalPages = Math.ceil(filteredRoles.length / pageSize);
  const paginatedRoles = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRoles.slice(start, start + pageSize);
  }, [filteredRoles, currentPage]);

  // Stats
  const stats = useMemo(() => ({
    total: roles.length,
    builtin: roles.filter(r => r.builtin).length,
    custom: roles.filter(r => !r.builtin).length,
    active: roles.filter(r => r.status === 'active').length,
    totalUsers: roles.reduce((sum, r) => sum + r.userCount, 0),
  }), [roles]);

  // Actions
  const toggleStatus = useCallback((id: string) => {
    setRoles(prev => prev.map(r => r.id === id ? { ...r, status: r.status === 'active' ? 'inactive' : 'active' } : r));
  }, []);

  const handleSaveRole = useCallback((role: RoleItem) => {
    setRoles(prev => {
      const idx = prev.findIndex(r => r.id === role.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = role;
        return next;
      }
      return [...prev, role];
    });
  }, []);

  const handleDelete = useCallback(() => {
    if (deleteRole) {
      setRoles(prev => prev.filter(r => r.id !== deleteRole.id));
      setDeleteRole(null);
    }
  }, [deleteRole]);

  const handleCopy = useCallback((role: RoleItem) => {
    setRoles(prev => [...prev, role]);
    setCopyRole(null);
  }, []);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)] mb-1">角色管理</h1>
        <p className="text-sm text-[var(--neutral-text-secondary)]">角色列表 · 权限配置 · 字段权限 · 关联用户</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '角色总数', value: stats.total, icon: Shield, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '系统预置', value: stats.builtin, icon: Lock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '自定义', value: stats.custom, icon: Unlock, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '启用中', value: stats.active, icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
          { label: '关联用户', value: stats.totalUsers, icon: Users, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <Select value={builtinFilter} onValueChange={(v) => { setBuiltinFilter(v); setCurrentPage(1); }}>
          <SelectTrigger className="w-[140px] h-9">
            <SelectValue placeholder="全部类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="builtin">系统预置</SelectItem>
            <SelectItem value="custom">自定义</SelectItem>
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1); }}>
          <SelectTrigger className="w-[120px] h-9">
            <SelectValue placeholder="全部状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="active">启用</SelectItem>
            <SelectItem value="inactive">停用</SelectItem>
          </SelectContent>
        </Select>

        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              placeholder="搜索角色名称、编码、描述..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>

        <Button
          onClick={() => setShowCreate(true)}
          className="h-9 bg-[#2563EB] hover:bg-[#1D4ED8] text-white flex items-center gap-2"
        >
          <Plus size={15} /> 新增角色
        </Button>
      </div>

      {/* Role Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">角色名称</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">角色编码</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">描述</th>
                <th className="px-3 py-2.5 text-center text-[13px] font-medium text-[#475569]">用户数量</th>
                <th className="px-3 py-2.5 text-center text-[13px] font-medium text-[#475569]">权限数量</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">预置</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">创建时间</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedRoles.map((role, idx) => (
                <motion.tr
                  key={role.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.15, delay: idx * 0.02 }}
                  className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group"
                >
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                        <Shield size={16} className="text-[#2563EB]" />
                      </div>
                      <span className="text-sm font-medium text-[#0F172A]">{role.name}</span>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <span className="text-xs text-[#475569] font-mono">{role.code}</span>
                  </td>
                  <td className="px-3 py-3">
                    <span className="text-sm text-[#475569] truncate max-w-[200px] inline-block" title={role.description}>{role.description}</span>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className="text-sm text-[#475569]">{role.userCount}</span>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className="text-sm text-[#475569]">{role.permissionCount}</span>
                  </td>
                  <td className="px-3 py-3">
                    <BuiltinTag builtin={role.builtin} />
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={role.status === 'active'}
                        onCheckedChange={() => toggleStatus(role.id)}
                        disabled={role.builtin}
                      />
                      <StatusTag status={role.status} />
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <span className="text-xs text-[#94A3B8] font-mono">{role.createdAt}</span>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => setEditRole(role)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="编辑">
                        <Edit3 size={13} className="text-[#475569]" />
                      </button>
                      <button onClick={() => setPreviewRole(role)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="权限预览">
                        <Eye size={13} className="text-[#475569]" />
                      </button>
                      <button onClick={() => setCopyRole(role)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="复制角色">
                        <Copy size={13} className="text-[#475569]" />
                      </button>
                      {!role.builtin && (
                        <button onClick={() => setDeleteRole(role)} className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="删除">
                          <Trash2 size={13} className="text-[#EF4444]" />
                        </button>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
              {paginatedRoles.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Shield size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无角色数据</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredRoles.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">共 <strong>{filteredRoles.length}</strong> 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">上一页</button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button key={page} onClick={() => setCurrentPage(page)} className={cn('w-8 h-8 rounded-md text-sm font-medium transition-colors', currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]')}>{page}</button>
                );
              })}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">下一页</button>
            </div>
          </div>
        )}
      </div>

      {/* Role Cards (Quick View) */}
      <div>
        <h3 className="text-base font-semibold text-[#0F172A] mb-4">系统预置角色</h3>
        <div className="grid grid-cols-3 gap-4">
          {roles.filter(r => r.builtin).map((role) => (
            <motion.div
              key={role.id}
              whileHover={{ y: -2 }}
              className="bg-white rounded-lg shadow-card p-5 hover:shadow-card-hover transition-shadow group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
                  <Shield size={20} className="text-[#2563EB]" />
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => setEditRole(role)} className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center" title="编辑">
                    <Edit3 size={13} className="text-[#475569]" />
                  </button>
                  <button onClick={() => setPreviewRole(role)} className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center" title="预览权限">
                    <Eye size={13} className="text-[#475569]" />
                  </button>
                </div>
              </div>
              <h4 className="text-base font-semibold text-[#0F172A] mb-1">{role.name}</h4>
              <p className="text-xs text-[#94A3B8] mb-3 line-clamp-2">{role.description}</p>
              <div className="flex items-center justify-between text-xs text-[#475569]">
                <span className="flex items-center gap-1"><Users size={12} /> {role.userCount} 位用户</span>
                <span className="flex items-center gap-1"><CheckSquare size={12} /> {role.permissionCount} 项权限</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Dialogs */}
      {(editRole || showCreate) && (
        <RoleEditDialog
          role={showCreate ? null : editRole}
          onClose={() => { setEditRole(null); setShowCreate(false); }}
          onSave={handleSaveRole}
        />
      )}

      {deleteRole && (
        <DeleteDialog
          role={deleteRole}
          onClose={() => setDeleteRole(null)}
          onConfirm={handleDelete}
        />
      )}

      {copyRole && (
        <CopyRoleDialog
          role={copyRole}
          onClose={() => setCopyRole(null)}
          onSave={handleCopy}
        />
      )}

      {previewRole && (
        <PermissionPreviewDialog
          role={previewRole}
          onClose={() => setPreviewRole(null)}
        />
      )}
    </div>
  );
}
