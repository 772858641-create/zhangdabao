import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Wifi,
  MessageSquare,
  Zap,
  AlertTriangle,
  LayoutDashboard,
  Monitor,
  Radio,
  Cpu,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import IotOverviewTab from './IotOverviewTab';
import IotDeviceMonitorTab from './IotDeviceMonitorTab';
import IotDataStreamTab from './IotDataStreamTab';
import IotRuleEngineTab from './IotRuleEngineTab';
import IotTimeSeriesTab from './IotTimeSeriesTab';

interface StatCard {
  label: string;
  value: string;
  sub: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

const stats: StatCard[] = [
  {
    label: '在线设备',
    value: '342',
    sub: '/ 440 总数',
    icon: Wifi,
    color: 'text-success',
    bgColor: 'bg-success-light',
  },
  {
    label: '今日消息',
    value: '21.4K',
    sub: '+12.5% 环比',
    icon: MessageSquare,
    color: 'text-primary',
    bgColor: 'bg-primary-light',
  },
  {
    label: '规则命中',
    value: '1,847',
    sub: '今日触发次数',
    icon: Zap,
    color: 'text-warning',
    bgColor: 'bg-warning-light',
  },
  {
    label: '活跃告警',
    value: '23',
    sub: '待处理',
    icon: AlertTriangle,
    color: 'text-danger',
    bgColor: 'bg-danger-light',
  },
];

const tabItems = [
  { value: 'overview', label: '总览', icon: LayoutDashboard },
  { value: 'devices', label: '设备监控', icon: Monitor },
  { value: 'stream', label: '数据流', icon: Radio },
  { value: 'rules', label: '规则引擎', icon: Cpu },
  { value: 'timeseries', label: '时序数据', icon: BarChart3 },
];

export default function IotPlatformPage() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold text-neutral-textPrimary">IoT 数据中台</h1>
        <p className="text-sm text-neutral-textSecondary mt-1">
          设备接入 · 实时监控 · 规则引擎 · 时序分析
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.06 }}
            >
              <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={cn('w-10 h-10 rounded-full flex items-center justify-center shrink-0', stat.bgColor)}>
                    <Icon size={20} className={stat.color} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-neutral-textTertiary">{stat.label}</p>
                    <p className="text-lg font-semibold text-neutral-textPrimary font-number truncate">{stat.value}</p>
                    <p className="text-xs text-neutral-textTertiary">{stat.sub}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-neutral-surface-elevated border border-neutral-border h-10 p-1">
          {tabItems.map((tab) => {
            const Icon = tab.icon;
            return (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className={cn(
                  'text-xs px-3 py-1.5 rounded-md transition-all data-[state=active]:shadow-sm',
                  activeTab === tab.value
                    ? 'bg-neutral-surface text-neutral-textPrimary font-medium'
                    : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                )}
              >
                <Icon size={14} className="mr-1.5" />
                {tab.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value="overview" className="mt-0">
          <IotOverviewTab />
        </TabsContent>
        <TabsContent value="devices" className="mt-0">
          <IotDeviceMonitorTab />
        </TabsContent>
        <TabsContent value="stream" className="mt-0">
          <IotDataStreamTab />
        </TabsContent>
        <TabsContent value="rules" className="mt-0">
          <IotRuleEngineTab />
        </TabsContent>
        <TabsContent value="timeseries" className="mt-0">
          <IotTimeSeriesTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
