import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
} from 'recharts';
import {
  Sparkles,
  Filter,
  CopyX,
  FilePlus,
  Settings2,
  BarChart3,
  ScrollText,
  Search,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ================================================================
   Theme
   ================================================================ */

const THEME = {
  spaceBg: '#070B19',
  spaceBgLight: '#0B1128',
  surfaceElevated: '#111D3D',
  borderSubtle: '#1A2B52',
  borderMedium: '#243B6D',
  textPrimary: '#E8EEF7',
  textSecondary: '#7A8BAF',
  textTertiary: '#4A5D85',
  auroraCyan: '#00D4FF',
  auroraCyanDim: 'rgba(0, 212, 255, 0.15)',
  auroraGreen: '#00FF9D',
  auroraPurple: '#9D4EDD',
  auroraOrange: '#FF8C42',
  auroraPink: '#F72585',
  chart1: '#00D4FF',
  chart2: '#00FF9D',
  chart3: '#FF8C42',
  chart4: '#9D4EDD',
  chart5: '#F72585',
};

/* ================================================================
   Chart Styles
   ================================================================ */

const chartTooltipStyle = {
  backgroundColor: 'rgba(7, 11, 25, 0.95)',
  border: '1px solid rgba(0, 212, 255, 0.2)',
  borderRadius: '8px',
  fontSize: '12px',
  color: '#E8EEF7',
  backdropFilter: 'blur(8px)',
  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
};

/* ================================================================
   Types
   ================================================================ */

interface CleaningRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
}

interface CleaningLog {
  id: string;
  time: string;
  ruleType: string;
  deviceId: string;
  originalValue: string;
  processedValue: string;
  method: '过滤' | '修正' | '补全';
}

/* ================================================================
   Mock Data
   ================================================================ */

const CLEANING_EFFECT_DATA = [
  { day: '01-15', raw: 105200, cleaned: 102800, filtered: 2400 },
  { day: '01-16', raw: 98200, cleaned: 95900, filtered: 2300 },
  { day: '01-17', raw: 112000, cleaned: 109400, filtered: 2600 },
  { day: '01-18', raw: 98700, cleaned: 96400, filtered: 2300 },
  { day: '01-19', raw: 108500, cleaned: 106100, filtered: 2400 },
  { day: '01-20', raw: 101200, cleaned: 98800, filtered: 2400 },
  { day: '01-21', raw: 98500, cleaned: 96200, filtered: 2300 },
];

const RULE_TYPES = ['异常值过滤', '重复去重', '缺失值补全', '坐标转换', '时间戳校准', '格式标准化'];
const METHODS: ('过滤' | '修正' | '补全')[] = ['过滤', '修正', '补全'];

function generateCleaningLogs(): CleaningLog[] {
  const logs: CleaningLog[] = [];
  const originalValues = [
    'lat: 999.99, lng: 199.99',
    'rssi: -15dBm',
    'battery: 105%',
    'temperature: null',
    'lat: 39.90, lng: 116.40 (GCJ-02)',
    'timestamp: 2024-01-15 14:20:00 (dev)',
    'field: dev_temp → temperature',
    'location: null, last: 31.23,121.47@2h',
    'battery: -3%',
    'tag_id: TAG-001 scanned@GW-003 x3',
  ];
  const processedValues = [
    'lat: 31.23, lng: 121.47',
    '[filtered]',
    'battery: 100%',
    'temperature: 24.5C (batch avg)',
    'lat: 39.9042, lng: 116.4074 (WGS84)',
    'timestamp: 2024-01-15 14:32:18 (srv) [drift]',
    'field: temperature',
    'location: 31.23,121.47 [stale: 2h]',
    'battery: 0%',
    'tag_id: TAG-001 [deduped]',
  ];
  for (let i = 1; i <= 20; i++) {
    const method = METHODS[i % METHODS.length];
    logs.push({
      id: `log_${i}`,
      time: `2024-01-15 ${String(8 + Math.floor(i / 3)).padStart(2, '0')}:${String((i * 7) % 60).padStart(2, '0')}:${String((i * 13) % 60).padStart(2, '0')}`,
      ruleType: RULE_TYPES[i % RULE_TYPES.length],
      deviceId: `LOC-2024-${String(10000 + i).slice(1)}`,
      originalValue: originalValues[i % originalValues.length],
      processedValue: processedValues[i % processedValues.length],
      method,
    });
  }
  return logs;
}

const CLEANING_LOGS = generateCleaningLogs();

/* ================================================================
   Glass Card Component
   ================================================================ */

function GlassCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn('rounded-[10px] backdrop-blur-[12px]', className)}
      style={{
        background: 'rgba(11, 17, 40, 0.7)',
        border: '1px solid rgba(26, 43, 82, 0.8)',
        boxShadow: '0 2px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.03)',
      }}
    >
      {children}
    </div>
  );
}

/* ================================================================
   KPI Card Component
   ================================================================ */

interface KPICardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  accent: string;
}

function KPICard({ icon: Icon, label, value, sub, accent }: KPICardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="rounded-[10px] p-4"
      style={{
        background: 'rgba(11, 17, 40, 0.8)',
        border: `1px solid ${accent}40`,
        boxShadow: `0 0 16px ${accent}10, inset 0 1px 0 rgba(255,255,255,0.04)`,
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Icon size={16} style={{ color: accent }} />
        <span className="text-[11px] font-medium" style={{ color: THEME.textSecondary }}>{label}</span>
      </div>
      <div className="text-[22px] font-bold font-mono" style={{ color: THEME.textPrimary }}>{value}</div>
      <div className="text-xs mt-1" style={{ color: THEME.textTertiary }}>{sub}</div>
    </motion.div>
  );
}

/* ================================================================
   Toggle Switch Component
   ================================================================ */

function ToggleSwitch({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button
      onClick={onChange}
      className="relative w-9 h-5 rounded-full transition-colors duration-200 shrink-0"
      style={{ background: checked ? '#00D4FF' : 'rgba(26, 43, 82, 0.8)' }}
    >
      <div
        className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all duration-200"
        style={{ left: checked ? 18 : 2 }}
      />
    </button>
  );
}

/* ================================================================
   Method Badge Component
   ================================================================ */

function MethodBadge({ method }: { method: '过滤' | '修正' | '补全' }) {
  const colors = {
    过滤: { bg: 'rgba(247, 37, 133, 0.12)', color: '#F72585', border: 'rgba(247, 37, 133, 0.3)' },
    修正: { bg: 'rgba(255, 140, 66, 0.12)', color: '#FF8C42', border: 'rgba(255, 140, 66, 0.3)' },
    补全: { bg: 'rgba(157, 78, 221, 0.12)', color: '#9D4EDD', border: 'rgba(157, 78, 221, 0.3)' },
  };
  const c = colors[method];
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-[6px] text-[10px] font-medium"
      style={{ background: c.bg, color: c.color, border: `1px solid ${c.border}` }}
    >
      {method}
    </span>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function DataCleanTab() {
  const [rules, setRules] = useState<CleaningRule[]>([
    { id: 'r1', name: '异常值过滤', description: 'GPS坐标超中国边界或偏离>500km丢弃；RSSI超出-30~-100dBm丢弃；电量>100%或<0%修正为边界值', enabled: true },
    { id: 'r2', name: '重复数据去重', description: '同一标签10秒内被同一网关多次扫描仅保留第一次；定位器1小时周期内多次上报仅保留最后一次', enabled: true },
    { id: 'r3', name: '缺失值补全', description: '设备离线时返回"最后已知位置"并标注时效；缺失温度用同批次平均值补全', enabled: true },
    { id: 'r4', name: '坐标系统一', description: '所有GPS统一转WGS84', enabled: true },
    { id: 'r5', name: '时间戳校准', description: '服务器接收时间为准，偏差>5分钟标记时钟异常', enabled: true },
    { id: 'r6', name: '数据格式标准化', description: '不同厂商字段名统一映射', enabled: true },
  ]);

  const [ruleTypeFilter, setRuleTypeFilter] = useState('All');
  const [methodFilter, setMethodFilter] = useState('All');
  const [searchText, setSearchText] = useState('');

  const filteredLogs = useMemo(() => {
    return CLEANING_LOGS.filter((l) => {
      if (ruleTypeFilter !== 'All' && l.ruleType !== ruleTypeFilter) return false;
      if (methodFilter !== 'All' && l.method !== methodFilter) return false;
      if (searchText && !l.deviceId.toLowerCase().includes(searchText.toLowerCase())) return false;
      return true;
    });
  }, [ruleTypeFilter, methodFilter, searchText]);

  const handleToggleRule = (id: string) => {
    setRules((prev) => prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r)));
  };

  return (
    <div className="space-y-5">
      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard icon={Sparkles} label="今日清洗量" value="98.5K" sub="条" accent={THEME.auroraCyan} />
        <KPICard icon={Filter} label="异常过滤率" value="2.3%" sub="过滤脏数据占比" accent={THEME.auroraOrange} />
        <KPICard icon={CopyX} label="重复去重数" value="1,240" sub="条" accent={THEME.auroraPurple} />
        <KPICard icon={FilePlus} label="缺失补全数" value="856" sub="条" accent={THEME.auroraGreen} />
      </div>

      {/* ── Cleaning Rule Configuration ── */}
      <GlassCard className="p-4">
        <div className="flex items-center gap-2 mb-4">
          <Settings2 size={16} style={{ color: THEME.auroraCyan }} />
          <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>清洗规则配置</h3>
        </div>

        <div className="divide-y" style={{ borderColor: 'rgba(26, 43, 82, 0.5)' }}>
          {rules.map((rule, idx) => (
            <div key={rule.id} className="flex items-start gap-3 py-3 px-2">
              <ToggleSwitch checked={rule.enabled} onChange={() => handleToggleRule(rule.id)} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold" style={{ color: THEME.textPrimary }}>
                    {idx + 1}. {rule.name}
                  </span>
                </div>
                <p className="text-xs mt-1 leading-relaxed" style={{ color: THEME.textSecondary }}>
                  {rule.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* ── Row: Combo Chart + Log Table ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cleaning Effect Combo Chart */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>清洗效果统计</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={CLEANING_EFFECT_DATA}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(26, 43, 82, 0.4)" />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 11, fill: '#4A5D85' }}
                axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#4A5D85' }}
                axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
                tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}K`}
              />
              <Tooltip
                contentStyle={chartTooltipStyle as any}
                formatter={(value: number, name: string) => [`${value.toLocaleString()}`, name]}
              />
              <Legend wrapperStyle={{ fontSize: '11px', color: THEME.textSecondary }} />
              <Bar dataKey="raw" name="原始数据量" fill="#00D4FF" barSize={24} radius={[4, 4, 0, 0]} opacity={0.85} />
              <Bar dataKey="cleaned" name="清洗后数据量" fill="#00FF9D" barSize={24} radius={[4, 4, 0, 0]} opacity={0.85} />
              <Line type="monotone" dataKey="filtered" name="过滤数据量" stroke="#F72585" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </GlassCard>

        {/* Cleaning Log Table */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <ScrollText size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>清洗日志</h3>
          </div>

          {/* Filter bar */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Filter size={14} style={{ color: THEME.textTertiary }} />
            <select
              value={ruleTypeFilter}
              onChange={(e) => setRuleTypeFilter(e.target.value)}
              className="rounded-md px-2 py-1 text-xs outline-none"
              style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)', color: THEME.textSecondary }}
            >
              <option value="All">规则类型</option>
              <option value="异常值过滤">异常值过滤</option>
              <option value="重复去重">重复去重</option>
              <option value="缺失值补全">缺失值补全</option>
              <option value="坐标转换">坐标转换</option>
              <option value="时间戳校准">时间戳校准</option>
              <option value="格式标准化">格式标准化</option>
            </select>
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="rounded-md px-2 py-1 text-xs outline-none"
              style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)', color: THEME.textSecondary }}
            >
              <option value="All">处理方式</option>
              <option value="过滤">过滤</option>
              <option value="修正">修正</option>
              <option value="补全">补全</option>
            </select>
            <div className="flex items-center gap-1 rounded-md px-2 py-1 flex-1 max-w-[160px]" style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)' }}>
              <Search size={12} style={{ color: THEME.textTertiary }} />
              <input
                type="text"
                placeholder="设备ID"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                className="bg-transparent outline-none text-xs w-full"
                style={{ color: THEME.textSecondary }}
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-auto max-h-[340px]">
            {/* Header */}
            <div
              className="grid gap-2 px-3 py-2 text-[11px] font-semibold uppercase tracking-wide sticky top-0"
              style={{
                gridTemplateColumns: '130px 100px 100px 140px 140px 70px',
                background: 'rgba(17, 29, 61, 0.6)',
                borderBottom: '1px solid rgba(36, 59, 109, 0.5)',
                color: THEME.textTertiary,
              }}
            >
              <div>时间</div>
              <div>规则类型</div>
              <div>设备ID</div>
              <div>原始值</div>
              <div>处理后值</div>
              <div>处理方式</div>
            </div>
            {/* Body */}
            {filteredLogs.map((log, idx) => (
              <div
                key={log.id}
                className="grid gap-2 px-3 py-2 text-xs transition-colors"
                style={{
                  gridTemplateColumns: '130px 100px 100px 140px 140px 70px',
                  borderBottom: '1px solid rgba(26, 43, 82, 0.5)',
                  background: idx % 2 === 0 ? 'rgba(11, 17, 40, 0.4)' : 'rgba(11, 17, 40, 0.6)',
                  color: THEME.textSecondary,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0, 212, 255, 0.04)')}
                onMouseLeave={(e) => (e.currentTarget.style.background = idx % 2 === 0 ? 'rgba(11, 17, 40, 0.4)' : 'rgba(11, 17, 40, 0.6)')}
              >
                <div className="font-mono truncate">{log.time}</div>
                <div className="truncate">{log.ruleType}</div>
                <div className="font-mono truncate">{log.deviceId}</div>
                <div className="truncate" style={{ color: THEME.textPrimary }}>{log.originalValue}</div>
                <div className="truncate" style={{ color: THEME.auroraGreen }}>{log.processedValue}</div>
                <div><MethodBadge method={log.method} /></div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
