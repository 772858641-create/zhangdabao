import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Play,
  Pause,
  MapPin,
  Clock,
  Gauge,
  Route,
  Truck,
  Calendar,
  AlertTriangle,
  ChevronRight,
  Navigation,
  Timer,
  Zap,
  Flag,
  Circle,
  RotateCcw,
  FastForward,
  Rewind,
  Filter,
  X,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
// Table imports available if needed
// import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { cn } from '@/lib/utils';

// ============================================================
// Types
// ============================================================

interface TrackPoint {
  x: number;
  y: number;
  name: string;
  time: string;
  stayMinutes?: number;
}

interface AlarmEvent {
  id: string;
  time: string;
  type: string;
  level: 'high' | 'medium' | 'low';
  description: string;
}

interface SpeedPoint {
  time: string;
  speed: number;
  distance: number;
}

interface TrackRecord {
  id: string;
  orderNo: string;
  vehicleNo: string;
  vehicleType: string;
  from: string;
  to: string;
  distance: number;
  startTime: string;
  endTime: string;
  status: 'completed' | 'in_progress' | 'abnormal';
  points: TrackPoint[];
  speedData: SpeedPoint[];
  alarms: AlarmEvent[];
  avgSpeed: number;
  maxSpeed: number;
  currentLng: string;
  currentLat: string;
  currentAddress: string;
}

// ============================================================
// Mock Data
// ============================================================

const statusConfig: Record<string, { label: string; color: string; bg: string }> = {
  completed: { label: '已完成', color: '#10B981', bg: '#ECFDF5' },
  in_progress: { label: '进行中', color: '#2563EB', bg: '#EFF6FF' },
  abnormal: { label: '异常', color: '#EF4444', bg: '#FEF2F2' },
};

const alarmLevelConfig: Record<string, { label: string; color: string; bg: string }> = {
  high: { label: '高', color: '#EF4444', bg: '#FEF2F2' },
  medium: { label: '中', color: '#F59E0B', bg: '#FFFBEB' },
  low: { label: '低', color: '#06B6D4', bg: '#ECFEFF' },
};

const generateSpeedData = (baseSpeed: number, count: number): SpeedPoint[] => {
  const data: SpeedPoint[] = [];
  for (let i = 0; i < count; i++) {
    data.push({
      time: `${String(Math.floor(i * 15 / 60)).padStart(2, '0')}:${String((i * 15) % 60).padStart(2, '0')}`,
      speed: Math.round(baseSpeed + Math.sin(i * 0.5) * 25 + Math.random() * 15),
      distance: Math.round(i * 4.2),
    });
  }
  return data;
};

const trackRecords: TrackRecord[] = [
  {
    id: 'TR001',
    orderNo: 'DB-2024-0115-001',
    vehicleNo: '沪A·B8236',
    vehicleType: '厢式货车',
    from: '苏州仓',
    to: '上海仓',
    distance: 120,
    startTime: '2024-01-15 08:30',
    endTime: '2024-01-15 11:15',
    status: 'completed',
    points: [
      { x: 120, y: 180, name: '苏州仓', time: '08:30', stayMinutes: 0 },
      { x: 200, y: 200, name: '途经点1', time: '09:15', stayMinutes: 5 },
      { x: 280, y: 190, name: '途经点2', time: '09:50', stayMinutes: 10 },
      { x: 360, y: 220, name: '途经点3', time: '10:20', stayMinutes: 3 },
      { x: 440, y: 210, name: '途经点4', time: '10:45', stayMinutes: 0 },
      { x: 520, y: 200, name: '途经点5', time: '11:00', stayMinutes: 0 },
      { x: 600, y: 190, name: '上海仓', time: '11:15', stayMinutes: 0 },
    ],
    speedData: generateSpeedData(65, 13),
    alarms: [],
    avgSpeed: 58,
    maxSpeed: 82,
    currentLng: '121.4737',
    currentLat: '31.2304',
    currentAddress: '上海市浦东新区张江镇科苑路88号',
  },
  {
    id: 'TR002',
    orderNo: 'DB-2024-0115-002',
    vehicleNo: '浙A·C9157',
    vehicleType: '冷藏车',
    from: '上海仓',
    to: '杭州仓',
    distance: 180,
    startTime: '2024-01-15 09:00',
    endTime: '2024-01-15 13:30',
    status: 'completed',
    points: [
      { x: 600, y: 190, name: '上海仓', time: '09:00', stayMinutes: 0 },
      { x: 540, y: 250, name: '途经点1', time: '09:45', stayMinutes: 8 },
      { x: 480, y: 300, name: '途经点2', time: '10:30', stayMinutes: 15 },
      { x: 420, y: 340, name: '途经点3', time: '11:10', stayMinutes: 5 },
      { x: 370, y: 380, name: '途经点4', time: '11:50', stayMinutes: 10 },
      { x: 330, y: 430, name: '途经点5', time: '12:30', stayMinutes: 3 },
      { x: 290, y: 480, name: '途经点6', time: '13:10', stayMinutes: 0 },
      { x: 260, y: 520, name: '杭州仓', time: '13:30', stayMinutes: 0 },
    ],
    speedData: generateSpeedData(60, 19),
    alarms: [
      { id: 'A001', time: '10:35', type: '超速', level: 'medium', description: '时速超过90km/h，持续2分钟' },
    ],
    avgSpeed: 52,
    maxSpeed: 95,
    currentLng: '120.1551',
    currentLat: '30.2741',
    currentAddress: '杭州市萧山区建设三路158号',
  },
  {
    id: 'TR003',
    orderNo: 'DB-2024-0116-001',
    vehicleNo: '浙B·D3682',
    vehicleType: '平板车',
    from: '杭州仓',
    to: '宁波仓',
    distance: 150,
    startTime: '2024-01-16 07:45',
    endTime: '2024-01-16 10:50',
    status: 'completed',
    points: [
      { x: 260, y: 520, name: '杭州仓', time: '07:45', stayMinutes: 0 },
      { x: 330, y: 500, name: '途经点1', time: '08:30', stayMinutes: 10 },
      { x: 400, y: 480, name: '途经点2', time: '09:10', stayMinutes: 5 },
      { x: 470, y: 460, name: '途经点3', time: '09:45', stayMinutes: 8 },
      { x: 540, y: 440, name: '途经点4', time: '10:20', stayMinutes: 0 },
      { x: 610, y: 420, name: '宁波仓', time: '10:50', stayMinutes: 0 },
    ],
    speedData: generateSpeedData(70, 14),
    alarms: [],
    avgSpeed: 61,
    maxSpeed: 85,
    currentLng: '121.5440',
    currentLat: '29.8683',
    currentAddress: '宁波市鄞州区金达路66号',
  },
  {
    id: 'TR004',
    orderNo: 'DB-2024-0116-002',
    vehicleNo: '苏A·E4721',
    vehicleType: '厢式货车',
    from: '南京仓',
    to: '苏州仓',
    distance: 200,
    startTime: '2024-01-16 06:00',
    endTime: '2024-01-16 10:45',
    status: 'abnormal',
    points: [
      { x: 80, y: 300, name: '南京仓', time: '06:00', stayMinutes: 0 },
      { x: 120, y: 260, name: '途经点1', time: '06:45', stayMinutes: 5 },
      { x: 160, y: 230, name: '途经点2', time: '07:25', stayMinutes: 10 },
      { x: 200, y: 210, name: '途经点3', time: '08:00', stayMinutes: 20 },
      { x: 240, y: 200, name: '途经点4', time: '08:50', stayMinutes: 3 },
      { x: 280, y: 195, name: '途经点5', time: '09:20', stayMinutes: 5 },
      { x: 320, y: 190, name: '途经点6', time: '09:50', stayMinutes: 8 },
      { x: 360, y: 185, name: '途经点7', time: '10:20', stayMinutes: 0 },
      { x: 120, y: 180, name: '苏州仓', time: '10:45', stayMinutes: 0 },
    ],
    speedData: generateSpeedData(55, 20),
    alarms: [
      { id: 'A002', time: '08:05', type: '偏离路线', level: 'high', description: '车辆偏离预定路线500米' },
      { id: 'A003', time: '08:30', type: '长时间停留', level: 'medium', description: '途经点3停留超过15分钟' },
      { id: 'A004', time: '09:55', type: '急刹车', level: 'low', description: '检测到急刹车事件' },
    ],
    avgSpeed: 48,
    maxSpeed: 78,
    currentLng: '120.5853',
    currentLat: '31.2989',
    currentAddress: '苏州市相城区太阳路188号',
  },
  {
    id: 'TR005',
    orderNo: 'DB-2024-0117-001',
    vehicleNo: '皖A·F5834',
    vehicleType: '高栏车',
    from: '合肥仓',
    to: '南京仓',
    distance: 170,
    startTime: '2024-01-17 08:00',
    endTime: '2024-01-17 11:40',
    status: 'completed',
    points: [
      { x: 60, y: 420, name: '合肥仓', time: '08:00', stayMinutes: 0 },
      { x: 80, y: 380, name: '途经点1', time: '08:50', stayMinutes: 10 },
      { x: 80, y: 340, name: '途经点2', time: '09:35', stayMinutes: 5 },
      { x: 80, y: 320, name: '途经点3', time: '10:00', stayMinutes: 8 },
      { x: 80, y: 310, name: '途经点4', time: '10:40', stayMinutes: 3 },
      { x: 80, y: 305, name: '途经点5', time: '11:10', stayMinutes: 0 },
      { x: 80, y: 300, name: '南京仓', time: '11:40', stayMinutes: 0 },
    ],
    speedData: generateSpeedData(62, 16),
    alarms: [
      { id: 'A005', time: '09:45', type: '疲劳驾驶', level: 'high', description: '连续驾驶超过4小时' },
    ],
    avgSpeed: 53,
    maxSpeed: 88,
    currentLng: '118.7969',
    currentLat: '32.0603',
    currentAddress: '南京市江宁区将军大道669号',
  },
];

// ============================================================
// Utility: Interpolate position along polyline
// ============================================================

function interpolateAlongPath(points: TrackPoint[], progress: number): { x: number; y: number; angle: number } {
  const totalSegments = points.length - 1;
  const globalPos = progress * totalSegments;
  const segmentIndex = Math.min(Math.floor(globalPos), totalSegments - 1);
  const segmentProgress = globalPos - segmentIndex;

  const p1 = points[segmentIndex];
  const p2 = points[segmentIndex + 1];
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);

  return {
    x: p1.x + dx * segmentProgress,
    y: p1.y + dy * segmentProgress,
    angle,
  };
}

function getSpeedAtProgress(speedData: SpeedPoint[], progress: number): number {
  const index = Math.min(Math.floor(progress * speedData.length), speedData.length - 1);
  return speedData[index]?.speed ?? 0;
}

// ============================================================
// Speed Chart Component
// ============================================================

function SpeedChart({ data, currentIndex }: { data: SpeedPoint[]; currentIndex: number }) {
  return (
    <ResponsiveContainer width="100%" height={140}>
      <AreaChart data={data} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="speedGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis dataKey="time" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
        <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #E2E8F0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }}
          formatter={(value: number) => [`${value} km/h`, '速度']}
        />
        <Area
          type="monotone"
          dataKey="speed"
          stroke="#2563EB"
          fill="url(#speedGradient)"
          strokeWidth={2}
          dot={false}
        />
        {currentIndex >= 0 && currentIndex < data.length && (
          <>
            {/* Vertical reference line at current position */}
          </>
        )}
      </AreaChart>
    </ResponsiveContainer>
  );
}

// ============================================================
// Map Background Component
// ============================================================

function MapBackground() {
  return (
    <g opacity="0.08">
      {/* Grid lines */}
      {Array.from({ length: 9 }, (_, i) => (
        <line key={`h${i}`} x1={0} y1={(i + 1) * 80} x2={720} y2={(i + 1) * 80} stroke="#0F172A" strokeWidth={0.5} />
      ))}
      {Array.from({ length: 8 }, (_, i) => (
        <line key={`v${i}`} x1={(i + 1) * 80} y1={0} x2={(i + 1) * 80} y2={640} stroke="#0F172A" strokeWidth={0.5} />
      ))}
      {/* Major roads */}
      <line x1={0} y1={200} x2={720} y2={200} stroke="#0F172A" strokeWidth={1.5} />
      <line x1={0} y1={420} x2={720} y2={420} stroke="#0F172A" strokeWidth={1.5} />
      <line x1={80} y1={0} x2={80} y2={640} stroke="#0F172A" strokeWidth={1.5} />
      <line x1={600} y1={0} x2={600} y2={640} stroke="#0F172A" strokeWidth={1.5} />
      <line x1={260} y1={0} x2={260} y2={640} stroke="#0F172A" strokeWidth={1} />
      <line x1={0} y1={520} x2={720} y2={520} stroke="#0F172A" strokeWidth={1} />
    </g>
  );
}

// ============================================================
// Main Page Component
// ============================================================

export default function TransferTrackReplayPage() {
  const [selectedTrackId, setSelectedTrackId] = useState<string>('TR001');
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [searchOrderNo, setSearchOrderNo] = useState('');
  const [searchVehicle, setSearchVehicle] = useState('');
  const [dateRange, setDateRange] = useState('all');
  const animationRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  const selectedTrack = useMemo(
    () => trackRecords.find((t) => t.id === selectedTrackId) || trackRecords[0],
    [selectedTrackId]
  );

  const vehiclePos = useMemo(
    () => interpolateAlongPath(selectedTrack.points, progress),
    [selectedTrack.points, progress]
  );

  const currentSpeed = useMemo(
    () => getSpeedAtProgress(selectedTrack.speedData, progress),
    [selectedTrack.speedData, progress]
  );

  const currentSpeedIndex = useMemo(
    () => Math.min(Math.floor(progress * selectedTrack.speedData.length), selectedTrack.speedData.length - 1),
    [selectedTrack.speedData, progress]
  );

  // Animation loop
  const animate = useCallback(
    (timestamp: number) => {
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const delta = timestamp - lastTimeRef.current;
      lastTimeRef.current = timestamp;

      setProgress((prev) => {
        const newProgress = prev + (delta / 10000) * playbackSpeed;
        if (newProgress >= 1) {
          setIsPlaying(false);
          return 1;
        }
        return newProgress;
      });

      animationRef.current = requestAnimationFrame(animate);
    },
    [playbackSpeed]
  );

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = 0;
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    }
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, animate]);

  // Reset progress when switching tracks
  useEffect(() => {
    setProgress(0);
    setIsPlaying(false);
  }, [selectedTrackId]);

  const handlePlay = () => setIsPlaying(!isPlaying);
  const handleReset = () => { setProgress(0); setIsPlaying(false); };
  const handleSkipForward = () => setProgress((p) => Math.min(p + 0.1, 1));
  const handleSkipBack = () => setProgress((p) => Math.max(p - 0.1, 0));

  const filteredTracks = useMemo(() => {
    return trackRecords.filter((t) => {
      if (searchOrderNo && !t.orderNo.toLowerCase().includes(searchOrderNo.toLowerCase())) return false;
      if (searchVehicle && !t.vehicleNo.includes(searchVehicle)) return false;
      if (dateRange === 'today' && !t.startTime.includes('2024-01-17')) return false;
      if (dateRange === 'week' && t.startTime < '2024-01-14') return false;
      return true;
    });
  }, [searchOrderNo, searchVehicle, dateRange]);

  const pointsToLine = (points: TrackPoint[]) => points.map((p) => `${p.x},${p.y}`).join(' ');

  const totalDuration = useMemo(() => {
    const start = new Date(`2024-01-15 ${selectedTrack.startTime.split(' ')[1]}`);
    const end = new Date(`2024-01-15 ${selectedTrack.endTime.split(' ')[1]}`);
    return Math.round((end.getTime() - start.getTime()) / 60000);
  }, [selectedTrack]);

  const currentTime = useMemo(() => {
    const startMinutes = 8 * 60 + 30;
    const currentMinutes = startMinutes + Math.round(progress * totalDuration);
    const h = Math.floor(currentMinutes / 60);
    const m = currentMinutes % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }, [progress, totalDuration]);

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#F8FAFC' }}>
      {/* ==================== Top Filter Bar ==================== */}
      <div className="shrink-0 px-4 pt-3 pb-2">
        <Card className="border-[var(--color-border)]">
          <CardContent className="p-3 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-[#94A3B8]" />
              <Input
                placeholder="调拨单号搜索"
                value={searchOrderNo}
                onChange={(e) => setSearchOrderNo(e.target.value)}
                className="w-48 h-8 text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#94A3B8]" />
              <Input
                placeholder="车辆/载具筛选"
                value={searchVehicle}
                onChange={(e) => setSearchVehicle(e.target.value)}
                className="w-40 h-8 text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#94A3B8]" />
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="h-8 px-2 text-sm rounded-md border border-[#E2E8F0] bg-white text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#2563EB]/20"
              >
                <option value="all">全部时间</option>
                <option value="today">今天</option>
                <option value="week">近一周</option>
              </select>
            </div>
            <div className="flex items-center gap-1 ml-auto">
              <Badge variant="secondary" className="text-xs">
                共 {filteredTracks.length} 条轨迹
              </Badge>
              {(searchOrderNo || searchVehicle || dateRange !== 'all') && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 text-xs text-[#94A3B8]"
                  onClick={() => { setSearchOrderNo(''); setSearchVehicle(''); setDateRange('all'); }}
                >
                  <X className="w-3 h-3 mr-1" /> 清除
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ==================== Main Content ==================== */}
      <div className="flex-1 flex gap-3 px-4 pb-3 min-h-0">
        {/* Left: Track List */}
        <div className="w-64 flex flex-col gap-2 shrink-0">
          <div className="flex items-center justify-between px-1">
            <h3 className="text-sm font-semibold text-[#0F172A]">轨迹列表</h3>
            <Filter className="w-3.5 h-3.5 text-[#94A3B8]" />
          </div>
          <ScrollArea className="flex-1">
            <div className="flex flex-col gap-2 pr-2">
              {filteredTracks.map((track) => (
                <motion.div
                  key={track.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => setSelectedTrackId(track.id)}
                  className={cn(
                    'cursor-pointer rounded-lg border p-3 transition-all',
                    selectedTrackId === track.id
                      ? 'border-[#2563EB] bg-[#EFF6FF] shadow-sm'
                      : 'border-[#E2E8F0] bg-white hover:border-[#CBD5E1] hover:shadow-sm'
                  )}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-medium text-[#0F172A]">{track.orderNo}</span>
                    <Badge
                      className="text-[10px] px-1.5 py-0"
                      style={{
                        backgroundColor: statusConfig[track.status].bg,
                        color: statusConfig[track.status].color,
                        border: `1px solid ${statusConfig[track.status].color}20`,
                      }}
                    >
                      {statusConfig[track.status].label}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-[#475569] mb-1.5">
                    <MapPin className="w-3 h-3" />
                    <span>{track.from}</span>
                    <ChevronRight className="w-3 h-3" />
                    <span>{track.to}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#94A3B8]">
                    <span className="flex items-center gap-1">
                      <Truck className="w-3 h-3" />
                      {track.vehicleNo}
                    </span>
                    <span className="flex items-center gap-1">
                      <Route className="w-3 h-3" />
                      {track.distance}km
                    </span>
                  </div>
                  <div className="mt-1.5 flex items-center gap-2 text-[11px] text-[#94A3B8]">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {track.startTime.split(' ')[1]}
                    </span>
                    <span>~</span>
                    <span>{track.endTime.split(' ')[1]}</span>
                  </div>
                  {track.alarms.length > 0 && (
                    <div className="mt-1.5 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-[#EF4444]" />
                      <span className="text-[11px] text-[#EF4444]">{track.alarms.length} 个报警</span>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Center: Map Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <Card className="flex-1 flex flex-col border-[var(--color-border)] overflow-hidden">
            {/* Map Header */}
            <CardHeader className="px-4 py-2.5 shrink-0 flex flex-row items-center justify-between border-b border-[#E2E8F0]">
              <div className="flex items-center gap-3">
                <CardTitle className="text-sm font-semibold text-[#0F172A]">
                  {selectedTrack.from} → {selectedTrack.to}
                </CardTitle>
                <Badge variant="outline" className="text-xs">
                  {selectedTrack.vehicleNo}
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {selectedTrack.vehicleType}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Badge
                  className="text-xs"
                  style={{
                    backgroundColor: statusConfig[selectedTrack.status].bg,
                    color: statusConfig[selectedTrack.status].color,
                  }}
                >
                  {statusConfig[selectedTrack.status].label}
                </Badge>
              </div>
            </CardHeader>

            {/* SVG Map */}
            <CardContent className="flex-1 p-0 relative min-h-0">
              <svg
                viewBox="0 0 720 640"
                preserveAspectRatio="xMidYMid meet"
                className="w-full h-full"
                style={{ backgroundColor: '#F1F5F9' }}
              >
                <MapBackground />

                {/* Route Line (completed part) */}
                <polyline
                  points={pointsToLine(selectedTrack.points)}
                  fill="none"
                  stroke="#CBD5E1"
                  strokeWidth={4}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray="8 4"
                />

                {/* Route Line (progress part) */}
                <motion.polyline
                  points={pointsToLine(selectedTrack.points)}
                  fill="none"
                  stroke="#2563EB"
                  strokeWidth={4}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: progress }}
                  transition={{ duration: 0.1 }}
                  style={{
                    strokeDasharray: 'none',
                  }}
                />

                {/* Start Point */}
                <g transform={`translate(${selectedTrack.points[0].x}, ${selectedTrack.points[0].y})`}>
                  <circle r={14} fill="#10B981" opacity={0.2} />
                  <circle r={8} fill="#10B981" />
                  <circle r={4} fill="white" />
                  <text y={-18} textAnchor="middle" fontSize={11} fontWeight="600" fill="#0F172A">
                    {selectedTrack.points[0].name}
                  </text>
                </g>

                {/* End Point */}
                <g transform={`translate(${selectedTrack.points[selectedTrack.points.length - 1].x}, ${selectedTrack.points[selectedTrack.points.length - 1].y})`}>
                  <circle r={14} fill="#EF4444" opacity={0.2} />
                  <circle r={8} fill="#EF4444" />
                  <circle r={4} fill="white" />
                  <text y={-18} textAnchor="middle" fontSize={11} fontWeight="600" fill="#0F172A">
                    {selectedTrack.points[selectedTrack.points.length - 1].name}
                  </text>
                </g>

                {/* Waypoints */}
                {selectedTrack.points.slice(1, -1).map((point, idx) => (
                  <g key={idx} transform={`translate(${point.x}, ${point.y})`}>
                    <circle r={8} fill="#F59E0B" opacity={0.15} />
                    <circle r={5} fill="#F59E0B" />
                    <circle r={2.5} fill="white" />
                    <text y={-12} textAnchor="middle" fontSize={9} fill="#475569">
                      {point.name}
                    </text>
                  </g>
                ))}

                {/* Vehicle Icon */}
                <AnimatePresence>
                  <motion.g
                    transform={`translate(${vehiclePos.x}, ${vehiclePos.y})`}
                    initial={false}
                    transition={{ type: 'tween', duration: 0.05, ease: 'linear' }}
                  >
                    <circle r={18} fill="#2563EB" opacity={0.15} />
                    <circle r={14} fill="#2563EB" />
                    <g transform={`rotate(${vehiclePos.angle + 90})`}>
                      <Navigation className="w-0 h-0" />
                      <polygon points="0,-7 -5,5 0,3 5,5" fill="white" />
                    </g>
                  </motion.g>
                </AnimatePresence>

                {/* Map Scale */}
                <g transform="translate(30, 600)">
                  <rect x={0} y={0} width={80} height={3} fill="#0F172A" opacity={0.3} />
                  <text x={40} y={16} textAnchor="middle" fontSize={10} fill="#64748B">
                    0 —— 50km
                  </text>
                </g>
              </svg>

              {/* Speed overlay */}
              <div className="absolute bottom-2 left-2 flex items-center gap-2 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 shadow-sm border border-[#E2E8F0]">
                <Gauge className="w-4 h-4 text-[#2563EB]" />
                <span className="text-sm font-semibold text-[#0F172A]">{currentSpeed}</span>
                <span className="text-xs text-[#94A3B8]">km/h</span>
              </div>
            </CardContent>

            {/* Playback Controls */}
            <div className="shrink-0 px-4 py-2.5 border-t border-[#E2E8F0] bg-white">
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleReset}
                  title="重置"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleSkipBack}
                  title="后退"
                >
                  <Rewind className="w-4 h-4" />
                </Button>
                <Button
                  variant="default"
                  size="icon"
                  className="h-9 w-9 rounded-full bg-[#2563EB] hover:bg-[#1D4ED8]"
                  onClick={handlePlay}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleSkipForward}
                  title="前进"
                >
                  <FastForward className="w-4 h-4" />
                </Button>

                <div className="flex-1 flex items-center gap-3">
                  <span className="text-xs text-[#94A3B8] w-10 text-right">{currentTime}</span>
                  <Slider
                    value={[Math.round(progress * 100)]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(v) => setProgress(v[0] / 100)}
                    className="flex-1"
                  />
                  <span className="text-xs text-[#94A3B8] w-10">{selectedTrack.endTime.split(' ')[1]}</span>
                </div>

                <div className="flex items-center gap-1">
                  <span className="text-[11px] text-[#94A3B8]">倍速</span>
                  <select
                    value={playbackSpeed}
                    onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
                    className="h-7 px-1.5 text-xs rounded-md border border-[#E2E8F0] bg-white focus:outline-none"
                  >
                    <option value={0.5}>0.5x</option>
                    <option value={1}>1x</option>
                    <option value={2}>2x</option>
                    <option value={4}>4x</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Speed Chart */}
            <div className="shrink-0 px-4 pb-2 border-t border-[#E2E8F0] pt-2">
              <div className="flex items-center gap-1 mb-1">
                <Zap className="w-3 h-3 text-[#2563EB]" />
                <span className="text-[11px] text-[#475569] font-medium">速度变化曲线</span>
              </div>
              <SpeedChart data={selectedTrack.speedData} currentIndex={currentSpeedIndex} />
            </div>
          </Card>
        </div>

        {/* Right: Info Panel */}
        <div className="w-64 flex flex-col gap-3 shrink-0">
          <Tabs defaultValue="info" className="flex flex-col h-full">
            <TabsList className="w-full h-8">
              <TabsTrigger value="info" className="text-xs flex-1">位置信息</TabsTrigger>
              <TabsTrigger value="nodes" className="text-xs flex-1">节点记录</TabsTrigger>
              <TabsTrigger value="alarms" className="text-xs flex-1">
                报警
                {selectedTrack.alarms.length > 0 && (
                  <span className="ml-1 text-[10px] bg-[#EF4444] text-white rounded-full w-4 h-4 flex items-center justify-center">
                    {selectedTrack.alarms.length}
                  </span>
                )}
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="mt-2 flex-1">
              <ScrollArea className="h-[calc(100vh-260px)]">
                <div className="flex flex-col gap-2 pr-2">
                  {/* Current Position Card */}
                  <Card className="border-[#E2E8F0]">
                    <CardHeader className="px-3 py-2">
                      <CardTitle className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                        <Navigation className="w-3.5 h-3.5 text-[#2563EB]" />
                        当前位置
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 py-2 pt-0 space-y-2">
                      <div className="flex items-start gap-2">
                        <MapPin className="w-3.5 h-3.5 text-[#94A3B8] mt-0.5 shrink-0" />
                        <div>
                          <p className="text-xs text-[#475569] leading-relaxed">{selectedTrack.currentAddress}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-[#F1F5F9] rounded-md p-2">
                          <p className="text-[10px] text-[#94A3B8]">经度</p>
                          <p className="text-xs font-medium text-[#0F172A] font-number">{selectedTrack.currentLng}</p>
                        </div>
                        <div className="bg-[#F1F5F9] rounded-md p-2">
                          <p className="text-[10px] text-[#94A3B8]">纬度</p>
                          <p className="text-xs font-medium text-[#0F172A] font-number">{selectedTrack.currentLat}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Stats Card */}
                  <Card className="border-[#E2E8F0]">
                    <CardHeader className="px-3 py-2">
                      <CardTitle className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                        <Gauge className="w-3.5 h-3.5 text-[#10B981]" />
                        速度/里程统计
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 py-2 pt-0 space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-[#EFF6FF] rounded-md p-2">
                          <p className="text-[10px] text-[#2563EB]">当前速度</p>
                          <p className="text-lg font-bold text-[#2563EB] font-number">{currentSpeed}</p>
                          <p className="text-[10px] text-[#2563EB]/60">km/h</p>
                        </div>
                        <div className="bg-[#ECFDF5] rounded-md p-2">
                          <p className="text-[10px] text-[#10B981]">平均速度</p>
                          <p className="text-lg font-bold text-[#10B981] font-number">{selectedTrack.avgSpeed}</p>
                          <p className="text-[10px] text-[#10B981]/60">km/h</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="bg-[#FFFBEB] rounded-md p-2">
                          <p className="text-[10px] text-[#F59E0B]">最高速度</p>
                          <p className="text-lg font-bold text-[#F59E0B] font-number">{selectedTrack.maxSpeed}</p>
                          <p className="text-[10px] text-[#F59E0B]/60">km/h</p>
                        </div>
                        <div className="bg-[#F5F3FF] rounded-md p-2">
                          <p className="text-[10px] text-[#8B5CF6]">总里程</p>
                          <p className="text-lg font-bold text-[#8B5CF6] font-number">{selectedTrack.distance}</p>
                          <p className="text-[10px] text-[#8B5CF6]/60">km</p>
                        </div>
                      </div>
                      <div className="bg-[#F1F5F9] rounded-md p-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Route className="w-3.5 h-3.5 text-[#475569]" />
                            <span className="text-xs text-[#475569]">已行驶</span>
                          </div>
                          <span className="text-xs font-medium text-[#0F172A] font-number">
                            {Math.round(progress * selectedTrack.distance)} / {selectedTrack.distance} km
                          </span>
                        </div>
                        <div className="mt-1.5 h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
                          <motion.div
                            className="h-full bg-[#2563EB] rounded-full"
                            style={{ width: `${progress * 100}%` }}
                            transition={{ duration: 0.1 }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Trip Info */}
                  <Card className="border-[#E2E8F0]">
                    <CardHeader className="px-3 py-2">
                      <CardTitle className="text-xs font-semibold text-[#0F172A] flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-[#8B5CF6]" />
                        行程信息
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 py-2 pt-0 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#94A3B8]">出发时间</span>
                        <span className="text-xs text-[#0F172A] font-medium">{selectedTrack.startTime}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#94A3B8]">到达时间</span>
                        <span className="text-xs text-[#0F172A] font-medium">{selectedTrack.endTime}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#94A3B8]">总耗时</span>
                        <span className="text-xs text-[#0F172A] font-medium">
                          {Math.floor(totalDuration / 60)}小时{totalDuration % 60}分钟
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-[#94A3B8]">途经点数</span>
                        <span className="text-xs text-[#0F172A] font-medium">{selectedTrack.points.length - 2}个</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="nodes" className="mt-2 flex-1">
              <ScrollArea className="h-[calc(100vh-260px)]">
                <div className="flex flex-col gap-1.5 pr-2">
                  {selectedTrack.points.map((point, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={cn(
                        'relative rounded-lg border p-2.5 bg-white',
                        idx === 0
                          ? 'border-[#10B981] bg-[#ECFDF5]/50'
                          : idx === selectedTrack.points.length - 1
                            ? 'border-[#EF4444] bg-[#FEF2F2]/50'
                            : 'border-[#E2E8F0]'
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          'w-6 h-6 rounded-full flex items-center justify-center shrink-0',
                          idx === 0
                            ? 'bg-[#10B981]'
                            : idx === selectedTrack.points.length - 1
                              ? 'bg-[#EF4444]'
                              : 'bg-[#F59E0B]'
                        )}>
                          {idx === 0 ? (
                            <Flag className="w-3 h-3 text-white" />
                          ) : idx === selectedTrack.points.length - 1 ? (
                            <MapPin className="w-3 h-3 text-white" />
                          ) : (
                            <Circle className="w-3 h-3 text-white" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-[#0F172A]">{point.name}</span>
                            <span className="text-[11px] text-[#94A3B8]">{point.time}</span>
                          </div>
                          {point.stayMinutes !== undefined && point.stayMinutes > 0 && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <Timer className="w-3 h-3 text-[#94A3B8]" />
                              <span className="text-[11px] text-[#94A3B8]">
                                停留 {point.stayMinutes} 分钟
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      {idx < selectedTrack.points.length - 1 && (
                        <div className="absolute left-[22px] bottom-[-10px] w-0.5 h-[10px] bg-[#E2E8F0]" />
                      )}
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="alarms" className="mt-2 flex-1">
              <ScrollArea className="h-[calc(100vh-260px)]">
                <div className="flex flex-col gap-2 pr-2">
                  {selectedTrack.alarms.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <div className="w-12 h-12 rounded-full bg-[#ECFDF5] flex items-center justify-center mb-3">
                        <CheckCircleIcon className="w-6 h-6 text-[#10B981]" />
                      </div>
                      <p className="text-sm text-[#475569]">暂无报警事件</p>
                      <p className="text-xs text-[#94A3B8] mt-1">本次行程运行正常</p>
                    </div>
                  ) : (
                    selectedTrack.alarms.map((alarm, idx) => (
                      <motion.div
                        key={alarm.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.08 }}
                        className="rounded-lg border border-[#E2E8F0] p-3 bg-white"
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <AlertTriangle
                              className="w-3.5 h-3.5"
                              style={{ color: alarmLevelConfig[alarm.level].color }}
                            />
                            <span className="text-xs font-medium text-[#0F172A]">{alarm.type}</span>
                          </div>
                          <Badge
                            className="text-[10px] px-1.5 py-0"
                            style={{
                              backgroundColor: alarmLevelConfig[alarm.level].bg,
                              color: alarmLevelConfig[alarm.level].color,
                            }}
                          >
                            {alarmLevelConfig[alarm.level].label}
                          </Badge>
                        </div>
                        <p className="text-[11px] text-[#475569] leading-relaxed mb-1">{alarm.description}</p>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-[#94A3B8]" />
                          <span className="text-[11px] text-[#94A3B8]">{alarm.time}</span>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

// Small icon component for empty state
function CheckCircleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
