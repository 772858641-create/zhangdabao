import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from 'recharts';
import {
  Building2,
  MapPin,
  Warehouse,
  Users,
  TrendingUp,
  ChevronRight,
  ChevronDown,
  FolderOpen,
  FileText,
  BarChart3,
  Search,
  ChevronLeft,
  ChevronLast,
  ChevronFirst,
  Activity,
  Package,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────

type OrgNodeType = 'group' | 'region' | 'province' | 'city' | 'site';
type SiteStatus = 'active' | 'inactive' | 'warning';

interface OrgNode {
  id: string;
  name: string;
  type: OrgNodeType;
  children?: OrgNode[];
  parentId?: string | null;
}

interface SiteData {
  id: string;
  code: string;
  name: string;
  orgPath: string[];
  region: string;
  province: string;
  city: string;
  address: string;
  carrierCount: number;
  inStockCount: number;
  todayIn: number;
  todayOut: number;
  manager: string;
  managerPhone: string;
  status: SiteStatus;
  lat: number;
  lng: number;
}

// ─── Color Constants ─────────────────────────────────────────────
const STATUS_COLORS: Record<SiteStatus, { bg: string; text: string; dot: string }> = {
  active: { bg: 'bg-success/10', text: 'text-success', dot: '#10B981' },
  inactive: { bg: 'bg-neutral-textTertiary/10', text: 'text-neutral-textTertiary', dot: '#94A3B8' },
  warning: { bg: 'bg-warning/10', text: 'text-warning', dot: '#F59E0B' },
};

const STATUS_LABELS: Record<SiteStatus, string> = {
  active: '运营中',
  inactive: '已停用',
  warning: '异常',
};

// const CHART_COLORS = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#06B6D4', '#EC4899', '#14B8A6'];

// ─── Build Organization Tree ─────────────────────────────────────

const ORG_TREE: OrgNode = {
  id: 'group-1',
  name: '集团总部',
  type: 'group',
  children: [
    {
      id: 'region-east',
      name: '华东大区',
      type: 'region',
      parentId: 'group-1',
      children: [
        {
          id: 'prov-shanghai',
          name: '上海',
          type: 'province',
          parentId: 'region-east',
          children: [
            {
              id: 'city-shanghai',
              name: '上海市',
              type: 'city',
              parentId: 'prov-shanghai',
              children: [
                { id: 'site-sh-1', name: '浦东物流园', type: 'site', parentId: 'city-shanghai' },
                { id: 'site-sh-2', name: '虹桥配送中心', type: 'site', parentId: 'city-shanghai' },
              ],
            },
          ],
        },
        {
          id: 'prov-jiangsu',
          name: '江苏',
          type: 'province',
          parentId: 'region-east',
          children: [
            {
              id: 'city-nanjing',
              name: '南京市',
              type: 'city',
              parentId: 'prov-jiangsu',
              children: [
                { id: 'site-js-1', name: '江宁仓储中心', type: 'site', parentId: 'city-nanjing' },
              ],
            },
            {
              id: 'city-suzhou',
              name: '苏州市',
              type: 'city',
              parentId: 'prov-jiangsu',
              children: [
                { id: 'site-js-2', name: '昆山物流基地', type: 'site', parentId: 'city-suzhou' },
                { id: 'site-js-3', name: '苏州园区仓', type: 'site', parentId: 'city-suzhou' },
              ],
            },
          ],
        },
        {
          id: 'prov-zhejiang',
          name: '浙江',
          type: 'province',
          parentId: 'region-east',
          children: [
            {
              id: 'city-hangzhou',
              name: '杭州市',
              type: 'city',
              parentId: 'prov-zhejiang',
              children: [
                { id: 'site-zj-1', name: '萧山配送中心', type: 'site', parentId: 'city-hangzhou' },
              ],
            },
            {
              id: 'city-ningbo',
              name: '宁波市',
              type: 'city',
              parentId: 'prov-zhejiang',
              children: [
                { id: 'site-zj-2', name: '北仑港物流园', type: 'site', parentId: 'city-ningbo' },
              ],
            },
          ],
        },
        {
          id: 'prov-anhui',
          name: '安徽',
          type: 'province',
          parentId: 'region-east',
          children: [
            {
              id: 'city-hefei',
              name: '合肥市',
              type: 'city',
              parentId: 'prov-anhui',
              children: [
                { id: 'site-ah-1', name: '蜀山仓储基地', type: 'site', parentId: 'city-hefei' },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 'region-north',
      name: '华北大区',
      type: 'region',
      parentId: 'group-1',
      children: [
        {
          id: 'prov-beijing',
          name: '北京',
          type: 'province',
          parentId: 'region-north',
          children: [
            {
              id: 'city-beijing',
              name: '北京市',
              type: 'city',
              parentId: 'prov-beijing',
              children: [
                { id: 'site-bj-1', name: '通州物流中心', type: 'site', parentId: 'city-beijing' },
                { id: 'site-bj-2', name: '大兴配送基地', type: 'site', parentId: 'city-beijing' },
              ],
            },
          ],
        },
        {
          id: 'prov-tianjin',
          name: '天津',
          type: 'province',
          parentId: 'region-north',
          children: [
            {
              id: 'city-tianjin',
              name: '天津市',
              type: 'city',
              parentId: 'prov-tianjin',
              children: [
                { id: 'site-tj-1', name: '滨海新区仓储', type: 'site', parentId: 'city-tianjin' },
              ],
            },
          ],
        },
        {
          id: 'prov-hebei',
          name: '河北',
          type: 'province',
          parentId: 'region-north',
          children: [
            {
              id: 'city-shijiazhuang',
              name: '石家庄市',
              type: 'city',
              parentId: 'prov-hebei',
              children: [
                { id: 'site-hb-1', name: '裕华物流园', type: 'site', parentId: 'city-shijiazhuang' },
              ],
            },
            {
              id: 'city-tangshan',
              name: '唐山市',
              type: 'city',
              parentId: 'prov-hebei',
              children: [
                { id: 'site-hb-2', name: '曹妃甸港仓', type: 'site', parentId: 'city-tangshan' },
              ],
            },
          ],
        },
        {
          id: 'prov-shandong',
          name: '山东',
          type: 'province',
          parentId: 'region-north',
          children: [
            {
              id: 'city-jinan',
              name: '济南市',
              type: 'city',
              parentId: 'prov-shandong',
              children: [
                { id: 'site-sd-1', name: '高新物流中心', type: 'site', parentId: 'city-jinan' },
              ],
            },
            {
              id: 'city-qingdao',
              name: '青岛市',
              type: 'city',
              parentId: 'prov-shandong',
              children: [
                { id: 'site-sd-2', name: '胶州湾配送仓', type: 'site', parentId: 'city-qingdao' },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 'region-south',
      name: '华南大区',
      type: 'region',
      parentId: 'group-1',
      children: [
        {
          id: 'prov-guangdong',
          name: '广东',
          type: 'province',
          parentId: 'region-south',
          children: [
            {
              id: 'city-guangzhou',
              name: '广州市',
              type: 'city',
              parentId: 'prov-guangdong',
              children: [
                { id: 'site-gd-1', name: '白云物流枢纽', type: 'site', parentId: 'city-guangzhou' },
                { id: 'site-gd-2', name: '南沙仓储中心', type: 'site', parentId: 'city-guangzhou' },
              ],
            },
            {
              id: 'city-shenzhen',
              name: '深圳市',
              type: 'city',
              parentId: 'prov-guangdong',
              children: [
                { id: 'site-gd-3', name: '前海智慧仓', type: 'site', parentId: 'city-shenzhen' },
              ],
            },
          ],
        },
        {
          id: 'prov-guangxi',
          name: '广西',
          type: 'province',
          parentId: 'region-south',
          children: [
            {
              id: 'city-nanning',
              name: '南宁市',
              type: 'city',
              parentId: 'prov-guangxi',
              children: [
                { id: 'site-gx-1', name: '五象物流园', type: 'site', parentId: 'city-nanning' },
              ],
            },
          ],
        },
        {
          id: 'prov-fujian',
          name: '福建',
          type: 'province',
          parentId: 'region-south',
          children: [
            {
              id: 'city-fuzhou',
              name: '福州市',
              type: 'city',
              parentId: 'prov-fujian',
              children: [
                { id: 'site-fj-1', name: '马尾港配送仓', type: 'site', parentId: 'city-fuzhou' },
              ],
            },
          ],
        },
        {
          id: 'prov-hainan',
          name: '海南',
          type: 'province',
          parentId: 'region-south',
          children: [
            {
              id: 'city-haikou',
              name: '海口市',
              type: 'city',
              parentId: 'prov-hainan',
              children: [
                { id: 'site-hn-1', name: '海口物流基地', type: 'site', parentId: 'city-haikou' },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 'region-west',
      name: '西部大区',
      type: 'region',
      parentId: 'group-1',
      children: [
        {
          id: 'prov-sichuan',
          name: '四川',
          type: 'province',
          parentId: 'region-west',
          children: [
            {
              id: 'city-chengdu',
              name: '成都市',
              type: 'city',
              parentId: 'prov-sichuan',
              children: [
                { id: 'site-sc-1', name: '双流物流中心', type: 'site', parentId: 'city-chengdu' },
                { id: 'site-sc-2', name: '天府仓储园', type: 'site', parentId: 'city-chengdu' },
              ],
            },
          ],
        },
        {
          id: 'prov-chongqing',
          name: '重庆',
          type: 'province',
          parentId: 'region-west',
          children: [
            {
              id: 'city-chongqing',
              name: '重庆市',
              type: 'city',
              parentId: 'prov-chongqing',
              children: [
                { id: 'site-cq-1', name: '两江新区仓', type: 'site', parentId: 'city-chongqing' },
              ],
            },
          ],
        },
        {
          id: 'prov-shaanxi',
          name: '陕西',
          type: 'province',
          parentId: 'region-west',
          children: [
            {
              id: 'city-xian',
              name: '西安市',
              type: 'city',
              parentId: 'prov-shaanxi',
              children: [
                { id: 'site-sx-1', name: '咸阳空港仓', type: 'site', parentId: 'city-xian' },
              ],
            },
          ],
        },
        {
          id: 'prov-yunnan',
          name: '云南',
          type: 'province',
          parentId: 'region-west',
          children: [
            {
              id: 'city-kunming',
              name: '昆明市',
              type: 'city',
              parentId: 'prov-yunnan',
              children: [
                { id: 'site-yn-1', name: '呈贡物流园', type: 'site', parentId: 'city-kunming' },
              ],
            },
          ],
        },
      ],
    },
  ],
};

// ─── Site Mock Data ──────────────────────────────────────────────

const SITES: SiteData[] = [
  { id: 'site-sh-1', code: 'ST-2024-001', name: '浦东物流园', orgPath: ['集团总部', '华东大区', '上海', '上海市'], region: '华东大区', province: '上海', city: '上海市', address: '上海市浦东新区申江路3000号', carrierCount: 1250, inStockCount: 820, todayIn: 156, todayOut: 134, manager: '张伟', managerPhone: '13800138001', status: 'active', lat: 31.2304, lng: 121.6177 },
  { id: 'site-sh-2', code: 'ST-2024-002', name: '虹桥配送中心', orgPath: ['集团总部', '华东大区', '上海', '上海市'], region: '华东大区', province: '上海', city: '上海市', address: '上海市闵行区申虹路888号', carrierCount: 980, inStockCount: 640, todayIn: 112, todayOut: 98, manager: '李娜', managerPhone: '13800138002', status: 'active', lat: 31.1942, lng: 121.3281 },
  { id: 'site-js-1', code: 'ST-2024-003', name: '江宁仓储中心', orgPath: ['集团总部', '华东大区', '江苏', '南京市'], region: '华东大区', province: '江苏', city: '南京市', address: '南京市江宁区将军大道669号', carrierCount: 860, inStockCount: 590, todayIn: 89, todayOut: 76, manager: '王强', managerPhone: '13800138003', status: 'active', lat: 31.9505, lng: 118.7901 },
  { id: 'site-js-2', code: 'ST-2024-004', name: '昆山物流基地', orgPath: ['集团总部', '华东大区', '江苏', '苏州市'], region: '华东大区', province: '江苏', city: '苏州市', address: '苏州市昆山市花桥镇绿地大道', carrierCount: 740, inStockCount: 510, todayIn: 78, todayOut: 82, manager: '赵敏', managerPhone: '13800138004', status: 'active', lat: 31.3870, lng: 121.1145 },
  { id: 'site-js-3', code: 'ST-2024-005', name: '苏州园区仓', orgPath: ['集团总部', '华东大区', '江苏', '苏州市'], region: '华东大区', province: '江苏', city: '苏州市', address: '苏州市工业园区现代大道88号', carrierCount: 650, inStockCount: 420, todayIn: 65, todayOut: 71, manager: '孙杰', managerPhone: '13800138005', status: 'active', lat: 31.3230, lng: 120.7428 },
  { id: 'site-zj-1', code: 'ST-2024-006', name: '萧山配送中心', orgPath: ['集团总部', '华东大区', '浙江', '杭州市'], region: '华东大区', province: '浙江', city: '杭州市', address: '杭州市萧山区靖江街道保税路', carrierCount: 920, inStockCount: 680, todayIn: 102, todayOut: 95, manager: '周芳', managerPhone: '13800138006', status: 'active', lat: 30.2436, lng: 120.4344 },
  { id: 'site-zj-2', code: 'ST-2024-007', name: '北仑港物流园', orgPath: ['集团总部', '华东大区', '浙江', '宁波市'], region: '华东大区', province: '浙江', city: '宁波市', address: '宁波市北仑区新碶街道进港路', carrierCount: 1100, inStockCount: 750, todayIn: 134, todayOut: 122, manager: '吴磊', managerPhone: '13800138007', status: 'active', lat: 29.9247, lng: 121.8505 },
  { id: 'site-ah-1', code: 'ST-2024-008', name: '蜀山仓储基地', orgPath: ['集团总部', '华东大区', '安徽', '合肥市'], region: '华东大区', province: '安徽', city: '合肥市', address: '合肥市蜀山区望江西路800号', carrierCount: 480, inStockCount: 310, todayIn: 45, todayOut: 38, manager: '郑涛', managerPhone: '13800138008', status: 'active', lat: 31.8573, lng: 117.2267 },
  { id: 'site-bj-1', code: 'ST-2024-009', name: '通州物流中心', orgPath: ['集团总部', '华北大区', '北京', '北京市'], region: '华北大区', province: '北京', city: '北京市', address: '北京市通州区马驹桥镇物流产业园', carrierCount: 1380, inStockCount: 920, todayIn: 167, todayOut: 145, manager: '陈明', managerPhone: '13800138009', status: 'active', lat: 39.8652, lng: 116.5406 },
  { id: 'site-bj-2', code: 'ST-2024-010', name: '大兴配送基地', orgPath: ['集团总部', '华北大区', '北京', '北京市'], region: '华北大区', province: '北京', city: '北京市', address: '北京市大兴区京开高速旁物流园', carrierCount: 890, inStockCount: 540, todayIn: 98, todayOut: 112, manager: '杨静', managerPhone: '13800138010', status: 'warning', lat: 39.7269, lng: 116.3414 },
  { id: 'site-tj-1', code: 'ST-2024-011', name: '滨海新区仓储', orgPath: ['集团总部', '华北大区', '天津', '天津市'], region: '华北大区', province: '天津', city: '天津市', address: '天津市滨海新区天津港保税区', carrierCount: 760, inStockCount: 490, todayIn: 82, todayOut: 74, manager: '黄磊', managerPhone: '13800138011', status: 'active', lat: 39.0328, lng: 117.7138 },
  { id: 'site-hb-1', code: 'ST-2024-012', name: '裕华物流园', orgPath: ['集团总部', '华北大区', '河北', '石家庄市'], region: '华北大区', province: '河北', city: '石家庄市', address: '石家庄市裕华区仓兴街16号', carrierCount: 520, inStockCount: 340, todayIn: 56, todayOut: 48, manager: '林峰', managerPhone: '13800138012', status: 'active', lat: 38.0212, lng: 114.5378 },
  { id: 'site-hb-2', code: 'ST-2024-013', name: '曹妃甸港仓', orgPath: ['集团总部', '华北大区', '河北', '唐山市'], region: '华北大区', province: '河北', city: '唐山市', address: '唐山市曹妃甸区综合保税区', carrierCount: 680, inStockCount: 450, todayIn: 72, todayOut: 65, manager: '徐丽', managerPhone: '13800138013', status: 'active', lat: 39.2785, lng: 118.0563 },
  { id: 'site-sd-1', code: 'ST-2024-014', name: '高新物流中心', orgPath: ['集团总部', '华北大区', '山东', '济南市'], region: '华北大区', province: '山东', city: '济南市', address: '济南市高新区遥墙机场路', carrierCount: 590, inStockCount: 380, todayIn: 62, todayOut: 55, manager: '马超', managerPhone: '13800138014', status: 'active', lat: 36.7201, lng: 117.1524 },
  { id: 'site-sd-2', code: 'ST-2024-015', name: '胶州湾配送仓', orgPath: ['集团总部', '华北大区', '山东', '青岛市'], region: '华北大区', province: '山东', city: '青岛市', address: '青岛市胶州市胶州湾物流园', carrierCount: 710, inStockCount: 460, todayIn: 78, todayOut: 69, manager: '朱红', managerPhone: '13800138015', status: 'active', lat: 36.2483, lng: 120.0338 },
  { id: 'site-gd-1', code: 'ST-2024-016', name: '白云物流枢纽', orgPath: ['集团总部', '华南大区', '广东', '广州市'], region: '华南大区', province: '广东', city: '广州市', address: '广州市白云区太和镇物流大道', carrierCount: 1420, inStockCount: 980, todayIn: 178, todayOut: 165, manager: '胡伟', managerPhone: '13800138016', status: 'active', lat: 23.2963, lng: 113.3076 },
  { id: 'site-gd-2', code: 'ST-2024-017', name: '南沙仓储中心', orgPath: ['集团总部', '华南大区', '广东', '广州市'], region: '华南大区', province: '广东', city: '广州市', address: '广州市南沙区龙穴岛保税港', carrierCount: 860, inStockCount: 590, todayIn: 95, todayOut: 88, manager: '罗雪', managerPhone: '13800138017', status: 'active', lat: 22.7712, lng: 113.6071 },
  { id: 'site-gd-3', code: 'ST-2024-018', name: '前海智慧仓', orgPath: ['集团总部', '华南大区', '广东', '深圳市'], region: '华南大区', province: '广东', city: '深圳市', address: '深圳市前海深港合作区', carrierCount: 1080, inStockCount: 720, todayIn: 132, todayOut: 125, manager: '高山', managerPhone: '13800138018', status: 'active', lat: 22.5054, lng: 113.9013 },
  { id: 'site-gx-1', code: 'ST-2024-019', name: '五象物流园', orgPath: ['集团总部', '华南大区', '广西', '南宁市'], region: '华南大区', province: '广西', city: '南宁市', address: '南宁市良庆区五象大道', carrierCount: 390, inStockCount: 250, todayIn: 42, todayOut: 36, manager: '谢东', managerPhone: '13800138019', status: 'inactive', lat: 22.7628, lng: 108.4085 },
  { id: 'site-fj-1', code: 'ST-2024-020', name: '马尾港配送仓', orgPath: ['集团总部', '华南大区', '福建', '福州市'], region: '华南大区', province: '福建', city: '福州市', address: '福州市马尾区青州路港务局', carrierCount: 560, inStockCount: 370, todayIn: 58, todayOut: 52, manager: '唐丽', managerPhone: '13800138020', status: 'active', lat: 26.0048, lng: 119.4628 },
  { id: 'site-hn-1', code: 'ST-2024-021', name: '海口物流基地', orgPath: ['集团总部', '华南大区', '海南', '海口市'], region: '华南大区', province: '海南', city: '海口市', address: '海口市秀英区南海大道', carrierCount: 320, inStockCount: 210, todayIn: 34, todayOut: 28, manager: '韩冰', managerPhone: '13800138021', status: 'active', lat: 20.0173, lng: 110.2927 },
  { id: 'site-sc-1', code: 'ST-2024-022', name: '双流物流中心', orgPath: ['集团总部', '西部大区', '四川', '成都市'], region: '西部大区', province: '四川', city: '成都市', address: '成都市双流区西航港大道', carrierCount: 780, inStockCount: 530, todayIn: 92, todayOut: 86, manager: '曹阳', managerPhone: '13800138022', status: 'active', lat: 30.5675, lng: 103.9536 },
  { id: 'site-sc-2', code: 'ST-2024-023', name: '天府仓储园', orgPath: ['集团总部', '西部大区', '四川', '成都市'], region: '西部大区', province: '四川', city: '成都市', address: '成都市天府新区新兴工业园', carrierCount: 620, inStockCount: 410, todayIn: 68, todayOut: 62, manager: '彭佳', managerPhone: '13800138023', status: 'active', lat: 30.4143, lng: 104.1431 },
  { id: 'site-cq-1', code: 'ST-2024-024', name: '两江新区仓', orgPath: ['集团总部', '西部大区', '重庆', '重庆市'], region: '西部大区', province: '重庆', city: '重庆市', address: '重庆市渝北区木耳镇物流园', carrierCount: 540, inStockCount: 350, todayIn: 58, todayOut: 52, manager: '邓辉', managerPhone: '13800138024', status: 'warning', lat: 29.7882, lng: 106.6366 },
  { id: 'site-sx-1', code: 'ST-2024-025', name: '咸阳空港仓', orgPath: ['集团总部', '西部大区', '陕西', '西安市'], region: '西部大区', province: '陕西', city: '西安市', address: '咸阳市渭城区空港新城', carrierCount: 470, inStockCount: 310, todayIn: 48, todayOut: 42, manager: '冯磊', managerPhone: '13800138025', status: 'active', lat: 34.3230, lng: 108.7691 },
  { id: 'site-yn-1', code: 'ST-2024-026', name: '呈贡物流园', orgPath: ['集团总部', '西部大区', '云南', '昆明市'], region: '西部大区', province: '云南', city: '昆明市', address: '昆明市呈贡区洛羊街道', carrierCount: 380, inStockCount: 250, todayIn: 38, todayOut: 34, manager: '潘虹', managerPhone: '13800138026', status: 'inactive', lat: 24.9011, lng: 102.8329 },
];

// ─── Chart Mock Data ─────────────────────────────────────────────

const REGION_BAR_DATA = [
  { region: '华东大区', count: 8 },
  { region: '华北大区', count: 8 },
  { region: '华南大区', count: 6 },
  { region: '西部大区', count: 4 },
];

const STATUS_PIE_DATA = [
  { name: '运营中', value: 22, color: '#10B981' },
  { name: '异常', value: 2, color: '#F59E0B' },
  { name: '已停用', value: 2, color: '#94A3B8' },
];

const TREND_DATA = Array.from({ length: 30 }, (_, i) => {
  const day = i + 1;
  return {
    date: `12/${String(day).padStart(2, '0')}`,
    in: Math.floor(65 + Math.sin(day * 0.3) * 40 + Math.random() * 30),
    out: Math.floor(55 + Math.sin(day * 0.3 + 1) * 35 + Math.random() * 25),
  };
});

// ─── Helpers ─────────────────────────────────────────────────────

function countNodes(node: OrgNode, typeFilter: OrgNodeType): number {
  let count = node.type === typeFilter ? 1 : 0;
  if (node.children) {
    for (const child of node.children) {
      count += countNodes(child, typeFilter);
    }
  }
  return count;
}

function getRegionSites(regionName: string): SiteData[] {
  return SITES.filter((s) => s.region === regionName);
}

function getAllNodeIds(node: OrgNode): string[] {
  const ids = [node.id];
  if (node.children) {
    for (const child of node.children) {
      ids.push(...getAllNodeIds(child));
    }
  }
  return ids;
}

function getSitesForNode(node: OrgNode): SiteData[] {
  if (node.type === 'site') {
    return SITES.filter((s) => s.id === node.id);
  }
  const allIds = getAllNodeIds(node);
  return SITES.filter((s) => allIds.includes(s.id));
}

function getNodeIcon(type: OrgNodeType, _isOpen: boolean) {
  switch (type) {
    case 'group': return <Building2 className="w-4 h-4 text-primary" />;
    case 'region': return <MapPin className="w-4 h-4 text-info" />;
    case 'province': return <FolderOpen className="w-4 h-4 text-warning" />;
    case 'city': return <FileText className="w-4 h-4 text-purple" />;
    case 'site': return <Warehouse className="w-4 h-4 text-success" />;
  }
}

// ─── Tree View Component ─────────────────────────────────────────

function TreeNodeView({
  node,
  level,
  expandedIds,
  selectedId,
  onToggle,
  onSelect,
}: {
  node: OrgNode;
  level: number;
  expandedIds: Set<string>;
  selectedId: string | null;
  onToggle: (id: string) => void;
  onSelect: (node: OrgNode) => void;
}) {
  const isExpanded = expandedIds.has(node.id);
  const hasChildren = (node.children?.length ?? 0) > 0;
  const isSelected = selectedId === node.id;
  const isSite = node.type === 'site';

  return (
    <div className="select-none">
      <motion.div
        initial={false}
        animate={{ backgroundColor: isSelected ? 'rgba(37,99,235,0.08)' : 'transparent' }}
        className={cn(
          'flex items-center gap-1.5 py-1.5 px-2 rounded-md cursor-pointer transition-colors',
          'hover:bg-[var(--neutral-surface-elevated)]',
          isSelected && 'bg-primary/5'
        )}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={() => onSelect(node)}
      >
        {hasChildren ? (
          <button
            className="flex-shrink-0 w-4 h-4 flex items-center justify-center text-[var(--neutral-text-tertiary)] hover:text-[var(--neutral-text-secondary)]"
            onClick={(e) => {
              e.stopPropagation();
              onToggle(node.id);
            }}
          >
            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        ) : (
          <span className="w-4 flex-shrink-0" />
        )}
        <span className="flex-shrink-0">{getNodeIcon(node.type, isExpanded)}</span>
        <span className={cn(
          'text-sm truncate',
          isSelected ? 'font-medium text-primary' : 'text-[var(--neutral-text-primary)]'
        )}>
          {node.name}
        </span>
        {isSite && (
          <Badge variant="outline" className="ml-auto text-[10px] px-1 py-0 h-4 shrink-0">
            网点
          </Badge>
        )}
      </motion.div>
      <AnimatePresence initial={false}>
        {hasChildren && isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            {node.children!.map((child) => (
              <TreeNodeView
                key={child.id}
                node={child}
                level={level + 1}
                expandedIds={expandedIds}
                selectedId={selectedId}
                onToggle={onToggle}
                onSelect={onSelect}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Stat Card ───────────────────────────────────────────────────

function StatCard({
  icon,
  label,
  value,
  sub,
  trend,
  trendUp,
  delay,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  trend?: string;
  trendUp?: boolean;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: delay * 0.08, ease: 'easeOut' }}
    >
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] hover:shadow-card-hover transition-shadow">
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div className="space-y-3 flex-1">
              <div className="text-sm text-[var(--neutral-text-secondary)]">{label}</div>
              <div className="text-2xl font-bold text-[var(--neutral-text-primary)] font-number">{value}</div>
              {(sub || trend) && (
                <div className="flex items-center gap-2">
                  {sub && (
                    <span className="text-xs text-[var(--neutral-text-tertiary)]">{sub}</span>
                  )}
                  {trend && (
                    <span className={cn(
                      'flex items-center gap-0.5 text-xs font-medium',
                      trendUp ? 'text-success' : 'text-danger'
                    )}>
                      {trendUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                      {trend}
                    </span>
                  )}
                </div>
              )}
            </div>
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
              {icon}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Summary Card for Drill-down ─────────────────────────────────

function DrillDownSummary({ regionName }: { regionName: string }) {
  const sites = getRegionSites(regionName);
  const totalCarrier = sites.reduce((s, site) => s + site.carrierCount, 0);
  const totalInStock = sites.reduce((s, site) => s + site.inStockCount, 0);
  const inStockRate = totalCarrier > 0 ? ((totalInStock / totalCarrier) * 100).toFixed(1) : '0.0';
  const totalTodayIn = sites.reduce((s, site) => s + site.todayIn, 0);
  const totalTodayOut = sites.reduce((s, site) => s + site.todayOut, 0);
  const turnoverRate = totalInStock > 0 ? (((totalTodayIn + totalTodayOut) / 2 / totalInStock) * 100).toFixed(1) : '0.0';

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="grid grid-cols-1 sm:grid-cols-3 gap-4"
    >
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Package className="w-4 h-4 text-primary" />
            <span className="text-sm text-[var(--neutral-text-secondary)]">总载具数</span>
          </div>
          <div className="text-xl font-bold text-[var(--neutral-text-primary)] font-number">
            {totalCarrier.toLocaleString()}
          </div>
          <div className="text-xs text-[var(--neutral-text-tertiary)] mt-1">{regionName} · {sites.length}个网点</div>
        </CardContent>
      </Card>
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Warehouse className="w-4 h-4 text-success" />
            <span className="text-sm text-[var(--neutral-text-secondary)]">在库率</span>
          </div>
          <div className="text-xl font-bold text-[var(--neutral-text-primary)] font-number">
            {inStockRate}%
          </div>
          <div className="w-full bg-[var(--neutral-border)] rounded-full h-1.5 mt-2">
            <div
              className="bg-success h-1.5 rounded-full transition-all"
              style={{ width: `${inStockRate}%` }}
            />
          </div>
        </CardContent>
      </Card>
      <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-warning" />
            <span className="text-sm text-[var(--neutral-text-secondary)]">周转率</span>
          </div>
          <div className="text-xl font-bold text-[var(--neutral-text-primary)] font-number">
            {turnoverRate}%
          </div>
          <div className="text-xs text-[var(--neutral-text-tertiary)] mt-1">
            日均入库 {Math.round(totalTodayIn / 30)} / 日均出库 {Math.round(totalTodayOut / 30)}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ─── Main Component ──────────────────────────────────────────────

export default function OrgSiteAggregationPage() {
  // ── State ──
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['group-1', 'region-east']));
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<OrgNode | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<string>('carrierCount');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const PAGE_SIZE_OPTIONS = [10, 20, 50];

  // ── Stats ──
  const totalOrgs = useMemo(() => {
    return 1 + countNodes(ORG_TREE, 'region') + countNodes(ORG_TREE, 'province') + countNodes(ORG_TREE, 'city');
  }, []);
  const totalSites = SITES.length;
  const newThisMonth = 5;
  const activeRate = ((SITES.filter((s) => s.status === 'active').length / totalSites) * 100).toFixed(1);

  // ── Tree handlers ──
  const handleToggle = useCallback((id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleSelectNode = useCallback((node: OrgNode) => {
    setSelectedNodeId(node.id);
    setSelectedNode(node);
    setPage(1);
    if ((node.children?.length ?? 0) > 0) {
      setExpandedIds((prev) => {
        const next = new Set(prev);
        next.add(node.id);
        return next;
      });
    }
  }, []);

  // ── Table data ──
  const tableSites = useMemo(() => {
    let data = selectedNode ? getSitesForNode(selectedNode) : [...SITES];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      data = data.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.manager.toLowerCase().includes(q) ||
          s.address.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'all') {
      data = data.filter((s) => s.status === statusFilter);
    }

    data.sort((a, b) => {
      let av: number | string;
      let bv: number | string;
      switch (sortField) {
        case 'code': av = a.code; bv = b.code; break;
        case 'name': av = a.name; bv = b.name; break;
        case 'orgPath': av = a.orgPath.join(''); bv = b.orgPath.join(''); break;
        case 'address': av = a.address; bv = b.address; break;
        case 'carrierCount': av = a.carrierCount; bv = b.carrierCount; break;
        case 'inStockCount': av = a.inStockCount; bv = b.inStockCount; break;
        case 'todayIn': av = a.todayIn; bv = b.todayIn; break;
        case 'todayOut': av = a.todayOut; bv = b.todayOut; break;
        case 'manager': av = a.manager; bv = b.manager; break;
        default: av = a.carrierCount; bv = b.carrierCount;
      }
      if (typeof av === 'number' && typeof bv === 'number') {
        return sortDir === 'asc' ? av - bv : bv - av;
      }
      return sortDir === 'asc' ? String(av).localeCompare(String(bv)) : String(bv).localeCompare(String(av));
    });

    return data;
  }, [selectedNode, searchQuery, statusFilter, sortField, sortDir]);

  const totalPages = Math.max(1, Math.ceil(tableSites.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paginatedSites = tableSites.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSort = useCallback((field: string) => {
    setSortField((prev) => {
      if (prev === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return prev;
      }
      setSortDir('desc');
      return field;
    });
  }, []);

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) return <span className="text-[var(--neutral-text-tertiary)] opacity-40">↕</span>;
    return sortDir === 'asc' ? (
      <ArrowUpRight className="w-3 h-3 text-primary" />
    ) : (
      <ArrowDownRight className="w-3 h-3 text-primary" />
    );
  };

  const showDrillDown = selectedNode?.type === 'region';

  return (
    <div className="min-h-screen bg-[var(--neutral-background)] p-5">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-5"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-[var(--neutral-text-primary)]">组织网点聚合</h1>
            <p className="text-xs text-[var(--neutral-text-secondary)] mt-0.5">
              组织架构管理 · 网点数据概览 · 载具分布统计
            </p>
          </div>
        </div>
      </motion.div>

      {/* Top Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        <StatCard icon={<Building2 className="w-5 h-5" />} label="总组织数" value={totalOrgs} sub="4级架构" delay={0} />
        <StatCard icon={<MapPin className="w-5 h-5" />} label="总网点数" value={totalSites} sub="覆盖全国" trend="+8.2%" trendUp delay={1} />
        <StatCard icon={<TrendingUp className="w-5 h-5" />} label="本月新增网点" value={newThisMonth} sub="较上月" trend="+25%" trendUp delay={2} />
        <StatCard icon={<Activity className="w-5 h-5" />} label="活跃网点占比" value={`${activeRate}%`} sub={`${SITES.filter((s) => s.status === 'active').length}个运营中`} delay={3} />
      </div>

      {/* Main Content: Tree + Table */}
      <div className="grid grid-cols-1 lg:grid-cols-[320px_1fr] gap-5 mb-5">
        {/* Tree Panel */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.15 }}
        >
          <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)] h-full">
            <CardHeader className="pb-3 pt-4 px-4">
              <div className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-primary" />
                <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)]">组织架构</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-3 pb-4 pt-0">
              <div className="text-xs text-[var(--neutral-text-tertiary)] mb-2 px-2">
                点击节点查看网点详情，点击箭头展开/折叠
              </div>
              <div className="space-y-0.5 max-h-[560px] overflow-y-auto pr-1">
                {ORG_TREE.children?.map((child) => (
                  <TreeNodeView
                    key={child.id}
                    node={child}
                    level={0}
                    expandedIds={expandedIds}
                    selectedId={selectedNodeId}
                    onToggle={handleToggle}
                    onSelect={handleSelectNode}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Table Panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          {/* Drill-down Summary */}
          {showDrillDown && <DrillDownSummary regionName={selectedNode.name} />}

          {/* Selected node info */}
          {selectedNode && !showDrillDown && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex items-center gap-2 text-sm"
            >
              <Badge variant="outline" className="gap-1">
                {getNodeIcon(selectedNode.type, true)}
                {selectedNode.name}
              </Badge>
              <span className="text-[var(--neutral-text-secondary)]">
                共 {getSitesForNode(selectedNode).length} 个网点
              </span>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 text-xs text-[var(--neutral-text-tertiary)] hover:text-primary"
                onClick={() => {
                  setSelectedNode(null);
                  setSelectedNodeId(null);
                }}
              >
                查看全部
              </Button>
            </motion.div>
          )}

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--neutral-text-tertiary)]" />
              <Input
                placeholder="搜索网点名称、编码、负责人..."
                className="pl-9 bg-[var(--neutral-surface)] border-[var(--neutral-border)] text-[var(--neutral-text-primary)]"
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] bg-[var(--neutral-surface)] border-[var(--neutral-border)]">
                <SelectValue placeholder="全部状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="active">运营中</SelectItem>
                <SelectItem value="warning">异常</SelectItem>
                <SelectItem value="inactive">已停用</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Table */}
          <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b-[var(--neutral-border)] hover:bg-transparent">
                      {[
                        { key: 'code', label: '网点编码', w: '' },
                        { key: 'name', label: '网点名称', w: '' },
                        { key: 'orgPath', label: '所属组织', w: '' },
                        { key: 'address', label: '地址', w: '' },
                        { key: 'carrierCount', label: '载具数量', w: '' },
                        { key: 'inStockCount', label: '在库数', w: '' },
                        { key: 'todayIn', label: '今日入库', w: '' },
                        { key: 'todayOut', label: '今日出库', w: '' },
                        { key: 'manager', label: '负责人', w: '' },
                        { key: '', label: '状态', w: '' },
                      ].map((col) => (
                        <TableHead
                          key={col.key || col.label}
                          className={cn(
                            'text-xs text-[var(--neutral-text-secondary)] font-medium whitespace-nowrap',
                            col.key && 'cursor-pointer hover:text-primary'
                          )}
                          onClick={() => col.key && handleSort(col.key)}
                        >
                          <span className="flex items-center gap-1">
                            {col.label}
                            {col.key && <SortIcon field={col.key} />}
                          </span>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedSites.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center py-12 text-[var(--neutral-text-tertiary)]">
                          <div className="flex flex-col items-center gap-2">
                            <Warehouse className="w-8 h-8 opacity-30" />
                            <span>暂无网点数据</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ) : (
                      paginatedSites.map((site, idx) => (
                        <motion.tr
                          key={site.id}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.03 }}
                          className="border-b-[var(--neutral-border)] hover:bg-[var(--neutral-surface-elevated)] transition-colors"
                        >
                          <TableCell className="text-xs text-[var(--neutral-text-primary)] font-mono whitespace-nowrap">
                            {site.code}
                          </TableCell>
                          <TableCell className="text-sm font-medium text-[var(--neutral-text-primary)] whitespace-nowrap">
                            <div className="flex items-center gap-1.5">
                              <Warehouse className="w-3.5 h-3.5 text-success" />
                              {site.name}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)] whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Building2 className="w-3 h-3" />
                              {site.region}
                              <ChevronRight className="w-3 h-3 text-[var(--neutral-text-tertiary)]" />
                              {site.city}
                            </div>
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)] max-w-[200px] truncate">
                            {site.address}
                          </TableCell>
                          <TableCell className="text-sm text-[var(--neutral-text-primary)] font-number whitespace-nowrap">
                            {site.carrierCount.toLocaleString()}
                          </TableCell>
                          <TableCell className="text-sm text-[var(--neutral-text-primary)] font-number whitespace-nowrap">
                            {site.inStockCount.toLocaleString()}
                          </TableCell>
                          <TableCell className="text-sm text-success font-number whitespace-nowrap">
                            +{site.todayIn}
                          </TableCell>
                          <TableCell className="text-sm text-danger font-number whitespace-nowrap">
                            -{site.todayOut}
                          </TableCell>
                          <TableCell className="text-xs text-[var(--neutral-text-secondary)] whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              {site.manager}
                            </div>
                          </TableCell>
                          <TableCell className="whitespace-nowrap">
                            <Badge
                              className={cn(
                                'text-[10px] border-0',
                                STATUS_COLORS[site.status].bg,
                                STATUS_COLORS[site.status].text
                              )}
                            >
                              <span className="flex items-center gap-1">
                                <span
                                  className="w-1.5 h-1.5 rounded-full"
                                  style={{ backgroundColor: STATUS_COLORS[site.status].dot }}
                                />
                                {STATUS_LABELS[site.status]}
                              </span>
                            </Badge>
                          </TableCell>
                        </motion.tr>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              <div className="flex items-center justify-between px-4 py-3 border-t border-[var(--neutral-border)]">
                <div className="flex items-center gap-2 text-xs text-[var(--neutral-text-secondary)]">
                  <span>共 {tableSites.length} 条</span>
                  <Select value={String(pageSize)} onValueChange={(v) => { setPageSize(Number(v)); setPage(1); }}>
                    <SelectTrigger className="h-7 w-[80px] text-xs bg-transparent border-[var(--neutral-border)]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PAGE_SIZE_OPTIONS.map((o) => (
                        <SelectItem key={o} value={String(o)}>{o}条/页</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-7 w-7 border-[var(--neutral-border)]"
                    onClick={() => setPage(1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronFirst className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-7 w-7 border-[var(--neutral-border)]"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </Button>
                  <span className="text-xs text-[var(--neutral-text-secondary)] px-2">
                    {currentPage} / {totalPages}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-7 w-7 border-[var(--neutral-border)]"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-7 w-7 border-[var(--neutral-border)]"
                    onClick={() => setPage(totalPages)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronLast className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-primary" />
                <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)]">
                  各区域网点数量对比
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={REGION_BAR_DATA} barSize={40}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="region" tick={{ fontSize: 12, fill: '#475569' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 8,
                      border: '1px solid #E2E8F0',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="count" fill="#2563EB" radius={[4, 4, 0, 0]} name="网点数" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Pie Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
        >
          <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-success" />
                <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)]">
                  网点状态分布
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={STATUS_PIE_DATA}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {STATUS_PIE_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      borderRadius: 8,
                      border: '1px solid #E2E8F0',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      fontSize: 12,
                    }}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    iconSize={8}
                    formatter={(value: string) => (
                      <span className="text-xs text-[var(--neutral-text-secondary)]">{value}</span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Line Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="border-[var(--neutral-border)] bg-[var(--neutral-surface)]">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-warning" />
                <CardTitle className="text-sm font-semibold text-[var(--neutral-text-primary)]">
                  近30天载具流转趋势
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="px-4 pb-4">
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={TREND_DATA}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11, fill: '#94A3B8' }}
                    axisLine={false}
                    tickLine={false}
                    interval={4}
                  />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 8,
                      border: '1px solid #E2E8F0',
                      boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                      fontSize: 12,
                    }}
                  />
                  <Legend
                    verticalAlign="top"
                    height={24}
                    iconType="line"
                    iconSize={10}
                    formatter={(value: string) => (
                      <span className="text-xs text-[var(--neutral-text-secondary)]">
                        {value === 'in' ? '入库' : '出库'}
                      </span>
                    )}
                  />
                  <Line type="monotone" dataKey="in" stroke="#10B981" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                  <Line type="monotone" dataKey="out" stroke="#EF4444" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}