import { useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Search,
  ChevronDown,
  Filter,
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Package,
  Ruler,
  Factory,
  ShieldCheck,
  FileText,
  X,
  Container,
  Info,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
} from '@/components/ui/drawer';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// ============================================================
// Types
// ============================================================

interface CarrierModel {
  id: string;
  code: string;
  name: string;
  type: string;
  length: number; // cm
  width: number; // cm
  height: number; // cm
  maxLoad: number; // kg
  selfWeight: number; // kg
  material: string;
  manufacturer: string;
  origin: string;
  certNo: string;
  certOrg: string;
  certValidUntil: string;
  status: 'active' | 'inactive';
  relatedCarrierCount: number;
  remark: string;
  createdAt: string;
}

interface ChangeLog {
  time: string;
  action: string;
  user: string;
  detail: string;
}

type SortField = 'code' | 'name' | 'type' | 'material' | 'manufacturer' | 'status' | 'relatedCarrierCount' | 'createdAt';
type SortDirection = 'asc' | 'desc';

// ============================================================
// Mock Data
// ============================================================

const CARRIER_TYPES = ['托盘', '周转箱', '料架', '保温箱', '危险品容器', '集装箱', '笼车'];
const MATERIALS = ['木质', '塑料', '金属', '复合材料'];

const MOCK_MODELS: CarrierModel[] = [
  {
    id: 'model-1', code: 'ZHX-STD-600', name: '物流周转箱-标准600', type: '周转箱',
    length: 60, width: 40, height: 32, maxLoad: 25, selfWeight: 1.8,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'GB/T 5737-2024-001', certOrg: '国家包装产品质量监督检验中心',
    certValidUntil: '2027-06-15', status: 'active', relatedCarrierCount: 320,
    remark: '标准物流周转箱，适用于汽车零部件轻载运输', createdAt: '2024-01-15',
  },
  {
    id: 'model-2', code: 'ZHX-STD-800', name: '物流周转箱-标准800', type: '周转箱',
    length: 80, width: 60, height: 42, maxLoad: 40, selfWeight: 3.2,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'GB/T 5737-2024-002', certOrg: '国家包装产品质量监督检验中心',
    certValidUntil: '2027-06-15', status: 'active', relatedCarrierCount: 285,
    remark: '中大型周转箱，适合电子产品运输', createdAt: '2024-01-20',
  },
  {
    id: 'model-3', code: 'ZHX-STD-400', name: '物流周转箱-标准400', type: '周转箱',
    length: 40, width: 30, height: 25, maxLoad: 15, selfWeight: 0.9,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'GB/T 5737-2024-003', certOrg: '国家包装产品质量监督检验中心',
    certValidUntil: '2027-06-15', status: 'active', relatedCarrierCount: 180,
    remark: '小型周转箱，适用于精密零件', createdAt: '2024-02-01',
  },
  {
    id: 'model-4', code: 'TP-WD-1200', name: '仓储托盘-木质1200', type: '托盘',
    length: 120, width: 100, height: 15, maxLoad: 1500, selfWeight: 22,
    material: '木质', manufacturer: '林海木业集团', origin: '江苏苏州',
    certNo: 'GB/T 2934-2024-101', certOrg: '中国木材与木制品流通协会',
    certValidUntil: '2026-12-20', status: 'active', relatedCarrierCount: 520,
    remark: '标准欧规木质托盘，四面进叉', createdAt: '2024-01-10',
  },
  {
    id: 'model-5', code: 'TP-WD-1100', name: '仓储托盘-木质1100', type: '托盘',
    length: 110, width: 110, height: 15, maxLoad: 1200, selfWeight: 20,
    material: '木质', manufacturer: '林海木业集团', origin: '江苏苏州',
    certNo: 'GB/T 2934-2024-102', certOrg: '中国木材与木制品流通协会',
    certValidUntil: '2026-12-20', status: 'active', relatedCarrierCount: 260,
    remark: '日规木质托盘，适合出口日本', createdAt: '2024-01-12',
  },
  {
    id: 'model-6', code: 'TP-PL-1200', name: '仓储托盘-塑料1200', type: '托盘',
    length: 120, width: 100, height: 15, maxLoad: 1200, selfWeight: 18,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'GB/T 2934-2024-201', certOrg: '国家包装产品质量监督检验中心',
    certValidUntil: '2027-03-10', status: 'active', relatedCarrierCount: 410,
    remark: 'HDPE塑料托盘，可水洗，适合食品行业', createdAt: '2024-02-15',
  },
  {
    id: 'model-7', code: 'TP-MT-1200', name: '仓储托盘-金属1200', type: '托盘',
    length: 120, width: 100, height: 15, maxLoad: 2000, selfWeight: 35,
    material: '金属', manufacturer: '宝钢物流装备', origin: '上海宝山',
    certNo: 'GB/T 2934-2024-301', certOrg: '中国物流与采购联合会托盘专业委员会',
    certValidUntil: '2028-01-05', status: 'active', relatedCarrierCount: 150,
    remark: '钢制托盘，超重型货物专用', createdAt: '2024-03-01',
  },
  {
    id: 'model-8', code: 'LJ-MT-AUTO', name: '汽车零部件料架-A型', type: '料架',
    length: 150, width: 120, height: 140, maxLoad: 500, selfWeight: 65,
    material: '金属', manufacturer: '宝钢物流装备', origin: '上海宝山',
    certNo: 'Q/BGWL-2024-001', certOrg: '上海机动车检测认证技术研究中心',
    certValidUntil: '2029-04-18', status: 'active', relatedCarrierCount: 88,
    remark: '汽车发动机专用料架，可折叠', createdAt: '2024-03-20',
  },
  {
    id: 'model-9', code: 'LJ-MT-BODY', name: '汽车零部件料架-车身件', type: '料架',
    length: 180, width: 140, height: 120, maxLoad: 800, selfWeight: 95,
    material: '金属', manufacturer: '宝钢物流装备', origin: '上海宝山',
    certNo: 'Q/BGWL-2024-002', certOrg: '上海机动车检测认证技术研究中心',
    certValidUntil: '2029-04-18', status: 'active', relatedCarrierCount: 62,
    remark: '车身冲压件专用，表面镀锌防锈', createdAt: '2024-04-01',
  },
  {
    id: 'model-10', code: 'LJ-COMP-TIRE', name: '汽车零部件料架-轮胎架', type: '料架',
    length: 130, width: 130, height: 160, maxLoad: 600, selfWeight: 48,
    material: '复合材料', manufacturer: '华复新材科技', origin: '广东深圳',
    certNo: 'Q/HFXC-2024-003', certOrg: '广东省质量技术监督局',
    certValidUntil: '2027-08-22', status: 'active', relatedCarrierCount: 45,
    remark: '碳纤维复合材料，轻量化设计', createdAt: '2024-04-15',
  },
  {
    id: 'model-11', code: 'LC-BX-80L', name: '冷链保温箱-80L', type: '保温箱',
    length: 65, width: 45, height: 55, maxLoad: 50, selfWeight: 8.5,
    material: '复合材料', manufacturer: '冷链科技（苏州）', origin: '江苏苏州',
    certNo: 'GB/T 34399-2024-501', certOrg: '国家食品安全风险评估中心',
    certValidUntil: '2026-11-30', status: 'active', relatedCarrierCount: 120,
    remark: '医药冷链专用，保温时效72小时', createdAt: '2024-05-01',
  },
  {
    id: 'model-12', code: 'LC-BX-120L', name: '冷链保温箱-120L', type: '保温箱',
    length: 80, width: 60, height: 70, maxLoad: 80, selfWeight: 12,
    material: '复合材料', manufacturer: '冷链科技（苏州）', origin: '江苏苏州',
    certNo: 'GB/T 34399-2024-502', certOrg: '国家食品安全风险评估中心',
    certValidUntil: '2026-11-30', status: 'active', relatedCarrierCount: 75,
    remark: '大型冷链箱，带温度记录仪接口', createdAt: '2024-05-10',
  },
  {
    id: 'model-13', code: 'WX-DR-200', name: '危险品专用容器-200L', type: '危险品容器',
    length: 60, width: 60, height: 90, maxLoad: 200, selfWeight: 18,
    material: '金属', manufacturer: '安盾特种容器制造', origin: '山东青岛',
    certNo: 'UN 1A1/Y/250/24/CN/001', certOrg: '中国船级社质量认证公司',
    certValidUntil: '2028-06-10', status: 'active', relatedCarrierCount: 38,
    remark: 'UN认证，适用于II类危险品液体', createdAt: '2024-05-20',
  },
  {
    id: 'model-14', code: 'WX-DR-1000', name: '危险品专用容器-IBC吨桶', type: '危险品容器',
    length: 120, width: 100, height: 116, maxLoad: 1000, selfWeight: 58,
    material: '金属', manufacturer: '安盾特种容器制造', origin: '山东青岛',
    certNo: 'UN 31A/Y/1000/24/CN/002', certOrg: '中国船级社质量认证公司',
    certValidUntil: '2028-06-10', status: 'active', relatedCarrierCount: 22,
    remark: '中型散装容器，化工原料专用', createdAt: '2024-06-01',
  },
  {
    id: 'model-15', code: 'ZHX-ESD-400', name: '物流周转箱-防静电400', type: '周转箱',
    length: 40, width: 30, height: 25, maxLoad: 12, selfWeight: 1.2,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'SJ/T 11277-2024-001', certOrg: '中国电子技术标准化研究院',
    certValidUntil: '2027-09-15', status: 'active', relatedCarrierCount: 95,
    remark: '防静电周转箱，适用于电子元器件', createdAt: '2024-06-15',
  },
  {
    id: 'model-16', code: 'TP-WD-EPAL', name: '仓储托盘-欧标EPAL', type: '托盘',
    length: 120, width: 80, height: 14.4, maxLoad: 1500, selfWeight: 25,
    material: '木质', manufacturer: 'EPAL授权生产商', origin: '德国',
    certNo: 'EPAL-2024-DE-003', certOrg: '欧洲托盘协会EPAL',
    certValidUntil: '2029-02-28', status: 'active', relatedCarrierCount: 180,
    remark: '欧标EPAL托盘，出口欧洲必备', createdAt: '2024-07-01',
  },
  {
    id: 'model-17', code: 'LJ-MT-ENG2', name: '汽车零部件料架-B型发动机', type: '料架',
    length: 140, width: 110, height: 130, maxLoad: 450, selfWeight: 55,
    material: '金属', manufacturer: '宝钢物流装备', origin: '上海宝山',
    certNo: 'Q/BGWL-2024-004', certOrg: '上海机动车检测认证技术研究中心',
    certValidUntil: '2029-04-18', status: 'inactive', relatedCarrierCount: 0,
    remark: '已停用，升级至A型料架', createdAt: '2024-07-15',
  },
  {
    id: 'model-18', code: 'WX-DR-IBC2', name: '危险品专用容器-IBC塑料', type: '危险品容器',
    length: 120, width: 100, height: 116, maxLoad: 1000, selfWeight: 32,
    material: '塑料', manufacturer: '安盾特种容器制造', origin: '山东青岛',
    certNo: 'UN 31H2/Y/1000/24/CN-003', certOrg: '中国船级社质量认证公司',
    certValidUntil: '2028-06-10', status: 'active', relatedCarrierCount: 15,
    remark: 'HDPE塑料IBC，耐腐蚀', createdAt: '2024-08-01',
  },
  {
    id: 'model-19', code: 'LC-BX-40L', name: '冷链保温箱-40L便携', type: '保温箱',
    length: 45, width: 35, height: 40, maxLoad: 30, selfWeight: 4.5,
    material: '复合材料', manufacturer: '冷链科技（苏州）', origin: '江苏苏州',
    certNo: 'GB/T 34399-2024-503', certOrg: '国家食品安全风险评估中心',
    certValidUntil: '2026-11-30', status: 'active', relatedCarrierCount: 200,
    remark: '便携式冷链箱，最后一公里配送', createdAt: '2024-08-15',
  },
  {
    id: 'model-20', code: 'ZHX-FD-600', name: '物流周转箱-折叠600', type: '周转箱',
    length: 60, width: 40, height: 32, maxLoad: 25, selfWeight: 2.5,
    material: '塑料', manufacturer: '恒力塑料制品有限公司', origin: '浙江宁波',
    certNo: 'GB/T 5737-2024-010', certOrg: '国家包装产品质量监督检验中心',
    certValidUntil: '2027-06-15', status: 'active', relatedCarrierCount: 155,
    remark: '可折叠设计，返程节省70%空间', createdAt: '2024-09-01',
  },
];

const MOCK_CHANGE_LOGS: Record<string, ChangeLog[]> = {
  'model-1': [
    { time: '2024-01-15 10:00', action: '创建', user: '管理员', detail: '新增型号 ZHX-STD-600' },
    { time: '2024-03-20 14:30', action: '认证更新', user: '张三', detail: '更新认证有效期至2027-06-15' },
    { time: '2024-06-10 09:15', action: '参数调整', user: '李四', detail: '额定载重从20kg调整至25kg' },
  ],
  'model-4': [
    { time: '2024-01-10 08:30', action: '创建', user: '管理员', detail: '新增型号 TP-WD-1200' },
    { time: '2024-05-15 11:00', action: '状态变更', user: '王五', detail: '关联载具数量超过500，触发库存预警' },
  ],
  'model-17': [
    { time: '2024-07-15 10:00', action: '创建', user: '管理员', detail: '新增型号 LJ-MT-ENG2' },
    { time: '2024-10-01 09:00', action: '停用', user: '赵六', detail: '型号已停用，建议迁移至A型料架' },
  ],
};

// ============================================================
// Utility Functions
// ============================================================

function getStatusConfig(status: string) {
  return status === 'active'
    ? { color: '#10B981', bg: '#ECFDF5', label: '启用' }
    : { color: '#EF4444', bg: '#FEF2F2', label: '停用' };
}

function getMaterialColor(material: string): string {
  const colors: Record<string, string> = {
    '木质': '#A0522D',
    '塑料': '#2563EB',
    '金属': '#64748B',
    '复合材料': '#8B5CF6',
  };
  return colors[material] || '#475569';
}

function getMaterialBg(material: string): string {
  const bgs: Record<string, string> = {
    '木质': '#FFF7ED',
    '塑料': '#EFF6FF',
    '金属': '#F1F5F9',
    '复合材料': '#F5F3FF',
  };
  return bgs[material] || '#F8FAFC';
}

// ============================================================
// Sub Components
// ============================================================

function StatusTag({ status }: { status: string }) {
  const cfg = getStatusConfig(status);
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: cfg.bg, color: cfg.color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: cfg.color }} />
      {cfg.label}
    </span>
  );
}

function MaterialTag({ material }: { material: string }) {
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: getMaterialBg(material), color: getMaterialColor(material) }}
    >
      {material}
    </span>
  );
}

function KPICard({ label, value, subtext, color, icon: Icon }: { label: string; value: string; subtext?: string; color: string; icon: React.ElementType }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-card flex-1">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
          <Icon size={18} style={{ color }} />
        </div>
        <span className="text-xs text-[#475569]">{label}</span>
      </div>
      <div className="text-[28px] font-semibold text-[#0F172A] leading-tight">{value}</div>
      {subtext && <div className="text-xs text-[#94A3B8] mt-1">{subtext}</div>}
    </div>
  );
}

function PaginationBar({
  page,
  totalPages,
  pageSize,
  onPageChange,
  onPageSizeChange,
  total,
}: {
  page: number;
  totalPages: number;
  pageSize: number;
  onPageChange: (p: number) => void;
  onPageSizeChange: (s: number) => void;
  total: number;
}) {
  const pageSizes = [10, 20, 50];
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
      <div className="flex items-center gap-2 text-sm text-[#475569]">
        <span>每页</span>
        <Select value={String(pageSize)} onValueChange={(v) => onPageSizeChange(Number(v))}>
          <SelectTrigger className="h-8 w-[70px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {pageSizes.map((s) => (
              <SelectItem key={s} value={String(s)}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span>条</span>
        <span className="ml-4">共 {total} 条</span>
      </div>
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(Math.max(1, page - 1))}
          disabled={page <= 1}
        >
          <ChevronLeft size={16} />
        </Button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let pageNum: number;
          if (totalPages <= 5) {
            pageNum = i + 1;
          } else if (page <= 3) {
            pageNum = i + 1;
          } else if (page >= totalPages - 2) {
            pageNum = totalPages - 4 + i;
          } else {
            pageNum = page - 2 + i;
          }
          return (
            <Button
              key={pageNum}
              variant={pageNum === page ? 'default' : 'ghost'}
              size="icon-sm"
              className={cn('w-8 h-8 text-xs', pageNum === page && 'bg-[#2563EB] text-white')}
              onClick={() => onPageChange(pageNum)}
            >
              {pageNum}
            </Button>
          );
        })}
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages}
        >
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
}

function DeleteConfirmDialog({ open, onClose, onConfirm, modelName }: { open: boolean; onClose: () => void; onConfirm: () => void; modelName: string }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>确认删除</DialogTitle>
          <DialogDescription>
            确定要删除型号 <strong className="text-[#0F172A]">{modelName}</strong> 吗？此操作不可撤销。
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button variant="destructive" onClick={onConfirm}>删除</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ModelFormDrawer({ model, open, onClose, onSave }: { model?: CarrierModel; open: boolean; onClose: () => void; onSave: (_m: CarrierModel) => void }) {
  const isEdit = !!model;
  const [form, setForm] = useState<Partial<CarrierModel>>(() => model || {
    code: '', name: '', type: '周转箱', length: 0, width: 0, height: 0,
    maxLoad: 0, selfWeight: 0, material: '塑料', manufacturer: '', origin: '',
    certNo: '', certOrg: '', certValidUntil: '', status: 'active', remark: '',
  });

  const update = useCallback(<K extends keyof CarrierModel>(key: K, value: CarrierModel[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  }, []);

  const handleSave = () => {
    const saved: CarrierModel = {
      ...(form as CarrierModel),
      id: model?.id || `model-${Date.now()}`,
      relatedCarrierCount: model?.relatedCarrierCount || 0,
      createdAt: model?.createdAt || new Date().toISOString().slice(0, 10),
    };
    onSave(saved);
    onClose();
  };

  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[600px] w-3/4">
        <DrawerHeader>
          <DrawerTitle>{isEdit ? '编辑型号' : '新增型号'}</DrawerTitle>
          <DrawerDescription>{isEdit ? `编辑型号 ${model?.code}` : '填写载具型号信息'}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4 space-y-5">
          {/* 基本信息 */}
          <div>
            <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
              <Info size={14} className="text-[#2563EB]" /> 基本信息
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">型号编码 {isEdit ? '' : '*'}</label>
                <Input value={form.code || ''} onChange={(e) => update('code', e.target.value)} disabled={isEdit} placeholder="如 ZHX-STD-600" />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">型号名称 *</label>
                <Input value={form.name || ''} onChange={(e) => update('name', e.target.value)} placeholder="请输入型号名称" />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">载具类型 *</label>
                <Select value={form.type || '周转箱'} onValueChange={(v) => update('type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CARRIER_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">状态</label>
                <div className="flex items-center gap-3 h-9">
                  <Switch checked={form.status === 'active'} onCheckedChange={(v) => update('status', v ? 'active' : 'inactive')} />
                  <span className="text-sm text-[#475569]">{form.status === 'active' ? '启用' : '停用'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 规格参数 */}
          <div>
            <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
              <Ruler size={14} className="text-[#2563EB]" /> 规格参数
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">长度 (cm)</label>
                <Input type="number" value={form.length || 0} onChange={(e) => update('length', Number(e.target.value))} />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">宽度 (cm)</label>
                <Input type="number" value={form.width || 0} onChange={(e) => update('width', Number(e.target.value))} />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">高度 (cm)</label>
                <Input type="number" value={form.height || 0} onChange={(e) => update('height', Number(e.target.value))} />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">额定载重 (kg)</label>
                <Input type="number" value={form.maxLoad || 0} onChange={(e) => update('maxLoad', Number(e.target.value))} />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">自重 (kg)</label>
                <Input type="number" value={form.selfWeight || 0} onChange={(e) => update('selfWeight', Number(e.target.value))} />
              </div>
            </div>
          </div>

          {/* 材质信息 */}
          <div>
            <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
              <Factory size={14} className="text-[#2563EB]" /> 材质信息
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">材质类型</label>
                <Select value={form.material || '塑料'} onValueChange={(v) => update('material', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {MATERIALS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">产地</label>
                <Input value={form.origin || ''} onChange={(e) => update('origin', e.target.value)} placeholder="如 浙江宁波" />
              </div>
              <div className="space-y-2 col-span-2">
                <label className="text-sm text-[#475569]">制造商</label>
                <Input value={form.manufacturer || ''} onChange={(e) => update('manufacturer', e.target.value)} placeholder="请输入制造商名称" />
              </div>
            </div>
          </div>

          {/* 认证信息 */}
          <div>
            <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
              <ShieldCheck size={14} className="text-[#2563EB]" /> 认证信息
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">认证编号</label>
                <Input value={form.certNo || ''} onChange={(e) => update('certNo', e.target.value)} placeholder="请输入认证编号" />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-[#475569]">认证机构</label>
                <Input value={form.certOrg || ''} onChange={(e) => update('certOrg', e.target.value)} placeholder="请输入认证机构" />
              </div>
              <div className="space-y-2 col-span-2">
                <label className="text-sm text-[#475569]">认证有效期至</label>
                <Input type="date" value={form.certValidUntil || ''} onChange={(e) => update('certValidUntil', e.target.value)} />
              </div>
            </div>
          </div>

          {/* 备注 */}
          <div>
            <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
              <FileText size={14} className="text-[#2563EB]" /> 备注说明
            </h4>
            <Textarea
              value={form.remark || ''}
              onChange={(e) => update('remark', e.target.value)}
              placeholder="请输入备注说明..."
              className="min-h-[80px]"
            />
          </div>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={handleSave}>{isEdit ? '保存' : '创建'}</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

function ModelDetailDrawer({ model, open, onClose, onEdit, carriers }: {
  model?: CarrierModel;
  open: boolean;
  onClose: () => void;
  onEdit: () => void;
  carriers: { code: string; name: string; status: string; siteName: string }[];
}) {
  if (!model) return null;
  const logs = MOCK_CHANGE_LOGS[model.id] || [
    { time: model.createdAt + ' 08:00', action: '创建', user: '管理员', detail: `新增型号 ${model.code}` },
  ];

  const statusCfg = getStatusConfig(model.status);

  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[600px] w-3/4">
        <DrawerHeader>
          <div className="flex items-center justify-between">
            <DrawerTitle className="text-xl font-semibold font-mono">{model.code}</DrawerTitle>
            <StatusTag status={model.status} />
          </div>
          <DrawerDescription>{model.name}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4">
          <Tabs defaultValue="basic">
            <TabsList className="w-full">
              <TabsTrigger value="basic" className="flex-1">基本信息</TabsTrigger>
              <TabsTrigger value="carriers" className="flex-1">关联载具</TabsTrigger>
              <TabsTrigger value="logs" className="flex-1">变更记录</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="mt-4 space-y-5">
              {/* 基本信息 */}
              <div className="bg-[#F8FAFC] rounded-lg p-4">
                <h4 className="text-sm font-semibold text-[#0F172A] mb-3">基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    ['型号编码', model.code],
                    ['型号名称', model.name],
                    ['载具类型', model.type],
                    ['状态', statusCfg.label],
                    ['材质', model.material],
                    ['制造商', model.manufacturer],
                    ['产地', model.origin],
                    ['关联载具数量', String(model.relatedCarrierCount)],
                    ['创建时间', model.createdAt],
                  ].map(([label, value]) => (
                    <div key={label}>
                      <div className="text-xs text-[#94A3B8] mb-1">{label}</div>
                      <div className="text-sm text-[#0F172A]">{value}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 规格参数 */}
              <div className="bg-[#F8FAFC] rounded-lg p-4">
                <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
                  <Ruler size={14} className="text-[#2563EB]" /> 规格参数
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-[#94A3B8] mb-1">规格尺寸</div>
                    <div className="text-sm text-[#0F172A]">{model.length} × {model.width} × {model.height} cm</div>
                  </div>
                  <div>
                    <div className="text-xs text-[#94A3B8] mb-1">体积</div>
                    <div className="text-sm text-[#0F172A]">{(model.length * model.width * model.height / 1000000).toFixed(3)} m³</div>
                  </div>
                  <div>
                    <div className="text-xs text-[#94A3B8] mb-1">额定载重</div>
                    <div className="text-sm text-[#0F172A]">{model.maxLoad} kg</div>
                  </div>
                  <div>
                    <div className="text-xs text-[#94A3B8] mb-1">自重</div>
                    <div className="text-sm text-[#0F172A]">{model.selfWeight} kg</div>
                  </div>
                  <div>
                    <div className="text-xs text-[#94A3B8] mb-1">有效载荷比</div>
                    <div className="text-sm text-[#0F172A]">{((model.maxLoad / model.selfWeight)).toFixed(1)} : 1</div>
                  </div>
                </div>
              </div>

              {/* 认证信息 */}
              <div className="bg-[#F8FAFC] rounded-lg p-4">
                <h4 className="text-sm font-semibold text-[#0F172A] mb-3 flex items-center gap-2">
                  <ShieldCheck size={14} className="text-[#2563EB]" /> 认证信息
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    ['认证编号', model.certNo],
                    ['认证机构', model.certOrg],
                    ['认证有效期', model.certValidUntil],
                  ].map(([label, value]) => (
                    <div key={label} className={label === '认证有效期' ? 'col-span-2' : ''}>
                      <div className="text-xs text-[#94A3B8] mb-1">{label}</div>
                      <div className="text-sm text-[#0F172A]">{value || '-'}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 备注 */}
              {model.remark && (
                <div className="bg-[#F8FAFC] rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-[#0F172A] mb-2">备注说明</h4>
                  <p className="text-sm text-[#475569]">{model.remark}</p>
                </div>
              )}

              <div className="flex justify-end">
                <Button onClick={onEdit}><Pencil size={14} className="mr-2" />编辑</Button>
              </div>
            </TabsContent>

            <TabsContent value="carriers" className="mt-4">
              {carriers.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs text-[#94A3B8] mb-2">共 {carriers.length} 条关联载具</div>
                  {carriers.map((c, i) => (
                    <motion.div
                      key={c.code}
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.15, delay: i * 0.03 }}
                      className="bg-[#F8FAFC] rounded-lg p-3 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
                          <Container size={16} className="text-[#2563EB]" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-[#0F172A] font-mono">{c.code}</div>
                          <div className="text-xs text-[#94A3B8]">{c.name} · {c.siteName}</div>
                        </div>
                      </div>
                      <StatusTag status={c.status === 'normal' ? 'active' : 'inactive'} />
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-[#94A3B8]">
                  <Container size={48} className="mx-auto mb-2 text-[#CBD5E1]" />
                  <p>暂无关联载具</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="logs" className="mt-4">
              <div className="space-y-3">
                {logs.map((log, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-[#2563EB]" />
                      {i < logs.length - 1 && <div className="w-px h-full bg-[#E2E8F0]" />}
                    </div>
                    <div className="pb-4">
                      <div className="text-xs text-[#94A3B8]">{log.time}</div>
                      <div className="text-sm font-medium text-[#0F172A]">{log.action} · {log.user}</div>
                      <div className="text-sm text-[#475569]">{log.detail}</div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>关闭</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

// ============================================================
// Main Page
// ============================================================

export default function ModelManagementPage() {
  const { carriers: allCarriers } = useMockData();
  const [models, setModels] = useState<CarrierModel[]>(MOCK_MODELS);

  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [materialFilter, setMaterialFilter] = useState<string>('all');
  const [manufacturerFilter, setManufacturerFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDir, setSortDir] = useState<SortDirection>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [showAdvancedFilter, setShowAdvancedFilter] = useState(false);

  // Drawer/Dialog states
  const [detailModel, setDetailModel] = useState<CarrierModel | undefined>();
  const [showDetail, setShowDetail] = useState(false);
  const [editModel, setEditModel] = useState<CarrierModel | undefined>();
  const [showForm, setShowForm] = useState(false);
  const [deleteModel, setDeleteModel] = useState<CarrierModel | undefined>();
  const [showDelete, setShowDelete] = useState(false);

  // Filter & Sort
  const filtered = useMemo(() => {
    let data = [...models];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      data = data.filter((m) =>
        m.code.toLowerCase().includes(q) ||
        m.name.toLowerCase().includes(q)
      );
    }

    if (typeFilter !== 'all') {
      data = data.filter((m) => m.type === typeFilter);
    }

    if (materialFilter !== 'all') {
      data = data.filter((m) => m.material === materialFilter);
    }

    if (manufacturerFilter !== 'all') {
      data = data.filter((m) => m.manufacturer === manufacturerFilter);
    }

    if (statusFilter !== 'all') {
      data = data.filter((m) => m.status === statusFilter);
    }

    data.sort((a, b) => {
      const dir = sortDir === 'asc' ? 1 : -1;
      if (sortField === 'code') return dir * a.code.localeCompare(b.code);
      if (sortField === 'name') return dir * a.name.localeCompare(b.name);
      if (sortField === 'type') return dir * a.type.localeCompare(b.type);
      if (sortField === 'material') return dir * a.material.localeCompare(b.material);
      if (sortField === 'manufacturer') return dir * a.manufacturer.localeCompare(b.manufacturer);
      if (sortField === 'status') return dir * a.status.localeCompare(b.status);
      if (sortField === 'relatedCarrierCount') return dir * (a.relatedCarrierCount - b.relatedCarrierCount);
      return dir * a.createdAt.localeCompare(b.createdAt);
    });

    return data;
  }, [models, searchQuery, typeFilter, materialFilter, manufacturerFilter, statusFilter, sortField, sortDir]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Sort
  const handleSort = useCallback((field: SortField) => {
    setSortField((prev) => {
      if (prev === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return prev;
      }
      setSortDir('asc');
      return field;
    });
  }, []);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronDown size={12} className="text-[#CBD5E1]" />;
    return sortDir === 'asc'
      ? <ChevronDown size={12} className="text-[#2563EB] rotate-180" />
      : <ChevronDown size={12} className="text-[#2563EB]" />;
  };

  // KPI data
  const totalModels = models.length;
  const activeModels = models.filter((m) => m.status === 'active').length;
  const inactiveModels = models.filter((m) => m.status === 'inactive').length;
  const totalRelatedCarriers = models.reduce((sum, m) => sum + m.relatedCarrierCount, 0);

  const kpiData = [
    { label: '型号总数', value: String(totalModels), subtext: '全部型号', color: '#2563EB', icon: Package },
    { label: '已启用', value: String(activeModels), subtext: `${((activeModels / totalModels) * 100).toFixed(1)}%`, color: '#10B981', icon: ShieldCheck },
    { label: '已停用', value: String(inactiveModels), subtext: '需关注', color: '#EF4444', icon: X },
    { label: '关联载具', value: String(totalRelatedCarriers), subtext: '全部关联', color: '#8B5CF6', icon: Container },
  ];

  // Manufacturer options
  const manufacturerOptions = useMemo(() => {
    const set = new Set(models.map((m) => m.manufacturer));
    return Array.from(set);
  }, [models]);

  // Get related carriers for detail view
  const getRelatedCarriers = (model: CarrierModel) => {
    return allCarriers
      .filter((c) => c.type === model.type)
      .slice(0, Math.min(model.relatedCarrierCount, 10))
      .map((c) => ({
        code: c.code,
        name: c.name,
        status: c.status,
        siteName: c.siteName,
      }));
  };

  // Handlers
  const handleSaveModel = (saved: CarrierModel) => {
    setModels((prev) => {
      const exists = prev.find((m) => m.id === saved.id);
      if (exists) {
        return prev.map((m) => (m.id === saved.id ? saved : m));
      }
      return [saved, ...prev];
    });
  };

  const handleDelete = () => {
    if (deleteModel) {
      setModels((prev) => prev.filter((m) => m.id !== deleteModel.id));
      setShowDelete(false);
      setDeleteModel(undefined);
    }
  };

  const confirmDelete = (model: CarrierModel) => {
    setDeleteModel(model);
    setShowDelete(true);
  };

  const typeOptions = [
    { value: 'all', label: '全部类型' },
    ...CARRIER_TYPES.map((t) => ({ value: t, label: t })),
  ];

  const materialOptions = [
    { value: 'all', label: '全部材质' },
    ...MATERIALS.map((m) => ({ value: m, label: m })),
  ];

  const statusOptions = [
    { value: 'all', label: '全部状态' },
    { value: 'active', label: '启用' },
    { value: 'inactive', label: '停用' },
  ];

  return (
    <div className="space-y-4 animate-fade-in-up">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">载具型号管理</h1>
          <Badge variant="secondary" className="text-xs">共 {filtered.length} 条</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => { setEditModel(undefined); setShowForm(true); }}>
            <Plus size={16} className="mr-1" />新增型号
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="flex gap-4">
        {kpiData.map((kpi) => (
          <KPICard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg p-4 shadow-card space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          {/* Type filter */}
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="h-8 w-[140px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {typeOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Material filter */}
          <Select value={materialFilter} onValueChange={setMaterialFilter}>
            <SelectTrigger className="h-8 w-[140px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {materialOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Manufacturer filter */}
          <Select value={manufacturerFilter} onValueChange={setManufacturerFilter}>
            <SelectTrigger className="h-8 w-[180px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部制造商</SelectItem>
              {manufacturerOptions.map((m) => (
                <SelectItem key={m} value={m}>{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Status filter */}
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-[120px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex-1" />

          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              placeholder="搜索型号编码、名称..."
              className="h-8 w-[240px] pl-8 text-xs"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-xs"
            onClick={() => setShowAdvancedFilter(!showAdvancedFilter)}
          >
            <Filter size={14} className="mr-1" />
            高级筛选
            <ChevronDown size={12} className={cn('ml-1 transition-transform', showAdvancedFilter && 'rotate-180')} />
          </Button>
        </div>

        {/* Advanced filters */}
        {showAdvancedFilter && (
          <div className="pt-3 border-t border-[#E2E8F0] grid grid-cols-4 gap-3">
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">型号编码</label>
              <Input placeholder="模糊搜索" className="h-8 text-xs" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">载具类型</label>
              <Select>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部类型" /></SelectTrigger>
                <SelectContent>
                  {CARRIER_TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">材质</label>
              <Select>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部材质" /></SelectTrigger>
                <SelectContent>
                  {MATERIALS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">制造商</label>
              <Input placeholder="制造商名称" className="h-8 text-xs" />
            </div>
            <div className="col-span-4 flex justify-end gap-2">
              <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => {
                setTypeFilter('all');
                setMaterialFilter('all');
                setManufacturerFilter('all');
                setStatusFilter('all');
                setSearchQuery('');
              }}>重置</Button>
              <Button size="sm" className="h-8 text-xs">筛选</Button>
            </div>
          </div>
        )}
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="cursor-pointer" onClick={() => handleSort('code')}>
                  <div className="flex items-center gap-1">型号编码 <SortIcon field="code" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('name')}>
                  <div className="flex items-center gap-1">型号名称 <SortIcon field="name" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('type')}>
                  <div className="flex items-center gap-1">载具类型 <SortIcon field="type" /></div>
                </TableHead>
                <TableHead>规格尺寸 (cm)</TableHead>
                <TableHead>额定载重 (kg)</TableHead>
                <TableHead>自重 (kg)</TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('material')}>
                  <div className="flex items-center gap-1">材质 <SortIcon field="material" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('manufacturer')}>
                  <div className="flex items-center gap-1">制造商 <SortIcon field="manufacturer" /></div>
                </TableHead>
                <TableHead>认证信息</TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                  <div className="flex items-center gap-1">状态 <SortIcon field="status" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('relatedCarrierCount')}>
                  <div className="flex items-center gap-1">关联载具 <SortIcon field="relatedCarrierCount" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('createdAt')}>
                  <div className="flex items-center gap-1">创建时间 <SortIcon field="createdAt" /></div>
                </TableHead>
                <TableHead className="w-[120px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={13} className="text-center py-16 text-[#94A3B8]">
                    <div className="flex flex-col items-center gap-2">
                      <Search size={48} className="text-[#CBD5E1]" />
                      <p className="text-sm">未找到匹配的型号</p>
                      <Button variant="outline" size="sm" onClick={() => {
                        setSearchQuery('');
                        setTypeFilter('all');
                        setMaterialFilter('all');
                        setManufacturerFilter('all');
                        setStatusFilter('all');
                      }}>清除筛选</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                pageData.map((model, idx) => (
                  <motion.tr
                    key={model.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className={cn(
                      'h-12 border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors',
                      idx % 2 === 1 && 'bg-[#F8FAFC]'
                    )}
                  >
                    <TableCell>
                      <button
                        className="font-mono text-[13px] text-[#2563EB] hover:underline"
                        onClick={() => { setDetailModel(model); setShowDetail(true); }}
                      >
                        {model.code}
                      </button>
                    </TableCell>
                    <TableCell className="text-sm text-[#0F172A]">{model.name}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#F1F5F9] text-[#475569]">
                        {model.type}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-[#475569] font-mono">
                      {model.length}×{model.width}×{model.height}
                    </TableCell>
                    <TableCell className="text-sm text-[#475569]">{model.maxLoad}</TableCell>
                    <TableCell className="text-sm text-[#475569]">{model.selfWeight}</TableCell>
                    <TableCell>
                      <MaterialTag material={model.material} />
                    </TableCell>
                    <TableCell className="text-sm text-[#475569] max-w-[140px] truncate" title={model.manufacturer}>
                      {model.manufacturer}
                    </TableCell>
                    <TableCell>
                      {model.certNo ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-[#ECFDF5] text-[#10B981]">
                          <ShieldCheck size={10} />
                          {model.certNo.slice(0, 12)}...
                        </span>
                      ) : (
                        <span className="text-xs text-[#94A3B8]">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <StatusTag status={model.status} />
                    </TableCell>
                    <TableCell>
                      <span className={cn(
                        'text-sm font-medium',
                        model.relatedCarrierCount > 0 ? 'text-[#2563EB]' : 'text-[#94A3B8]'
                      )}>
                        {model.relatedCarrierCount}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs text-[#94A3B8] font-mono">{model.createdAt}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setDetailModel(model); setShowDetail(true); }}>
                          <Eye size={14} className="text-[#475569]" />
                        </Button>
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setEditModel(model); setShowForm(true); }}>
                          <Pencil size={14} className="text-[#475569]" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" className="h-7 w-7">
                              <MoreHorizontal size={14} className="text-[#475569]" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => { setEditModel(model); setShowForm(true); }}>
                              <Pencil size={14} className="mr-2" />编辑
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-[#EF4444]" onClick={() => confirmDelete(model)}>
                              <Trash2 size={14} className="mr-2" />删除
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </motion.tr>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <PaginationBar
          page={currentPage}
          totalPages={totalPages}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={(s) => { setPageSize(s); setPage(1); }}
          total={filtered.length}
        />
      </div>

      {/* Form Drawer */}
      <ModelFormDrawer
        model={editModel}
        open={showForm}
        onClose={() => setShowForm(false)}
        onSave={handleSaveModel}
      />

      {/* Detail Drawer */}
      <ModelDetailDrawer
        model={detailModel}
        open={showDetail}
        onClose={() => setShowDetail(false)}
        onEdit={() => { setShowDetail(false); setEditModel(detailModel); setShowForm(true); }}
        carriers={detailModel ? getRelatedCarriers(detailModel) : []}
      />

      {/* Delete Confirm */}
      <DeleteConfirmDialog
        open={showDelete}
        onClose={() => { setShowDelete(false); setDeleteModel(undefined); }}
        onConfirm={handleDelete}
        modelName={deleteModel?.name || ''}
      />
    </div>
  );
}
