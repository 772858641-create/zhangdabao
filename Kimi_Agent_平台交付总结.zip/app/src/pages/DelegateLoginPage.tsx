import { useState, useMemo } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import {
  KeyRound,
  UserCheck,
  Shield,
  Clock,
  Search,
  Plus,
  Eye,
  Trash2,
  Settings,
  CheckCircle,
  XCircle,
  Ban,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Filter,
  RotateCcw,
  Calendar,
  TrendingUp,
  Minus,
  Users,
  FileText,
  BarChart3,
} from 'lucide-react';

/* ═══════════════════════════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════════════════════════ */

/** 委托记录 */
interface DelegateRecord {
  id: string;
  fromUser: string;
  fromUserName: string;
  toUser: string;
  toUserName: string;
  scope: string[];
  scopeMode: Record<string, 'readonly' | 'editable'>;
  startTime: string;
  endTime: string;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  createdAt: string;
  revokedAt?: string;
  revokeReason?: string;
}

/** 审计记录 */
interface AuditRecord {
  id: string;
  time: string;
  operator: string;
  module: string;
  type: string;
  target: string;
  delegateId: string;
}

/** 规则设置 */
interface RuleSettings {
  maxDurationDays: number;
  maxSameDelegatee: number;
  expireReminder: boolean;
  reminderDays: number;
}

/** 排序配置 */
interface SortConfig {
  key: string;
  direction: 'asc' | 'desc';
}

/* ═══════════════════════════════════════════════════════════════
   Mock 数据 — 15 条委托记录
   ═══════════════════════════════════════════════════════════════ */

const DELEGATE_MOCK: DelegateRecord[] = [
  {
    id: 'DL-20250601-001',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'zhangming',
    toUserName: '张明',
    scope: ['载具管理', '调拨管理', '报警中心'],
    scopeMode: {
      '载具管理': 'editable',
      '调拨管理': 'editable',
      '报警中心': 'readonly',
    },
    startTime: '2025-06-01T08:00:00',
    endTime: '2025-06-08T08:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-01T08:00:00',
  },
  {
    id: 'DL-20250602-002',
    fromUser: 'liwei',
    fromUserName: '李威',
    toUser: 'wangqiang',
    toUserName: '王强',
    scope: ['网点管理', '设备管理'],
    scopeMode: {
      '网点管理': 'editable',
      '设备管理': 'readonly',
    },
    startTime: '2025-06-02T09:00:00',
    endTime: '2025-06-05T09:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-02T09:00:00',
  },
  {
    id: 'DL-20250603-003',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'zhaoli',
    toUserName: '赵丽',
    scope: ['数据统计', '载具管理'],
    scopeMode: {
      '数据统计': 'readonly',
      '载具管理': 'readonly',
    },
    startTime: '2025-06-03T10:00:00',
    endTime: '2025-06-06T10:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-03T10:00:00',
  },
  {
    id: 'DL-20250528-004',
    fromUser: 'chenhao',
    fromUserName: '陈浩',
    toUser: 'liuyang',
    toUserName: '刘洋',
    scope: ['报警中心', '调拨管理'],
    scopeMode: {
      '报警中心': 'editable',
      '调拨管理': 'editable',
    },
    startTime: '2025-05-28T14:00:00',
    endTime: '2025-05-29T14:00:00',
    status: 'EXPIRED',
    createdAt: '2025-05-28T14:00:00',
  },
  {
    id: 'DL-20250525-005',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'sunlei',
    toUserName: '孙磊',
    scope: ['全部权限'],
    scopeMode: { '全部权限': 'editable' },
    startTime: '2025-05-25T08:00:00',
    endTime: '2025-05-26T08:00:00',
    status: 'EXPIRED',
    createdAt: '2025-05-25T08:00:00',
  },
  {
    id: 'DL-20250520-006',
    fromUser: 'zhoujun',
    fromUserName: '周军',
    toUser: 'wumin',
    toUserName: '吴敏',
    scope: ['设备管理', '数据统计'],
    scopeMode: {
      '设备管理': 'readonly',
      '数据统计': 'readonly',
    },
    startTime: '2025-05-20T09:00:00',
    endTime: '2025-05-22T09:00:00',
    status: 'REVOKED',
    createdAt: '2025-05-20T09:00:00',
    revokedAt: '2025-05-21T10:00:00',
    revokeReason: '提前完成工作',
  },
  {
    id: 'DL-20250518-007',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'zhengyu',
    toUserName: '郑宇',
    scope: ['载具管理', '网点管理'],
    scopeMode: {
      '载具管理': 'editable',
      '网点管理': 'editable',
    },
    startTime: '2025-05-18T08:00:00',
    endTime: '2025-05-20T08:00:00',
    status: 'EXPIRED',
    createdAt: '2025-05-18T08:00:00',
  },
  {
    id: 'DL-20250604-008',
    fromUser: 'liwei',
    fromUserName: '李威',
    toUser: 'huangxia',
    toUserName: '黄霞',
    scope: ['调拨管理', '报警中心'],
    scopeMode: {
      '调拨管理': 'editable',
      '报警中心': 'readonly',
    },
    startTime: '2025-06-04T10:00:00',
    endTime: '2025-06-11T10:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-04T10:00:00',
  },
  {
    id: 'DL-20250605-009',
    fromUser: 'chenhao',
    fromUserName: '陈浩',
    toUser: 'xulin',
    toUserName: '徐林',
    scope: ['设备管理'],
    scopeMode: { '设备管理': 'editable' },
    startTime: '2025-06-05T13:00:00',
    endTime: '2025-06-07T13:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-05T13:00:00',
  },
  {
    id: 'DL-20250515-010',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'zhujie',
    toUserName: '朱杰',
    scope: ['载具管理', '调拨管理', '报警中心', '网点管理'],
    scopeMode: {
      '载具管理': 'editable',
      '调拨管理': 'editable',
      '报警中心': 'readonly',
      '网点管理': 'readonly',
    },
    startTime: '2025-05-15T08:00:00',
    endTime: '2025-05-17T08:00:00',
    status: 'EXPIRED',
    createdAt: '2025-05-15T08:00:00',
  },
  {
    id: 'DL-20250512-011',
    fromUser: 'zhoujun',
    fromUserName: '周军',
    toUser: 'hexin',
    toUserName: '何欣',
    scope: ['数据统计'],
    scopeMode: { '数据统计': 'readonly' },
    startTime: '2025-05-12T09:00:00',
    endTime: '2025-05-13T09:00:00',
    status: 'REVOKED',
    createdAt: '2025-05-12T09:00:00',
    revokedAt: '2025-05-12T16:00:00',
    revokeReason: '误操作授权',
  },
  {
    id: 'DL-20250606-012',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'sunlei',
    toUserName: '孙磊',
    scope: ['报警中心', '设备管理', '数据统计'],
    scopeMode: {
      '报警中心': 'editable',
      '设备管理': 'readonly',
      '数据统计': 'readonly',
    },
    startTime: '2025-06-06T08:00:00',
    endTime: '2025-06-09T08:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-06T08:00:00',
  },
  {
    id: 'DL-20250510-013',
    fromUser: 'liwei',
    fromUserName: '李威',
    toUser: 'zhangming',
    toUserName: '张明',
    scope: ['载具管理', '数据统计'],
    scopeMode: {
      '载具管理': 'readonly',
      '数据统计': 'readonly',
    },
    startTime: '2025-05-10T10:00:00',
    endTime: '2025-05-11T10:00:00',
    status: 'EXPIRED',
    createdAt: '2025-05-10T10:00:00',
  },
  {
    id: 'DL-20250508-014',
    fromUser: 'chenhao',
    fromUserName: '陈浩',
    toUser: 'wangqiang',
    toUserName: '王强',
    scope: ['网点管理', '调拨管理'],
    scopeMode: {
      '网点管理': 'editable',
      '调拨管理': 'editable',
    },
    startTime: '2025-05-08T14:00:00',
    endTime: '2025-05-09T14:00:00',
    status: 'REVOKED',
    createdAt: '2025-05-08T14:00:00',
    revokedAt: '2025-05-08T18:00:00',
    revokeReason: '权限范围过大',
  },
  {
    id: 'DL-20250607-015',
    fromUser: 'admin',
    fromUserName: '系统管理员',
    toUser: 'liuyang',
    toUserName: '刘洋',
    scope: ['载具管理', '报警中心', '设备管理'],
    scopeMode: {
      '载具管理': 'editable',
      '报警中心': 'editable',
      '设备管理': 'readonly',
    },
    startTime: '2025-06-07T09:00:00',
    endTime: '2025-06-10T09:00:00',
    status: 'ACTIVE',
    createdAt: '2025-06-07T09:00:00',
  },
];

/* ═══════════════════════════════════════════════════════════════
   Mock 数据 — 20 条审计记录
   ═══════════════════════════════════════════════════════════════ */

const AUDIT_MOCK: AuditRecord[] = [
  {
    id: 'AU001',
    time: '2025-06-07T09:15:00',
    operator: '系统管理员',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250607-015',
    delegateId: 'DL-20250607-015',
  },
  {
    id: 'AU002',
    time: '2025-06-07T09:30:00',
    operator: '刘洋',
    module: '载具管理',
    type: '编辑载具',
    target: 'VH-20250607-101',
    delegateId: 'DL-20250607-015',
  },
  {
    id: 'AU003',
    time: '2025-06-07T10:00:00',
    operator: '刘洋',
    module: '报警中心',
    type: '处理报警',
    target: 'AL-20250607-055',
    delegateId: 'DL-20250607-015',
  },
  {
    id: 'AU004',
    time: '2025-06-07T10:45:00',
    operator: '刘洋',
    module: '设备管理',
    type: '查看设备',
    target: 'EQ-20250607-032',
    delegateId: 'DL-20250607-015',
  },
  {
    id: 'AU005',
    time: '2025-06-06T08:20:00',
    operator: '系统管理员',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250606-012',
    delegateId: 'DL-20250606-012',
  },
  {
    id: 'AU006',
    time: '2025-06-06T09:00:00',
    operator: '孙磊',
    module: '报警中心',
    type: '关闭报警',
    target: 'AL-20250606-048',
    delegateId: 'DL-20250606-012',
  },
  {
    id: 'AU007',
    time: '2025-06-06T11:30:00',
    operator: '孙磊',
    module: '设备管理',
    type: '查看设备列表',
    target: 'EQ-LIST',
    delegateId: 'DL-20250606-012',
  },
  {
    id: 'AU008',
    time: '2025-06-05T13:30:00',
    operator: '陈浩',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250605-009',
    delegateId: 'DL-20250605-009',
  },
  {
    id: 'AU009',
    time: '2025-06-05T14:00:00',
    operator: '徐林',
    module: '设备管理',
    type: '创建设备',
    target: 'EQ-20250605-028',
    delegateId: 'DL-20250605-009',
  },
  {
    id: 'AU010',
    time: '2025-06-04T10:30:00',
    operator: '李威',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250604-008',
    delegateId: 'DL-20250604-008',
  },
  {
    id: 'AU011',
    time: '2025-06-04T11:00:00',
    operator: '黄霞',
    module: '调拨管理',
    type: '审批调拨',
    target: 'TR-20250604-015',
    delegateId: 'DL-20250604-008',
  },
  {
    id: 'AU012',
    time: '2025-06-04T14:00:00',
    operator: '黄霞',
    module: '报警中心',
    type: '查看报警',
    target: 'AL-20250604-041',
    delegateId: 'DL-20250604-008',
  },
  {
    id: 'AU013',
    time: '2025-06-03T10:15:00',
    operator: '系统管理员',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250603-003',
    delegateId: 'DL-20250603-003',
  },
  {
    id: 'AU014',
    time: '2025-06-03T11:00:00',
    operator: '赵丽',
    module: '数据统计',
    type: '导出报表',
    target: 'RPT-20250603-007',
    delegateId: 'DL-20250603-003',
  },
  {
    id: 'AU015',
    time: '2025-06-02T09:20:00',
    operator: '李威',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250602-002',
    delegateId: 'DL-20250602-002',
  },
  {
    id: 'AU016',
    time: '2025-06-02T10:00:00',
    operator: '王强',
    module: '网点管理',
    type: '编辑网点',
    target: 'ST-20250602-012',
    delegateId: 'DL-20250602-002',
  },
  {
    id: 'AU017',
    time: '2025-06-01T08:30:00',
    operator: '系统管理员',
    module: '委托授权',
    type: '创建委托',
    target: 'DL-20250601-001',
    delegateId: 'DL-20250601-001',
  },
  {
    id: 'AU018',
    time: '2025-06-01T09:00:00',
    operator: '张明',
    module: '载具管理',
    type: '创建载具',
    target: 'VH-20250601-098',
    delegateId: 'DL-20250601-001',
  },
  {
    id: 'AU019',
    time: '2025-06-01T11:00:00',
    operator: '张明',
    module: '调拨管理',
    type: '提交调拨',
    target: 'TR-20250601-010',
    delegateId: 'DL-20250601-001',
  },
  {
    id: 'AU020',
    time: '2025-06-01T14:00:00',
    operator: '张明',
    module: '报警中心',
    type: '查看报警',
    target: 'AL-20250601-035',
    delegateId: 'DL-20250601-001',
  },
];

/* ═══════════════════════════════════════════════════════════════
   常量定义
   ═══════════════════════════════════════════════════════════════ */

const PERMISSION_OPTIONS = [
  '载具管理',
  '调拨管理',
  '报警中心',
  '网点管理',
  '设备管理',
  '数据统计',
];

const STATUS_MAP: Record<
  string,
  { label: string; color: string; icon: typeof CheckCircle }
> = {
  ACTIVE: {
    label: '生效中',
    color: 'bg-emerald-500 text-white',
    icon: CheckCircle,
  },
  EXPIRED: {
    label: '已过期',
    color: 'bg-gray-500 text-white',
    icon: Clock,
  },
  REVOKED: {
    label: '已撤销',
    color: 'bg-red-500 text-white',
    icon: XCircle,
  },
};

const PIE_COLORS = [
  'var(--color-primary)',
  'var(--color-success)',
  'var(--color-warning)',
  'var(--color-info)',
  'var(--color-danger)',
  '#8b5cf6',
];

const PERMISSION_DETAIL_ROWS = [
  {
    name: '载具管理',
    desc: '车辆信息查看、创建、编辑、删除',
    read: '查看载具列表、详情',
    edit: '创建、编辑、删除载具',
  },
  {
    name: '调拨管理',
    desc: '车辆调拨申请、审批、执行',
    read: '查看调拨记录',
    edit: '提交调拨、审批调拨',
  },
  {
    name: '报警中心',
    desc: '报警查看、处理、关闭',
    read: '查看报警列表、详情',
    edit: '处理报警、关闭报警',
  },
  {
    name: '网点管理',
    desc: '网点信息维护',
    read: '查看网点列表',
    edit: '创建、编辑网点',
  },
  {
    name: '设备管理',
    desc: '设备信息维护',
    read: '查看设备列表',
    edit: '创建、编辑设备',
  },
  {
    name: '数据统计',
    desc: '报表查看与导出',
    read: '查看报表、导出数据',
    edit: '-',
  },
];

/* ═══════════════════════════════════════════════════════════════
   辅助函数
   ═══════════════════════════════════════════════════════════════ */

function formatDateTime(iso: string): string {
  return iso.replace('T', ' ').slice(0, 16);
}

function formatDate(iso: string): string {
  return iso.slice(0, 10);
}

function getDaysRemaining(endTime: string): number {
  const end = new Date(endTime).getTime();
  const now = new Date().getTime();
  return Math.max(0, Math.ceil((end - now) / (1000 * 60 * 60 * 24)));
}

function getProgressPercent(start: string, end: string): number {
  const startMs = new Date(start).getTime();
  const endMs = new Date(end).getTime();
  const nowMs = new Date().getTime();
  if (nowMs >= endMs) return 100;
  if (nowMs <= startMs) return 0;
  return Math.round(((nowMs - startMs) / (endMs - startMs)) * 100);
}

/* ═══════════════════════════════════════════════════════════════
   子组件 — KPI 卡片
   ═══════════════════════════════════════════════════════════════ */

function KpiCard({
  icon: Icon,
  label,
  value,
  iconColor,
  iconBg,
}: {
  icon: typeof KeyRound;
  label: string;
  value: number;
  iconColor: string;
  iconBg: string;
}) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: iconBg }}
        >
          <Icon className="w-5 h-5" style={{ color: iconColor }} />
        </div>
        <div className="min-w-0">
          <div className="text-sm truncate" style={{ color: 'var(--color-textSecondary)' }}>
            {label}
          </div>
          <div className="text-2xl font-bold">{value}</div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ═══════════════════════════════════════════════════════════════
   子组件 — 委托状态分布
   ═══════════════════════════════════════════════════════════════ */

function StatusDistribution({
  label,
  count,
  total,
  color,
}: {
  label: string;
  count: number;
  total: number;
  color: string;
}) {
  const pct = total ? ((count / total) * 100).toFixed(1) : '0.0';
  return (
    <div
      className="flex items-center gap-3 p-4 rounded-lg border"
      style={{ borderColor: 'var(--color-border)' }}
    >
      <div
        className="w-3 h-3 rounded-full flex-shrink-0"
        style={{ backgroundColor: color }}
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">{label}</span>
          <span className="text-lg font-bold">{count}</span>
        </div>
        <div
          className="w-full h-2 rounded-full mt-2"
          style={{ backgroundColor: 'var(--color-border)' }}
        >
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${total ? (count / total) * 100 : 0}%`,
              backgroundColor: color,
            }}
          />
        </div>
        <div className="text-xs mt-1" style={{ color: 'var(--color-textTertiary)' }}>
          占比 {pct}%
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   主组件
   ═══════════════════════════════════════════════════════════════ */

export default function DelegateLoginPage() {
  /* ── 状态 ── */
  const [activeTab, setActiveTab] = useState('delegates');
  const [delegateSubTab, setDelegateSubTab] = useState('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [extendOpen, setExtendOpen] = useState(false);
  const [revokeOpen, setRevokeOpen] = useState(false);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [selectedDelegate, setSelectedDelegate] = useState<DelegateRecord | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [auditModuleFilter, setAuditModuleFilter] = useState('all');
  const [auditSearch, setAuditSearch] = useState('');
  const [auditTypeFilter, setAuditTypeFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState<SortConfig | null>(null);
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  /* 新增委托表单 */
  const [newDelegatee, setNewDelegatee] = useState('');
  const [newScope, setNewScope] = useState<string[]>([]);
  const [newScopeMode, setNewScopeMode] = useState<Record<string, 'readonly' | 'editable'>>({});
  const [newDurationDays, setNewDurationDays] = useState('3');
  const [newStartTime, setNewStartTime] = useState('');
  const [newEndTime, setNewEndTime] = useState('');

  /* 延长授权 */
  const [extendDays, setExtendDays] = useState('3');

  /* 撤销原因 */
  const [revokeReason, setRevokeReason] = useState('');

  /* 规则设置 */
  const [rules, setRules] = useState<RuleSettings>({
    maxDurationDays: 30,
    maxSameDelegatee: 3,
    expireReminder: true,
    reminderDays: 1,
  });

  /* ── 展开行切换 ── */
  const toggleRow = (id: string) => {
    setExpandedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  /* ── 排序处理 ── */
  const handleSort = (key: string) => {
    setSortConfig((prev) => {
      if (prev && prev.key === key) {
        return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
      }
      return { key, direction: 'asc' };
    });
  };

  const SortIcon = ({ column }: { column: string }) => {
    if (!sortConfig || sortConfig.key !== column) {
      return <Minus className="w-3 h-3 inline ml-1 opacity-30" />;
    }
    return sortConfig.direction === 'asc' ? (
      <ChevronUp className="w-3 h-3 inline ml-1" />
    ) : (
      <ChevronDown className="w-3 h-3 inline ml-1" />
    );
  };

  /* ── 过滤委托 ── */
  const filteredDelegates = useMemo(() => {
    let data = [...DELEGATE_MOCK];

    /* 子标签过滤 */
    if (delegateSubTab === 'active') {
      data = data.filter((d) => d.status === 'ACTIVE');
    } else if (delegateSubTab === 'expired') {
      data = data.filter((d) => d.status === 'EXPIRED');
    } else if (delegateSubTab === 'revoked') {
      data = data.filter((d) => d.status === 'REVOKED');
    }

    /* 搜索过滤 */
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      data = data.filter(
        (d) =>
          d.id.toLowerCase().includes(q) ||
          d.fromUserName.toLowerCase().includes(q) ||
          d.toUserName.toLowerCase().includes(q) ||
          d.scope.some((s) => s.toLowerCase().includes(q))
      );
    }

    /* 排序 */
    if (sortConfig) {
      data.sort((a, b) => {
        const aVal = (a as any)[sortConfig.key] || '';
        const bVal = (b as any)[sortConfig.key] || '';
        if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return data;
  }, [delegateSubTab, searchQuery, sortConfig]);

  /* ── 过滤审计 ── */
  const filteredAudits = useMemo(() => {
    let data = [...AUDIT_MOCK];

    if (auditModuleFilter !== 'all') {
      data = data.filter((a) => a.module === auditModuleFilter);
    }

    if (auditTypeFilter !== 'all') {
      data = data.filter((a) => a.type.includes(auditTypeFilter));
    }

    if (auditSearch.trim()) {
      const q = auditSearch.toLowerCase();
      data = data.filter(
        (a) =>
          a.operator.toLowerCase().includes(q) ||
          a.target.toLowerCase().includes(q) ||
          a.type.toLowerCase().includes(q)
      );
    }

    return data;
  }, [auditModuleFilter, auditTypeFilter, auditSearch]);

  /* ── KPI 计算 ── */
  const activeCount = DELEGATE_MOCK.filter((d) => d.status === 'ACTIVE').length;
  const todayOps = AUDIT_MOCK.filter((a) => a.time.startsWith('2025-06-07')).length;
  const monthCount = DELEGATE_MOCK.filter((d) => d.createdAt.startsWith('2025-06')).length;
  const revokedCount = DELEGATE_MOCK.filter((d) => d.status === 'REVOKED').length;

  /* ── 饼图数据（权限分布） ── */
  const pieData = useMemo(() => {
    const counts: Record<string, number> = {};
    DELEGATE_MOCK.forEach((d) => {
      d.scope.forEach((s) => {
        counts[s] = (counts[s] || 0) + 1;
      });
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, []);

  /* ── 近30天折线图数据 ── */
  const trendData = useMemo(() => {
    const days: Record<string, number> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date(2025, 5, 7);
      d.setDate(d.getDate() - i);
      const key = `${d.getMonth() + 1}-${d.getDate()}`;
      days[key] = 0;
    }
    DELEGATE_MOCK.forEach((rec) => {
      const d = new Date(rec.createdAt);
      const key = `${d.getMonth() + 1}-${d.getDate()}`;
      if (days[key] !== undefined) days[key] += 1;
    });
    return Object.entries(days).map(([name, value]) => ({ name, value }));
  }, []);

  /* ── 柱状图数据（按委托人统计） ── */
  const barData = useMemo(() => {
    const counts: Record<string, number> = {};
    DELEGATE_MOCK.forEach((d) => {
      counts[d.fromUserName] = (counts[d.fromUserName] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, []);

  /* ── 操作处理 ── */
  const openDetail = (d: DelegateRecord) => {
    setSelectedDelegate(d);
    setDetailOpen(true);
  };

  const openExtend = (d: DelegateRecord) => {
    setSelectedDelegate(d);
    setExtendDays('3');
    setExtendOpen(true);
  };

  const openRevoke = (d: DelegateRecord) => {
    setSelectedDelegate(d);
    setRevokeReason('');
    setRevokeOpen(true);
  };

  const toggleScope = (perm: string) => {
    setNewScope((prev) => {
      const exists = prev.includes(perm);
      const next = exists ? prev.filter((p) => p !== perm) : [...prev, perm];
      if (!exists) {
        setNewScopeMode((m) => ({ ...m, [perm]: 'readonly' }));
      } else {
        setNewScopeMode((m) => {
          const copy = { ...m };
          delete copy[perm];
          return copy;
        });
      }
      return next;
    });
  };

  const handleCreateSubmit = () => {
    setCreateOpen(false);
    setNewDelegatee('');
    setNewScope([]);
    setNewScopeMode({});
    setNewDurationDays('3');
    setNewStartTime('');
    setNewEndTime('');
  };

  const handleExtendSubmit = () => {
    setExtendOpen(false);
    setSelectedDelegate(null);
  };

  const handleRevokeSubmit = () => {
    setRevokeOpen(false);
    setRevokeReason('');
    setSelectedDelegate(null);
  };

  /* ── 渲染表格头部排序 ── */
  const renderSortableHeader = (label: string, column: string) => (
    <TableHead
      className="cursor-pointer select-none hover:bg-neutral-100 transition-colors"
      onClick={() => handleSort(column)}
    >
      {label}
      <SortIcon column={column} />
    </TableHead>
  );

  /* ═══════════════════════════════════════════════════════════════
     渲染
     ═══════════════════════════════════════════════════════════════ */
  return (
    <div className="space-y-6">
      {/* ── 标题栏 ── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1
            className="text-2xl font-bold"
            style={{ color: 'var(--color-textPrimary)' }}
          >
            委托登录管理
          </h1>
          <p
            className="text-sm mt-1"
            style={{ color: 'var(--color-textSecondary)' }}
          >
            委托授权管理、权限配置、审计追踪与规则设置
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setRulesOpen(true)}
          >
            <Settings className="w-4 h-4 mr-2" />
            规则设置
          </Button>
          <Button size="sm" onClick={() => setCreateOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            新增委托
          </Button>
        </div>
      </div>

      {/* ── KPI 卡片 ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          icon={KeyRound}
          label="生效中委托数"
          value={activeCount}
          iconColor="var(--color-primary)"
          iconBg="var(--color-primary-10)"
        />
        <KpiCard
          icon={UserCheck}
          label="今日委托操作数"
          value={todayOps}
          iconColor="var(--color-success)"
          iconBg="var(--color-success-10)"
        />
        <KpiCard
          icon={Calendar}
          label="本月委托数"
          value={monthCount}
          iconColor="var(--color-info)"
          iconBg="var(--color-info-10)"
        />
        <KpiCard
          icon={Trash2}
          label="已撤销数"
          value={revokedCount}
          iconColor="var(--color-danger)"
          iconBg="var(--color-danger-10)"
        />
      </div>

      {/* ── 主 Tab ── */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="delegates">
            <Shield className="w-4 h-4 mr-1" />
            委托授权管理
          </TabsTrigger>
          <TabsTrigger value="audit">
            <FileText className="w-4 h-4 mr-1" />
            委托审计
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="w-4 h-4 mr-1" />
            数据统计
          </TabsTrigger>
        </TabsList>

        {/* ══════ Tab 1: 委托授权管理 ══════ */}
        <TabsContent value="delegates" className="space-y-4">
          {/* 子 Tab + 搜索 */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <Tabs value={delegateSubTab} onValueChange={setDelegateSubTab}>
              <TabsList>
                <TabsTrigger value="all">全部</TabsTrigger>
                <TabsTrigger value="active">
                  <CheckCircle className="w-3.5 h-3.5 mr-1" />
                  生效中
                </TabsTrigger>
                <TabsTrigger value="expired">
                  <Clock className="w-3.5 h-3.5 mr-1" />
                  已过期
                </TabsTrigger>
                <TabsTrigger value="revoked">
                  <Ban className="w-3.5 h-3.5 mr-1" />
                  已撤销
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <Search
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4"
                  style={{ color: 'var(--color-textTertiary)' }}
                />
                <Input
                  placeholder="搜索编号、人员、权限..."
                  className="pl-9 w-full sm:w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* 统计摘要 */}
          <div
            className="flex flex-wrap items-center gap-4 text-sm px-4 py-2 rounded-md border"
            style={{ borderColor: 'var(--color-border)' }}
          >
            <span style={{ color: 'var(--color-textSecondary)' }}>
              共 <strong>{filteredDelegates.length}</strong> 条记录
            </span>
            <span style={{ color: 'var(--color-border)' }}>|</span>
            <span style={{ color: 'var(--color-textSecondary)' }}>
              生效中: <strong>{filteredDelegates.filter((d) => d.status === 'ACTIVE').length}</strong>
            </span>
            <span style={{ color: 'var(--color-textSecondary)' }}>
              已过期: <strong>{filteredDelegates.filter((d) => d.status === 'EXPIRED').length}</strong>
            </span>
            <span style={{ color: 'var(--color-textSecondary)' }}>
              已撤销: <strong>{filteredDelegates.filter((d) => d.status === 'REVOKED').length}</strong>
            </span>
          </div>

          {/* 委托表格 */}
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[40px]"></TableHead>
                      {renderSortableHeader('委托编号', 'id')}
                      <TableHead>委托人</TableHead>
                      <TableHead>被委托人</TableHead>
                      <TableHead>权限范围</TableHead>
                      {renderSortableHeader('开始时间', 'startTime')}
                      {renderSortableHeader('结束时间', 'endTime')}
                      <TableHead>状态</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDelegates.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={9}
                          className="text-center py-12"
                          style={{ color: 'var(--color-textTertiary)' }}
                        >
                          <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
                          暂无符合条件的委托记录
                        </TableCell>
                      </TableRow>
                    )}
                    {filteredDelegates.map((d) => {
                      const sm = STATUS_MAP[d.status];
                      const StatusIcon = sm.icon;
                      const isExpanded = expandedRows.has(d.id);
                      const progress = getProgressPercent(d.startTime, d.endTime);
                      const daysLeft = getDaysRemaining(d.endTime);
                      return (
                        <>
                          <TableRow
                            key={d.id}
                            className="hover:bg-neutral-50 cursor-pointer"
                            onClick={() => toggleRow(d.id)}
                          >
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 p-0"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleRow(d.id);
                                }}
                              >
                                {isExpanded ? (
                                  <ChevronUp className="w-4 h-4" />
                                ) : (
                                  <ChevronDown className="w-4 h-4" />
                                )}
                              </Button>
                            </TableCell>
                            <TableCell className="font-medium">{d.id}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Shield
                                  className="w-4 h-4 flex-shrink-0"
                                  style={{ color: 'var(--color-textSecondary)' }}
                                />
                                <span>{d.fromUserName}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <UserCheck
                                  className="w-4 h-4 flex-shrink-0"
                                  style={{ color: 'var(--color-textSecondary)' }}
                                />
                                <span>{d.toUserName}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1 max-w-[200px]">
                                {d.scope.slice(0, 3).map((s) => (
                                  <Badge
                                    key={s}
                                    variant="outline"
                                    className="text-xs"
                                    style={{ borderColor: 'var(--color-border)' }}
                                  >
                                    {s}
                                  </Badge>
                                ))}
                                {d.scope.length > 3 && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs"
                                    style={{ borderColor: 'var(--color-border)' }}
                                  >
                                    +{d.scope.length - 3}
                                  </Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-sm whitespace-nowrap">
                              {formatDateTime(d.startTime)}
                            </TableCell>
                            <TableCell className="text-sm whitespace-nowrap">
                              {formatDateTime(d.endTime)}
                            </TableCell>
                            <TableCell>
                              <Badge className={sm.color}>
                                <StatusIcon className="w-3 h-3 mr-1" />
                                {sm.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openDetail(d);
                                  }}
                                >
                                  <Eye className="w-4 h-4 mr-1" />
                                  详情
                                </Button>
                                {d.status === 'ACTIVE' && (
                                  <>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        openExtend(d);
                                      }}
                                    >
                                      <Clock className="w-4 h-4 mr-1" />
                                      延长
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        openRevoke(d);
                                      }}
                                    >
                                      <Ban className="w-4 h-4 mr-1" />
                                      撤销
                                    </Button>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                          {/* 展开详情行 */}
                          {isExpanded && (
                            <TableRow className="bg-neutral-50/50">
                              <TableCell colSpan={9} className="py-3">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm pl-10">
                                  <div>
                                    <div
                                      className="text-xs mb-1"
                                      style={{ color: 'var(--color-textTertiary)' }}
                                    >
                                      权限详情
                                    </div>
                                    <div className="flex flex-wrap gap-1">
                                      {d.scope.map((s) => (
                                        <Badge
                                          key={s}
                                          variant="outline"
                                          className="text-xs"
                                        >
                                          {s}
                                          {d.scopeMode[s] === 'readonly'
                                            ? ' (只读)'
                                            : d.scopeMode[s] === 'editable'
                                            ? ' (可编辑)'
                                            : ''}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                  <div>
                                    <div
                                      className="text-xs mb-1"
                                      style={{ color: 'var(--color-textTertiary)' }}
                                    >
                                      时间进度
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div
                                        className="flex-1 h-2 rounded-full"
                                        style={{ backgroundColor: 'var(--color-border)' }}
                                      >
                                        <div
                                          className="h-full rounded-full transition-all"
                                          style={{
                                            width: `${progress}%`,
                                            backgroundColor:
                                              d.status === 'ACTIVE'
                                                ? 'var(--color-success)'
                                                : d.status === 'EXPIRED'
                                                ? 'var(--color-textSecondary)'
                                                : 'var(--color-danger)',
                                          }}
                                        />
                                      </div>
                                      <span className="text-xs whitespace-nowrap">
                                        {d.status === 'ACTIVE'
                                          ? `${daysLeft}天剩余`
                                          : `${progress}%`}
                                      </span>
                                    </div>
                                  </div>
                                  <div>
                                    <div
                                      className="text-xs mb-1"
                                      style={{ color: 'var(--color-textTertiary)' }}
                                    >
                                      创建信息
                                    </div>
                                    <div style={{ color: 'var(--color-textSecondary)' }}>
                                      创建于 {formatDateTime(d.createdAt)}
                                      {d.revokedAt && (
                                        <span className="block">
                                          撤销于 {formatDateTime(d.revokedAt)}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </TableCell>
                            </TableRow>
                          )}
                        </>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* 权限范围配置说明 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="w-4 h-4" />
                权限范围配置
              </CardTitle>
              <CardDescription>
                配置委托授权时可分配的模块权限及读写级别
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>模块名称</TableHead>
                      <TableHead>权限说明</TableHead>
                      <TableHead>可读权限</TableHead>
                      <TableHead>可编辑权限</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {PERMISSION_DETAIL_ROWS.map((perm) => (
                      <TableRow key={perm.name}>
                        <TableCell className="font-medium">{perm.name}</TableCell>
                        <TableCell
                          className="text-sm"
                          style={{ color: 'var(--color-textSecondary)' }}
                        >
                          {perm.desc}
                        </TableCell>
                        <TableCell className="text-sm">{perm.read}</TableCell>
                        <TableCell className="text-sm">{perm.edit}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ══════ Tab 2: 委托审计 ══════ */}
        <TabsContent value="audit" className="space-y-4">
          {/* 审计筛选栏 */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <Select
                value={auditModuleFilter}
                onValueChange={setAuditModuleFilter}
              >
                <SelectTrigger className="w-36">
                  <Filter className="w-4 h-4 mr-1" />
                  <SelectValue placeholder="模块筛选" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部模块</SelectItem>
                  <SelectItem value="委托授权">委托授权</SelectItem>
                  <SelectItem value="载具管理">载具管理</SelectItem>
                  <SelectItem value="调拨管理">调拨管理</SelectItem>
                  <SelectItem value="报警中心">报警中心</SelectItem>
                  <SelectItem value="网点管理">网点管理</SelectItem>
                  <SelectItem value="设备管理">设备管理</SelectItem>
                  <SelectItem value="数据统计">数据统计</SelectItem>
                </SelectContent>
              </Select>
              <Select value={auditTypeFilter} onValueChange={setAuditTypeFilter}>
                <SelectTrigger className="w-36">
                  <FileText className="w-4 h-4 mr-1" />
                  <SelectValue placeholder="操作类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部类型</SelectItem>
                  <SelectItem value="创建委托">创建委托</SelectItem>
                  <SelectItem value="编辑">编辑</SelectItem>
                  <SelectItem value="查看">查看</SelectItem>
                  <SelectItem value="处理">处理</SelectItem>
                  <SelectItem value="审批">审批</SelectItem>
                  <SelectItem value="导出">导出</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setAuditModuleFilter('all');
                  setAuditTypeFilter('all');
                  setAuditSearch('');
                }}
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                重置
              </Button>
            </div>
            <div className="relative flex-1 sm:flex-none">
              <Search
                className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4"
                style={{ color: 'var(--color-textTertiary)' }}
              />
              <Input
                placeholder="搜索操作人、操作类型、对象..."
                className="pl-9 w-full sm:w-72"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
              />
            </div>
          </div>

          {/* 审计统计摘要 */}
          <div
            className="flex flex-wrap items-center gap-4 text-sm px-4 py-2 rounded-md border"
            style={{ borderColor: 'var(--color-border)' }}
          >
            <span style={{ color: 'var(--color-textSecondary)' }}>
              共 <strong>{filteredAudits.length}</strong> 条记录
            </span>
            <span style={{ color: 'var(--color-border)' }}>|</span>
            <span style={{ color: 'var(--color-textSecondary)' }}>
              涉及 <strong>{new Set(filteredAudits.map((a) => a.delegateId)).size}</strong> 笔委托
            </span>
            <span style={{ color: 'var(--color-border)' }}>|</span>
            <span style={{ color: 'var(--color-textSecondary)' }}>
              <strong>{new Set(filteredAudits.map((a) => a.operator)).size}</strong> 位操作人
            </span>
          </div>

          {/* 审计表格 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">委托期间操作记录</CardTitle>
              <CardDescription>
                记录被委托人在委托期间的所有系统操作
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>时间</TableHead>
                      <TableHead>操作人</TableHead>
                      <TableHead>模块</TableHead>
                      <TableHead>操作类型</TableHead>
                      <TableHead>操作对象</TableHead>
                      <TableHead>关联委托</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAudits.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="text-center py-12"
                          style={{ color: 'var(--color-textTertiary)' }}
                        >
                          <Search className="w-8 h-8 mx-auto mb-2 opacity-40" />
                          暂无符合条件的审计记录
                        </TableCell>
                      </TableRow>
                    )}
                    {filteredAudits.map((a) => (
                      <TableRow key={a.id} className="hover:bg-neutral-50">
                        <TableCell className="text-sm whitespace-nowrap">
                          {formatDateTime(a.time)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Users
                              className="w-4 h-4 flex-shrink-0"
                              style={{ color: 'var(--color-textSecondary)' }}
                            />
                            {a.operator}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {a.module}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">{a.type}</TableCell>
                        <TableCell className="text-sm font-medium">
                          {a.target}
                        </TableCell>
                        <TableCell
                          className="text-xs"
                          style={{ color: 'var(--color-textTertiary)' }}
                        >
                          {a.delegateId}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ══════ Tab 3: 数据统计 ══════ */}
        <TabsContent value="analytics" className="space-y-4">
          {/* 图表区 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 权限使用分布饼图 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  委托权限使用分布
                </CardTitle>
                <CardDescription>
                  各模块权限在委托记录中的使用频率
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={110}
                      paddingAngle={4}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) =>
                        `${name} ${(percent * 100).toFixed(0)}%`
                      }
                    >
                      {pieData.map((_, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={PIE_COLORS[index % PIE_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value: number, name: string) => [
                        `${value} 次`,
                        name,
                      ]}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* 近30天委托趋势折线图 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  近30天委托趋势
                </CardTitle>
                <CardDescription>
                  每日新增委托数量的变化趋势
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <LineChart data={trendData}>
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--color-border)"
                    />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11 }}
                      stroke="var(--color-textTertiary)"
                    />
                    <YAxis
                      allowDecimals={false}
                      tick={{ fontSize: 12 }}
                      stroke="var(--color-textTertiary)"
                    />
                    <Tooltip
                      contentStyle={{
                        border: '1px solid var(--color-border)',
                        borderRadius: '6px',
                        fontSize: '12px',
                      }}
                    />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="value"
                      name="新增委托数"
                      stroke="var(--color-primary)"
                      strokeWidth={2.5}
                      dot={{
                        r: 3,
                        fill: 'var(--color-primary)',
                      }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* 柱状图 + 状态分布 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 按委托人统计 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  按委托人统计
                </CardTitle>
                <CardDescription>
                  各委托人发起的委托数量对比
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={barData} layout="vertical">
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="var(--color-border)"
                    />
                    <XAxis
                      type="number"
                      tick={{ fontSize: 12 }}
                      stroke="var(--color-textTertiary)"
                      allowDecimals={false}
                    />
                    <YAxis
                      dataKey="name"
                      type="category"
                      tick={{ fontSize: 11 }}
                      stroke="var(--color-textTertiary)"
                      width={80}
                    />
                    <Tooltip
                      contentStyle={{
                        border: '1px solid var(--color-border)',
                        borderRadius: '6px',
                        fontSize: '12px',
                      }}
                    />
                    <Legend />
                    <Bar
                      dataKey="value"
                      name="委托数量"
                      fill="var(--color-primary)"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* 委托状态概览 */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  委托状态概览
                </CardTitle>
                <CardDescription>
                  各状态委托的数量与占比
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <StatusDistribution
                  label="生效中"
                  count={activeCount}
                  total={DELEGATE_MOCK.length}
                  color="var(--color-success)"
                />
                <StatusDistribution
                  label="已过期"
                  count={DELEGATE_MOCK.filter((d) => d.status === 'EXPIRED').length}
                  total={DELEGATE_MOCK.length}
                  color="var(--color-textSecondary)"
                />
                <StatusDistribution
                  label="已撤销"
                  count={revokedCount}
                  total={DELEGATE_MOCK.length}
                  color="var(--color-danger)"
                />
              </CardContent>
            </Card>
          </div>

          {/* 数据摘要表格 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                权限使用频率明细
              </CardTitle>
              <CardDescription>
                各模块权限在全部委托中的使用次数统计
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>模块名称</TableHead>
                      <TableHead className="text-right">使用次数</TableHead>
                      <TableHead className="text-right">占比</TableHead>
                      <TableHead>只读次数</TableHead>
                      <TableHead>可编辑次数</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(() => {
                      const totalAssignments = DELEGATE_MOCK.reduce(
                        (sum, d) => sum + d.scope.length,
                        0
                      );
                      return PERMISSION_OPTIONS.map((perm) => {
                        const usedCount = DELEGATE_MOCK.filter((d) =>
                          d.scope.includes(perm)
                        ).length;
                        const readCount = DELEGATE_MOCK.filter(
                          (d) => d.scopeMode[perm] === 'readonly'
                        ).length;
                        const editCount = DELEGATE_MOCK.filter(
                          (d) => d.scopeMode[perm] === 'editable'
                        ).length;
                        return (
                          <TableRow key={perm}>
                            <TableCell className="font-medium">{perm}</TableCell>
                            <TableCell className="text-right">{usedCount}</TableCell>
                            <TableCell className="text-right">
                              <Badge variant="outline" className="text-xs">
                                {totalAssignments
                                  ? ((usedCount / DELEGATE_MOCK.length) * 100).toFixed(1)
                                  : 0}
                                %
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {readCount > 0 ? (
                                <Badge
                                  variant="outline"
                                  className="text-xs"
                                  style={{ color: 'var(--color-info)' }}
                                >
                                  {readCount} 次只读
                                </Badge>
                              ) : (
                                <span
                                  className="text-xs"
                                  style={{ color: 'var(--color-textTertiary)' }}
                                >
                                  -
                                </span>
                              )}
                            </TableCell>
                            <TableCell>
                              {editCount > 0 ? (
                                <Badge
                                  variant="outline"
                                  className="text-xs"
                                  style={{ color: 'var(--color-success)' }}
                                >
                                  {editCount} 次可编辑
                                </Badge>
                              ) : (
                                <span
                                  className="text-xs"
                                  style={{ color: 'var(--color-textTertiary)' }}
                                >
                                  -
                                </span>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      });
                    })()}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ═══════════════════════════════════════════════════════════
         新增委托对话框
         ═══════════════════════════════════════════════════════════ */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              新增委托授权
            </DialogTitle>
            <DialogDescription>
              创建新的委托授权，被委托人将获得指定模块的临时操作权限
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-5 py-4">
            {/* 被委托人 */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-1">
                <UserCheck className="w-4 h-4" />
                被委托人
              </label>
              <Select value={newDelegatee} onValueChange={setNewDelegatee}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择被委托人" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="zhangming">张明 (zhangming)</SelectItem>
                  <SelectItem value="wangqiang">王强 (wangqiang)</SelectItem>
                  <SelectItem value="zhaoli">赵丽 (zhaoli)</SelectItem>
                  <SelectItem value="liuyang">刘洋 (liuyang)</SelectItem>
                  <SelectItem value="sunlei">孙磊 (sunlei)</SelectItem>
                  <SelectItem value="zhengyu">郑宇 (zhengyu)</SelectItem>
                  <SelectItem value="huangxia">黄霞 (huangxia)</SelectItem>
                  <SelectItem value="xulin">徐林 (xulin)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* 有效期 */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  开始时间
                </label>
                <Input
                  type="datetime-local"
                  value={newStartTime}
                  onChange={(e) => setNewStartTime(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  持续天数
                </label>
                <Select
                  value={newDurationDays}
                  onValueChange={setNewDurationDays}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 天</SelectItem>
                    <SelectItem value="3">3 天</SelectItem>
                    <SelectItem value="7">7 天</SelectItem>
                    <SelectItem value="14">14 天</SelectItem>
                    <SelectItem value="30">30 天</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* 权限范围多选 */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-1">
                <Shield className="w-4 h-4" />
                权限范围
              </label>
              <div
                className="border rounded-md p-3 space-y-3"
                style={{ borderColor: 'var(--color-border)' }}
              >
                {PERMISSION_OPTIONS.map((perm) => {
                  const checked = newScope.includes(perm);
                  return (
                    <div key={perm} className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id={`perm-${perm}`}
                          checked={checked}
                          onCheckedChange={() => toggleScope(perm)}
                        />
                        <label
                          htmlFor={`perm-${perm}`}
                          className="text-sm font-medium cursor-pointer"
                        >
                          {perm}
                        </label>
                      </div>
                      {checked && (
                        <div className="pl-6 flex items-center gap-4">
                          <label className="flex items-center gap-1.5 text-sm cursor-pointer">
                            <input
                              type="radio"
                              name={`mode-${perm}`}
                              className="rounded"
                              checked={newScopeMode[perm] === 'readonly'}
                              onChange={() =>
                                setNewScopeMode((m) => ({
                                  ...m,
                                  [perm]: 'readonly',
                                }))
                              }
                            />
                            只读
                          </label>
                          <label className="flex items-center gap-1.5 text-sm cursor-pointer">
                            <input
                              type="radio"
                              name={`mode-${perm}`}
                              className="rounded"
                              checked={newScopeMode[perm] === 'editable'}
                              onChange={() =>
                                setNewScopeMode((m) => ({
                                  ...m,
                                  [perm]: 'editable',
                                }))
                              }
                            />
                            可编辑
                          </label>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 提示 */}
            <div
              className="p-3 rounded-md text-sm flex items-start gap-2"
              style={{ backgroundColor: 'var(--color-warning-10)' }}
            >
              <AlertTriangle
                className="w-4 h-4 flex-shrink-0 mt-0.5"
                style={{ color: 'var(--color-warning)' }}
              />
              <span>
                委托期间，被委托人将以您的身份执行操作。请谨慎选择权限范围，敏感操作将记录完整审计日志。
              </span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              取消
            </Button>
            <Button onClick={handleCreateSubmit}>
              <CheckCircle className="w-4 h-4 mr-2" />
              确认创建
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════
         查看详情对话框
         ═══════════════════════════════════════════════════════════ */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              委托详情
            </DialogTitle>
            <DialogDescription>
              查看委托授权的完整信息与操作历史
            </DialogDescription>
          </DialogHeader>
          {selectedDelegate && (
            <div className="space-y-4 py-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    委托编号
                  </div>
                  <div className="font-medium">{selectedDelegate.id}</div>
                </div>
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    状态
                  </div>
                  <div>
                    <Badge
                      className={STATUS_MAP[selectedDelegate.status].color}
                    >
                      {STATUS_MAP[selectedDelegate.status].label}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    委托人
                  </div>
                  <div className="font-medium">
                    {selectedDelegate.fromUserName}
                  </div>
                </div>
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    被委托人
                  </div>
                  <div className="font-medium">
                    {selectedDelegate.toUserName}
                  </div>
                </div>
              </div>
              <div>
                <div
                  className="text-xs mb-1"
                  style={{ color: 'var(--color-textTertiary)' }}
                >
                  权限范围
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedDelegate.scope.map((s) => (
                    <Badge key={s} variant="outline" className="text-xs">
                      {s}
                      {selectedDelegate.scopeMode[s] === 'readonly'
                        ? ' (只读)'
                        : selectedDelegate.scopeMode[s] === 'editable'
                        ? ' (可编辑)'
                        : ''}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    开始时间
                  </div>
                  <div>{formatDateTime(selectedDelegate.startTime)}</div>
                </div>
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    结束时间
                  </div>
                  <div>{formatDateTime(selectedDelegate.endTime)}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    创建时间
                  </div>
                  <div>{formatDateTime(selectedDelegate.createdAt)}</div>
                </div>
                {selectedDelegate.revokedAt && (
                  <div>
                    <div
                      className="text-xs mb-1"
                      style={{ color: 'var(--color-textTertiary)' }}
                    >
                      撤销时间
                    </div>
                    <div>{formatDateTime(selectedDelegate.revokedAt)}</div>
                  </div>
                )}
              </div>
              {selectedDelegate.revokeReason && (
                <div>
                  <div
                    className="text-xs mb-1"
                    style={{ color: 'var(--color-textTertiary)' }}
                  >
                    撤销原因
                  </div>
                  <div
                    className="p-2 rounded-md text-sm"
                    style={{
                      backgroundColor: 'var(--color-danger-10)',
                      color: 'var(--color-danger)',
                    }}
                  >
                    {selectedDelegate.revokeReason}
                  </div>
                </div>
              )}
              {/* 关联审计记录 */}
              <div>
                <div
                  className="text-xs mb-2 font-medium"
                  style={{ color: 'var(--color-textSecondary)' }}
                >
                  关联操作记录
                </div>
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {AUDIT_MOCK.filter(
                    (a) => a.delegateId === selectedDelegate.id
                  ).map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between text-xs p-2 rounded"
                      style={{ backgroundColor: 'var(--color-background)' }}
                    >
                      <span>
                        {a.type} - {a.target}
                      </span>
                      <span style={{ color: 'var(--color-textTertiary)' }}>
                        {formatDateTime(a.time)}
                      </span>
                    </div>
                  ))}
                  {AUDIT_MOCK.filter(
                    (a) => a.delegateId === selectedDelegate.id
                  ).length === 0 && (
                    <div
                      className="text-xs text-center py-2"
                      style={{ color: 'var(--color-textTertiary)' }}
                    >
                      暂无操作记录
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════
         延长授权对话框
         ═══════════════════════════════════════════════════════════ */}
      <Dialog open={extendOpen} onOpenChange={setExtendOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              延长授权期限
            </DialogTitle>
            <DialogDescription>
              延长当前生效中委托的授权期限
            </DialogDescription>
          </DialogHeader>
          {selectedDelegate && (
            <div className="space-y-4 py-4">
              <div
                className="p-3 rounded-md border"
                style={{ borderColor: 'var(--color-border)' }}
              >
                <div className="text-xs mb-1" style={{ color: 'var(--color-textTertiary)' }}>
                  当前委托
                </div>
                <div className="font-medium">{selectedDelegate.id}</div>
                <div className="text-sm mt-1">
                  {selectedDelegate.fromUserName} → {selectedDelegate.toUserName}
                </div>
                <div
                  className="text-sm mt-1"
                  style={{ color: 'var(--color-textSecondary)' }}
                >
                  原结束时间：{formatDateTime(selectedDelegate.endTime)}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">延长天数</label>
                <Select value={extendDays} onValueChange={setExtendDays}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 天</SelectItem>
                    <SelectItem value="3">3 天</SelectItem>
                    <SelectItem value="7">7 天</SelectItem>
                    <SelectItem value="14">14 天</SelectItem>
                    <SelectItem value="30">30 天</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div
                className="p-3 rounded-md text-sm flex items-start gap-2"
                style={{ backgroundColor: 'var(--color-info-10)' }}
              >
                <Shield
                  className="w-4 h-4 flex-shrink-0 mt-0.5"
                  style={{ color: 'var(--color-info)' }}
                />
                <span>
                  延长后的新结束时间将自动计算并显示在委托记录中。
                </span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setExtendOpen(false)}>
              取消
            </Button>
            <Button onClick={handleExtendSubmit}>
              <CheckCircle className="w-4 h-4 mr-2" />
              确认延长
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════
         撤销委托对话框
         ═══════════════════════════════════════════════════════════ */}
      <Dialog open={revokeOpen} onOpenChange={setRevokeOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <Ban className="w-5 h-5" />
              撤销委托授权
            </DialogTitle>
            <DialogDescription>
              撤销后，被委托人将立即失去所有委托权限
            </DialogDescription>
          </DialogHeader>
          {selectedDelegate && (
            <div className="space-y-4 py-4">
              <div
                className="p-3 rounded-md border"
                style={{
                  borderColor: 'var(--color-danger)',
                  backgroundColor: 'var(--color-danger-10)',
                }}
              >
                <div className="font-medium">{selectedDelegate.id}</div>
                <div className="text-sm mt-1">
                  被委托人：{selectedDelegate.toUserName}
                </div>
                <div
                  className="text-sm mt-1"
                  style={{ color: 'var(--color-textSecondary)' }}
                >
                  权限范围：{selectedDelegate.scope.join('、')}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">撤销原因（选填）</label>
                <Input
                  placeholder="请输入撤销原因"
                  value={revokeReason}
                  onChange={(e) => setRevokeReason(e.target.value)}
                />
              </div>
              <div
                className="p-3 rounded-md text-sm flex items-start gap-2"
                style={{ backgroundColor: 'var(--color-warning-10)' }}
              >
                <AlertTriangle
                  className="w-4 h-4 flex-shrink-0 mt-0.5"
                  style={{ color: 'var(--color-warning)' }}
                />
                <span>
                  撤销后，被委托人将立即失去所有委托权限，已执行的操作不受影响。
                </span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setRevokeOpen(false)}>
              取消
            </Button>
            <Button variant="destructive" onClick={handleRevokeSubmit}>
              <Ban className="w-4 h-4 mr-2" />
              确认撤销
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════════════════════
         规则设置对话框
         ═══════════════════════════════════════════════════════════ */}
      <Dialog open={rulesOpen} onOpenChange={setRulesOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              委托规则设置
            </DialogTitle>
            <DialogDescription>
              配置系统级委托授权规则与限制策略
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            {/* 最大委托时长 */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4" />
                最大委托时长（天）
              </label>
              <div className="flex items-center gap-3">
                <Input
                  type="number"
                  min={1}
                  max={365}
                  value={rules.maxDurationDays}
                  onChange={(e) =>
                    setRules((r) => ({
                      ...r,
                      maxDurationDays: Number(e.target.value),
                    }))
                  }
                  className="w-24"
                />
                <span
                  className="text-sm"
                  style={{ color: 'var(--color-textSecondary)' }}
                >
                  天
                </span>
              </div>
              <p
                className="text-xs"
                style={{ color: 'var(--color-textTertiary)' }}
              >
                单个委托授权的最长有效期，超过此期限需要重新创建委托
              </p>
            </div>

            {/* 同一被委托人上限 */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <UserCheck className="w-4 h-4" />
                同一被委托人上限
              </label>
              <div className="flex items-center gap-3">
                <Input
                  type="number"
                  min={1}
                  max={20}
                  value={rules.maxSameDelegatee}
                  onChange={(e) =>
                    setRules((r) => ({
                      ...r,
                      maxSameDelegatee: Number(e.target.value),
                    }))
                  }
                  className="w-24"
                />
                <span
                  className="text-sm"
                  style={{ color: 'var(--color-textSecondary)' }}
                >
                  人
                </span>
              </div>
              <p
                className="text-xs"
                style={{ color: 'var(--color-textTertiary)' }}
              >
                同一委托人在同一时间内可向同一被委托人发起的最大委托数量
              </p>
            </div>

            {/* 到期提醒 */}
            <div className="space-y-3">
              <label className="text-sm font-medium flex items-center gap-2">
                <KeyRound className="w-4 h-4" />
                到期提醒
              </label>
              <div className="flex items-center gap-3">
                <Switch
                  checked={rules.expireReminder}
                  onCheckedChange={(checked) =>
                    setRules((r) => ({ ...r, expireReminder: checked }))
                  }
                />
                <span className="text-sm">
                  {rules.expireReminder ? '已启用' : '已关闭'}
                </span>
              </div>
              {rules.expireReminder && (
                <div className="flex items-center gap-3 pl-1">
                  <span
                    className="text-sm"
                    style={{ color: 'var(--color-textSecondary)' }}
                  >
                    提前
                  </span>
                  <Select
                    value={String(rules.reminderDays)}
                    onValueChange={(v) =>
                      setRules((r) => ({ ...r, reminderDays: Number(v) }))
                    }
                  >
                    <SelectTrigger className="w-20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="7">7</SelectItem>
                    </SelectContent>
                  </Select>
                  <span
                    className="text-sm"
                    style={{ color: 'var(--color-textSecondary)' }}
                  >
                    天提醒
                  </span>
                </div>
              )}
              <p
                className="text-xs"
                style={{ color: 'var(--color-textTertiary)' }}
              >
                委托即将到期时，系统将向委托人和被委托人发送提醒通知
              </p>
            </div>

            {/* 权限说明 */}
            <div
              className="p-3 rounded-md text-sm"
              style={{
                backgroundColor: 'var(--color-info-10)',
                border: '1px solid var(--color-info-30)',
              }}
            >
              <div className="font-medium mb-1 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                权限继承规则
              </div>
              <ul
                className="list-disc list-inside space-y-1"
                style={{ color: 'var(--color-textSecondary)' }}
              >
                <li>被委托人仅获得委托人明确授权的模块权限</li>
                <li>只读权限允许查看和导出，不允许修改数据</li>
                <li>可编辑权限允许执行所有增删改查操作</li>
                <li>委托到期或撤销后，权限立即失效</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRulesOpen(false)}>
              取消
            </Button>
            <Button onClick={() => setRulesOpen(false)}>
              <CheckCircle className="w-4 h-4 mr-2" />
              保存设置
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

