import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users,
  Building2,
  Shield,
  Search,
  Plus,
  Edit3,
  Lock,
  Trash2,
  ChevronRight,
  ChevronDown,
  MoreHorizontal,
  UserCircle,
  X,
  Network,
  MapPin,
  Container,
  CheckSquare,
  Square,
  MinusSquare,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type OrgType = 'service' | 'user';
type UserStatus = 'active' | 'inactive' | 'locked';
type TabKey = 'organizations' | 'users';

interface OrgNode {
  id: string;
  name: string;
  type: OrgType;
  parentId: string | null;
  children?: OrgNode[];
  userCount?: number;
  siteCount?: number;
  carrierCount?: number;
}

interface UserItem {
  id: string;
  name: string;
  account: string;
  phone: string;
  email: string;
  orgId: string;
  orgName: string;
  role: string;
  status: UserStatus;
  lastLoginAt: string;
  createdAt: string;
}

interface RoleItem {
  id: string;
  name: string;
  description: string;
  userCount: number;
  permissionCount: number;
  createdAt: string;
  builtin: boolean;
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const TAB_OPTIONS: { key: TabKey; label: string; icon: React.ElementType }[] = [
  { key: 'organizations', label: '组织管理', icon: Network },
  { key: 'users', label: '用户管理', icon: Users },
];

const BUILTIN_ROLES: RoleItem[] = [
  { id: 'role-1', name: '系统管理员', description: '平台最高权限，可管理所有模块', userCount: 1, permissionCount: 48, createdAt: '2024-01-01', builtin: true },
  { id: 'role-2', name: '组织管理员', description: '组织级管理，可管理本组织及下级', userCount: 3, permissionCount: 36, createdAt: '2024-01-01', builtin: true },
  { id: 'role-3', name: '项目管理员', description: '项目管理权限，可管理项目内所有资源', userCount: 2, permissionCount: 32, createdAt: '2024-01-01', builtin: true },
  { id: 'role-4', name: '调度员', description: '运输调度权限', userCount: 3, permissionCount: 12, createdAt: '2024-01-01', builtin: true },
  { id: 'role-5', name: '仓库管理员', description: '仓储管理权限', userCount: 4, permissionCount: 16, createdAt: '2024-01-01', builtin: true },
  { id: 'role-6', name: '观察员', description: '只读权限，可查看所有模块', userCount: 2, permissionCount: 11, createdAt: '2024-01-01', builtin: true },
  { id: 'role-7', name: '司机', description: '移动端角色', userCount: 0, permissionCount: 4, createdAt: '2024-01-01', builtin: true },
];

const PERMISSION_MODULES = [
  { key: 'dashboard', label: '数据看板', permissions: ['查看'] },
  { key: 'map', label: '地图看板', permissions: ['查看'] },
  { key: 'carrier', label: '载具管理', permissions: ['查看', '新增', '编辑', '删除', '导出'] },
  { key: 'fleet', label: '车辆管理', permissions: ['查看', '新增', '编辑', '删除', '导出'] },
  { key: 'device', label: '设备管理', permissions: ['查看', '新增', '编辑', '删除', '导出'] },
  { key: 'site', label: '网点管理', permissions: ['查看', '新增', '编辑', '删除', '导出'] },
  { key: 'transfer', label: '调拨管理', permissions: ['查看', '新增', '编辑', '删除', '导出', '审核'] },
  { key: 'route', label: '流转线路', permissions: ['查看', '新增', '编辑', '删除', '导出'] },
  { key: 'alarm', label: '报警中心', permissions: ['查看', '处理', '导出', '配置'] },
  { key: 'user', label: '用户管理', permissions: ['查看', '新增', '编辑', '删除', '权限分配'] },
  { key: 'settings', label: '系统设置', permissions: ['查看', '配置'] },
];

const STATUS_CONFIG: Record<string, { color: string; bg: string; label: string }> = {
  active: { color: '#10B981', bg: '#ECFDF5', label: '启用' },
  inactive: { color: '#94A3B8', bg: '#F1F5F9', label: '停用' },
  locked: { color: '#EF4444', bg: '#FEF2F2', label: '锁定' },
};

// ------------------------------------------------------------------
// Org type colors
// ------------------------------------------------------------------
const ORG_TYPE_CONFIG: Record<OrgType, { color: string; bg: string; label: string }> = {
  service: { color: '#2563EB', bg: '#EFF6FF', label: '服务方' },
  user: { color: '#10B981', bg: '#ECFDF5', label: '使用方' },
};

// ------------------------------------------------------------------
// Mock Users
// ------------------------------------------------------------------
const MOCK_USERS: UserItem[] = [
  { id: 'u-1', name: '系统管理员', account: 'admin', phone: '138****8000', email: 'admin@vehicle-cloud.com', orgId: 'org-1', orgName: '云载科技（总部）', role: '系统管理员', status: 'active', lastLoginAt: '2024-12-20 09:30:00', createdAt: '2024-01-01' },
  { id: 'u-2', name: '张三', account: 'zhangsan', phone: '138****8001', email: 'zhangsan@vehicle-cloud.com', orgId: 'org-1-1-1', orgName: '上海运营中心', role: '组织管理员', status: 'active', lastLoginAt: '2024-12-20 08:45:00', createdAt: '2024-02-15' },
  { id: 'u-3', name: '李四', account: 'lisi', phone: '138****8002', email: 'lisi@vehicle-cloud.com', orgId: 'org-1-1-1', orgName: '上海运营中心', role: '调度员', status: 'active', lastLoginAt: '2024-12-19 17:20:00', createdAt: '2024-03-01' },
  { id: 'u-4', name: '王五', account: 'wangwu', phone: '138****8003', email: 'wangwu@vehicle-cloud.com', orgId: 'org-2-1', orgName: '上海浦东工厂', role: '仓库管理员', status: 'active', lastLoginAt: '2024-12-18 16:00:00', createdAt: '2024-03-10' },
  { id: 'u-5', name: '赵六', account: 'zhaoliu', phone: '138****8004', email: 'zhaoliu@vehicle-cloud.com', orgId: 'org-2', orgName: '华东汽车制造有限公司', role: '组织管理员', status: 'active', lastLoginAt: '2024-12-20 10:00:00', createdAt: '2024-04-01' },
  { id: 'u-6', name: '孙七', account: 'sunqi', phone: '138****8005', email: 'sunqi@vehicle-cloud.com', orgId: 'org-3-1', orgName: '广州仓储中心', role: '仓库管理员', status: 'inactive', lastLoginAt: '2024-11-30 14:00:00', createdAt: '2024-05-01' },
  { id: 'u-7', name: '周八', account: 'zhouba', phone: '138****8006', email: 'zhouba@vehicle-cloud.com', orgId: 'org-4', orgName: '北方供应链管理有限公司', role: '组织管理员', status: 'active', lastLoginAt: '2024-12-19 09:15:00', createdAt: '2024-06-01' },
  { id: 'u-8', name: '吴九', account: 'wujiu', phone: '138****8007', email: 'wujiu@vehicle-cloud.com', orgId: 'org-1-2-1', orgName: '北京运营中心', role: '项目管理员', status: 'active', lastLoginAt: '2024-12-20 07:30:00', createdAt: '2024-06-15' },
  { id: 'u-9', name: '郑十', account: 'zhengshi', phone: '138****8008', email: 'zhengshi@vehicle-cloud.com', orgId: 'org-2-2', orgName: '宁波生产基地', role: '观察员', status: 'locked', lastLoginAt: '2024-10-20 11:00:00', createdAt: '2024-07-01' },
  { id: 'u-10', name: '钱十一', account: 'qian11', phone: '138****8009', email: 'qian11@vehicle-cloud.com', orgId: 'org-3-2', orgName: '深圳配送中心', role: '调度员', status: 'active', lastLoginAt: '2024-12-19 18:30:00', createdAt: '2024-08-01' },
  { id: 'u-11', name: '刘十二', account: 'liu12', phone: '139****0010', email: 'liu12@vehicle-cloud.com', orgId: 'org-2', orgName: '华东汽车制造有限公司', role: '仓库管理员', status: 'active', lastLoginAt: '2024-12-18 09:00:00', createdAt: '2024-08-15' },
  { id: 'u-12', name: '陈十三', account: 'chen13', phone: '139****0011', email: 'chen13@vehicle-cloud.com', orgId: 'org-4-1', orgName: '天津港仓库', role: '观察员', status: 'active', lastLoginAt: '2024-12-17 15:30:00', createdAt: '2024-09-01' },
];

// ------------------------------------------------------------------
// Org Tree Data
// ------------------------------------------------------------------
const ORG_TREE: OrgNode[] = [
  {
    id: 'org-1', name: '云载科技（总部）', type: 'service', parentId: null, userCount: 5, siteCount: 0, carrierCount: 0,
    children: [
      { id: 'org-1-1', name: '华东大区', type: 'service', parentId: 'org-1', userCount: 0, siteCount: 0, carrierCount: 0, children: [
        { id: 'org-1-1-1', name: '上海运营中心', type: 'service', parentId: 'org-1-1', userCount: 2, siteCount: 2, carrierCount: 150 },
        { id: 'org-1-1-2', name: '杭州运营中心', type: 'service', parentId: 'org-1-1', userCount: 1, siteCount: 1, carrierCount: 80 },
      ]},
      { id: 'org-1-2', name: '华北大区', type: 'service', parentId: 'org-1', userCount: 0, siteCount: 0, carrierCount: 0, children: [
        { id: 'org-1-2-1', name: '北京运营中心', type: 'service', parentId: 'org-1-2', userCount: 1, siteCount: 1, carrierCount: 100 },
      ]},
    ],
  },
  {
    id: 'org-2', name: '华东汽车制造有限公司', type: 'user', parentId: null, userCount: 3, siteCount: 2, carrierCount: 520,
    children: [
      { id: 'org-2-1', name: '上海浦东工厂', type: 'user', parentId: 'org-2', userCount: 1, siteCount: 2, carrierCount: 320 },
      { id: 'org-2-2', name: '宁波生产基地', type: 'user', parentId: 'org-2', userCount: 1, siteCount: 1, carrierCount: 200 },
    ],
  },
  {
    id: 'org-3', name: '南方物流集团', type: 'user', parentId: null, userCount: 2, siteCount: 2, carrierCount: 380,
    children: [
      { id: 'org-3-1', name: '广州仓储中心', type: 'user', parentId: 'org-3', userCount: 1, siteCount: 1, carrierCount: 200 },
      { id: 'org-3-2', name: '深圳配送中心', type: 'user', parentId: 'org-3', userCount: 1, siteCount: 1, carrierCount: 180 },
    ],
  },
  {
    id: 'org-4', name: '北方供应链管理有限公司', type: 'user', parentId: null, userCount: 2, siteCount: 2, carrierCount: 290,
    children: [
      { id: 'org-4-1', name: '天津港仓库', type: 'user', parentId: 'org-4', userCount: 1, siteCount: 1, carrierCount: 150 },
      { id: 'org-4-2', name: '青岛物流中心', type: 'user', parentId: 'org-4', userCount: 0, siteCount: 1, carrierCount: 140 },
    ],
  },
];

// ------------------------------------------------------------------
// Sub-components
// ------------------------------------------------------------------

/** Tag */
function Tag({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

/** Org Tree Node */
function OrgTreeNode({ node, depth = 0 }: { node: OrgNode; depth?: number }) {
  const [expanded, setExpanded] = useState(depth < 2);
  const [showDetail, setShowDetail] = useState(false);
  const typeCfg = ORG_TYPE_CONFIG[node.type];
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div>
      <div
        className="flex items-center gap-2 px-3 py-2.5 rounded-lg hover:bg-[#F8FAFC] cursor-pointer transition-colors group"
        style={{ paddingLeft: `${12 + depth * 20}px` }}
        onClick={() => hasChildren ? setExpanded(!expanded) : setShowDetail(!showDetail)}
      >
        {hasChildren ? (
          <button
            onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
            className="w-5 h-5 rounded flex items-center justify-center hover:bg-[#E2E8F0] transition-colors"
          >
            {expanded ? <ChevronDown size={14} className="text-[#475569]" /> : <ChevronRight size={14} className="text-[#475569]" />}
          </button>
        ) : (
          <span className="w-5" />
        )}
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${typeCfg.color}15` }}>
          <Building2 size={16} style={{ color: typeCfg.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-[#0F172A]">{node.name}</span>
            <Tag label={typeCfg.label} color={typeCfg.color} bg={typeCfg.bg} />
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs text-[#94A3B8] flex-shrink-0">
          <span className="flex items-center gap-1"><Users size={12} /> {node.userCount || 0} 用户</span>
          <span className="flex items-center gap-1"><MapPin size={12} /> {node.siteCount || 0} 网点</span>
          <span className="flex items-center gap-1"><Container size={12} /> {node.carrierCount || 0} 载具</span>
        </div>
        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 ml-2">
          <button className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="编辑">
            <Edit3 size={13} className="text-[#475569]" />
          </button>
          <button className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="权限分配">
            <Shield size={13} className="text-[#475569]" />
          </button>
          <button className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="更多">
            <MoreHorizontal size={13} className="text-[#475569]" />
          </button>
        </div>
      </div>
      <AnimatePresence>
        {expanded && hasChildren && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            {node.children!.map((child) => (
              <OrgTreeNode key={child.id} node={child} depth={depth + 1} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** Permission Assignment Modal */
function PermissionModal({ orgName, onClose }: { orgName: string; onClose: () => void }) {
  const [perms, setPerms] = useState<Record<string, Record<string, boolean>>>({});

  const togglePerm = (module: string, perm: string) => {
    setPerms(prev => ({
      ...prev,
      [module]: {
        ...(prev[module] || {}),
        [perm]: !(prev[module]?.[perm]),
      },
    }));
  };

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-[8%] -translate-x-1/2 w-[720px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[85vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">权限分配 - {orgName}</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 overflow-y-auto flex-1">
            <div className="space-y-6">
              {PERMISSION_MODULES.map((mod) => (
                <div key={mod.key}>
                  <h4 className="text-sm font-semibold text-[#0F172A] mb-2">{mod.label}</h4>
                  <div className="flex flex-wrap gap-3">
                    {mod.permissions.map((perm) => {
                      const checked = perms[mod.key]?.[perm] || false;
                      return (
                        <label key={perm} className="flex items-center gap-2 cursor-pointer">
                          <button
                            onClick={() => togglePerm(mod.key, perm)}
                            className="flex items-center justify-center w-4 h-4"
                          >
                            {checked ? (
                              <CheckSquare size={16} className="text-[#2563EB]" />
                            ) : (
                              <Square size={16} className="text-[#CBD5E1]" />
                            )}
                          </button>
                          <span className="text-sm text-[#475569]">{perm}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
            <button onClick={onClose} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存权限</button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

/** User Edit Modal */
function UserEditModal({ user, onClose, onSave }: { user: UserItem | null; onClose: () => void; onSave: (_user: UserItem) => void }) {
  const formVals: Partial<UserItem> = user || {
    name: '', account: '', phone: '', email: '', orgId: '', role: '观察员', status: 'active',
  };

  const handleSave = () => {
    onSave(formVals as UserItem);
    onClose();
  };

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[85vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">{user ? '编辑用户' : '新增用户'}</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 space-y-4 overflow-y-auto">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">用户名 <span className="text-[#EF4444]">*</span></label>
                <input
                  defaultValue={formVals.account}
                  placeholder="请输入用户名"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">姓名 <span className="text-[#EF4444]">*</span></label>
                <input
                  defaultValue={formVals.name}
                  placeholder="请输入姓名"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">手机号 <span className="text-[#EF4444]">*</span></label>
                <input
                  defaultValue={formVals.phone}
                  placeholder="请输入手机号"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">邮箱</label>
                <input
                  defaultValue={formVals.email}
                  placeholder="请输入邮箱"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">初始密码 {!user && <span className="text-[#EF4444]">*</span>}</label>
              <div className="flex gap-2">
                <input
                  type="password"
                  placeholder={user ? '不修改请留空' : '请输入初始密码'}
                  className="flex-1 h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
                {!user && (
                  <button className="h-9 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC]">随机生成</button>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">所属组织 <span className="text-[#EF4444]">*</span></label>
                <select
                  defaultValue={formVals.orgId}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
                >
                  <option value="">请选择组织</option>
                  <option value="org-1">云载科技（总部）</option>
                  <option value="org-1-1-1">上海运营中心</option>
                  <option value="org-1-1-2">杭州运营中心</option>
                  <option value="org-1-2-1">北京运营中心</option>
                  <option value="org-2">华东汽车制造有限公司</option>
                  <option value="org-2-1">上海浦东工厂</option>
                  <option value="org-2-2">宁波生产基地</option>
                  <option value="org-3">南方物流集团</option>
                  <option value="org-3-1">广州仓储中心</option>
                  <option value="org-3-2">深圳配送中心</option>
                  <option value="org-4">北方供应链管理有限公司</option>
                  <option value="org-4-1">天津港仓库</option>
                  <option value="org-4-2">青岛物流中心</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">角色 <span className="text-[#EF4444]">*</span></label>
                <select
                  defaultValue={formVals.role}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
                >
                  {BUILTIN_ROLES.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">状态</label>
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="status" defaultChecked={formVals.status === 'active'} className="w-4 h-4 text-[#2563EB]" />
                  <span className="text-sm text-[#475569]">启用</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="status" defaultChecked={formVals.status === 'inactive'} className="w-4 h-4 text-[#2563EB]" />
                  <span className="text-sm text-[#475569]">停用</span>
                </label>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">备注</label>
              <textarea
                placeholder="请输入备注（可选）"
                className="w-full h-20 px-3 py-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus resize-none"
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
            <button onClick={handleSave} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存</button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

/** Role Permission Matrix Modal */
function RoleMatrixModal({ role, onClose }: { role: RoleItem; onClose: () => void }) {
  const [matrix, setMatrix] = useState<Record<string, Record<string, boolean>>>({});

  const toggleMatrixCell = (module: string, perm: string) => {
    setMatrix(prev => {
      const next = {
        ...prev,
        [module]: { ...(prev[module] || {}), [perm]: !(prev[module]?.[perm]) },
      };
      // Auto-check "查看" when other perms are checked
      if (perm !== '查看' && next[module][perm]) {
        next[module]['查看'] = true;
      }
      return next;
    });
  };

  const toggleModuleAll = (module: string, perms: string[]) => {
    setMatrix(prev => {
      const allChecked = perms.every(p => prev[module]?.[p]);
      const next = { ...prev, [module]: { ...(prev[module] || {}) } };
      perms.forEach(p => { next[module][p] = !allChecked; });
      return next;
    });
  };

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-[5%] -translate-x-1/2 w-[720px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[90vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">配置角色权限 - {role.name}</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 overflow-y-auto flex-1">
            <div className="space-y-4">
              {PERMISSION_MODULES.map((mod) => {
                const allChecked = mod.permissions.every(p => matrix[mod.key]?.[p]);
                const someChecked = mod.permissions.some(p => matrix[mod.key]?.[p]) && !allChecked;
                return (
                  <div key={mod.key} className="border border-[#E2E8F0] rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <button onClick={() => toggleModuleAll(mod.key, mod.permissions)}>
                        {allChecked ? <CheckSquare size={16} className="text-[#2563EB]" /> : someChecked ? <MinusSquare size={16} className="text-[#2563EB]" /> : <Square size={16} className="text-[#CBD5E1]" />}
                      </button>
                      <span className="text-sm font-semibold text-[#0F172A]">{mod.label}</span>
                    </div>
                    <div className="flex flex-wrap gap-4 ml-6">
                      {mod.permissions.map((perm) => {
                        const checked = matrix[mod.key]?.[perm] || false;
                        return (
                          <label key={perm} className="flex items-center gap-2 cursor-pointer">
                            <button onClick={() => toggleMatrixCell(mod.key, perm)}>
                              {checked ? <CheckSquare size={14} className="text-[#2563EB]" /> : <Square size={14} className="text-[#CBD5E1]" />}
                            </button>
                            <span className="text-sm text-[#475569]">{perm}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
            <button onClick={onClose} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存</button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

// ------------------------------------------------------------------
// Organization Tab
// ------------------------------------------------------------------
function OrganizationTab() {
  const [viewMode, setViewMode] = useState<'tree' | 'list'>('tree');
  const [permOrg, setPermOrg] = useState<string | null>(null);
  const [searchOrg, setSearchOrg] = useState('');

  const allOrgs = useMemo(() => {
    const flat: OrgNode[] = [];
    const walk = (nodes: OrgNode[]) => {
      nodes.forEach(n => {
        flat.push(n);
        if (n.children) walk(n.children);
      });
    };
    walk(ORG_TREE);
    return flat;
  }, []);

  const filteredOrgs = useMemo(() => {
    if (!searchOrg) return allOrgs;
    return allOrgs.filter(o => o.name.includes(searchOrg));
  }, [allOrgs, searchOrg]);

  const stats = useMemo(() => ({
    total: allOrgs.length,
    service: allOrgs.filter(o => o.type === 'service').length,
    user: allOrgs.filter(o => o.type === 'user').length,
    users: MOCK_USERS.length,
  }), [allOrgs]);

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { title: '组织总数', value: stats.total, color: '#2563EB', icon: Building2 },
          { title: '服务方', value: stats.service, color: '#2563EB', icon: Shield },
          { title: '使用方', value: stats.user, color: '#10B981', icon: Users },
          { title: '用户总数', value: stats.users, color: '#8B5CF6', icon: UserCircle },
        ].map((kpi) => (
          <div key={kpi.title} className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${kpi.color}15` }}>
              <kpi.icon size={20} style={{ color: kpi.color }} />
            </div>
            <div>
              <p className="text-xs text-[#475569] mb-1">{kpi.title}</p>
              <p className="text-[28px] font-semibold text-[#0F172A] leading-tight">{kpi.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors">
            <Plus size={15} /> 新增组织
          </button>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              value={searchOrg}
              onChange={(e) => setSearchOrg(e.target.value)}
              placeholder="搜索组织名称..."
              className="h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus w-56"
            />
          </div>
          <div className="flex items-center border border-[#E2E8F0] rounded-md overflow-hidden">
            <button
              onClick={() => setViewMode('tree')}
              className={cn('h-9 px-3 text-sm transition-colors', viewMode === 'tree' ? 'bg-[#EFF6FF] text-[#2563EB]' : 'text-[#475569] hover:bg-[#F8FAFC]')}
            >
              树形
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={cn('h-9 px-3 text-sm transition-colors', viewMode === 'list' ? 'bg-[#EFF6FF] text-[#2563EB]' : 'text-[#475569] hover:bg-[#F8FAFC]')}
            >
              列表
            </button>
          </div>
        </div>
      </div>

      {/* Org Content */}
      <div className="bg-white rounded-lg shadow-card p-4">
        {viewMode === 'tree' ? (
          <div>
            {ORG_TREE.map((node) => (
              <OrgTreeNode key={node.id} node={node} />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#F1F5F9]">
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">组织名称</th>
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">类型</th>
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">用户数量</th>
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">网点数量</th>
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">载具数量</th>
                  <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrgs.map((org) => {
                  const typeCfg = ORG_TYPE_CONFIG[org.type];
                  return (
                    <tr key={org.id} className="border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group">
                      <td className="px-3 py-3">
                        <span className="text-sm font-medium text-[#0F172A]">{org.name}</span>
                      </td>
                      <td className="px-3 py-3">
                        <Tag label={typeCfg.label} color={typeCfg.color} bg={typeCfg.bg} />
                      </td>
                      <td className="px-3 py-3 text-sm text-[#475569]">{org.userCount || 0}</td>
                      <td className="px-3 py-3 text-sm text-[#475569]">{org.siteCount || 0}</td>
                      <td className="px-3 py-3 text-sm text-[#475569]">{org.carrierCount || 0}</td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1">
                          <button className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="编辑">
                            <Edit3 size={13} className="text-[#475569]" />
                          </button>
                          <button onClick={() => setPermOrg(org.name)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="权限分配">
                            <Shield size={13} className="text-[#475569]" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Permission Modal */}
      {permOrg && <PermissionModal orgName={permOrg} onClose={() => setPermOrg(null)} />}
    </div>
  );
}

// ------------------------------------------------------------------
// User Management Tab
// ------------------------------------------------------------------
function UserManagementTab() {
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [editingUser, setEditingUser] = useState<UserItem | null>(null);
  const [showAddUser, setShowAddUser] = useState(false);
  const [showRoleMatrix, setShowRoleMatrix] = useState<RoleItem | null>(null);
  const [selectedUsers, setSelectedUsers] = useState<Set<string>>(new Set());
  const pageSize = 10;

  const filteredUsers = useMemo(() => {
    return MOCK_USERS.filter((u) => {
      if (roleFilter !== 'all' && u.role !== roleFilter) return false;
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (search) {
        return u.name.includes(search) || u.account.includes(search) || u.phone.includes(search);
      }
      return true;
    });
  }, [roleFilter, statusFilter, search]);

  const totalPages = Math.ceil(filteredUsers.length / pageSize);
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredUsers.slice(start, start + pageSize);
  }, [filteredUsers, currentPage]);

  const toggleUserRow = (id: string) => {
    setSelectedUsers(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <select
          value={roleFilter}
          onChange={(e) => { setRoleFilter(e.target.value); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          <option value="all">全部角色</option>
          {BUILTIN_ROLES.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          <option value="all">全部状态</option>
          <option value="active">启用</option>
          <option value="inactive">停用</option>
          <option value="locked">锁定</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              placeholder="搜索用户名、姓名、手机号..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
        <button
          onClick={() => setShowAddUser(true)}
          className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors"
        >
          <Plus size={15} /> 新增用户
        </button>
      </div>

      {/* User Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="w-10 px-3 py-2.5">
                  <input
                    type="checkbox"
                    checked={paginatedUsers.length > 0 && paginatedUsers.every(u => selectedUsers.has(u.id))}
                    onChange={() => {
                      if (paginatedUsers.every(u => selectedUsers.has(u.id))) {
                        setSelectedUsers(prev => {
                          const next = new Set(prev);
                          paginatedUsers.forEach(u => next.delete(u.id));
                          return next;
                        });
                      } else {
                        setSelectedUsers(prev => {
                          const next = new Set(prev);
                          paginatedUsers.forEach(u => next.add(u.id));
                          return next;
                        });
                      }
                    }}
                    className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]"
                  />
                </th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">用户</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">手机号</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">所属组织</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">角色</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">最后登录</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedUsers.map((user, idx) => {
                const statusCfg = STATUS_CONFIG[user.status];
                const isSelected = selectedUsers.has(user.id);
                return (
                  <motion.tr
                    key={user.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.15, delay: idx * 0.02 }}
                    className={cn('border-b border-[#E2E8F0] hover:bg-[#EFF6FF] transition-colors group', isSelected && 'bg-[#EFF6FF]')}
                  >
                    <td className="px-3 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleUserRow(user.id)}
                        className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB]"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-[#EFF6FF] flex items-center justify-center flex-shrink-0">
                          <UserCircle size={18} className="text-[#2563EB]" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-[#0F172A]">{user.name}</p>
                          <p className="text-xs text-[#94A3B8]">{user.account}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569]">{user.phone}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569]">{user.orgName}</span>
                    </td>
                    <td className="px-3 py-3">
                      <Tag label={user.role} color="#2563EB" bg="#EFF6FF" />
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                                                        <button
                                                          className={cn(
                                                            'relative w-9 h-5 rounded-full transition-colors',
                                                            user.status === 'active' ? 'bg-[#10B981]' : 'bg-[#CBD5E1]'
                                                          )}
                                                        >
                                                          <span className={cn(
                                                            'absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform',
                                                            user.status === 'active' ? 'translate-x-4' : 'translate-x-0'
                                                          )} />
                                                        </button>
                        <span className="text-xs" style={{ color: statusCfg.color }}>{statusCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#94A3B8] font-mono">{user.lastLoginAt}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditingUser(user)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="编辑">
                          <Edit3 size={13} className="text-[#475569]" />
                        </button>
                        <button className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="重置密码">
                          <Lock size={13} className="text-[#F59E0B]" />
                        </button>
                        <button className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="删除">
                          <Trash2 size={13} className="text-[#EF4444]" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {paginatedUsers.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Users size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无用户数据</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        {filteredUsers.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">共 <strong>{filteredUsers.length}</strong> 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">上一页</button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button key={page} onClick={() => setCurrentPage(page)} className={cn('w-8 h-8 rounded-md text-sm font-medium transition-colors', currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]')}>{page}</button>
                );
              })}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors">下一页</button>
            </div>
          </div>
        )}
      </div>

      {/* Role Cards */}
      <div>
        <h3 className="text-base font-semibold text-[#0F172A] mb-4">角色权限</h3>
        <div className="grid grid-cols-3 gap-4">
          {BUILTIN_ROLES.map((role) => (
            <motion.div
              key={role.id}
              whileHover={{ y: -2 }}
              className="bg-white rounded-lg shadow-card p-5 hover:shadow-card-hover transition-shadow group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-lg bg-[#EFF6FF] flex items-center justify-center">
                  <Shield size={20} className="text-[#2563EB]" />
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => setShowRoleMatrix(role)} className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center" title="编辑权限">
                    <Edit3 size={13} className="text-[#475569]" />
                  </button>
                </div>
              </div>
              <h4 className="text-base font-semibold text-[#0F172A] mb-1">{role.name}</h4>
              <p className="text-xs text-[#94A3B8] mb-3 line-clamp-2">{role.description}</p>
              <div className="flex items-center justify-between text-xs text-[#475569]">
                <span className="flex items-center gap-1"><Users size={12} /> {role.userCount} 位用户</span>
                <span className="flex items-center gap-1"><CheckSquare size={12} /> {role.permissionCount} 项权限</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Modals */}
      {(editingUser || showAddUser) && (
        <UserEditModal
          user={editingUser}
          onClose={() => { setEditingUser(null); setShowAddUser(false); }}
          onSave={() => { setEditingUser(null); setShowAddUser(false); }}
        />
      )}
      {showRoleMatrix && (
        <RoleMatrixModal role={showRoleMatrix} onClose={() => setShowRoleMatrix(null)} />
      )}
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function UserManagementPage() {
  const [activeTab, setActiveTab] = useState<TabKey>('organizations');

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#0F172A] mb-4">用户管理</h1>
        {/* Tab Navigation */}
        <div className="flex border-b border-[#E2E8F0]">
          {TAB_OPTIONS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex items-center gap-2 px-5 py-3 text-sm font-medium transition-colors',
                activeTab === tab.key ? 'text-[#2563EB]' : 'text-[#475569] hover:text-[#0F172A]'
              )}
            >
              <tab.icon size={16} />
              {tab.label}
              {activeTab === tab.key && (
                <motion.div
                  layoutId="userTabIndicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2563EB] rounded-full"
                  transition={{ duration: 0.2 }}
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'organizations' && <OrganizationTab />}
          {activeTab === 'users' && <UserManagementTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
