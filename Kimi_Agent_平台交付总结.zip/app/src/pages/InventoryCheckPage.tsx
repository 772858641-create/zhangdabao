import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  ClipboardList,
  ScanLine,
  CheckCircle,
  XCircle,
  AlertTriangle,
  FileText,
  Plus,
  Eye,
  BarChart3,
  Play,
  RotateCcw,
  SkipForward,
  Download,
  Printer,
  Search,
  CalendarDays,
  UserCircle,
  Warehouse,
  PackageCheck,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from 'recharts';

/* ─── 1. 盘点任务 mock（10条） ─── */
const taskMock = [
  { id: 'PD-20250601-001', name: '6月上海浦东全盘', scope: '上海浦东仓库', method: '全盘', status: 'PENDING', plannedAt: '2025-06-01', manager: '张明', total: 1240, scanned: 0 },
  { id: 'PD-20250603-002', name: '苏州昆山A区抽盘', scope: '苏州昆山工厂-A区域', method: '抽盘', status: 'EXECUTING', plannedAt: '2025-06-03', manager: '李华', total: 320, scanned: 156 },
  { id: 'PD-20250605-003', name: '深圳龙岗发货区盘点', scope: '深圳龙岗仓库-发货区', method: '全盘', status: 'EXECUTING', plannedAt: '2025-06-05', manager: '王强', total: 580, scanned: 412 },
  { id: 'PD-20250608-004', name: '武汉东西湖全盘', scope: '武汉东西湖仓库', method: '全盘', status: 'PENDING', plannedAt: '2025-06-08', manager: '赵敏', total: 890, scanned: 0 },
  { id: 'PD-20250610-005', name: '成都双流抽盘', scope: '成都双流仓库-B区域', method: '抽盘', status: 'COMPLETED', plannedAt: '2025-06-10', manager: '刘洋', total: 210, scanned: 210 },
  { id: 'PD-20250612-006', name: '南京江宁全盘', scope: '南京江宁仓库', method: '全盘', status: 'COMPLETED', plannedAt: '2025-06-12', manager: '陈丽', total: 750, scanned: 750 },
  { id: 'PD-20250615-007', name: '杭州萧山发货区抽盘', scope: '杭州萧山仓库-发货区', method: '抽盘', status: 'CANCELLED', plannedAt: '2025-06-15', manager: '周杰', total: 180, scanned: 0 },
  { id: 'PD-20250618-008', name: '广州白云全盘', scope: '广州白云仓库', method: '全盘', status: 'EXECUTING', plannedAt: '2025-06-18', manager: '吴芳', total: 1100, scanned: 723 },
  { id: 'PD-20250620-009', name: '北京通州抽盘', scope: '北京通州仓库-C区域', method: '抽盘', status: 'PENDING', plannedAt: '2025-06-20', manager: '郑伟', total: 260, scanned: 0 },
  { id: 'PD-20250622-010', name: '青岛黄岛全盘', scope: '青岛黄岛仓库', method: '全盘', status: 'COMPLETED', plannedAt: '2025-06-22', manager: '孙磊', total: 640, scanned: 640 },
];

/* ─── 2. 差异记录 mock（30条） ─── */
const diffMock = [
  { id: 'D001', carrierCode: 'CA-20250601-001', systemSite: '上海浦东仓库-收货区', actualSite: '上海浦东仓库-收货区', diffType: '位置不符', status: 'PENDING', taskId: 'PD-20250601-001', checkTime: '2025-06-01 09:23' },
  { id: 'D002', carrierCode: 'CA-20250601-015', systemSite: '上海浦东仓库-合格品区', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250601-001', checkTime: '2025-06-01 09:45' },
  { id: 'D003', carrierCode: 'CA-20250601-038', systemSite: '-', actualSite: '上海浦东仓库-发货区', diffType: '盘盈', status: 'CONFIRMED', taskId: 'PD-20250601-001', checkTime: '2025-06-01 10:12' },
  { id: 'D004', carrierCode: 'CA-20250603-007', systemSite: '苏州昆山工厂-A区域', actualSite: '苏州昆山工厂-B区域', diffType: '位置不符', status: 'PENDING', taskId: 'PD-20250603-002', checkTime: '2025-06-03 14:33' },
  { id: 'D005', carrierCode: 'CA-20250603-022', systemSite: '苏州昆山工厂-A区域', actualSite: '-', diffType: '盘亏', status: 'PROCESSING', taskId: 'PD-20250603-002', checkTime: '2025-06-03 15:01' },
  { id: 'D006', carrierCode: 'CA-20250605-011', systemSite: '深圳龙岗仓库-发货区', actualSite: '深圳龙岗仓库-暂存区', diffType: '位置不符', status: 'CONFIRMED', taskId: 'PD-20250605-003', checkTime: '2025-06-05 08:56' },
  { id: 'D007', carrierCode: 'CA-20250605-019', systemSite: '深圳龙岗仓库-发货区', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250605-003', checkTime: '2025-06-05 09:18' },
  { id: 'D008', carrierCode: 'CA-20250605-044', systemSite: '-', actualSite: '深圳龙岗仓库-发货区', diffType: '盘盈', status: 'PENDING', taskId: 'PD-20250605-003', checkTime: '2025-06-05 09:42' },
  { id: 'D009', carrierCode: 'CA-20250605-067', systemSite: '深圳龙岗仓库-发货区', actualSite: '深圳龙岗仓库-退货区', diffType: '位置不符', status: 'PROCESSING', taskId: 'PD-20250605-003', checkTime: '2025-06-05 10:05' },
  { id: 'D010', carrierCode: 'CA-20250608-003', systemSite: '武汉东西湖仓库', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250608-004', checkTime: '2025-06-08 11:27' },
  { id: 'D011', carrierCode: 'CA-20250610-009', systemSite: '成都双流仓库-B区域', actualSite: '成都双流仓库-B区域', diffType: '位置不符', status: 'CONFIRMED', taskId: 'PD-20250610-005', checkTime: '2025-06-10 13:45' },
  { id: 'D012', carrierCode: 'CA-20250610-014', systemSite: '-', actualSite: '成都双流仓库-B区域', diffType: '盘盈', status: 'CONFIRMED', taskId: 'PD-20250610-005', checkTime: '2025-06-10 14:02' },
  { id: 'D013', carrierCode: 'CA-20250612-029', systemSite: '南京江宁仓库', actualSite: '南京江宁仓库-二期', diffType: '位置不符', status: 'CONFIRMED', taskId: 'PD-20250612-006', checkTime: '2025-06-12 16:21' },
  { id: 'D014', carrierCode: 'CA-20250612-031', systemSite: '南京江宁仓库', actualSite: '-', diffType: '盘亏', status: 'PROCESSING', taskId: 'PD-20250612-006', checkTime: '2025-06-12 16:38' },
  { id: 'D015', carrierCode: 'CA-20250612-055', systemSite: '-', actualSite: '南京江宁仓库', diffType: '盘盈', status: 'CONFIRMED', taskId: 'PD-20250612-006', checkTime: '2025-06-12 17:05' },
  { id: 'D016', carrierCode: 'CA-20250615-002', systemSite: '杭州萧山仓库-发货区', actualSite: '-', diffType: '盘亏', status: 'CANCELLED', taskId: 'PD-20250615-007', checkTime: '2025-06-15 08:15' },
  { id: 'D017', carrierCode: 'CA-20250618-012', systemSite: '广州白云仓库', actualSite: '广州白云仓库-外仓', diffType: '位置不符', status: 'PENDING', taskId: 'PD-20250618-008', checkTime: '2025-06-18 09:33' },
  { id: 'D018', carrierCode: 'CA-20250618-025', systemSite: '广州白云仓库', actualSite: '-', diffType: '盘亏', status: 'PROCESSING', taskId: 'PD-20250618-008', checkTime: '2025-06-18 10:01' },
  { id: 'D019', carrierCode: 'CA-20250618-041', systemSite: '-', actualSite: '广州白云仓库', diffType: '盘盈', status: 'PENDING', taskId: 'PD-20250618-008', checkTime: '2025-06-18 10:28' },
  { id: 'D020', carrierCode: 'CA-20250618-058', systemSite: '广州白云仓库', actualSite: '广州白云仓库-暂存区', diffType: '位置不符', status: 'PENDING', taskId: 'PD-20250618-008', checkTime: '2025-06-18 11:15' },
  { id: 'D021', carrierCode: 'CA-20250620-006', systemSite: '北京通州仓库-C区域', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250620-009', checkTime: '2025-06-20 13:42' },
  { id: 'D022', carrierCode: 'CA-20250620-017', systemSite: '-', actualSite: '北京通州仓库-C区域', diffType: '盘盈', status: 'PENDING', taskId: 'PD-20250620-009', checkTime: '2025-06-20 14:08' },
  { id: 'D023', carrierCode: 'CA-20250622-008', systemSite: '青岛黄岛仓库', actualSite: '-', diffType: '盘亏', status: 'CONFIRMED', taskId: 'PD-20250622-010', checkTime: '2025-06-22 15:33' },
  { id: 'D024', carrierCode: 'CA-20250622-019', systemSite: '-', actualSite: '青岛黄岛仓库', diffType: '盘盈', status: 'CONFIRMED', taskId: 'PD-20250622-010', checkTime: '2025-06-22 15:56' },
  { id: 'D025', carrierCode: 'CA-20250622-037', systemSite: '青岛黄岛仓库', actualSite: '青岛黄岛仓库-外协区', diffType: '位置不符', status: 'PROCESSING', taskId: 'PD-20250622-010', checkTime: '2025-06-22 16:18' },
  { id: 'D026', carrierCode: 'CA-20250601-062', systemSite: '上海浦东仓库-合格品区', actualSite: '上海浦东仓库-发货区', diffType: '位置不符', status: 'PENDING', taskId: 'PD-20250601-001', checkTime: '2025-06-01 11:05' },
  { id: 'D027', carrierCode: 'CA-20250605-033', systemSite: '-', actualSite: '深圳龙岗仓库-收货区', diffType: '盘盈', status: 'PROCESSING', taskId: 'PD-20250605-003', checkTime: '2025-06-05 11:35' },
  { id: 'D028', carrierCode: 'CA-20250612-048', systemSite: '南京江宁仓库', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250612-006', checkTime: '2025-06-12 17:42' },
  { id: 'D029', carrierCode: 'CA-20250618-071', systemSite: '广州白云仓库', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250618-008', checkTime: '2025-06-18 11:48' },
  { id: 'D030', carrierCode: 'CA-20250622-051', systemSite: '青岛黄岛仓库', actualSite: '-', diffType: '盘亏', status: 'PENDING', taskId: 'PD-20250622-010', checkTime: '2025-06-22 16:45' },
];

/* ─── 3. 扫码模拟 mock 库 ─── */
const scanLibrary = [
  { carrierCode: 'CA-20250603-001', systemSite: '苏州昆山工厂-A区域', isMatch: true },
  { carrierCode: 'CA-20250603-007', systemSite: '苏州昆山工厂-A区域', isMatch: false, actualSite: '苏州昆山工厂-B区域' },
  { carrierCode: 'CA-20250603-015', systemSite: '苏州昆山工厂-A区域', isMatch: true },
  { carrierCode: 'CA-20250603-022', systemSite: '苏州昆山工厂-A区域', isMatch: false, actualSite: '-' },
  { carrierCode: 'CA-20250605-011', systemSite: '深圳龙岗仓库-发货区', isMatch: false, actualSite: '深圳龙岗仓库-暂存区' },
  { carrierCode: 'CA-20250605-019', systemSite: '深圳龙岗仓库-发货区', isMatch: false, actualSite: '-' },
  { carrierCode: 'CA-20250605-044', systemSite: '深圳龙岗仓库-发货区', isMatch: false, actualSite: '深圳龙岗仓库-发货区' },
  { carrierCode: 'CA-20250618-012', systemSite: '广州白云仓库', isMatch: false, actualSite: '广州白云仓库-外仓' },
  { carrierCode: 'CA-20250618-025', systemSite: '广州白云仓库', isMatch: false, actualSite: '-' },
  { carrierCode: 'CA-20250618-041', systemSite: '广州白云仓库', isMatch: false, actualSite: '广州白云仓库' },
];

/* ─── 4. 图表数据 ─── */
const monthlyTrend = [
  { month: '2025-01', diffRate: 2.8 },
  { month: '2025-02', diffRate: 2.1 },
  { month: '2025-03', diffRate: 3.5 },
  { month: '2025-04', diffRate: 1.9 },
  { month: '2025-05', diffRate: 1.4 },
  { month: '2025-06', diffRate: 1.1 },
];

const siteRanking = [
  { site: '上海浦东仓库', diffRate: 1.1 },
  { site: '苏州昆山工厂', diffRate: 1.4 },
  { site: '深圳龙岗仓库', diffRate: 1.9 },
  { site: '武汉东西湖仓库', diffRate: 2.1 },
  { site: '成都双流仓库', diffRate: 2.5 },
  { site: '南京江宁仓库', diffRate: 2.8 },
  { site: '杭州萧山仓库', diffRate: 3.2 },
  { site: '广州白云仓库', diffRate: 3.5 },
  { site: '北京通州仓库', diffRate: 4.1 },
  { site: '青岛黄岛仓库', diffRate: 4.8 },
];

/* ─── 状态映射 ─── */
const taskStatusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'outline' | 'destructive' }> = {
  PENDING: { label: '待执行', variant: 'secondary' },
  EXECUTING: { label: '执行中', variant: 'default' },
  COMPLETED: { label: '已完成', variant: 'outline' },
  CANCELLED: { label: '已取消', variant: 'destructive' },
};

const diffStatusMap: Record<string, { label: string; color: string }> = {
  PENDING: { label: '待处理', color: 'bg-[var(--warning)] text-white' },
  PROCESSING: { label: '处理中', color: 'bg-[var(--info)] text-white' },
  CONFIRMED: { label: '已确认', color: 'bg-[var(--success)] text-white' },
  CANCELLED: { label: '已取消', color: 'bg-[var(--gray-5)] text-white' },
};

const methodMap: Record<string, string> = {
  全盘: '全盘',
  抽盘: '抽盘',
};

/* ─── 主组件 ─── */
export default function InventoryCheckPage() {
  const [activeTab, setActiveTab] = useState('tasks');
  const [tasks, setTasks] = useState(taskMock);
  const [diffs, setDiffs] = useState(diffMock);

  /* 盘点任务对话框 */
  const [createOpen, setCreateOpen] = useState(false);
  const [viewTaskOpen, setViewTaskOpen] = useState(false);
  const [viewTaskId, setViewTaskId] = useState<string | null>(null);
  const [newTaskName, setNewTaskName] = useState('');
  const [newTaskScope, setNewTaskScope] = useState('');
  const [newTaskMethod, setNewTaskMethod] = useState('全盘');
  const [newTaskManager, setNewTaskManager] = useState('');
  const [newTaskDate, setNewTaskDate] = useState('');

  /* 扫码模拟 */
  const [scanInput, setScanInput] = useState('');
  const [scanResult, setScanResult] = useState<typeof scanLibrary[0] | null>(null);
  const [scanHistory, setScanHistory] = useState<Array<{ carrierCode: string; result: string; time: string }>>([]);

  /* 差异处理对话框 */
  const [diffActionOpen, setDiffActionOpen] = useState(false);
  const [selectedDiffId, setSelectedDiffId] = useState<string | null>(null);
  const [diffActionType, setDiffActionType] = useState('');
  const [diffRemark, setDiffRemark] = useState('');

  /* 报告 */
  const [reportPreviewOpen, setReportPreviewOpen] = useState(false);
  const [selectedReportTask, setSelectedReportTask] = useState<string | null>(null);

  /* 搜索过滤 */
  const [taskSearch, setTaskSearch] = useState('');
  const [taskStatusFilter, setTaskStatusFilter] = useState('all');
  const [diffSearch, setDiffSearch] = useState('');
  const [diffStatusFilter, setDiffStatusFilter] = useState('all');

  /* ─── 过滤后的任务 ─── */
  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch = taskSearch === '' || t.id.includes(taskSearch) || t.name.includes(taskSearch) || t.scope.includes(taskSearch);
      const matchStatus = taskStatusFilter === 'all' || t.status === taskStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [tasks, taskSearch, taskStatusFilter]);

  /* ─── 过滤后的差异 ─── */
  const filteredDiffs = useMemo(() => {
    return diffs.filter((d) => {
      const matchSearch = diffSearch === '' || d.carrierCode.includes(diffSearch) || d.systemSite.includes(diffSearch);
      const matchStatus = diffStatusFilter === 'all' || d.status === diffStatusFilter;
      return matchSearch && matchStatus;
    });
  }, [diffs, diffSearch, diffStatusFilter]);

  /* ─── 结果总览计算 ─── */
  const resultOverview = useMemo(() => {
    const totalShould = tasks.filter((t) => t.status === 'COMPLETED').reduce((sum, t) => sum + t.total, 0);
    const totalActual = tasks.filter((t) => t.status === 'COMPLETED').reduce((sum, t) => sum + t.scanned, 0);
    const surplusCount = diffs.filter((d) => d.diffType === '盘盈' && d.status === 'CONFIRMED').length;
    const deficitCount = diffs.filter((d) => d.diffType === '盘亏' && d.status === 'CONFIRMED').length;
    const diffTotal = surplusCount + deficitCount;
    const diffRate = totalShould > 0 ? ((diffTotal / totalShould) * 100).toFixed(2) : '0.00';
    return { totalShould, totalActual, surplusCount, deficitCount, diffTotal, diffRate };
  }, [tasks, diffs]);

  /* ─── KPI 计算 ─── */
  const kpiData = useMemo(() => {
    const thisMonthCount = tasks.filter((t) => t.plannedAt.startsWith('2025-06')).length;
    const completedTasks = tasks.filter((t) => t.status === 'COMPLETED');
    const avgDiffRate = completedTasks.length > 0
      ? (completedTasks.reduce((sum, t) => sum + (t.scanned / Math.max(t.total, 1) * 100), 0) / completedTasks.length).toFixed(1)
      : '0.0';
    const processedDiff = diffs.filter((d) => d.status === 'CONFIRMED' || d.status === 'PROCESSING').length;
    const diffProcessRate = diffs.length > 0 ? ((processedDiff / diffs.length) * 100).toFixed(1) : '0.0';
    return { thisMonthCount, avgDiffRate, diffProcessRate };
  }, [tasks, diffs]);

  /* ─── 新增盘点任务 ─── */
  const handleCreateTask = () => {
    if (!newTaskName || !newTaskScope || !newTaskManager || !newTaskDate) return;
    const dateStr = newTaskDate.replace(/-/g, '');
    const idx = String(tasks.length + 1).padStart(3, '0');
    const newTask = {
      id: `PD-${dateStr}-${idx}`,
      name: newTaskName,
      scope: newTaskScope,
      method: newTaskMethod,
      status: 'PENDING' as const,
      plannedAt: newTaskDate,
      manager: newTaskManager,
      total: Math.floor(Math.random() * 1000) + 100,
      scanned: 0,
    };
    setTasks((prev) => [...prev, newTask]);
    setNewTaskName('');
    setNewTaskScope('');
    setNewTaskMethod('全盘');
    setNewTaskManager('');
    setNewTaskDate('');
    setCreateOpen(false);
  };

  /* ─── 开始盘点 ─── */
  const handleStartTask = (taskId: string) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, status: 'EXECUTING' } : t)));
  };

  /* ─── 取消盘点 ─── */
  const handleCancelTask = (taskId: string) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, status: 'CANCELLED' } : t)));
  };

  /* ─── 查看进度 ─── */
  const handleViewProgress = (taskId: string) => {
    setViewTaskId(taskId);
    setViewTaskOpen(true);
  };

  const viewTask = useMemo(() => tasks.find((t) => t.id === viewTaskId) || null, [tasks, viewTaskId]);

  /* ─── PDA扫码模拟 ─── */
  const handleScan = () => {
    if (!scanInput.trim()) return;
    const found = scanLibrary.find((s) => s.carrierCode === scanInput.trim());
    if (found) {
      setScanResult(found);
      setScanHistory((prev) => [{ carrierCode: found.carrierCode, result: found.isMatch ? '一致' : '差异', time: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    } else {
      setScanResult({ carrierCode: scanInput.trim(), systemSite: '未知', isMatch: false, actualSite: '未找到系统记录' });
      setScanHistory((prev) => [{ carrierCode: scanInput.trim(), result: '未知', time: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    }
    setScanInput('');
  };

  const handleConfirmMatch = () => {
    if (!scanResult) return;
    setScanHistory((prev) => [{ carrierCode: scanResult.carrierCode, result: '确认一致', time: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    setScanResult(null);
  };

  const handleMarkDiff = () => {
    if (!scanResult) return;
    const newDiff = {
      id: `D${String(diffs.length + 1).padStart(3, '0')}`,
      carrierCode: scanResult.carrierCode,
      systemSite: scanResult.systemSite,
      actualSite: scanResult.actualSite || '-',
      diffType: scanResult.actualSite === '-' ? '盘亏' : scanResult.systemSite === '-' ? '盘盈' : '位置不符',
      status: 'PENDING',
      taskId: 'PD-20250603-002',
      checkTime: new Date().toLocaleString('zh-CN'),
    };
    setDiffs((prev) => [newDiff, ...prev]);
    setScanHistory((prev) => [{ carrierCode: scanResult.carrierCode, result: '标记差异', time: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    setScanResult(null);
  };

  const handleSkip = () => {
    if (!scanResult) return;
    setScanHistory((prev) => [{ carrierCode: scanResult.carrierCode, result: '跳过', time: new Date().toLocaleTimeString() }, ...prev].slice(0, 20));
    setScanResult(null);
  };

  /* ─── 差异处理 ─── */
  const openDiffAction = (diffId: string, action: string) => {
    setSelectedDiffId(diffId);
    setDiffActionType(action);
    setDiffRemark('');
    setDiffActionOpen(true);
  };

  const handleDiffActionConfirm = () => {
    if (!selectedDiffId) return;
    const newStatus = diffActionType === 'confirm' ? 'CONFIRMED' : diffActionType === 'process' ? 'PROCESSING' : 'PENDING';
    setDiffs((prev) => prev.map((d) => (d.id === selectedDiffId ? { ...d, status: newStatus } : d)));
    setDiffActionOpen(false);
    setSelectedDiffId(null);
    setDiffActionType('');
    setDiffRemark('');
  };

  /* ─── 报告 ─── */
  const handlePreviewReport = (taskId: string) => {
    setSelectedReportTask(taskId);
    setReportPreviewOpen(true);
  };

  const reportTask = useMemo(() => tasks.find((t) => t.id === selectedReportTask) || null, [tasks, selectedReportTask]);

  return (
    <div className="space-y-6">
      {/* ===== 页面标题 ===== */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--neutral-textPrimary)' }}>库存盘点管理</h1>
          <p className="text-sm mt-1" style={{ color: 'var(--neutral-textSecondary)' }}>仓库载具账实核对、差异处理与盘点报告</p>
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          新增盘点任务
        </Button>
      </div>

      {/* ===== KPI 卡片 ===== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>本月盘点次数</div>
              <div className="text-xl font-bold">{kpiData.thisMonthCount}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--warning-10)', color: 'var(--warning)' }}>
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>平均差异率 (%)</div>
              <div className="text-xl font-bold">{kpiData.avgDiffRate}%</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--success-10)', color: 'var(--success)' }}>
              <CheckCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>差异处理率</div>
              <div className="text-xl font-bold">{kpiData.diffProcessRate}%</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--info-10)', color: 'var(--info)' }}>
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>总差异数</div>
              <div className="text-xl font-bold">{diffs.length}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ===== 图表区域 ===== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              近6个月盘点差异率趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--gray-3)" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="var(--neutral-textSecondary)" />
                <YAxis tick={{ fontSize: 12 }} stroke="var(--neutral-textSecondary)" unit="%" />
                <Tooltip
                  contentStyle={{ borderRadius: 8, border: '1px solid var(--gray-3)', fontSize: 12 }}
                  formatter={(value: number) => [`${value}%`, '差异率']}
                />
                <Line type="monotone" dataKey="diffRate" stroke="var(--primary)" strokeWidth={2} dot={{ r: 4, fill: 'var(--primary)' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              各网点差异率排名
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={siteRanking} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--gray-3)" />
                <XAxis type="number" tick={{ fontSize: 12 }} stroke="var(--neutral-textSecondary)" unit="%" />
                <YAxis dataKey="site" type="category" tick={{ fontSize: 11 }} stroke="var(--neutral-textSecondary)" width={100} />
                <Tooltip
                  contentStyle={{ borderRadius: 8, border: '1px solid var(--gray-3)', fontSize: 12 }}
                  formatter={(value: number) => [`${value}%`, '差异率']}
                />
                <Bar dataKey="diffRate" fill="var(--chart-1)" radius={[0, 4, 4, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* ===== 主 Tab 区域 ===== */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList>
          <TabsTrigger value="tasks">
            <ClipboardList className="w-4 h-4 mr-1" />
            盘点任务管理
          </TabsTrigger>
          <TabsTrigger value="execute">
            <ScanLine className="w-4 h-4 mr-1" />
            盘点执行
          </TabsTrigger>
          <TabsTrigger value="results">
            <CheckCircle className="w-4 h-4 mr-1" />
            盘点结果
          </TabsTrigger>
          <TabsTrigger value="report">
            <FileText className="w-4 h-4 mr-1" />
            盘点报告
          </TabsTrigger>
        </TabsList>

        {/* ─── Tab 1: 盘点任务管理 ─── */}
        <TabsContent value="tasks" className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--neutral-textSecondary)' }} />
              <Input
                placeholder="搜索任务编号/名称/范围"
                className="pl-9 w-[280px]"
                value={taskSearch}
                onChange={(e) => setTaskSearch(e.target.value)}
              />
            </div>
            <Select value={taskStatusFilter} onValueChange={setTaskStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="全部状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="PENDING">待执行</SelectItem>
                <SelectItem value="EXECUTING">执行中</SelectItem>
                <SelectItem value="COMPLETED">已完成</SelectItem>
                <SelectItem value="CANCELLED">已取消</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>任务编号</TableHead>
                  <TableHead>任务名称</TableHead>
                  <TableHead>盘点范围</TableHead>
                  <TableHead>盘点方式</TableHead>
                  <TableHead>负责人</TableHead>
                  <TableHead>计划日期</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>应盘/实盘</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTasks.map((t) => {
                  const s = taskStatusMap[t.status];
                  return (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">{t.id}</TableCell>
                      <TableCell>{t.name}</TableCell>
                      <TableCell>{t.scope}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{methodMap[t.method] || t.method}</Badge>
                      </TableCell>
                      <TableCell className="flex items-center gap-1">
                        <UserCircle className="w-4 h-4" style={{ color: 'var(--neutral-textSecondary)' }} />
                        {t.manager}
                      </TableCell>
                      <TableCell className="flex items-center gap-1">
                        <CalendarDays className="w-4 h-4" style={{ color: 'var(--neutral-textSecondary)' }} />
                        {t.plannedAt}
                      </TableCell>
                      <TableCell>
                        <Badge variant={s.variant}>{s.label}</Badge>
                      </TableCell>
                      <TableCell>
                        {t.total} / {t.scanned}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {t.status === 'PENDING' && (
                            <Button variant="ghost" size="sm" onClick={() => handleStartTask(t.id)} title="开始盘点">
                              <Play className="w-4 h-4" style={{ color: 'var(--success)' }} />
                            </Button>
                          )}
                          {(t.status === 'PENDING' || t.status === 'EXECUTING') && (
                            <Button variant="ghost" size="sm" onClick={() => handleViewProgress(t.id)} title="查看进度">
                              <Eye className="w-4 h-4" style={{ color: 'var(--info)' }} />
                            </Button>
                          )}
                          {(t.status === 'PENDING' || t.status === 'EXECUTING') && (
                            <Button variant="ghost" size="sm" onClick={() => handleCancelTask(t.id)} title="取消">
                              <XCircle className="w-4 h-4" style={{ color: 'var(--danger)' }} />
                            </Button>
                          )}
                          {t.status === 'COMPLETED' && (
                            <Button variant="ghost" size="sm" onClick={() => handlePreviewReport(t.id)} title="查看报告">
                              <FileText className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        {/* ─── Tab 2: 盘点执行 (PDA扫码模拟) ─── */}
        <TabsContent value="execute" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* 左侧：扫码输入 */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <ScanLine className="w-4 h-4" />
                  PDA 扫码模拟
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="请输入载具编号模拟扫码（如 CA-20250603-001）"
                    value={scanInput}
                    onChange={(e) => setScanInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleScan()}
                    className="flex-1"
                  />
                  <Button onClick={handleScan}>
                    <ScanLine className="w-4 h-4 mr-2" />
                    扫码
                  </Button>
                </div>

                {/* 扫码结果展示 */}
                {scanResult && (
                  <Card className="border-2" style={{ borderColor: scanResult.isMatch ? 'var(--success)' : scanResult.actualSite === '未找到系统记录' ? 'var(--gray-4)' : 'var(--warning)' }}>
                    <CardContent className="p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <PackageCheck className="w-5 h-5" style={{ color: 'var(--primary)' }} />
                          <span className="font-bold text-lg">{scanResult.carrierCode}</span>
                        </div>
                        <Badge
                          variant={scanResult.isMatch ? 'default' : scanResult.actualSite === '未找到系统记录' ? 'secondary' : 'destructive'}
                        >
                          {scanResult.isMatch ? '一致' : scanResult.actualSite === '未找到系统记录' ? '未知' : '差异'}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span style={{ color: 'var(--neutral-textSecondary)' }}>系统记录位置：</span>
                          <span className="font-medium ml-1">{scanResult.systemSite}</span>
                        </div>
                        <div>
                          <span style={{ color: 'var(--neutral-textSecondary)' }}>实际扫描位置：</span>
                          <span className="font-medium ml-1">{scanResult.actualSite || '-'}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 pt-2">
                        {!scanResult.isMatch && scanResult.actualSite !== '未找到系统记录' && (
                          <>
                            <Button size="sm" onClick={handleConfirmMatch}>
                              <CheckCircle className="w-4 h-4 mr-1" />
                              确认一致
                            </Button>
                            <Button size="sm" variant="outline" onClick={handleMarkDiff}>
                              <AlertTriangle className="w-4 h-4 mr-1" />
                              标记差异
                            </Button>
                          </>
                        )}
                        {scanResult.isMatch && (
                          <Button size="sm" onClick={handleConfirmMatch}>
                            <CheckCircle className="w-4 h-4 mr-1" />
                            确认一致
                          </Button>
                        )}
                        <Button size="sm" variant="ghost" onClick={handleSkip}>
                          <SkipForward className="w-4 h-4 mr-1" />
                          跳过
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* 扫码历史 */}
                {scanHistory.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">最近扫码记录</h4>
                    <div className="border rounded-lg overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-xs">载具编号</TableHead>
                            <TableHead className="text-xs">结果</TableHead>
                            <TableHead className="text-xs">时间</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {scanHistory.map((h, idx) => (
                            <TableRow key={idx}>
                              <TableCell className="text-xs font-medium py-2">{h.carrierCode}</TableCell>
                              <TableCell className="text-xs py-2">
                                <span
                                  className="text-xs px-2 py-0.5 rounded-full"
                                  style={{
                                    background: h.result === '一致' || h.result === '确认一致' ? 'var(--success-10)' : h.result === '跳过' ? 'var(--gray-2)' : 'var(--warning-10)',
                                    color: h.result === '一致' || h.result === '确认一致' ? 'var(--success)' : h.result === '跳过' ? 'var(--neutral-textSecondary)' : 'var(--warning)',
                                  }}
                                >
                                  {h.result}
                                </span>
                              </TableCell>
                              <TableCell className="text-xs py-2" style={{ color: 'var(--neutral-textSecondary)' }}>{h.time}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 右侧：操作说明 */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  操作指南
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex gap-2 items-start">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>1</div>
                  <p style={{ color: 'var(--neutral-textSecondary)' }}>在输入框中输入载具编号，点击"扫码"按钮模拟 PDA 扫描。</p>
                </div>
                <div className="flex gap-2 items-start">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>2</div>
                  <p style={{ color: 'var(--neutral-textSecondary)' }}>系统将自动比对系统记录位置与实际扫描位置。</p>
                </div>
                <div className="flex gap-2 items-start">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>3</div>
                  <p style={{ color: 'var(--neutral-textSecondary)' }}>若一致，点击"确认一致"通过；若存在差异，点击"标记差异"。</p>
                </div>
                <div className="flex gap-2 items-start">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>4</div>
                  <p style={{ color: 'var(--neutral-textSecondary)' }}>点击"跳过"可跳过当前载具，继续扫描下一个。</p>
                </div>
                <div className="mt-4 p-3 rounded-lg" style={{ background: 'var(--gray-1)' }}>
                  <h5 className="font-medium mb-2 flex items-center gap-1">
                    <Warehouse className="w-4 h-4" />
                    当前执行任务
                  </h5>
                  <p className="text-xs mb-1" style={{ color: 'var(--neutral-textSecondary)' }}>任务：苏州昆山A区抽盘</p>
                  <p className="text-xs mb-1" style={{ color: 'var(--neutral-textSecondary)' }}>编号：PD-20250603-002</p>
                  <p className="text-xs" style={{ color: 'var(--neutral-textSecondary)' }}>范围：苏州昆山工厂-A区域</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ─── Tab 3: 盘点结果 ─── */}
        <TabsContent value="results" className="space-y-4">
          {/* 结果总览卡片 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--primary-10)', color: 'var(--primary)' }}>
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>应盘数量</div>
                  <div className="text-xl font-bold">{resultOverview.totalShould}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--success-10)', color: 'var(--success)' }}>
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>实盘数量</div>
                  <div className="text-xl font-bold">{resultOverview.totalActual}</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--warning-10)', color: 'var(--warning)' }}>
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>差异数量</div>
                  <div className="text-xl font-bold">
                    {resultOverview.diffTotal}
                    <span className="text-xs font-normal ml-1" style={{ color: 'var(--neutral-textSecondary)' }}>
                      (盈{resultOverview.surplusCount}/亏{resultOverview.deficitCount})
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'var(--danger-10)', color: 'var(--danger)' }}>
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>差异率</div>
                  <div className="text-xl font-bold">{resultOverview.diffRate}%</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 差异明细表格 */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-base font-semibold flex items-center gap-2">
                <Eye className="w-4 h-4" />
                差异明细
              </h3>
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--neutral-textSecondary)' }} />
                  <Input placeholder="搜索载具编号/位置" className="pl-9 w-[220px]" value={diffSearch} onChange={(e) => setDiffSearch(e.target.value)} />
                </div>
                <Select value={diffStatusFilter} onValueChange={setDiffStatusFilter}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="处理状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="PENDING">待处理</SelectItem>
                    <SelectItem value="PROCESSING">处理中</SelectItem>
                    <SelectItem value="CONFIRMED">已确认</SelectItem>
                    <SelectItem value="CANCELLED">已取消</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>差异编号</TableHead>
                    <TableHead>载具编号</TableHead>
                    <TableHead>系统位置</TableHead>
                    <TableHead>实际位置</TableHead>
                    <TableHead>差异类型</TableHead>
                    <TableHead>处理状态</TableHead>
                    <TableHead>盘点时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDiffs.map((d) => {
                    const ds = diffStatusMap[d.status];
                    return (
                      <TableRow key={d.id}>
                        <TableCell className="font-medium">{d.id}</TableCell>
                        <TableCell>{d.carrierCode}</TableCell>
                        <TableCell>{d.systemSite}</TableCell>
                        <TableCell>{d.actualSite}</TableCell>
                        <TableCell>
                          <Badge
                            variant={d.diffType === '盘盈' ? 'default' : d.diffType === '盘亏' ? 'destructive' : 'secondary'}
                          >
                            {d.diffType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${ds.color}`}>{ds.label}</span>
                        </TableCell>
                        <TableCell className="text-xs" style={{ color: 'var(--neutral-textSecondary)' }}>{d.checkTime}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {d.status === 'PENDING' && (
                              <Button variant="ghost" size="sm" onClick={() => openDiffAction(d.id, 'process')} title="开始处理">
                                <RotateCcw className="w-4 h-4" style={{ color: 'var(--info)' }} />
                              </Button>
                            )}
                            {(d.status === 'PENDING' || d.status === 'PROCESSING') && (
                              <Button variant="ghost" size="sm" onClick={() => openDiffAction(d.id, 'confirm')} title="确认处理">
                                <CheckCircle className="w-4 h-4" style={{ color: 'var(--success)' }} />
                              </Button>
                            )}
                            <Button variant="ghost" size="sm" onClick={() => openDiffAction(d.id, 'reject')} title="驳回">
                              <XCircle className="w-4 h-4" style={{ color: 'var(--danger)' }} />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Card>
          </div>
        </TabsContent>

        {/* ─── Tab 4: 盘点报告 ─── */}
        <TabsContent value="report" className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="text-base font-semibold flex items-center gap-2">
              <FileText className="w-4 h-4" />
              盘点报告列表
            </h3>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>报告编号</TableHead>
                  <TableHead>任务名称</TableHead>
                  <TableHead>盘点范围</TableHead>
                  <TableHead>盘点方式</TableHead>
                  <TableHead>完成日期</TableHead>
                  <TableHead>负责人</TableHead>
                  <TableHead>差异率</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {tasks.filter((t) => t.status === 'COMPLETED').map((t) => {
                  const taskDiffs = diffs.filter((d) => d.taskId === t.id);
                  const diffCount = taskDiffs.length;
                  const diffRateVal = t.total > 0 ? ((diffCount / t.total) * 100).toFixed(2) : '0.00';
                  return (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">RP-{t.id.slice(3)}</TableCell>
                      <TableCell>{t.name}</TableCell>
                      <TableCell>{t.scope}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{methodMap[t.method] || t.method}</Badge>
                      </TableCell>
                      <TableCell>{t.plannedAt}</TableCell>
                      <TableCell>{t.manager}</TableCell>
                      <TableCell>{diffRateVal}%</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="sm" onClick={() => handlePreviewReport(t.id)}>
                            <Eye className="w-4 h-4 mr-1" />
                            预览
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="w-4 h-4 mr-1" />
                            导出
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ===== 对话框：新增盘点任务 ===== */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5" />
              新增盘点任务
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>任务名称</Label>
              <Input placeholder="请输入任务名称" value={newTaskName} onChange={(e) => setNewTaskName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>盘点范围</Label>
              <Select value={newTaskScope} onValueChange={setNewTaskScope}>
                <SelectTrigger>
                  <SelectValue placeholder="选择盘点范围" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="上海浦东仓库">上海浦东仓库</SelectItem>
                  <SelectItem value="苏州昆山工厂-A区域">苏州昆山工厂-A区域</SelectItem>
                  <SelectItem value="深圳龙岗仓库-发货区">深圳龙岗仓库-发货区</SelectItem>
                  <SelectItem value="武汉东西湖仓库">武汉东西湖仓库</SelectItem>
                  <SelectItem value="成都双流仓库-B区域">成都双流仓库-B区域</SelectItem>
                  <SelectItem value="南京江宁仓库">南京江宁仓库</SelectItem>
                  <SelectItem value="杭州萧山仓库-发货区">杭州萧山仓库-发货区</SelectItem>
                  <SelectItem value="广州白云仓库">广州白云仓库</SelectItem>
                  <SelectItem value="北京通州仓库-C区域">北京通州仓库-C区域</SelectItem>
                  <SelectItem value="青岛黄岛仓库">青岛黄岛仓库</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>盘点方式</Label>
              <Select value={newTaskMethod} onValueChange={setNewTaskMethod}>
                <SelectTrigger>
                  <SelectValue placeholder="选择盘点方式" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="全盘">全盘</SelectItem>
                  <SelectItem value="抽盘">抽盘</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>负责人</Label>
              <Input placeholder="请输入负责人姓名" value={newTaskManager} onChange={(e) => setNewTaskManager(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>计划日期</Label>
              <Input type="date" value={newTaskDate} onChange={(e) => setNewTaskDate(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>取消</Button>
            <Button onClick={handleCreateTask}>创建</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== 对话框：查看进度 ===== */}
      <Dialog open={viewTaskOpen} onOpenChange={setViewTaskOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              盘点任务进度
            </DialogTitle>
          </DialogHeader>
          {viewTask && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>任务编号：</span>
                  <span className="font-medium">{viewTask.id}</span>
                </div>
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>任务名称：</span>
                  <span className="font-medium">{viewTask.name}</span>
                </div>
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>盘点范围：</span>
                  <span className="font-medium">{viewTask.scope}</span>
                </div>
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>盘点方式：</span>
                  <span className="font-medium">{methodMap[viewTask.method]}</span>
                </div>
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>负责人：</span>
                  <span className="font-medium">{viewTask.manager}</span>
                </div>
                <div>
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>状态：</span>
                  <Badge variant={taskStatusMap[viewTask.status].variant}>{taskStatusMap[viewTask.status].label}</Badge>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>盘点进度</span>
                  <span className="font-medium">{viewTask.scanned} / {viewTask.total} ({viewTask.total > 0 ? ((viewTask.scanned / viewTask.total) * 100).toFixed(1) : 0}%)</span>
                </div>
                <div className="w-full h-3 rounded-full overflow-hidden" style={{ background: 'var(--gray-2)' }}>
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${viewTask.total > 0 ? (viewTask.scanned / viewTask.total) * 100 : 0}%`,
                      background: 'var(--primary)',
                    }}
                  />
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" style={{ color: 'var(--success)' }} />
                  <span>已盘 {viewTask.scanned}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Minus className="w-4 h-4" style={{ color: 'var(--neutral-textSecondary)' }} />
                  <span>未盘 {viewTask.total - viewTask.scanned}</span>
                </div>
                <div className="flex items-center gap-1">
                  <AlertTriangle className="w-4 h-4" style={{ color: 'var(--warning)' }} />
                  <span>差异 {diffs.filter((d) => d.taskId === viewTask.id).length}</span>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewTaskOpen(false)}>关闭</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== 对话框：差异处理 ===== */}
      <Dialog open={diffActionOpen} onOpenChange={setDiffActionOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {diffActionType === 'confirm' && <CheckCircle className="w-5 h-5" style={{ color: 'var(--success)' }} />}
              {diffActionType === 'process' && <RotateCcw className="w-5 h-5" style={{ color: 'var(--info)' }} />}
              {diffActionType === 'reject' && <XCircle className="w-5 h-5" style={{ color: 'var(--danger)' }} />}
              {diffActionType === 'confirm' && '确认差异处理'}
              {diffActionType === 'process' && '开始处理差异'}
              {diffActionType === 'reject' && '驳回差异记录'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedDiffId && (
              <div className="p-3 rounded-lg text-sm" style={{ background: 'var(--gray-1)' }}>
                <div className="flex items-center gap-2 mb-1">
                  <PackageCheck className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span className="font-medium">{diffs.find((d) => d.id === selectedDiffId)?.carrierCode}</span>
                </div>
                <div className="text-xs" style={{ color: 'var(--neutral-textSecondary)' }}>
                  差异类型：{diffs.find((d) => d.id === selectedDiffId)?.diffType} |
                  系统位置：{diffs.find((d) => d.id === selectedDiffId)?.systemSite} |
                  实际位置：{diffs.find((d) => d.id === selectedDiffId)?.actualSite}
                </div>
              </div>
            )}
            <div className="space-y-2">
              <Label>处理备注</Label>
              <Textarea placeholder="请输入处理备注说明..." value={diffRemark} onChange={(e) => setDiffRemark(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDiffActionOpen(false)}>取消</Button>
            <Button onClick={handleDiffActionConfirm}>确认</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ===== 对话框：报告预览 ===== */}
      <Dialog open={reportPreviewOpen} onOpenChange={setReportPreviewOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              盘点报告预览
            </DialogTitle>
          </DialogHeader>
          {reportTask && (
            <div className="space-y-6 py-4">
              {/* 报告头部 */}
              <div className="text-center border-b pb-4" style={{ borderColor: 'var(--gray-3)' }}>
                <h2 className="text-xl font-bold mb-1">载具盘点报告</h2>
                <p className="text-sm" style={{ color: 'var(--neutral-textSecondary)' }}>报告编号：RP-{reportTask.id.slice(3)}</p>
              </div>

              {/* 基本信息 */}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>任务名称：</span>
                  <span className="font-medium">{reportTask.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>盘点范围：</span>
                  <span className="font-medium">{reportTask.scope}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>盘点方式：</span>
                  <span className="font-medium">{methodMap[reportTask.method]}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>负责人：</span>
                  <span className="font-medium">{reportTask.manager}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>完成日期：</span>
                  <span className="font-medium">{reportTask.plannedAt}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4" style={{ color: 'var(--primary)' }} />
                  <span style={{ color: 'var(--neutral-textSecondary)' }}>应盘数量：</span>
                  <span className="font-medium">{reportTask.total}</span>
                </div>
              </div>

              {/* 统计数据 */}
              <div className="grid grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold" style={{ color: 'var(--success)' }}>{reportTask.scanned}</div>
                    <div className="text-xs mt-1" style={{ color: 'var(--neutral-textSecondary)' }}>实盘数量</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold" style={{ color: 'var(--warning)' }}>
                      {diffs.filter((d) => d.taskId === reportTask.id).length}
                    </div>
                    <div className="text-xs mt-1" style={{ color: 'var(--neutral-textSecondary)' }}>差异数量</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold" style={{ color: 'var(--primary)' }}>
                      {reportTask.total > 0 ? ((diffs.filter((d) => d.taskId === reportTask.id).length / reportTask.total) * 100).toFixed(2) : '0.00'}%
                    </div>
                    <div className="text-xs mt-1" style={{ color: 'var(--neutral-textSecondary)' }}>差异率</div>
                  </CardContent>
                </Card>
              </div>

              {/* 差异明细摘要 */}
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" style={{ color: 'var(--warning)' }} />
                  差异明细摘要
                </h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">差异编号</TableHead>
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">差异类型</TableHead>
                      <TableHead className="text-xs">处理状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {diffs.filter((d) => d.taskId === reportTask.id).map((d) => (
                      <TableRow key={d.id}>
                        <TableCell className="text-xs py-2">{d.id}</TableCell>
                        <TableCell className="text-xs py-2">{d.carrierCode}</TableCell>
                        <TableCell className="text-xs py-2">
                          <Badge variant={d.diffType === '盘盈' ? 'default' : d.diffType === '盘亏' ? 'destructive' : 'secondary'} className="text-xs">
                            {d.diffType}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs py-2">
                          <span className={`text-xs px-2 py-0.5 rounded-full ${diffStatusMap[d.status].color}`}>
                            {diffStatusMap[d.status].label}
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                    {diffs.filter((d) => d.taskId === reportTask.id).length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-4 text-xs" style={{ color: 'var(--neutral-textSecondary)' }}>
                          本次盘点无差异记录
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setReportPreviewOpen(false)}>关闭</Button>
            <Button variant="outline">
              <Printer className="w-4 h-4 mr-2" />
              打印
            </Button>
            <Button>
              <Download className="w-4 h-4 mr-2" />
              导出 PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
