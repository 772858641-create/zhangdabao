import { useState, useEffect, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Truck, Container, Warehouse, AlertTriangle, ZoomIn, ZoomOut, Crosshair } from 'lucide-react';

const MAP_STYLE = { width: '100%', height: 'calc(100vh - 56px)', position: 'relative' as const, overflow: 'hidden' };

// 真实地图坐标数据（上海及周边）
const realCoords = {
  sites: [
    { id: 's1', name: '上海浦东仓库', lat: 31.2304, lng: 121.4737, count: 156, type: 'site' },
    { id: 's2', name: '苏州昆山工厂', lat: 31.3909, lng: 120.9807, count: 203, type: 'site' },
    { id: 's3', name: '深圳龙岗仓库', lat: 22.7209, lng: 114.2478, count: 178, type: 'site' },
    { id: 's4', name: '宁德生产基地', lat: 26.6787, lng: 119.5479, count: 134, type: 'site' },
  ],
  carriers: [
    { id: 'c1', name: 'CA-20250401-001', lat: 31.2804, lng: 121.5237, status: '在途', from: '上海浦东', to: '苏州昆山' },
    { id: 'c2', name: 'CA-20250401-002', lat: 31.3409, lng: 121.0807, status: '在途', from: '上海浦东', to: '苏州昆山' },
    { id: 'c3', name: 'CA-20250410-015', lat: 22.7709, lng: 114.2978, status: '在库', site: '深圳龙岗' },
  ],
  vehicles: [
    { id: 'v1', name: '沪A12345', lat: 31.3004, lng: 121.5037, driver: '王师傅', speed: '65km/h' },
    { id: 'v2', name: '沪B67890', lat: 31.3609, lng: 121.1207, driver: '李师傅', speed: '72km/h' },
  ],
  alarms: [
    { id: 'a1', name: 'ALM-001', lat: 31.2904, lng: 121.4837, level: '紧急', msg: '在途超时' },
  ],
};

// 坐标转屏幕位置（简化投影，以上海为中心）
function latLngToScreen(lat: number, lng: number, zoom: number, centerLat: number, centerLng: number, width: number, height: number) {
  const scale = Math.pow(2, zoom) * 256 / (40075016.686 / 360);
  const x = (lng - centerLng) * scale * (width / 256) + width / 2;
  const y = -(lat - centerLat) * scale * (width / 256) + height / 2;
  return { x, y };
}

export default function AmapPage() {
  const [baseMap, setBaseMap] = useState('standard');
  const [layers, setLayers] = useState({ carrier: true, vehicle: true, site: true, alarm: true, route: false });
  const [selectedMarker, setSelectedMarker] = useState<any>(null);
  const [zoom, setZoom] = useState(10);
  const [center, setCenter] = useState({ lat: 31.2304, lng: 121.4737 });
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapSize, setMapSize] = useState({ width: 1200, height: 800 });

  useEffect(() => {
    const updateSize = () => {
      if (mapRef.current) {
        setMapSize({ width: mapRef.current.clientWidth, height: mapRef.current.clientHeight });
      }
    };
    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  const toggleLayer = (key: string) => setLayers({ ...layers, [key]: !layers[key as keyof typeof layers] });

  const allMarkers = [
    ...realCoords.carriers.map(m => ({ ...m, type: 'carrier', color: '#2563EB', icon: Container })),
    ...realCoords.vehicles.map(m => ({ ...m, type: 'vehicle', color: '#10B981', icon: Truck })),
    ...realCoords.sites.map(m => ({ ...m, type: 'site', color: '#8B5CF6', icon: Warehouse })),
    ...realCoords.alarms.map(m => ({ ...m, type: 'alarm', color: '#EF4444', icon: AlertTriangle })),
  ].filter(m => layers[m.type as keyof typeof layers]);

  const getScreenPos = (lat: number, lng: number) => {
    return latLngToScreen(lat, lng, zoom, center.lat, center.lng, mapSize.width, mapSize.height);
  };

  const isInBounds = (x: number, y: number) => x > -50 && x < mapSize.width + 50 && y > -50 && y < mapSize.height + 50;

  // 模拟地图网格背景
  const gridOffsetX = ((center.lng * Math.pow(2, zoom) * 256 / 360) % 256);
  const gridOffsetY = ((center.lat * Math.pow(2, zoom) * 256 / 180) % 256);

  return (
    <div className="relative" style={MAP_STYLE} ref={mapRef}>
      {/* 真实地图模拟背景 */}
      <div className="absolute inset-0" style={{
        background: baseMap === 'satellite'
          ? 'linear-gradient(180deg, #1a3a2a 0%, #2d5a3d 30%, #1e4028 60%, #3d6b4a 100%)'
          : baseMap === 'light'
            ? '#f8fafc'
            : '#e8f4fd',
      }}>
        {/* 经纬度网格线 */}
        <svg className="absolute inset-0 w-full h-full" style={{ opacity: baseMap === 'satellite' ? 0.15 : 0.3 }}>
          {Array.from({ length: 12 }).map((_, i) => (
            <g key={i}>
              <line x1={0} y1={(i * 100 + gridOffsetY) % 100 + '%'} x2="100%" y2={(i * 100 + gridOffsetY) % 100 + '%'}
                stroke={baseMap === 'satellite' ? '#fff' : '#94a3b8'} strokeWidth="0.5" strokeDasharray="5,5" />
              <line x1={(i * 100 + gridOffsetX) % 100 + '%'} y1={0} x2={(i * 100 + gridOffsetX) % 100 + '%'} y2="100%"
                stroke={baseMap === 'satellite' ? '#fff' : '#94a3b8'} strokeWidth="0.5" strokeDasharray="5,5" />
            </g>
          ))}
        </svg>

        {/* 模拟道路 */}
        <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.7 }}>
          {/* 上海→苏州 高速 */}
          <path d={`M ${getScreenPos(31.2304, 121.4737).x} ${getScreenPos(31.2304, 121.4737).y} 
                    Q ${getScreenPos(31.31, 121.23).x} ${getScreenPos(31.31, 121.23).y} 
                      ${getScreenPos(31.3909, 120.9807).x} ${getScreenPos(31.3909, 120.9807).y}`}
            fill="none" stroke={baseMap === 'satellite' ? '#fbbf24' : '#f97316'} strokeWidth="4" opacity="0.8" />
          {/* 上海→杭州 */}
          <path d={`M ${getScreenPos(31.2304, 121.4737).x} ${getScreenPos(31.2304, 121.4737).y} 
                    Q ${getScreenPos(30.85, 121.0).x} ${getScreenPos(30.85, 121.0).y} 
                      ${getScreenPos(30.25, 120.2).x} ${getScreenPos(30.25, 120.2).y}`}
            fill="none" stroke={baseMap === 'satellite' ? '#fbbf24' : '#f97316'} strokeWidth="3" opacity="0.6" />
        </svg>

        {/* 城市标签 */}
        {realCoords.sites.map(site => {
          const pos = getScreenPos(site.lat, site.lng);
          if (!isInBounds(pos.x, pos.y)) return null;
          return (
            <div key={site.id} className="absolute text-xs font-medium pointer-events-none"
              style={{ left: pos.x, top: pos.y + 20, transform: 'translateX(-50%)', color: baseMap === 'satellite' ? '#fff' : '#1e293b', textShadow: baseMap === 'satellite' ? '0 1px 3px rgba(0,0,0,0.8)' : 'none' }}>
              {site.name}
            </div>
          );
        })}
      </div>

      {/* 地图标记点 */}
      {allMarkers.map(m => {
        const pos = getScreenPos(m.lat, m.lng);
        if (!isInBounds(pos.x, pos.y)) return null;
        const MarkerIcon = m.icon;
        return (
          <div key={m.id} className="absolute cursor-pointer transform -translate-x-1/2 -translate-y-full z-10 group"
            style={{ left: pos.x, top: pos.y }}
            onClick={() => setSelectedMarker(m)}>
            <div className="relative">
              <div className={`w-9 h-9 rounded-full flex items-center justify-center shadow-lg border-2 border-white transition-transform group-hover:scale-110`}
                style={{ backgroundColor: m.color }}>
                <MarkerIcon className="w-4 h-4 text-white" />
              </div>
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent"
                style={{ borderTopColor: m.color }} />
            </div>
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-white px-2 py-0.5 rounded shadow-md text-xs font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              {m.name}
            </div>
          </div>
        );
      })}

      {/* 标记详情弹窗 */}
      {selectedMarker && (
        <Card className="absolute z-30 shadow-xl" style={{
          left: Math.min(getScreenPos(selectedMarker.lat, selectedMarker.lng).x + 20, mapSize.width - 240),
          top: Math.max(getScreenPos(selectedMarker.lat, selectedMarker.lng).y - 120, 10),
          minWidth: 220,
        }}>
          <CardContent className="p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedMarker.color }} />
                {selectedMarker.name}
              </span>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setSelectedMarker(null)}>×</Button>
            </div>
            {selectedMarker.type === 'carrier' && <div className="text-sm space-y-1">
              <div>状态: <Badge variant="outline">{selectedMarker.status}</Badge></div>
              <div>起点: {selectedMarker.from}</div>
              <div>终点: {selectedMarker.to}</div>
              <div className="text-xs text-neutral-textTertiary">坐标: {selectedMarker.lat.toFixed(4)}, {selectedMarker.lng.toFixed(4)}</div>
            </div>}
            {selectedMarker.type === 'vehicle' && <div className="text-sm space-y-1">
              <div>司机: {selectedMarker.driver}</div>
              <div>速度: {selectedMarker.speed}</div>
              <div className="text-xs text-neutral-textTertiary">坐标: {selectedMarker.lat.toFixed(4)}, {selectedMarker.lng.toFixed(4)}</div>
            </div>}
            {selectedMarker.type === 'site' && <div className="text-sm space-y-1">
              <div>在库载具: {selectedMarker.count}个</div>
              <div className="text-xs text-neutral-textTertiary">坐标: {selectedMarker.lat.toFixed(4)}, {selectedMarker.lng.toFixed(4)}</div>
            </div>}
            {selectedMarker.type === 'alarm' && <div className="text-sm space-y-1">
              <div>级别: <Badge variant="destructive">{selectedMarker.level}</Badge></div>
              <div>{selectedMarker.msg}</div>
            </div>}
          </CardContent>
        </Card>
      )}

      {/* 顶部工具栏 */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-white/95 backdrop-blur rounded-lg shadow-lg p-2 flex items-center gap-2 z-20">
        <Select value={baseMap} onValueChange={setBaseMap}>
          <SelectTrigger className="w-[100px] h-8"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="standard">标准</SelectItem><SelectItem value="satellite">卫星</SelectItem><SelectItem value="light">浅色</SelectItem></SelectContent>
        </Select>
        <div className="h-6 w-px bg-gray-200" />
        <Button variant={layers.carrier ? 'default' : 'ghost'} size="sm" className="h-8" onClick={() => toggleLayer('carrier')}><Container className="w-4 h-4 mr-1" />载具</Button>
        <Button variant={layers.vehicle ? 'default' : 'ghost'} size="sm" className="h-8" onClick={() => toggleLayer('vehicle')}><Truck className="w-4 h-4 mr-1" />车辆</Button>
        <Button variant={layers.site ? 'default' : 'ghost'} size="sm" className="h-8" onClick={() => toggleLayer('site')}><Warehouse className="w-4 h-4 mr-1" />网点</Button>
        <Button variant={layers.alarm ? 'default' : 'ghost'} size="sm" className="h-8" onClick={() => toggleLayer('alarm')}><AlertTriangle className="w-4 h-4 mr-1" />报警</Button>
      </div>

      {/* 左侧筛选面板 */}
      <Card className="absolute top-16 left-4 w-[240px] z-20 shadow-lg">
        <CardContent className="p-4 space-y-3">
          <h3 className="font-medium text-sm">筛选器</h3>
          <Select><SelectTrigger className="h-8"><SelectValue placeholder="项目筛选" /></SelectTrigger><SelectContent><SelectItem value="all">全部项目</SelectItem><SelectItem value="sq">上汽乘用车</SelectItem><SelectItem value="catl">宁德时代</SelectItem></SelectContent></Select>
          <Select><SelectTrigger className="h-8"><SelectValue placeholder="组织筛选" /></SelectTrigger><SelectContent><SelectItem value="all">全部组织</SelectItem><SelectItem value="hd">华东运营中心</SelectItem><SelectItem value="hn">华南运营中心</SelectItem></SelectContent></Select>
          <Button variant="outline" size="sm" className="w-full h-8">重置筛选</Button>
        </CardContent>
      </Card>

      {/* 右侧统计面板 */}
      <Card className="absolute top-16 right-4 w-[200px] z-20 shadow-lg">
        <CardContent className="p-4 space-y-3">
          <h3 className="font-medium text-sm">实时统计</h3>
          <div className="flex justify-between text-sm"><span className="text-neutral-textSecondary">在途载具</span><span className="font-bold text-primary">156</span></div>
          <div className="flex justify-between text-sm"><span className="text-neutral-textSecondary">在途车辆</span><span className="font-bold text-success">42</span></div>
          <div className="flex justify-between text-sm"><span className="text-neutral-textSecondary">网点总数</span><span className="font-bold text-purple-500">8</span></div>
          <div className="flex justify-between text-sm"><span className="text-neutral-textSecondary">未处理报警</span><span className="font-bold text-danger">24</span></div>
        </CardContent>
      </Card>

      {/* 缩放控制 */}
      <div className="absolute bottom-8 right-4 flex flex-col gap-2 z-20">
        <Button variant="secondary" size="sm" className="w-10 h-10 p-0 shadow-lg" onClick={() => setZoom(Math.min(zoom + 1, 18))}><ZoomIn className="w-5 h-5" /></Button>
        <Button variant="secondary" size="sm" className="w-10 h-10 p-0 shadow-lg" onClick={() => setZoom(Math.max(zoom - 1, 5))}><ZoomOut className="w-5 h-5" /></Button>
        <Button variant="secondary" size="sm" className="w-10 h-10 p-0 shadow-lg" onClick={() => setCenter({ lat: 31.2304, lng: 121.4737 })}><Crosshair className="w-5 h-5" /></Button>
        <div className="bg-white rounded shadow-lg px-2 py-1 text-xs text-center font-medium">{zoom}x</div>
      </div>

      {/* 底部状态栏 */}
      <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur rounded px-3 py-1.5 text-xs text-neutral-textSecondary z-20 shadow">
        中心: {center.lat.toFixed(4)}, {center.lng.toFixed(4)} | 缩放: {zoom}x | 显示 {allMarkers.length} 个标记
      </div>
    </div>
  );
}
