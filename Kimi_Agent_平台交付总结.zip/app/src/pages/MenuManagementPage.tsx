import { useState, useMemo, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Container,
  ArrowLeftRight,
  Cpu,
  Warehouse,
  Bell,
  ShieldCheck,
  BarChart3,
  Settings,
  Plus,
  Edit3,
  Trash2,
  Download,
  CheckCircle,
  Search,
  ChevronRight,
  ChevronDown,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  GripVertical,
  X,
  Menu,
  ListTree,
  FileText,
  Save,
  Shield,
  Users,
  Building2,
  FolderOpen,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ─── Types ───
type MenuLevel = 1 | 2 | 3;
type MenuStatus = 'enabled' | 'hidden' | 'disabled';
type ConditionMatchType = 'any' | 'all';

interface MenuItem {
  id: string;
  name: string;
  code: string;
  icon: string;
  path: string;
  level: MenuLevel;
  parentId: string | null;
  sortOrder: number;
  status: MenuStatus;
  visibleRoles: string[];
  visibleOrgs: string[];
  visibleProjects: string[];
  conditionMatchType: ConditionMatchType;
  children?: MenuItem[];
}

// ─── Icon mapping ───
const ICON_MAP: Record<string, LucideIcon> = {
  LayoutDashboard, Container, ArrowLeftRight, Cpu, Warehouse, Bell, ShieldCheck, BarChart3, Settings,
  Plus, Edit3, Trash2, Download, CheckCircle, Search, Eye, EyeOff, FileText,
  Shield, Users, Building2, FolderOpen, Menu, ListTree, ArrowUp, ArrowDown, GripVertical,
};

const AVAILABLE_ICONS = [
  'LayoutDashboard', 'Container', 'ArrowLeftRight', 'Cpu', 'Warehouse', 'Bell',
  'ShieldCheck', 'BarChart3', 'Settings', 'Plus', 'Edit3', 'Trash2', 'Download',
  'CheckCircle', 'Search', 'Eye', 'EyeOff', 'FileText', 'Shield', 'Users',
  'Building2', 'FolderOpen', 'Menu', 'ListTree',
];

// ─── Constants ───
const STATUS_CONFIG: Record<MenuStatus, { color: string; bg: string; label: string; dot: string }> = {
  enabled: { color: '#10B981', bg: '#ECFDF5', label: '启用', dot: '#10B981' },
  hidden: { color: '#F59E0B', bg: '#FEF3C7', label: '隐藏', dot: '#F59E0B' },
  disabled: { color: '#EF4444', bg: '#FEF2F2', label: '禁用', dot: '#EF4444' },
};

const LEVEL_CONFIG: Record<MenuLevel, { color: string; bg: string; label: string }> = {
  1: { color: '#2563EB', bg: '#EFF6FF', label: '一级' },
  2: { color: '#8B5CF6', bg: '#F5F3FF', label: '二级' },
  3: { color: '#10B981', bg: '#ECFDF5', label: '三级' },
};

const ROLES = ['系统管理员', '组织管理员', '项目管理员', '调度员', '仓库管理员', '观察员', '司机'];
const ORGS = ['云载科技（总部）', '华东大区', '上海运营中心', '北京运营中心', '华东汽车制造', '南方物流集团', '北方供应链'];
const PROJECTS = ['华东汽车载具项目', '南方物流追踪项目', '北方供应链IoT项目', '全国调拨监控项目', '精准出入库试点'];

// ─── Tag component ───
function Tag({ label, color, bg }: { label: string; color: string; bg: string }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

// ─── Icon renderer ───
function IconRenderer({ name, size = 16, className, style }: { name: string; size?: number; className?: string; style?: React.CSSProperties }) {
  const Icon = ICON_MAP[name] || Menu;
  return <Icon size={size} className={className} style={style} />;
}

// ─── Mock data generation ───
function generateMockMenus(): MenuItem[] {
  const level1Defs = [
    { id: 'm-1', name: '数据看板', code: 'dashboard', icon: 'LayoutDashboard', path: '/dashboard', sortOrder: 1 },
    { id: 'm-2', name: '载具资产', code: 'carrier', icon: 'Container', path: '/vehicles', sortOrder: 2 },
    { id: 'm-3', name: '调拨流转', code: 'transfer', icon: 'ArrowLeftRight', path: '/transfers', sortOrder: 3 },
    { id: 'm-4', name: 'IoT设备', code: 'iot', icon: 'Cpu', path: '/devices', sortOrder: 4 },
    { id: 'm-5', name: '网点组织', code: 'site', icon: 'Warehouse', path: '/sites', sortOrder: 5 },
    { id: 'm-6', name: '报警中心', code: 'alarm', icon: 'Bell', path: '/alarms', sortOrder: 6 },
    { id: 'm-7', name: '精准出入库', code: 'inout', icon: 'ShieldCheck', path: '/inout-rules', sortOrder: 7 },
    { id: 'm-8', name: '运营中心', code: 'operation', icon: 'BarChart3', path: '/statistics', sortOrder: 8 },
    { id: 'm-9', name: '系统管理', code: 'system', icon: 'Settings', path: '/users', sortOrder: 9 },
  ];

  const level2Defs: Record<string, Array<{ id: string; name: string; code: string; icon: string; path: string }>> = {
    'm-1': [
      { id: 'm-1-1', name: '数据看板', code: 'dashboard_page', icon: 'LayoutDashboard', path: '/dashboard' },
      { id: 'm-1-2', name: '地图看板', code: 'map_page', icon: 'LayoutDashboard', path: '/map' },
      { id: 'm-1-3', name: '看板配置', code: 'dashboard_config', icon: 'Settings', path: '/dashboard-config' },
      { id: 'm-1-4', name: '框选操作', code: 'map_batch_ops', icon: 'LayoutDashboard', path: '/map-batch-ops' },
    ],
    'm-2': [
      { id: 'm-2-1', name: '载具管理', code: 'vehicles', icon: 'Container', path: '/vehicles' },
      { id: 'm-2-2', name: '载具型号', code: 'models', icon: 'Container', path: '/models' },
      { id: 'm-2-3', name: '载具分配', code: 'carrier_allocation', icon: 'ArrowLeftRight', path: '/carrier-allocation' },
      { id: 'm-2-4', name: '车辆管理', code: 'fleet', icon: 'Container', path: '/fleet' },
      { id: 'm-2-5', name: '物料管理', code: 'materials', icon: 'FileText', path: '/materials' },
      { id: 'm-2-6', name: '围栏联动', code: 'vehicle_fence', icon: 'ShieldCheck', path: '/vehicle-fence-inout' },
      { id: 'm-2-7', name: '解绑记录', code: 'unbind_records', icon: 'FileText', path: '/vehicle-unbind-records' },
      { id: 'm-2-8', name: '借用归还', code: 'borrow_return', icon: 'ArrowLeftRight', path: '/borrow-return' },
      { id: 'm-2-9', name: '过户管理', code: 'ownership', icon: 'FileText', path: '/transfers-ownership' },
    ],
    'm-3': [
      { id: 'm-3-1', name: '调拨管理', code: 'transfers', icon: 'ArrowLeftRight', path: '/transfers' },
      { id: 'm-3-2', name: '调拨审核', code: 'transfer_audit', icon: 'CheckCircle', path: '/transfer-audit' },
      { id: 'm-3-3', name: '轨迹回放', code: 'track_replay', icon: 'LayoutDashboard', path: '/transfer-track-replay' },
      { id: 'm-3-4', name: '发运状态', code: 'shipment', icon: 'ArrowLeftRight', path: '/shipment-status' },
      { id: 'm-3-5', name: '流转线路', code: 'routes', icon: 'LayoutDashboard', path: '/routes' },
      { id: 'm-3-6', name: '流转看板', code: 'route_dashboard', icon: 'BarChart3', path: '/route-dashboard' },
    ],
    'm-4': [
      { id: 'm-4-1', name: '设备管理', code: 'devices', icon: 'Cpu', path: '/devices' },
      { id: 'm-4-2', name: '设备指令', code: 'device_commands', icon: 'Cpu', path: '/device-commands' },
      { id: 'm-4-3', name: 'OTA升级', code: 'device_ota', icon: 'Cpu', path: '/device-ota' },
      { id: 'm-4-4', name: '设备影子', code: 'device_shadow', icon: 'Cpu', path: '/device-shadow' },
      { id: 'm-4-5', name: 'IoT数据中台', code: 'iot_platform', icon: 'BarChart3', path: '/iot-platform' },
      { id: 'm-4-6', name: '信标管理', code: 'beacon', icon: 'Cpu', path: '/beacon-management' },
    ],
    'm-5': [
      { id: 'm-5-1', name: '网点管理', code: 'sites', icon: 'Warehouse', path: '/sites' },
      { id: 'm-5-2', name: '组织网点聚合', code: 'org_site', icon: 'Building2', path: '/org-site-aggregation' },
      { id: 'm-5-3', name: '司机管理', code: 'drivers', icon: 'Users', path: '/drivers' },
    ],
    'm-6': [
      { id: 'm-6-1', name: '报警中心', code: 'alarms', icon: 'Bell', path: '/alarms' },
      { id: 'm-6-2', name: '报警工作流', code: 'alarm_workflow', icon: 'Bell', path: '/alarm-workflow' },
      { id: 'm-6-3', name: '报警分析', code: 'alarm_analysis', icon: 'BarChart3', path: '/alarm-analysis' },
      { id: 'm-6-4', name: '标签分离报警', code: 'tag_separation', icon: 'Bell', path: '/tag-separation' },
    ],
    'm-7': [
      { id: 'm-7-1', name: '出入库判定', code: 'inout_rules', icon: 'ShieldCheck', path: '/inout-rules' },
      { id: 'm-7-2', name: '库存盘点', code: 'inventory', icon: 'FileText', path: '/inventory-check' },
    ],
    'm-8': [
      { id: 'm-8-1', name: '数据统计', code: 'statistics', icon: 'BarChart3', path: '/statistics' },
      { id: 'm-8-2', name: '计费结算', code: 'billing', icon: 'BarChart3', path: '/billing' },
      { id: 'm-8-3', name: '项目管理', code: 'projects', icon: 'FolderOpen', path: '/projects' },
      { id: 'm-8-4', name: '消息中心', code: 'messages', icon: 'Bell', path: '/messages' },
      { id: 'm-8-5', name: '高德地图', code: 'amap', icon: 'LayoutDashboard', path: '/amap' },
    ],
    'm-9': [
      { id: 'm-9-1', name: '用户管理', code: 'users', icon: 'Users', path: '/users' },
      { id: 'm-9-2', name: '委托登录', code: 'delegate', icon: 'Shield', path: '/delegate-login' },
      { id: 'm-9-3', name: '字段权限', code: 'field_perm', icon: 'ShieldCheck', path: '/field-permissions' },
      { id: 'm-9-4', name: '微信小程序', code: 'wechat', icon: 'LayoutDashboard', path: '/wechat-miniprogram' },
      { id: 'm-9-5', name: '系统设置', code: 'settings', icon: 'Settings', path: '/settings' },
    ],
  };

  const level3Templates = [
    { name: '新增', code: 'create', icon: 'Plus' },
    { name: '编辑', code: 'edit', icon: 'Edit3' },
    { name: '删除', code: 'delete', icon: 'Trash2' },
    { name: '导出', code: 'export', icon: 'Download' },
    { name: '审批', code: 'approve', icon: 'CheckCircle' },
  ];

  const menus: MenuItem[] = level1Defs.map((m) => {
    const children: MenuItem[] = (level2Defs[m.id] || []).map((l2, idx) => {
      const l3Count = l2.code.includes('audit') || l2.code.includes('transfer') ? 5 : 4;
      const l3Children: MenuItem[] = level3Templates.slice(0, l3Count).map((tpl, i3) => ({
        id: `${l2.id}-${i3 + 1}`,
        name: `${tpl.name}${l2.name}`,
        code: `${l2.code}_${tpl.code}`,
        icon: tpl.icon,
        path: `${l2.path}/${tpl.code}`,
        level: 3,
        parentId: l2.id,
        sortOrder: i3 + 1,
        status: 'enabled' as MenuStatus,
        visibleRoles: ['系统管理员', '组织管理员'],
        visibleOrgs: ['云载科技（总部）'],
        visibleProjects: [],
        conditionMatchType: 'any',
      }));

      return {
        id: l2.id,
        name: l2.name,
        code: l2.code,
        icon: l2.icon,
        path: l2.path,
        level: 2,
        parentId: m.id,
        sortOrder: idx + 1,
        status: 'enabled' as MenuStatus,
        visibleRoles: ['系统管理员', '组织管理员', '项目管理员', '调度员', '仓库管理员', '观察员'],
        visibleOrgs: ORGS,
        visibleProjects: PROJECTS,
        conditionMatchType: 'any',
        children: l3Children,
      };
    });

    return {
      id: m.id,
      name: m.name,
      code: m.code,
      icon: m.icon,
      path: m.path,
      level: 1,
      parentId: null,
      sortOrder: m.sortOrder,
      status: 'enabled' as MenuStatus,
      visibleRoles: ROLES,
      visibleOrgs: ORGS,
      visibleProjects: PROJECTS,
      conditionMatchType: 'any',
      children,
    };
  });

  return menus;
}

const INITIAL_MENUS = generateMockMenus();

// ─── Flatten menu tree for searching ───
function flattenMenus(menus: MenuItem[]): MenuItem[] {
  const result: MenuItem[] = [];
  function walk(items: MenuItem[]) {
    items.forEach((item) => {
      result.push(item);
      if (item.children) walk(item.children);
    });
  }
  walk(menus);
  return result;
}

// ─── Menu Tree Node ───
function MenuTreeNode({
  menu,
  depth,
  selectedId,
  onSelect,
  onToggleExpand,
  expandedIds,
  onMoveUp,
  onMoveDown,
  isFirst,
  isLast,
}: {
  menu: MenuItem;
  depth: number;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onToggleExpand: (id: string) => void;
  expandedIds: Set<string>;
  onMoveUp: (id: string) => void;
  onMoveDown: (id: string) => void;
  isFirst: boolean;
  isLast: boolean;
}) {
  const isExpanded = expandedIds.has(menu.id);
  const hasChildren = menu.children && menu.children.length > 0;
  const isSelected = selectedId === menu.id;
  const statusCfg = STATUS_CONFIG[menu.status];
  const levelCfg = LEVEL_CONFIG[menu.level];

  return (
    <div>
      <div
        className={cn(
          'flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors group border border-transparent',
          isSelected ? 'bg-[#EFF6FF] border-[#BFDBFE]' : 'hover:bg-[#F8FAFC]'
        )}
        style={{ paddingLeft: `${12 + depth * 24}px` }}
        onClick={() => onSelect(menu.id)}
      >
        {/* Expand/Collapse button */}
        {hasChildren ? (
          <button
            onClick={(e) => { e.stopPropagation(); onToggleExpand(menu.id); }}
            className="w-5 h-5 rounded flex items-center justify-center hover:bg-[#E2E8F0] transition-colors flex-shrink-0"
          >
            {isExpanded ? (
              <ChevronDown size={14} className="text-[#475569]" />
            ) : (
              <ChevronRight size={14} className="text-[#475569]" />
            )}
          </button>
        ) : (
          <span className="w-5 flex-shrink-0" />
        )}

        {/* Icon */}
        <div
          className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${levelCfg.color}15` }}
        >
          <IconRenderer name={menu.icon} size={14} className="text-[#475569]" style={{ color: levelCfg.color } as React.CSSProperties} />
        </div>

        {/* Name & info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={cn('text-sm font-medium', isSelected ? 'text-[#2563EB]' : 'text-[#0F172A]')}>
              {menu.name}
            </span>
            <Tag label={levelCfg.label} color={levelCfg.color} bg={levelCfg.bg} />
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-xs text-[#94A3B8] font-mono">{menu.code}</span>
            {menu.status !== 'enabled' && (
              <span className="text-xs" style={{ color: statusCfg.color }}>{statusCfg.label}</span>
            )}
          </div>
        </div>

        {/* Sort controls */}
        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
          <button
            onClick={(e) => { e.stopPropagation(); onMoveUp(menu.id); }}
            disabled={isFirst}
            className="w-6 h-6 rounded hover:bg-[#E2E8F0] flex items-center justify-center disabled:opacity-30"
            title="上移"
          >
            <ArrowUp size={12} className="text-[#475569]" />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); onMoveDown(menu.id); }}
            disabled={isLast}
            className="w-6 h-6 rounded hover:bg-[#E2E8F0] flex items-center justify-center disabled:opacity-30"
            title="下移"
          >
            <ArrowDown size={12} className="text-[#475569]" />
          </button>
        </div>

        {/* Status dot */}
        <div
          className="w-2 h-2 rounded-full flex-shrink-0"
          style={{ backgroundColor: statusCfg.dot }}
          title={statusCfg.label}
        />
      </div>

      {/* Children */}
      <AnimatePresence initial={false}>
        {isExpanded && hasChildren && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            {menu.children!.map((child, idx, arr) => (
              <MenuTreeNode
                key={child.id}
                menu={child}
                depth={depth + 1}
                selectedId={selectedId}
                onSelect={onSelect}
                onToggleExpand={onToggleExpand}
                expandedIds={expandedIds}
                onMoveUp={onMoveUp}
                onMoveDown={onMoveDown}
                isFirst={idx === 0}
                isLast={idx === arr.length - 1}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Menu Detail Panel ───
function MenuDetailPanel({
  menu,
  onUpdate,
}: {
  menu: MenuItem | null;
  onUpdate: (menu: MenuItem) => void;
}) {
  const [editMode, setEditMode] = useState(false);
  const [form, setForm] = useState<MenuItem | null>(menu);

  // Sync form when menu changes
  useEffect(() => {
    setForm(menu);
    setEditMode(false);
  }, [menu]);

  if (!menu) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-[#94A3B8]">
        <ListTree size={48} className="mb-3 opacity-50" />
        <p className="text-sm">请在左侧选择菜单项查看详情</p>
      </div>
    );
  }

  const statusCfg = STATUS_CONFIG[menu.status];
  const levelCfg = LEVEL_CONFIG[menu.level];

  const handleSave = () => {
    if (form) {
      onUpdate(form);
      setEditMode(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${levelCfg.color}15` }}
          >
            <IconRenderer name={menu.icon} size={20} style={{ color: levelCfg.color } as React.CSSProperties} />
          </div>
          <div>
            <h3 className="text-base font-semibold text-[#0F172A]">{menu.name}</h3>
            <p className="text-xs text-[#94A3B8] font-mono">{menu.code}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {editMode ? (
            <>
              <button
                onClick={() => setEditMode(false)}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC]"
              >
                取消
              </button>
              <button
                onClick={handleSave}
                className="h-8 px-3 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-1"
              >
                <Save size={13} /> 保存
              </button>
            </>
          ) : (
            <button
              onClick={() => setEditMode(true)}
              className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center gap-1"
            >
              <Edit3 size={13} /> 编辑
            </button>
          )}
        </div>
      </div>

      {/* Basic Info */}
      <div className="space-y-4">
        <h4 className="text-sm font-semibold text-[#0F172A] border-b border-[#E2E8F0] pb-2">基本信息</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">菜单名称</label>
            {editMode ? (
              <input
                value={form?.name || ''}
                onChange={(e) => setForm(prev => prev ? { ...prev, name: e.target.value } : null)}
                className="w-full h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
              />
            ) : (
              <p className="text-sm text-[#0F172A]">{menu.name}</p>
            )}
          </div>
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">菜单编码</label>
            {editMode ? (
              <input
                value={form?.code || ''}
                onChange={(e) => setForm(prev => prev ? { ...prev, code: e.target.value } : null)}
                className="w-full h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
              />
            ) : (
              <p className="text-sm text-[#0F172A] font-mono">{menu.code}</p>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">图标</label>
            {editMode ? (
              <select
                value={form?.icon || ''}
                onChange={(e) => setForm(prev => prev ? { ...prev, icon: e.target.value } : null)}
                className="w-full h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
              >
                {AVAILABLE_ICONS.map(icon => (
                  <option key={icon} value={icon}>{icon}</option>
                ))}
              </select>
            ) : (
              <div className="flex items-center gap-2">
                <IconRenderer name={menu.icon} size={16} />
                <span className="text-sm text-[#475569]">{menu.icon}</span>
              </div>
            )}
          </div>
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">路径/标识</label>
            {editMode ? (
              <input
                value={form?.path || ''}
                onChange={(e) => setForm(prev => prev ? { ...prev, path: e.target.value } : null)}
                className="w-full h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
              />
            ) : (
              <p className="text-sm text-[#0F172A] font-mono">{menu.path}</p>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">菜单级别</label>
            <Tag label={levelCfg.label} color={levelCfg.color} bg={levelCfg.bg} />
          </div>
          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">排序号</label>
            {editMode ? (
              <input
                type="number"
                value={form?.sortOrder || 0}
                onChange={(e) => setForm(prev => prev ? { ...prev, sortOrder: parseInt(e.target.value) || 0 } : null)}
                className="w-full h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB]"
              />
            ) : (
              <p className="text-sm text-[#0F172A]">{menu.sortOrder}</p>
            )}
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-[#475569] mb-1">状态</label>
          {editMode ? (
            <div className="flex items-center gap-3">
              {(['enabled', 'hidden', 'disabled'] as MenuStatus[]).map((s) => (
                <label key={s} className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="status"
                    checked={form?.status === s}
                    onChange={() => setForm(prev => prev ? { ...prev, status: s } : null)}
                    className="w-4 h-4 text-[#2563EB]"
                  />
                  <Tag label={STATUS_CONFIG[s].label} color={STATUS_CONFIG[s].color} bg={STATUS_CONFIG[s].bg} />
                </label>
              ))}
            </div>
          ) : (
            <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
          )}
        </div>
      </div>

      {/* Visibility Conditions */}
      <div className="space-y-4">
        <h4 className="text-sm font-semibold text-[#0F172A] border-b border-[#E2E8F0] pb-2">可见性条件</h4>
        <div>
          <label className="block text-xs font-medium text-[#475569] mb-1">条件匹配方式</label>
          {editMode ? (
            <select
              value={form?.conditionMatchType || 'any'}
              onChange={(e) => setForm(prev => prev ? { ...prev, conditionMatchType: e.target.value as ConditionMatchType } : null)}
              className="h-8 px-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
            >
              <option value="any">满足任一条件即可见</option>
              <option value="all">需满足全部条件</option>
            </select>
          ) : (
            <p className="text-sm text-[#0F172A]">
              {menu.conditionMatchType === 'any' ? '满足任一条件即可见' : '需满足全部条件'}
            </p>
          )}
        </div>
        <div>
          <label className="block text-xs font-medium text-[#475569] mb-1">按角色可见</label>
          <div className="flex flex-wrap gap-2">
            {ROLES.map((role) => {
              const checked = menu.visibleRoles.includes(role);
              return (
                <span
                  key={role}
                  className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded text-xs',
                    checked ? 'bg-[#EFF6FF] text-[#2563EB]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                  )}
                >
                  {role}
                </span>
              );
            })}
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-[#475569] mb-1">按组织可见</label>
          <div className="flex flex-wrap gap-2">
            {ORGS.map((org) => {
              const checked = menu.visibleOrgs.includes(org);
              return (
                <span
                  key={org}
                  className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded text-xs',
                    checked ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                  )}
                >
                  {org}
                </span>
              );
            })}
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-[#475569] mb-1">按项目可见</label>
          <div className="flex flex-wrap gap-2">
            {PROJECTS.map((proj) => {
              const checked = menu.visibleProjects.includes(proj);
              return (
                <span
                  key={proj}
                  className={cn(
                    'inline-flex items-center px-2 py-0.5 rounded text-xs',
                    checked ? 'bg-[#F5F3FF] text-[#8B5CF6]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                  )}
                >
                  {proj}
                </span>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Menu Edit Modal ───
function MenuEditModal({
  menu,
  parentOptions,
  onClose,
  onSave,
}: {
  menu: MenuItem | null;
  parentOptions: Array<{ id: string; name: string; level: MenuLevel }>;
  onClose: () => void;
  onSave: (menu: MenuItem) => void;
}) {
  const isEdit = !!menu;
  const [form, setForm] = useState<Partial<MenuItem>>({
    name: menu?.name || '',
    code: menu?.code || '',
    icon: menu?.icon || 'LayoutDashboard',
    path: menu?.path || '',
    level: menu?.level || 1,
    parentId: menu?.parentId || null,
    sortOrder: menu?.sortOrder || 1,
    status: menu?.status || 'enabled',
    visibleRoles: menu?.visibleRoles || [],
    visibleOrgs: menu?.visibleOrgs || [],
    visibleProjects: menu?.visibleProjects || [],
    conditionMatchType: menu?.conditionMatchType || 'any',
  });

  const updateForm = <K extends keyof MenuItem>(key: K, value: MenuItem[K]) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const toggleArray = (key: 'visibleRoles' | 'visibleOrgs' | 'visibleProjects', value: string) => {
    setForm(prev => {
      const arr = (prev[key] || []) as string[];
      const next = arr.includes(value) ? arr.filter(v => v !== value) : [...arr, value];
      return { ...prev, [key]: next };
    });
  };

  const handleSave = () => {
    const newMenu: MenuItem = {
      id: menu?.id || `m-${Date.now()}`,
      name: form.name || '',
      code: form.code || '',
      icon: form.icon || 'LayoutDashboard',
      path: form.path || '',
      level: (form.level || 1) as MenuLevel,
      parentId: form.parentId || null,
      sortOrder: form.sortOrder || 1,
      status: (form.status || 'enabled') as MenuStatus,
      visibleRoles: form.visibleRoles || [],
      visibleOrgs: form.visibleOrgs || [],
      visibleProjects: form.visibleProjects || [],
      conditionMatchType: (form.conditionMatchType || 'any') as ConditionMatchType,
    };
    onSave(newMenu);
    onClose();
  };

  const level = form.level || 1;
  const filteredParents = parentOptions.filter(p =>
    level === 2 ? p.level === 1 : level === 3 ? p.level === 2 : false
  );

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-[5%] -translate-x-1/2 w-[640px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[90vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">{isEdit ? '编辑菜单' : '新增菜单'}</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 space-y-5 overflow-y-auto flex-1">
            {/* Basic info */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">菜单名称 <span className="text-[#EF4444]">*</span></label>
                <input
                  value={form.name || ''}
                  onChange={(e) => updateForm('name', e.target.value)}
                  placeholder="请输入菜单名称"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">菜单编码 <span className="text-[#EF4444]">*</span></label>
                <input
                  value={form.code || ''}
                  onChange={(e) => updateForm('code', e.target.value)}
                  placeholder="请输入菜单编码"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">图标</label>
                <select
                  value={form.icon || ''}
                  onChange={(e) => updateForm('icon', e.target.value)}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  {AVAILABLE_ICONS.map(icon => (
                    <option key={icon} value={icon}>{icon}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">路径/标识</label>
                <input
                  value={form.path || ''}
                  onChange={(e) => updateForm('path', e.target.value)}
                  placeholder="请输入路径"
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">菜单级别</label>
                <select
                  value={level}
                  onChange={(e) => updateForm('level', parseInt(e.target.value) as MenuLevel)}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value={1}>一级菜单（页面组）</option>
                  <option value={2}>二级菜单（页面）</option>
                  <option value={3}>三级菜单（功能按钮）</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">排序号</label>
                <input
                  type="number"
                  value={form.sortOrder || 0}
                  onChange={(e) => updateForm('sortOrder', parseInt(e.target.value) || 0)}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
                />
              </div>
            </div>
            {level > 1 && (
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">父级菜单</label>
                <select
                  value={form.parentId || ''}
                  onChange={(e) => updateForm('parentId', e.target.value || null)}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value="">请选择父级菜单</option>
                  {filteredParents.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">状态</label>
              <div className="flex items-center gap-4">
                {(['enabled', 'hidden', 'disabled'] as MenuStatus[]).map((s) => (
                  <label key={s} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="modal-status"
                      checked={form.status === s}
                      onChange={() => updateForm('status', s)}
                      className="w-4 h-4 text-[#2563EB]"
                    />
                    <span className="text-sm text-[#475569]">{STATUS_CONFIG[s].label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Visibility */}
            <div className="border-t border-[#E2E8F0] pt-4 space-y-4">
              <h4 className="text-sm font-semibold text-[#0F172A]">可见性条件配置</h4>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">条件匹配方式</label>
                <select
                  value={form.conditionMatchType || 'any'}
                  onChange={(e) => updateForm('conditionMatchType', e.target.value as ConditionMatchType)}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value="any">满足任一条件即可见</option>
                  <option value="all">需满足全部条件</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-2">按角色可见</label>
                <div className="flex flex-wrap gap-2">
                  {ROLES.map((role) => {
                    const checked = (form.visibleRoles || []).includes(role);
                    return (
                      <button
                        key={role}
                        onClick={() => toggleArray('visibleRoles', role)}
                        className={cn(
                          'px-2.5 py-1 rounded-md text-xs transition-colors border',
                          checked
                            ? 'bg-[#EFF6FF] text-[#2563EB] border-[#BFDBFE]'
                            : 'bg-white text-[#475569] border-[#E2E8F0] hover:bg-[#F8FAFC]'
                        )}
                      >
                        {role}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-2">按组织可见</label>
                <div className="flex flex-wrap gap-2">
                  {ORGS.map((org) => {
                    const checked = (form.visibleOrgs || []).includes(org);
                    return (
                      <button
                        key={org}
                        onClick={() => toggleArray('visibleOrgs', org)}
                        className={cn(
                          'px-2.5 py-1 rounded-md text-xs transition-colors border',
                          checked
                            ? 'bg-[#ECFDF5] text-[#10B981] border-[#A7F3D0]'
                            : 'bg-white text-[#475569] border-[#E2E8F0] hover:bg-[#F8FAFC]'
                        )}
                      >
                        {org}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-2">按项目可见</label>
                <div className="flex flex-wrap gap-2">
                  {PROJECTS.map((proj) => {
                    const checked = (form.visibleProjects || []).includes(proj);
                    return (
                      <button
                        key={proj}
                        onClick={() => toggleArray('visibleProjects', proj)}
                        className={cn(
                          'px-2.5 py-1 rounded-md text-xs transition-colors border',
                          checked
                            ? 'bg-[#F5F3FF] text-[#8B5CF6] border-[#DDD6FE]'
                            : 'bg-white text-[#475569] border-[#E2E8F0] hover:bg-[#F8FAFC]'
                        )}
                      >
                        {proj}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
            <button onClick={handleSave} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存</button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

// ─── Permission Matrix Panel ───
function PermissionMatrixPanel() {
  const modules = [
    { key: 'dashboard', label: '数据看板' },
    { key: 'carrier', label: '载具资产' },
    { key: 'transfer', label: '调拨流转' },
    { key: 'iot', label: 'IoT设备' },
    { key: 'site', label: '网点组织' },
    { key: 'alarm', label: '报警中心' },
    { key: 'inout', label: '精准出入库' },
    { key: 'operation', label: '运营中心' },
    { key: 'system', label: '系统管理' },
  ];

  const roleMatrix: Record<string, string[]> = {
    '系统管理员': modules.map(m => m.key),
    '组织管理员': ['dashboard', 'carrier', 'transfer', 'iot', 'site', 'alarm', 'inout', 'operation', 'system'],
    '项目管理员': ['dashboard', 'carrier', 'transfer', 'iot', 'site', 'alarm', 'operation'],
    '调度员': ['dashboard', 'carrier', 'transfer', 'alarm'],
    '仓库管理员': ['carrier', 'site', 'inout', 'alarm'],
    '观察员': ['dashboard', 'carrier', 'transfer', 'iot', 'site', 'alarm', 'operation'],
    '司机': ['dashboard', 'transfer'],
  };

  return (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-[#0F172A] border-b border-[#E2E8F0] pb-2">菜单权限矩阵</h4>
      <p className="text-xs text-[#94A3B8]">角色获得某模块权限时，对应菜单自动可见。高亮表示该角色拥有此模块权限。</p>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#F1F5F9]">
              <th className="px-2 py-2 text-left text-xs font-medium text-[#475569]">角色</th>
              {modules.map(m => (
                <th key={m.key} className="px-2 py-2 text-center text-xs font-medium text-[#475569] w-16">{m.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Object.entries(roleMatrix).map(([role, perms], idx) => (
              <motion.tr
                key={role}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.15, delay: idx * 0.03 }}
                className="border-b border-[#E2E8F0] hover:bg-[#F8FAFC]"
              >
                <td className="px-2 py-2 font-medium text-[#0F172A]">{role}</td>
                {modules.map(m => {
                  const hasPerm = perms.includes(m.key);
                  return (
                    <td key={m.key} className="px-2 py-2 text-center">
                      {hasPerm ? (
                        <CheckCircle size={14} className="text-[#10B981] mx-auto" />
                      ) : (
                        <span className="text-[#CBD5E1]">—</span>
                      )}
                    </td>
                  );
                })}
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Main Page ───
export default function MenuManagementPage() {
  const [menus, setMenus] = useState<MenuItem[]>(INITIAL_MENUS);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(INITIAL_MENUS.map(m => m.id)));
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingMenu, setEditingMenu] = useState<MenuItem | null>(null);

  // Flatten all menus for search & parent options
  const allMenus = useMemo(() => flattenMenus(menus), [menus]);

  // Find selected menu
  const selectedMenu = useMemo(() => allMenus.find(m => m.id === selectedId) || null, [allMenus, selectedId]);

  // Parent options for modal
  const parentOptions = useMemo(() => {
    return allMenus.filter(m => m.level === 1 || m.level === 2).map(m => ({ id: m.id, name: m.name, level: m.level }));
  }, [allMenus]);

  // Filtered menus for tree display
  const filteredMenus = useMemo(() => {
    if (!search && statusFilter === 'all') return menus;
    const searchLower = search.toLowerCase();
    const filterFn = (m: MenuItem): boolean => {
      const matchSearch = !search || m.name.toLowerCase().includes(searchLower) || m.code.toLowerCase().includes(searchLower);
      const matchStatus = statusFilter === 'all' || m.status === statusFilter;
      return matchSearch && matchStatus;
    };
    // Filter recursively, keeping parent if any child matches
    const mapFn = (m: MenuItem): MenuItem | null => {
      const children = m.children?.map(mapFn).filter(Boolean) as MenuItem[] | undefined;
      const selfMatch = filterFn(m);
      if (selfMatch || (children && children.length > 0)) {
        return { ...m, children };
      }
      return null;
    };
    return menus.map(mapFn).filter(Boolean) as MenuItem[];
  }, [menus, search, statusFilter]);

  // Stats
  const stats = useMemo(() => {
    const l1 = allMenus.filter(m => m.level === 1).length;
    const l2 = allMenus.filter(m => m.level === 2).length;
    const l3 = allMenus.filter(m => m.level === 3).length;
    return { l1, l2, l3, total: allMenus.length };
  }, [allMenus]);

  // Handlers
  const handleToggleExpand = useCallback((id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleMoveUp = useCallback((id: string) => {
    setMenus(prev => {
      // Find parent and reorder within siblings
      const reorder = (items: MenuItem[]): MenuItem[] => {
        const idx = items.findIndex(m => m.id === id);
        if (idx > 0) {
          const next = [...items];
          [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
          return next.map((m, i) => ({ ...m, sortOrder: i + 1 }));
        }
        // Check children recursively
        return items.map(m => ({
          ...m,
          children: m.children ? reorder(m.children) : undefined,
        }));
      };
      return reorder(prev);
    });
  }, []);

  const handleMoveDown = useCallback((id: string) => {
    setMenus(prev => {
      const reorder = (items: MenuItem[]): MenuItem[] => {
        const idx = items.findIndex(m => m.id === id);
        if (idx >= 0 && idx < items.length - 1) {
          const next = [...items];
          [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
          return next.map((m, i) => ({ ...m, sortOrder: i + 1 }));
        }
        return items.map(m => ({
          ...m,
          children: m.children ? reorder(m.children) : undefined,
        }));
      };
      return reorder(prev);
    });
  }, []);

  const handleUpdate = useCallback((updated: MenuItem) => {
    setMenus(prev => {
      const updateInTree = (items: MenuItem[]): MenuItem[] => {
        return items.map(m => {
          if (m.id === updated.id) {
            // Preserve children if not provided in update
            return { ...updated, children: updated.children || m.children };
          }
          return {
            ...m,
            children: m.children ? updateInTree(m.children) : undefined,
          };
        });
      };
      return updateInTree(prev);
    });
  }, []);

  const handleSaveModal = useCallback((menu: MenuItem) => {
    if (editingMenu) {
      handleUpdate(menu);
    } else {
      // Add new menu
      setMenus(prev => {
        if (menu.parentId) {
          return prev.map(m => {
            if (m.id === menu.parentId) {
              return { ...m, children: [...(m.children || []), menu] };
            }
            return {
              ...m,
              children: m.children ? m.children.map(c => {
                if (c.id === menu.parentId) {
                  return { ...c, children: [...(c.children || []), menu] };
                }
                return c;
              }) : undefined,
            };
          });
        }
        return [...prev, menu];
      });
    }
    setShowModal(false);
    setEditingMenu(null);
  }, [editingMenu, handleUpdate]);

  const handleDelete = useCallback((id: string) => {
    if (confirm('确定要删除此菜单吗？')) {
      setMenus(prev => {
        const removeFromTree = (items: MenuItem[]): MenuItem[] => {
          return items
            .filter(m => m.id !== id)
            .map(m => ({
              ...m,
              children: m.children ? removeFromTree(m.children) : undefined,
            }));
        };
        return removeFromTree(prev);
      });
      if (selectedId === id) setSelectedId(null);
    }
  }, [selectedId]);

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#0F172A] mb-1">菜单管理</h1>
        <p className="text-sm text-[#94A3B8]">配置系统导航菜单结构、可见性条件与权限联动</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { title: '一级菜单', value: stats.l1, color: '#2563EB', icon: FolderOpen },
          { title: '二级菜单', value: stats.l2, color: '#8B5CF6', icon: ListTree },
          { title: '三级菜单', value: stats.l3, color: '#10B981', icon: Menu },
          { title: '菜单总数', value: stats.total, color: '#F59E0B', icon: LayoutDashboard },
        ].map((kpi) => (
          <div key={kpi.title} className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${kpi.color}15` }}>
              <kpi.icon size={20} style={{ color: kpi.color }} />
            </div>
            <div>
              <p className="text-xs text-[#475569] mb-1">{kpi.title}</p>
              <p className="text-[28px] font-semibold text-[#0F172A] leading-tight">{kpi.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <button
          onClick={() => { setEditingMenu(null); setShowModal(true); }}
          className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors"
        >
          <Plus size={15} /> 新增菜单
        </button>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          <option value="all">全部状态</option>
          <option value="enabled">启用</option>
          <option value="hidden">隐藏</option>
          <option value="disabled">禁用</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="搜索菜单名称、编码..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
      </div>

      {/* Main Content: Left tree + Right detail */}
      <div className="flex gap-5">
        {/* Left: Tree Table */}
        <div className="flex-1 bg-white rounded-lg shadow-card p-4 min-h-[600px]">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-[#0F172A]">菜单树形列表</h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setExpandedIds(new Set(allMenus.map(m => m.id)))}
                className="text-xs text-[#2563EB] hover:underline"
              >
                全部展开
              </button>
              <span className="text-[#CBD5E1]">|</span>
              <button
                onClick={() => setExpandedIds(new Set())}
                className="text-xs text-[#2563EB] hover:underline"
              >
                全部折叠
              </button>
            </div>
          </div>
          <div className="space-y-0.5">
            {filteredMenus.map((menu, idx, arr) => (
              <MenuTreeNode
                key={menu.id}
                menu={menu}
                depth={0}
                selectedId={selectedId}
                onSelect={setSelectedId}
                onToggleExpand={handleToggleExpand}
                expandedIds={expandedIds}
                onMoveUp={handleMoveUp}
                onMoveDown={handleMoveDown}
                isFirst={idx === 0}
                isLast={idx === arr.length - 1}
              />
            ))}
            {filteredMenus.length === 0 && (
              <div className="py-16 text-center">
                <ListTree size={48} className="text-[#CBD5E1] mx-auto mb-3" />
                <p className="text-sm text-[#475569]">暂无匹配的菜单数据</p>
              </div>
            )}
          </div>
        </div>

        {/* Right: Detail Panel */}
        <div className="w-[380px] flex-shrink-0 bg-white rounded-lg shadow-card p-5 min-h-[600px]">
          <MenuDetailPanel menu={selectedMenu} onUpdate={handleUpdate} />
          {/* Permission Matrix */}
          <div className="mt-6 pt-6 border-t border-[#E2E8F0]">
            <PermissionMatrixPanel />
          </div>
          {/* Actions for selected menu */}
          {selectedMenu && (
            <div className="mt-6 pt-4 border-t border-[#E2E8F0] flex items-center gap-2">
              <button
                onClick={() => { setEditingMenu(selectedMenu); setShowModal(true); }}
                className="flex-1 h-9 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] flex items-center justify-center gap-1"
              >
                <Edit3 size={13} /> 编辑菜单
              </button>
              <button
                onClick={() => handleDelete(selectedMenu.id)}
                className="flex-1 h-9 rounded-md border border-[#FECACA] text-sm text-[#EF4444] hover:bg-[#FEF2F2] flex items-center justify-center gap-1"
              >
                <Trash2 size={13} /> 删除菜单
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <MenuEditModal
          menu={editingMenu}
          parentOptions={parentOptions}
          onClose={() => { setShowModal(false); setEditingMenu(null); }}
          onSave={handleSaveModal}
        />
      )}
    </div>
  );
}
