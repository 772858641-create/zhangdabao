import { useState, useMemo, useCallback } from 'react';
import type { Site } from '@/lib/mockData';
import { useMockData } from '@/hooks/useMockData';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerClose,
} from '@/components/ui/drawer';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';
import {
  Search,
  Plus,
  Download,
  Eye,
  Edit3,
  MapPin,
  Building2,
  AlertTriangle,
  Package,
  TrendingUp,
  TrendingDown,
  X,
  ChevronDown,
  ChevronRight,
  Bluetooth,
  Shield,
  Warehouse,
  LayoutGrid,
  List,
  CheckCircle2,
  Signal,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────
type ViewMode = 'physical' | 'project' | 'aggregation';
type SiteTypeFilter = 'all' | 'warehouse' | 'factory' | 'distribution';

interface WarehouseInfo {
  id: string;
  name: string;
  type: string;
  area: number;
  capacity: number;
  inStock: number;
  status: 'active' | 'inactive';
}

interface RegionInfo {
  id: string;
  name: string;
  type: '收货区' | '发货区' | '存储区' | '退货区';
  area: number;
  capacity: number;
  inStock: number;
  parentId: string | null;
}

interface FenceInfo {
  id: string;
  name: string;
  type: 'circle' | 'polygon';
  radius?: number;
  status: 'active' | 'inactive';
}

// ─── Mock sub-data ───────────────────────────────────────────────
const WAREHOUSES: WarehouseInfo[] = [
  { id: 'w-1', name: 'A1仓库', type: '平面仓', area: 2000, capacity: 500, inStock: 320, status: 'active' },
  { id: 'w-2', name: 'A2仓库', type: '立体仓', area: 1500, capacity: 800, inStock: 650, status: 'active' },
  { id: 'w-3', name: 'B1冷藏仓', type: '冷库', area: 800, capacity: 200, inStock: 120, status: 'active' },
];

const REGIONS: RegionInfo[] = [
  { id: 'r-1', name: '收货区-A', type: '收货区', area: 400, capacity: 100, inStock: 45, parentId: 'w-1' },
  { id: 'r-2', name: '存储区-A1', type: '存储区', area: 1200, capacity: 300, inStock: 210, parentId: 'w-1' },
  { id: 'r-3', name: '发货区-A', type: '发货区', area: 300, capacity: 80, inStock: 55, parentId: 'w-1' },
  { id: 'r-4', name: '退货区-A', type: '退货区', area: 100, capacity: 20, inStock: 10, parentId: 'w-1' },
  { id: 'r-5', name: '收货区-A2', type: '收货区', area: 300, capacity: 160, inStock: 100, parentId: 'w-2' },
  { id: 'r-6', name: '存储区-A2', type: '存储区', area: 900, capacity: 500, inStock: 420, parentId: 'w-2' },
  { id: 'r-7', name: '发货区-A2', type: '发货区', area: 300, capacity: 140, inStock: 130, parentId: 'w-2' },
];

const FENCES: FenceInfo[] = [
  { id: 'f-1', name: '主围栏', type: 'circle', radius: 500, status: 'active' },
  { id: 'f-2', name: '发货区围栏', type: 'polygon', status: 'active' },
];

const RULE_TEMPLATES = [
  { key: 'gps_fence', label: 'GPS 进出围栏', desc: '载具 GPS 位置进入/离开围栏范围触发出入库' },
  { key: 'beacon_scan', label: '蓝牙信标扫描', desc: '蓝牙信标检测到载具标签进入/离开扫描范围触发' },
  { key: 'gateway_detect', label: '车载网关检测', desc: '车辆载具绑定关系变更时触发（车辆到达/离开网点）' },
  { key: 'manual', label: '手动确认', desc: '人工在系统中确认出入库操作' },
  { key: 'hybrid', label: '混合模式（GPS+蓝牙）', desc: 'GPS + 蓝牙信标双验证，任一触发即记录' },
];

const BEACON_DEVICES = [
  { id: 'bc-1', code: 'SB001208', mac: 'AC:23:3F:A4:12:89', signal: -45, location: '仓库入口', status: 'online' as const },
  { id: 'bc-2', code: 'SB001209', mac: 'AC:23:3F:A4:12:90', signal: -52, location: '收货区', status: 'online' as const },
  { id: 'bc-3', code: 'SB001210', mac: 'AC:23:3F:A4:12:91', signal: -38, location: '发货区', status: 'online' as const },
  { id: 'bc-4', code: 'SB001211', mac: 'AC:23:3F:A4:12:92', signal: -60, location: '存储区', status: 'offline' as const },
];

const CARRIER_STATUS_DATA = [
  { name: '在库', value: 320, color: '#2563EB' },
  { name: '在途', value: 180, color: '#10B981' },
  { name: '维修中', value: 45, color: '#F59E0B' },
  { name: '空载', value: 85, color: '#94A3B8' },
];

const CARRIER_TYPE_DATA = [
  { name: '托盘', count: 520 },
  { name: '周转箱', count: 380 },
  { name: '料架', count: 210 },
  { name: '集装箱', count: 180 },
  { name: '笼车', count: 168 },
];

const INVENTORY_TREND = Array.from({ length: 30 }, (_, i) => ({
  date: `12/${String(i + 1).padStart(2, '0')}`,
  inStock: 280 + Math.floor(Math.random() * 100),
  in: Math.floor(Math.random() * 50) + 10,
  out: Math.floor(Math.random() * 40) + 5,
}));

// ─── Helpers ─────────────────────────────────────────────────────
function siteTypeLabel(type: string): string {
  switch (type) {
    case 'warehouse': return '仓库';
    case 'factory': return '工厂';
    case 'distribution': return '配送中心';
    default: return type;
  }
}

function siteTypeColor(type: string): string {
  switch (type) {
    case 'warehouse': return '#2563EB';
    case 'factory': return '#10B981';
    case 'distribution': return '#F59E0B';
    default: return '#94A3B8';
  }
}

// ─── Main Component ──────────────────────────────────────────────
export default function SiteManagementPage() {
  const { sites, carriers, getStatusLabel, getStatusColor } = useMockData();

  // ── State ──
  const [viewMode, setViewMode] = useState<ViewMode>('physical');
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<SiteTypeFilter>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedSite, setSelectedSite] = useState<Site | null>(null);
  const [detailTab, setDetailTab] = useState('basic');
  const [warehouseTab, setWarehouseTab] = useState('warehouse');
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editSite, setEditSite] = useState<Site | null>(null);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [alertDialogOpen, setAlertDialogOpen] = useState(false);
  const [alertSite, setAlertSite] = useState<Site | null>(null);
  const [expandedOrgs, setExpandedOrgs] = useState<Set<string>>(new Set(['org-2', 'org-3']));
  const [showMap, setShowMap] = useState(false);
  const [ruleTemplate, setRuleTemplate] = useState('gps_fence');

  // ── Filtering ──
  const filteredSites = useMemo(() => {
    return sites.filter((s) => {
      if (typeFilter !== 'all' && s.type !== typeFilter) return false;
      if (statusFilter === 'alert' && s.carrierCount < s.alertThreshold) return false;
      if (statusFilter === 'overlimit' && s.carrierCount >= s.alertThreshold * 1.2) return false;
      if (statusFilter === 'normal' && (s.carrierCount >= s.alertThreshold || s.carrierCount >= s.alertThreshold * 1.2)) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          s.name.toLowerCase().includes(q) ||
          s.address.toLowerCase().includes(q) ||
          s.orgName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [sites, typeFilter, statusFilter, searchQuery]);

  // ── KPI ──
  const kpi = useMemo(() => {
    const total = sites.length;
    const totalCarriers = sites.reduce((sum, s) => sum + s.carrierCount, 0);
    const alertSites = sites.filter((s) => s.carrierCount >= s.alertThreshold).length;
    const todayIn = 156;
    const todayOut = 203;
    return { total, totalCarriers, alertSites, todayIn, todayOut };
  }, [sites]);

  // ── Handlers ──
  const openDetail = useCallback((site: Site) => {
    setSelectedSite(site);
    setDetailTab('basic');
  }, []);

  const openEdit = useCallback((site: Site) => {
    setEditSite(site);
    setEditDialogOpen(true);
  }, []);

  const openAlert = useCallback((site: Site) => {
    setAlertSite(site);
    setAlertDialogOpen(true);
  }, []);

  const toggleOrg = useCallback((orgId: string) => {
    setExpandedOrgs((prev) => {
      const next = new Set(prev);
      if (next.has(orgId)) next.delete(orgId);
      else next.add(orgId);
      return next;
    });
  }, []);

  // ── Render helpers ──
  const renderAlertStatus = (site: Site) => {
    const ratio = site.carrierCount / site.alertThreshold;
    if (ratio >= 1.2) {
      return <span className="inline-flex items-center gap-1 text-xs text-[#EF4444] bg-[#FEF2F2] px-2 py-0.5 rounded"><AlertTriangle size={12} />超限</span>;
    }
    if (ratio >= 1.0) {
      return <span className="inline-flex items-center gap-1 text-xs text-[#F59E0B] bg-[#FFFBEB] px-2 py-0.5 rounded"><AlertTriangle size={12} />预警</span>;
    }
    return <span className="inline-flex items-center gap-1 text-xs text-[#10B981] bg-[#ECFDF5] px-2 py-0.5 rounded"><CheckCircle2 size={12} />正常</span>;
  };

  const renderSiteTypeBadge = (type: string) => (
    <span
      className="text-xs px-2 py-0.5 rounded"
      style={{ backgroundColor: siteTypeColor(type) + '15', color: siteTypeColor(type) }}
    >
      {siteTypeLabel(type)}
    </span>
  );

  // ── Aggregation tree data ──
  const orgTree = useMemo(() => {
    const orgGroups: Record<string, { name: string; sites: Site[]; children?: Record<string, Site[]> }> = {};
    sites.forEach((s) => {
      const orgId = s.orgId.split('-').slice(0, 2).join('-');
      const parentOrg = ['org-1', 'org-2', 'org-3', 'org-4'].find((o) => orgId.startsWith(o)) || orgId;
      if (!orgGroups[parentOrg]) {
        orgGroups[parentOrg] = { name: s.orgName.split('（')[0] || s.orgName, sites: [] };
      }
      orgGroups[parentOrg].sites.push(s);
    });
    return orgGroups;
  }, [sites]);

  return (
    <div className="space-y-5">
      {/* ═══════ Page Header ═══════ */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">网点管理</h1>
          <p className="text-sm text-[#475569] mt-1">共 {sites.length} 个网点 · 覆盖 {WAREHOUSES.length} 个仓库</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setShowMap((v) => !v)}>
            <MapPin size={14} />
            {showMap ? '列表视图' : '地图视图'}
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Download size={14} />
            导出
          </Button>
          <Button size="sm" className="gap-1.5 bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={() => setAddDialogOpen(true)}>
            <Plus size={14} />
            新增网点
          </Button>
        </div>
      </div>

      {/* ═══════ KPI Cards ═══════ */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: '网点总数', value: kpi.total, color: '#2563EB', icon: Building2, sub: '覆盖3省8市' },
          { label: '载具库存总量', value: kpi.totalCarriers.toLocaleString(), color: '#10B981', icon: Package, sub: '在库载具' },
          { label: '预警网点数', value: kpi.alertSites, color: '#F59E0B', icon: AlertTriangle, sub: '库存预警' },
          { label: '今日出入库', value: `+${kpi.todayIn} / -${kpi.todayOut}`, color: '#06B6D4', icon: TrendingUp, sub: '今日动态' },
        ].map((card) => (
          <div
            key={card.label}
            className="bg-white rounded-lg p-4 shadow-[0_1px_3px_rgba(0,0,0,0.06)] border-l-4"
            style={{ borderLeftColor: card.color }}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs text-[#475569]">{card.label}</span>
              <card.icon size={16} style={{ color: card.color }} />
            </div>
            <div className="mt-2 text-[28px] font-semibold text-[#0F172A] font-number leading-tight">
              {card.value}
            </div>
            {card.sub && <div className="text-xs text-[#94A3B8] mt-1">{card.sub}</div>}
          </div>
        ))}
      </div>

      {/* ═══════ View Mode Tabs ═══════ */}
      <div className="bg-white rounded-lg p-1.5 shadow-[0_1px_3px_rgba(0,0,0,0.06)]">
        <div className="flex gap-1">
          {[
            { key: 'physical' as ViewMode, label: '物理网点', icon: MapPin },
            { key: 'project' as ViewMode, label: '项目视角', icon: LayoutGrid },
            { key: 'aggregation' as ViewMode, label: '层级聚合', icon: List },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = viewMode === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setViewMode(tab.key)}
                className={cn(
                  'flex items-center gap-1.5 px-4 py-2.5 rounded-md text-sm font-medium transition-all',
                  active
                    ? 'bg-white text-[#2563EB] shadow-sm border-t-2 border-[#2563EB]'
                    : 'text-[#475569] hover:bg-[#F8FAFC]'
                )}
              >
                <Icon size={15} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ═══════ Filter Bar ═══════ */}
      <div className="bg-white rounded-lg p-3 shadow-[0_1px_3px_rgba(0,0,0,0.06)] flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
          <Input
            placeholder="搜索网点名称、地址..."
            className="pl-8 h-8 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v as SiteTypeFilter)}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue placeholder="网点类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="warehouse">仓库</SelectItem>
            <SelectItem value="factory">工厂</SelectItem>
            <SelectItem value="distribution">配送中心</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue placeholder="预警状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="normal">正常</SelectItem>
            <SelectItem value="alert">预警</SelectItem>
            <SelectItem value="overlimit">超限</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* ═══════ Map View (simulated) ═══════ */}
      {showMap && (
        <div className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] p-4">
          <div className="h-[400px] bg-[#F1F5F9] rounded-lg relative overflow-hidden flex items-center justify-center">
            {/* Simulated Map Background */}
            <div className="absolute inset-0" style={{
              backgroundImage: `
                linear-gradient(rgba(226,232,240,0.5) 1px, transparent 1px),
                linear-gradient(90deg, rgba(226,232,240,0.5) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
            }} />
            {/* Simulated roads */}
            <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <line x1="10%" y1="30%" x2="90%" y2="30%" stroke="#CBD5E1" strokeWidth="3" />
              <line x1="10%" y1="60%" x2="90%" y2="60%" stroke="#CBD5E1" strokeWidth="3" />
              <line x1="25%" y1="10%" x2="25%" y2="90%" stroke="#CBD5E1" strokeWidth="3" />
              <line x1="55%" y1="10%" x2="55%" y2="90%" stroke="#CBD5E1" strokeWidth="3" />
              <line x1="80%" y1="10%" x2="80%" y2="90%" stroke="#CBD5E1" strokeWidth="2" />
              <line x1="10%" y1="45%" x2="90%" y2="45%" stroke="#E2E8F0" strokeWidth="1" />
              <line x1="40%" y1="10%" x2="40%" y2="90%" stroke="#E2E8F0" strokeWidth="1" />
              <line x1="10%" y1="75%" x2="90%" y2="75%" stroke="#E2E8F0" strokeWidth="1" />
              {/* Water */}
              <ellipse cx="75%" cy="20%" rx="8%" ry="6%" fill="#BFDBFE" opacity="0.4" />
            </svg>
            {/* Site markers */}
            {filteredSites.map((site, i) => {
              const positions = [
                { left: '20%', top: '25%' }, { left: '50%', top: '25%' }, { left: '35%', top: '55%' },
                { left: '75%', top: '45%' }, { left: '70%', top: '70%' }, { left: '15%', top: '75%' },
                { left: '45%', top: '80%' }, { left: '60%', top: '50%' },
              ];
              const pos = positions[i % positions.length];
              return (
                <button
                  key={site.id}
                  className="absolute flex flex-col items-center group cursor-pointer"
                  style={{ left: pos.left, top: pos.top }}
                  onClick={() => openDetail(site)}
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg transition-transform group-hover:scale-110"
                    style={{ backgroundColor: siteTypeColor(site.type) }}
                  >
                    <Building2 size={16} />
                  </div>
                  <div className="mt-1 bg-white px-2 py-0.5 rounded shadow text-xs font-medium whitespace-nowrap opacity-90">
                    {site.name}
                  </div>
                  {/* Pulse animation for alert sites */}
                  {site.carrierCount >= site.alertThreshold && (
                    <span
                      className="absolute w-8 h-8 rounded-full animate-ping opacity-30"
                      style={{ backgroundColor: '#EF4444' }}
                    />
                  )}
                </button>
              );
            })}
            {/* Map legend */}
            <div className="absolute bottom-3 left-3 bg-white rounded-lg p-2 shadow text-xs space-y-1">
              <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ backgroundColor: '#2563EB' }} /> 仓库</div>
              <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ backgroundColor: '#10B981' }} /> 工厂</div>
              <div className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-full" style={{ backgroundColor: '#F59E0B' }} /> 配送中心</div>
            </div>
          </div>
        </div>
      )}

      {/* ═══════ Physical View - Table ═══════ */}
      {viewMode === 'physical' && !showMap && (
        <div className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                  <TableHead className="text-[#475569] text-[13px] font-medium">网点名称</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">网点类型</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">所属组织</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">地址</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">载具数量</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">容量</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">预警状态</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium">围栏</TableHead>
                  <TableHead className="text-[#475569] text-[13px] font-medium w-28">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSites.map((site, idx) => {
                  const isAlert = site.carrierCount >= site.alertThreshold;
                  const isOverlimit = site.carrierCount >= site.alertThreshold * 1.2;
                  return (
                    <TableRow
                      key={site.id}
                      className={cn(
                        'h-12 transition-colors cursor-pointer',
                        idx % 2 === 1 && 'bg-[#F8FAFC]',
                        isOverlimit && 'border-l-[3px] border-l-[#EF4444] bg-[#FEF2F2]',
                        isAlert && !isOverlimit && 'border-l-[3px] border-l-[#F59E0B] bg-[#FFFBEB]',
                      )}
                      onClick={() => openDetail(site)}
                    >
                      <TableCell className="font-medium text-sm text-[#0F172A]">{site.name}</TableCell>
                      <TableCell>{renderSiteTypeBadge(site.type)}</TableCell>
                      <TableCell className="text-sm">{site.orgName}</TableCell>
                      <TableCell className="text-sm text-[#475569] max-w-[200px] truncate">{site.address}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium tabular-nums">{site.carrierCount}</span>
                          <div className="w-12 h-1 bg-[#E2E8F0] rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${Math.min((site.carrierCount / (site.alertThreshold * 1.5)) * 100, 100)}%`,
                                backgroundColor: isOverlimit ? '#EF4444' : isAlert ? '#F59E0B' : '#10B981',
                              }}
                            />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-[#475569]">{site.alertThreshold * 1.5}</TableCell>
                      <TableCell>{renderAlertStatus(site)}</TableCell>
                      <TableCell>
                        {site.fenceEnabled ? (
                          <span className="inline-flex items-center gap-1 text-xs text-[#10B981]"><Shield size={12} />已启用</span>
                        ) : (
                          <span className="text-xs text-[#94A3B8]">未启用</span>
                        )}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center gap-1">
                          <button className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]" title="详情" onClick={() => openDetail(site)}>
                            <Eye size={14} />
                          </button>
                          <button className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]" title="编辑" onClick={() => openEdit(site)}>
                            <Edit3 size={14} />
                          </button>
                          <button className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]" title="预警设置" onClick={() => openAlert(site)}>
                            <AlertTriangle size={14} />
                          </button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          {filteredSites.length === 0 && (
            <div className="py-16 flex flex-col items-center text-[#94A3B8]">
              <Building2 size={48} strokeWidth={1} />
              <p className="mt-3 text-sm">暂无网点数据</p>
            </div>
          )}
        </div>
      )}

      {/* ═══════ Project View ═══════ */}
      {viewMode === 'project' && !showMap && (
        <div className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="text-[#475569] text-[13px] font-medium w-8" />
                <TableHead className="text-[#475569] text-[13px] font-medium">项目/网点</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">类型</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">载具数量</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">容量利用率</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium">预警状态</TableHead>
                <TableHead className="text-[#475569] text-[13px] font-medium w-28">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {Object.entries(orgTree).map(([orgId, org]) => (
                org.sites.map((site, sIdx) => (
                  <TableRow
                    key={site.id}
                    className={cn(
                      'h-12 transition-colors cursor-pointer',
                      sIdx % 2 === 1 && 'bg-[#F8FAFC]'
                    )}
                    onClick={() => openDetail(site)}
                  >
                    <TableCell>
                      {sIdx === 0 && (
                        <button onClick={(e) => { e.stopPropagation(); toggleOrg(orgId); }}>
                          {expandedOrgs.has(orgId) ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                        </button>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {sIdx === 0 ? (
                          <span className="font-medium text-sm text-[#2563EB]">{org.name}</span>
                        ) : (
                          <span className="text-sm text-[#0F172A] ml-6">{site.name}</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{sIdx > 0 && renderSiteTypeBadge(site.type)}</TableCell>
                    <TableCell className="text-sm tabular-nums">{site.carrierCount}</TableCell>
                    <TableCell>
                      {sIdx > 0 && (
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#2563EB] rounded-full"
                              style={{ width: `${Math.min((site.carrierCount / (site.alertThreshold * 1.5)) * 100, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs text-[#475569]">
                            {Math.round((site.carrierCount / (site.alertThreshold * 1.5)) * 100)}%
                          </span>
                        </div>
                      )}
                      {sIdx === 0 && (
                        <span className="text-sm font-medium text-[#0F172A]">
                          {org.sites.reduce((s, x) => s + x.carrierCount, 0)}
                        </span>
                      )}
                    </TableCell>
                    <TableCell>{sIdx > 0 && renderAlertStatus(site)}</TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      {sIdx > 0 && (
                        <div className="flex items-center gap-1">
                          <button className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]" onClick={() => openDetail(site)}><Eye size={14} /></button>
                          <button className="p-1 rounded hover:bg-[#F1F5F9] text-[#475569]" onClick={() => openEdit(site)}><Edit3 size={14} /></button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* ═══════ Aggregation View ═══════ */}
      {viewMode === 'aggregation' && !showMap && (
        <div className="space-y-4">
          {Object.entries(orgTree).map(([orgId, org]) => {
            const totalCarriers = org.sites.reduce((s, x) => s + x.carrierCount, 0);
            const alertCount = org.sites.filter((s) => s.carrierCount >= s.alertThreshold).length;
            return (
              <div key={orgId} className="bg-white rounded-lg shadow-[0_1px_3px_rgba(0,0,0,0.06)] p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <button onClick={() => toggleOrg(orgId)} className="text-[#475569]">
                      {expandedOrgs.has(orgId) ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                    </button>
                    <h3 className="font-semibold text-[#0F172A]">{org.name}</h3>
                    <span className="text-xs text-[#94A3B8]">{org.sites.length} 个网点</span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-[#475569]">载具总数：<strong className="text-[#0F172A] font-number">{totalCarriers}</strong></span>
                    {alertCount > 0 && <span className="text-[#F59E0B]">预警网点：{alertCount}</span>}
                  </div>
                </div>
                {expandedOrgs.has(orgId) && (
                  <div className="ml-6 grid grid-cols-2 gap-3">
                    {org.sites.map((site) => (
                      <div
                        key={site.id}
                        className="border border-[#E2E8F0] rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => openDetail(site)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Building2 size={14} style={{ color: siteTypeColor(site.type) }} />
                            <span className="text-sm font-medium">{site.name}</span>
                          </div>
                          {renderSiteTypeBadge(site.type)}
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-[#475569]">
                          <span>载具：<strong className="font-number">{site.carrierCount}</strong></span>
                          <span>围栏：{site.fenceEnabled ? '已启用' : '未启用'}</span>
                          <span>信标：4</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ═══════════════════════════════════════════
          SITE DETAIL DRAWER (Large: 720px)
          ═══════════════════════════════════════════ */}
      <Drawer open={!!selectedSite} onOpenChange={(open) => !open && setSelectedSite(null)}>
        <DrawerContent className="w-[720px] sm:max-w-[720px]">
          {selectedSite && (
            <>
              <DrawerHeader className="border-b border-[#E2E8F0]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <DrawerTitle className="text-lg font-semibold">{selectedSite.name}</DrawerTitle>
                    {renderAlertStatus(selectedSite)}
                    {renderSiteTypeBadge(selectedSite.type)}
                  </div>
                  <DrawerClose asChild>
                    <button className="p-1 rounded hover:bg-[#F1F5F9]">
                      <X size={18} className="text-[#94A3B8]" />
                    </button>
                  </DrawerClose>
                </div>
                <DrawerDescription className="text-xs text-[#94A3B8] mt-1">
                  {selectedSite.address} · 联系人：{selectedSite.contactName} {selectedSite.contactPhone}
                </DrawerDescription>
              </DrawerHeader>

              <Tabs value={detailTab} onValueChange={setDetailTab} className="flex-1 overflow-hidden">
                <TabsList className="w-full rounded-none border-b bg-transparent px-4 pt-2 gap-0 flex-wrap h-auto">
                  {[
                    { key: 'basic', label: '基本信息' },
                    { key: 'inventory', label: '库存概览' },
                    { key: 'carriers', label: '载具列表' },
                    { key: 'fence', label: '围栏设置' },
                    { key: 'rules', label: '出入库规则' },
                    { key: 'beacons', label: '信标管理' },
                    { key: 'warehouse', label: '仓储空间' },
                  ].map((t) => (
                    <TabsTrigger
                      key={t.key}
                      value={t.key}
                      className={cn(
                        'rounded-none border-b-2 border-transparent data-[state=active]:border-[#2563EB] data-[state=active]:shadow-none bg-transparent text-xs px-3',
                        detailTab === t.key ? 'text-[#2563EB]' : 'text-[#475569]'
                      )}
                    >
                      {t.label}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {/* ── Tab: Basic Info ── */}
                <TabsContent value="basic" className="p-4 overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: '网点名称', value: selectedSite.name },
                      { label: '网点类型', value: siteTypeLabel(selectedSite.type) },
                      { label: '网点编码', value: selectedSite.id.toUpperCase() },
                      { label: '所属组织', value: selectedSite.orgName },
                      { label: '地址', value: selectedSite.address },
                      { label: '经纬度', value: `${selectedSite.lat.toFixed(6)}, ${selectedSite.lng.toFixed(6)}` },
                      { label: '联系人', value: selectedSite.contactName },
                      { label: '联系电话', value: selectedSite.contactPhone },
                      { label: '容量上限', value: (selectedSite.alertThreshold * 1.5).toString() },
                      { label: '预警阈值', value: selectedSite.alertThreshold.toString() },
                      { label: '围栏状态', value: selectedSite.fenceEnabled ? '已启用' : '未启用' },
                      { label: '创建时间', value: selectedSite.createdAt },
                    ].map((item) => (
                      <div key={item.label} className="py-2">
                        <div className="text-xs text-[#94A3B8] mb-1">{item.label}</div>
                        <div className="text-sm text-[#0F172A] font-medium">{item.value}</div>
                      </div>
                    ))}
                  </div>
                  {/* Mini Map */}
                  <div className="mt-4 bg-[#F1F5F9] rounded-lg h-[200px] relative overflow-hidden">
                    <div className="absolute inset-0" style={{
                      backgroundImage: `linear-gradient(rgba(226,232,240,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(226,232,240,0.5) 1px, transparent 1px)`,
                      backgroundSize: '30px 30px',
                    }} />
                    <svg className="absolute inset-0 w-full h-full">
                      <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#CBD5E1" strokeWidth="2" />
                      <line x1="50%" y1="0" x2="50%" y2="100%" stroke="#CBD5E1" strokeWidth="2" />
                    </svg>
                    <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                      <div className="w-10 h-10 rounded-full bg-[#2563EB] flex items-center justify-center text-white shadow-lg">
                        <MapPin size={20} />
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-white rounded px-2 py-1 text-xs shadow">
                      {selectedSite.lat.toFixed(6)}, {selectedSite.lng.toFixed(6)}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4 pt-4 border-t border-[#E2E8F0]">
                    <Button size="sm" variant="outline" onClick={() => openEdit(selectedSite)}>
                      <Edit3 size={14} className="mr-1" />编辑
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => openAlert(selectedSite)}>
                      <AlertTriangle size={14} className="mr-1" />预警设置
                    </Button>
                  </div>
                </TabsContent>

                {/* ── Tab: Inventory Overview ── */}
                <TabsContent value="inventory" className="p-4 overflow-y-auto space-y-4">
                  <div className="grid grid-cols-4 gap-3">
                    {[
                      { label: '在库数量', value: selectedSite.carrierCount, color: '#2563EB', icon: Package },
                      { label: '容量利用率', value: `${Math.round((selectedSite.carrierCount / (selectedSite.alertThreshold * 1.5)) * 100)}%`, color: '#10B981', icon: TrendingUp },
                      { label: '今日入库', value: `+${Math.floor(Math.random() * 30) + 5}`, color: '#06B6D4', icon: TrendingUp },
                      { label: '今日出库', value: `-${Math.floor(Math.random() * 25) + 3}`, color: '#F59E0B', icon: TrendingDown },
                    ].map((item) => (
                      <div key={item.label} className="bg-[#F8FAFC] rounded-lg p-3 text-center">
                        <item.icon size={14} style={{ color: item.color }} className="mx-auto mb-1" />
                        <div className="text-xs text-[#475569]">{item.label}</div>
                        <div className="text-lg font-semibold font-number mt-1" style={{ color: item.color }}>{item.value}</div>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                      <h4 className="text-sm font-medium text-[#0F172A] mb-3">载具状态分布</h4>
                      <ResponsiveContainer width="100%" height={180}>
                        <PieChart>
                          <Pie data={CARRIER_STATUS_DATA} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                            {CARRIER_STATUS_DATA.map((entry, index) => (
                              <Cell key={index} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="flex flex-wrap gap-2 justify-center">
                        {CARRIER_STATUS_DATA.map((s) => (
                          <span key={s.name} className="text-xs flex items-center gap-1">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: s.color }} />{s.name}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                      <h4 className="text-sm font-medium text-[#0F172A] mb-3">载具类型分布</h4>
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={CARRIER_TYPE_DATA} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                          <XAxis type="number" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                          <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#475569' }} width={50} />
                          <Tooltip contentStyle={{ fontSize: 12 }} />
                          <Bar dataKey="count" fill="#2563EB" radius={[0, 4, 4, 0]} barSize={16} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0] p-4">
                    <h4 className="text-sm font-medium text-[#0F172A] mb-3">库存趋势（近30天）</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <AreaChart data={INVENTORY_TREND}>
                        <defs>
                          <linearGradient id="invGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                            <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
                        <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                        <Tooltip contentStyle={{ fontSize: 12 }} />
                        <Area type="monotone" dataKey="inStock" stroke="#2563EB" fill="url(#invGrad)" strokeWidth={2} name="在库数量" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </TabsContent>

                {/* ── Tab: Carrier List ── */}
                <TabsContent value="carriers" className="p-4 overflow-y-auto">
                  <div className="bg-white rounded-lg border border-[#E2E8F0]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#F8FAFC]">
                          <TableHead className="text-xs">载具编号</TableHead>
                          <TableHead className="text-xs">类型</TableHead>
                          <TableHead className="text-xs">状态</TableHead>
                          <TableHead className="text-xs">当前位置</TableHead>
                          <TableHead className="text-xs">最近使用</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {carriers.filter((_, i) => i < 15).map((carrier) => (
                          <TableRow key={carrier.id} className="h-10">
                            <TableCell className="text-sm font-mono">{carrier.code}</TableCell>
                            <TableCell className="text-xs">{carrier.type}</TableCell>
                            <TableCell>
                              <span className="text-xs px-1.5 py-0.5 rounded" style={{ backgroundColor: getStatusColor(carrier.status) + '20', color: getStatusColor(carrier.status) }}>
                                {getStatusLabel(carrier.status)}
                              </span>
                            </TableCell>
                            <TableCell className="text-xs text-[#475569]">{carrier.currentLocation}</TableCell>
                            <TableCell className="text-xs text-[#94A3B8]">{carrier.lastUsedAt}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* ── Tab: Fence Settings ── */}
                <TabsContent value="fence" className="p-4 overflow-y-auto space-y-4">
                  <div className="bg-[#F1F5F9] rounded-lg h-[250px] relative overflow-hidden">
                    <div className="absolute inset-0" style={{
                      backgroundImage: `linear-gradient(rgba(226,232,240,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(226,232,240,0.5) 1px, transparent 1px)`,
                      backgroundSize: '25px 25px',
                    }} />
                    <svg className="absolute inset-0 w-full h-full">
                      <line x1="0" y1="40%" x2="100%" y2="40%" stroke="#CBD5E1" strokeWidth="2" />
                      <line x1="0" y1="70%" x2="100%" y2="70%" stroke="#CBD5E1" strokeWidth="2" />
                      <line x1="30%" y1="0" x2="30%" y2="100%" stroke="#CBD5E1" strokeWidth="2" />
                      <line x1="65%" y1="0" x2="65%" y2="100%" stroke="#CBD5E1" strokeWidth="2" />
                    </svg>
                    {/* Fence visualization */}
                    <svg className="absolute inset-0 w-full h-full pointer-events-none">
                      <circle cx="50%" cy="50%" r="80" fill="none" stroke="#F59E0B" strokeWidth="2" strokeDasharray="6,4" />
                      <circle cx="50%" cy="50%" r="80" fill="#F59E0B" opacity="0.08" />
                      <polygon points="150,80 280,60 320,150 200,180" fill="none" stroke="#8B5CF6" strokeWidth="2" strokeDasharray="6,4" />
                      <polygon points="150,80 280,60 320,150 200,180" fill="#8B5CF6" opacity="0.05" />
                    </svg>
                    <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                      <div className="w-8 h-8 rounded-full bg-[#2563EB] flex items-center justify-center text-white shadow">
                        <Building2 size={16} />
                      </div>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-white rounded px-2 py-1 text-xs shadow space-y-0.5">
                      <div className="flex items-center gap-1"><span className="w-3 h-0.5 bg-[#F59E0B]" /> 圆形围栏 (500m)</div>
                      <div className="flex items-center gap-1"><span className="w-3 h-0.5 bg-[#8B5CF6]" /> 多边形围栏</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {FENCES.map((fence) => (
                      <div key={fence.id} className="flex items-center justify-between p-3 bg-[#F8FAFC] rounded-lg">
                        <div className="flex items-center gap-3">
                          <Shield size={16} className={fence.status === 'active' ? 'text-[#10B981]' : 'text-[#94A3B8]'} />
                          <div>
                            <div className="text-sm font-medium">{fence.name}</div>
                            <div className="text-xs text-[#94A3B8]">
                              {fence.type === 'circle' ? `圆形围栏 · 半径 ${fence.radius}m` : '多边形围栏'}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            'text-xs px-2 py-0.5 rounded',
                            fence.status === 'active' ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                          )}>
                            {fence.status === 'active' ? '启用中' : '已停用'}
                          </span>
                          <Button variant="outline" size="sm" className="h-7 text-xs">编辑</Button>
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" size="sm" className="w-full gap-1">
                      <Plus size={14} /> 新增围栏
                    </Button>
                  </div>
                </TabsContent>

                {/* ── Tab: In/Out Rules ── */}
                <TabsContent value="rules" className="p-4 overflow-y-auto space-y-4">
                  <div>
                    <label className="text-sm font-medium text-[#0F172A] mb-2 block">规则模板选择</label>
                    <div className="grid gap-2">
                      {RULE_TEMPLATES.map((t) => (
                        <button
                          key={t.key}
                          onClick={() => setRuleTemplate(t.key)}
                          className={cn(
                            'flex items-start gap-3 p-3 rounded-lg border text-left transition-all',
                            ruleTemplate === t.key
                              ? 'border-[#2563EB] bg-[#EFF6FF]'
                              : 'border-[#E2E8F0] hover:bg-[#F8FAFC]'
                          )}
                        >
                          <div className={cn(
                            'w-4 h-4 rounded-full border-2 mt-0.5 flex-shrink-0 flex items-center justify-center',
                            ruleTemplate === t.key ? 'border-[#2563EB]' : 'border-[#CBD5E1]'
                          )}>
                            {ruleTemplate === t.key && <div className="w-2 h-2 rounded-full bg-[#2563EB]" />}
                          </div>
                          <div>
                            <div className="text-sm font-medium">{t.label}</div>
                            <div className="text-xs text-[#475569] mt-0.5">{t.desc}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                  {ruleTemplate && (
                    <div className="border-t border-[#E2E8F0] pt-4 space-y-3">
                      <h4 className="text-sm font-medium">规则配置</h4>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-xs text-[#475569] mb-1 block">缓冲时间（分钟）</label>
                          <Input type="number" defaultValue="5" className="h-8" />
                        </div>
                        <div>
                          <label className="text-xs text-[#475569] mb-1 block">超时时间（小时）</label>
                          <Input type="number" defaultValue="24" className="h-8" />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch defaultChecked />
                        <span className="text-sm">触发联动出入库</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch />
                        <span className="text-sm">异常时自动报警</span>
                      </div>
                      <Button size="sm" className="bg-[#2563EB] hover:bg-[#1D4ED8]">保存规则</Button>
                    </div>
                  )}
                </TabsContent>

                {/* ── Tab: Beacon Management ── */}
                <TabsContent value="beacons" className="p-4 overflow-y-auto space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[#475569]">已绑定信标：<strong className="text-[#0F172A]">{BEACON_DEVICES.length}</strong> 个</span>
                    <Button size="sm" className="bg-[#2563EB] hover:bg-[#1D4ED8] gap-1">
                      <Plus size={14} />绑定信标
                    </Button>
                  </div>
                  <div className="bg-[#F1F5F9] rounded-lg h-[180px] relative overflow-hidden">
                    <div className="absolute inset-0" style={{
                      backgroundImage: `linear-gradient(rgba(226,232,240,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(226,232,240,0.5) 1px, transparent 1px)`,
                      backgroundSize: '20px 20px',
                    }} />
                    {/* Simulated beacon coverage */}
                    <svg className="absolute inset-0 w-full h-full">
                      <circle cx="30%" cy="40%" r="50" fill="none" stroke="#8B5CF6" strokeWidth="1" strokeDasharray="4,3" opacity="0.5" />
                      <circle cx="30%" cy="40%" r="50" fill="#8B5CF6" opacity="0.05" />
                      <circle cx="70%" cy="35%" r="40" fill="none" stroke="#2563EB" strokeWidth="1" strokeDasharray="4,3" opacity="0.5" />
                      <circle cx="70%" cy="35%" r="40" fill="#2563EB" opacity="0.05" />
                      <circle cx="50%" cy="70%" r="45" fill="none" stroke="#10B981" strokeWidth="1" strokeDasharray="4,3" opacity="0.5" />
                      <circle cx="50%" cy="70%" r="45" fill="#10B981" opacity="0.05" />
                    </svg>
                    {BEACON_DEVICES.slice(0, 3).map((bc, i) => {
                      const positions = [{ left: '28%', top: '35%' }, { left: '68%', top: '30%' }, { left: '48%', top: '65%' }];
                      return (
                        <div key={bc.id} className="absolute" style={positions[i]}>
                          <div className="w-6 h-6 rounded-full bg-white border-2 flex items-center justify-center" style={{ borderColor: ['#8B5CF6', '#2563EB', '#10B981'][i] }}>
                            <Bluetooth size={12} style={{ color: ['#8B5CF6', '#2563EB', '#10B981'][i] }} />
                          </div>
                        </div>
                      );
                    })}
                    <div className="absolute bottom-2 left-2 bg-white rounded px-2 py-1 text-xs shadow">信标信号覆盖范围（模拟）</div>
                  </div>
                  <div className="bg-white rounded-lg border border-[#E2E8F0]">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#F8FAFC]">
                          <TableHead className="text-xs">信标编号</TableHead>
                          <TableHead className="text-xs">MAC</TableHead>
                          <TableHead className="text-xs">信号强度</TableHead>
                          <TableHead className="text-xs">安装位置</TableHead>
                          <TableHead className="text-xs">状态</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {BEACON_DEVICES.map((bc) => (
                          <TableRow key={bc.id} className="h-10">
                            <TableCell className="text-sm font-mono">{bc.code}</TableCell>
                            <TableCell className="text-xs font-mono text-[#475569]">{bc.mac}</TableCell>
                            <TableCell>
                              <span className="inline-flex items-center gap-1 text-xs">
                                <Signal size={12} />
                                {bc.signal} dBm
                              </span>
                            </TableCell>
                            <TableCell className="text-xs">{bc.location}</TableCell>
                            <TableCell>
                              <span className={cn(
                                'text-xs px-1.5 py-0.5 rounded',
                                bc.status === 'online' ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#FEF2F2] text-[#EF4444]'
                              )}>
                                {bc.status === 'online' ? '在线' : '离线'}
                              </span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </TabsContent>

                {/* ── Tab: Warehouse Space ── */}
                <TabsContent value="warehouse" className="p-4 overflow-y-auto space-y-4">
                  <Tabs value={warehouseTab} onValueChange={setWarehouseTab}>
                    <TabsList className="h-8">
                      <TabsTrigger value="warehouse" className="text-xs">仓库管理</TabsTrigger>
                      <TabsTrigger value="region" className="text-xs">区域管理</TabsTrigger>
                    </TabsList>
                    <TabsContent value="warehouse" className="mt-3 space-y-3">
                      {WAREHOUSES.map((wh) => {
                        const whRegions = REGIONS.filter((r) => r.parentId === wh.id);
                        return (
                          <div key={wh.id} className="border border-[#E2E8F0] rounded-lg p-4">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Warehouse size={16} className="text-[#2563EB]" />
                                <span className="font-medium text-sm">{wh.name}</span>
                                <span className="text-xs px-1.5 py-0.5 rounded bg-[#F1F5F9] text-[#475569]">{wh.type}</span>
                              </div>
                              <span className={cn(
                                'text-xs px-2 py-0.5 rounded',
                                wh.status === 'active' ? 'bg-[#ECFDF5] text-[#10B981]' : 'bg-[#F1F5F9] text-[#94A3B8]'
                              )}>
                                {wh.status === 'active' ? '启用中' : '停用'}
                              </span>
                            </div>
                            <div className="grid grid-cols-4 gap-3 mt-3">
                              <div className="text-center">
                                <div className="text-xs text-[#94A3B8]">面积</div>
                                <div className="text-sm font-medium font-number">{wh.area}m²</div>
                              </div>
                              <div className="text-center">
                                <div className="text-xs text-[#94A3B8]">容量</div>
                                <div className="text-sm font-medium font-number">{wh.capacity}</div>
                              </div>
                              <div className="text-center">
                                <div className="text-xs text-[#94A3B8]">在库</div>
                                <div className="text-sm font-medium font-number">{wh.inStock}</div>
                              </div>
                              <div className="text-center">
                                <div className="text-xs text-[#94A3B8]">利用率</div>
                                <div className="text-sm font-medium font-number" style={{ color: wh.inStock / wh.capacity > 0.9 ? '#EF4444' : '#10B981' }}>
                                  {Math.round((wh.inStock / wh.capacity) * 100)}%
                                </div>
                              </div>
                            </div>
                            <div className="mt-2">
                              <Progress value={(wh.inStock / wh.capacity) * 100} className="h-1.5" />
                            </div>
                            {whRegions.length > 0 && (
                              <div className="mt-3 pt-3 border-t border-[#E2E8F0]">
                                <div className="text-xs text-[#94A3B8] mb-2">下属区域</div>
                                <div className="flex flex-wrap gap-2">
                                  {whRegions.map((r) => (
                                    <span key={r.id} className="text-xs px-2 py-1 rounded bg-[#F8FAFC] border border-[#E2E8F0]">
                                      {r.name} · {r.inStock}/{r.capacity}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                      <Button variant="outline" size="sm" className="w-full gap-1">
                        <Plus size={14} /> 新增仓库
                      </Button>
                    </TabsContent>
                    <TabsContent value="region" className="mt-3">
                      <div className="bg-white rounded-lg border border-[#E2E8F0]">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-[#F8FAFC]">
                              <TableHead className="text-xs">区域名称</TableHead>
                              <TableHead className="text-xs">类型</TableHead>
                              <TableHead className="text-xs">面积</TableHead>
                              <TableHead className="text-xs">容量</TableHead>
                              <TableHead className="text-xs">在库数</TableHead>
                              <TableHead className="text-xs">利用率</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {REGIONS.map((r) => (
                              <TableRow key={r.id} className="h-10">
                                <TableCell className="text-sm">{r.name}</TableCell>
                                <TableCell>
                                  <span className="text-xs px-1.5 py-0.5 rounded" style={{
                                    backgroundColor: r.type === '收货区' ? '#EFF6FF' : r.type === '发货区' ? '#ECFDF5' : r.type === '存储区' ? '#FFFBEB' : '#F5F3FF',
                                    color: r.type === '收货区' ? '#2563EB' : r.type === '发货区' ? '#10B981' : r.type === '存储区' ? '#F59E0B' : '#8B5CF6',
                                  }}>{r.type}</span>
                                </TableCell>
                                <TableCell className="text-xs">{r.area}m²</TableCell>
                                <TableCell className="text-xs">{r.capacity}</TableCell>
                                <TableCell className="text-xs font-number">{r.inStock}</TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <div className="w-12 h-1 bg-[#E2E8F0] rounded-full overflow-hidden">
                                      <div className="h-full rounded-full bg-[#2563EB]" style={{ width: `${(r.inStock / r.capacity) * 100}%` }} />
                                    </div>
                                    <span className="text-xs">{Math.round((r.inStock / r.capacity) * 100)}%</span>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </TabsContent>
                  </Tabs>
                </TabsContent>
              </Tabs>
            </>
          )}
        </DrawerContent>
      </Drawer>

      {/* ═══════════════════════════════════════════
          EDIT DIALOG
          ═══════════════════════════════════════════ */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">编辑网点</DialogTitle>
            <DialogDescription className="text-xs">网点：{editSite?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">网点名称</label>
              <Input defaultValue={editSite?.name} />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">网点类型</label>
              <Select defaultValue={editSite?.type}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="warehouse">仓库</SelectItem>
                  <SelectItem value="factory">工厂</SelectItem>
                  <SelectItem value="distribution">配送中心</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">地址</label>
              <Input defaultValue={editSite?.address} />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">联系人</label>
              <Input defaultValue={editSite?.contactName} />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">联系电话</label>
              <Input defaultValue={editSite?.contactPhone} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>取消</Button>
            <Button className="bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={() => setEditDialogOpen(false)}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          ADD DIALOG
          ═══════════════════════════════════════════ */}
      <Dialog open={addDialogOpen} onOpenChange={setAddDialogOpen}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">新增网点</DialogTitle>
            <DialogDescription className="text-xs">请填写网点基本信息</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">网点名称 <span className="text-[#EF4444]">*</span></label>
              <Input placeholder="请输入网点名称" />
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">网点类型 <span className="text-[#EF4444]">*</span></label>
              <Select>
                <SelectTrigger><SelectValue placeholder="请选择网点类型" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="warehouse">仓库</SelectItem>
                  <SelectItem value="factory">工厂</SelectItem>
                  <SelectItem value="distribution">配送中心</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">所属组织 <span className="text-[#EF4444]">*</span></label>
              <Select>
                <SelectTrigger><SelectValue placeholder="请选择所属组织" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="org-2">华东汽车制造有限公司</SelectItem>
                  <SelectItem value="org-3">南方物流集团</SelectItem>
                  <SelectItem value="org-4">北方供应链管理有限公司</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">地址</label>
              <Input placeholder="请输入详细地址" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">联系人</label>
                <Input placeholder="联系人姓名" />
              </div>
              <div>
                <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">联系电话</label>
                <Input placeholder="联系电话" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">容量</label>
              <Input type="number" placeholder="请输入容量上限" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddDialogOpen(false)}>取消</Button>
            <Button className="bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={() => setAddDialogOpen(false)}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ═══════════════════════════════════════════
          ALERT SETTINGS DIALOG
          ═══════════════════════════════════════════ */}
      <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold">库存预警设置</DialogTitle>
            <DialogDescription className="text-xs">网点：{alertSite?.name}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">预警阈值（容量百分比）</label>
              <Input type="number" defaultValue="80" />
              <p className="text-xs text-[#94A3B8] mt-1">当库存达到容量80%时触发预警</p>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">超限阈值（容量百分比）</label>
              <Input type="number" defaultValue="95" />
              <p className="text-xs text-[#94A3B8] mt-1">当库存达到容量95%时触发超限报警</p>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">预警通知方式</label>
              <div className="space-y-2 mt-1">
                {['站内消息', '短信通知', '邮件通知'].map((method) => (
                  <label key={method} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" defaultChecked={method === '站内消息'} className="rounded border-[#CBD5E1]" />
                    {method}
                  </label>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-[#0F172A] mb-1.5 block">预警频率</label>
              <Select defaultValue="hourly">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="realtime">实时</SelectItem>
                  <SelectItem value="hourly">每小时汇总</SelectItem>
                  <SelectItem value="daily">每日汇总</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAlertDialogOpen(false)}>取消</Button>
            <Button className="bg-[#2563EB] hover:bg-[#1D4ED8]" onClick={() => setAlertDialogOpen(false)}>保存设置</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
