import { useState, useMemo } from 'react';
import { BarChart3 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { cn } from '@/lib/utils';

interface TimePoint {
  time: string;
  avg: number;
  max: number;
  min: number;
}

const timeRanges = ['近1小时', '24小时', '7天'];
const metrics = [
  { key: 'temperature', label: '温度', unit: '°C', color: '#EF4444' },
  { key: 'humidity', label: '湿度', unit: '%', color: '#06B6D4' },
  { key: 'battery', label: '电量', unit: '%', color: '#10B981' },
  { key: 'signal', label: '信号强度', unit: 'dBm', color: '#8B5CF6' },
];

function generateData(range: string, metricKey: string): TimePoint[] {
  const now = new Date();
  const points: TimePoint[] = [];
  let count = 0;
  let intervalMinutes = 0;

  switch (range) {
    case '近1小时':
      count = 12;
      intervalMinutes = 5;
      break;
    case '24小时':
      count = 24;
      intervalMinutes = 60;
      break;
    case '7天':
      count = 7;
      intervalMinutes = 24 * 60;
      break;
  }

  for (let i = count - 1; i >= 0; i--) {
    const t = new Date(now.getTime() - i * intervalMinutes * 60000);
    let timeLabel = '';
    if (range === '近1小时') {
      timeLabel = `${String(t.getHours()).padStart(2, '0')}:${String(t.getMinutes()).padStart(2, '0')}`;
    } else if (range === '24小时') {
      timeLabel = `${String(t.getHours()).padStart(2, '0')}:00`;
    } else {
      timeLabel = `${t.getMonth() + 1}/${t.getDate()}`;
    }

    let base = 0;
    let spread = 0;
    switch (metricKey) {
      case 'temperature':
        base = 25;
        spread = 15;
        break;
      case 'humidity':
        base = 60;
        spread = 20;
        break;
      case 'battery':
        base = 70;
        spread = 25;
        break;
      case 'signal':
        base = -70;
        spread = 20;
        break;
    }

    const avg = base + (Math.random() - 0.5) * spread;
    const max = avg + Math.random() * spread * 0.3;
    const min = avg - Math.random() * spread * 0.3;

    points.push({
      time: timeLabel,
      avg: +avg.toFixed(1),
      max: +max.toFixed(1),
      min: +min.toFixed(1),
    });
  }
  return points;
}

export default function IotTimeSeriesTab() {
  const [timeRange, setTimeRange] = useState('24小时');
  const [metricKey, setMetricKey] = useState('temperature');

  const metric = metrics.find((m) => m.key === metricKey)!;
  const data = useMemo(() => generateData(timeRange, metricKey), [timeRange, metricKey]);

  return (
    <div className="space-y-5">
      {/* Controls */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-textSecondary">时间范围</span>
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-1.5 h-9">
                {timeRanges.map((r) => (
                  <button
                    key={r}
                    onClick={() => setTimeRange(r)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      timeRange === r
                        ? 'bg-primary text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-textSecondary">指标</span>
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-1.5 h-9">
                {metrics.map((m) => (
                  <button
                    key={m.key}
                    onClick={() => setMetricKey(m.key)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      metricKey === m.key
                        ? 'text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                    style={metricKey === m.key ? { backgroundColor: m.color } : undefined}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chart */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2 flex flex-row items-center gap-2">
          <BarChart3 size={16} className="text-neutral-textSecondary" />
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary">
            {metric.label}趋势 — {timeRange}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={360}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis
                dataKey="time"
                tick={{ fontSize: 11, fill: '#475569' }}
                axisLine={{ stroke: '#E2E8F0' }}
              />
              <YAxis
                tick={{ fontSize: 12, fill: '#475569' }}
                axisLine={{ stroke: '#E2E8F0' }}
                label={{ value: metric.unit, angle: -90, position: 'insideLeft', style: { fill: '#94A3B8', fontSize: 12 } }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => [`${value}${metric.unit}`, name === 'avg' ? '平均值' : name === 'max' ? '最大值' : '最小值']}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Line type="monotone" dataKey="avg" name="平均值" stroke={metric.color} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="max" name="最大值" stroke="#94A3B8" strokeWidth={1.5} strokeDasharray="5 5" dot={false} />
              <Line type="monotone" dataKey="min" name="最小值" stroke="#CBD5E1" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Data Table */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary">统计数据</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-neutral-border hover:bg-transparent">
                <TableHead className="text-neutral-textSecondary text-xs">时间点</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">平均值 ({metric.unit})</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">最大值 ({metric.unit})</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">最小值 ({metric.unit})</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((row, idx) => (
                <TableRow key={idx} className="border-neutral-border hover:bg-neutral-background">
                  <TableCell className="text-xs text-neutral-textPrimary">{row.time}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary font-number">{row.avg}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary font-number">{row.max}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary font-number">{row.min}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
