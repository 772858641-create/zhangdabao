import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShieldCheck,
  ArrowDownToLine,
  ArrowUpFromLine,
  CheckCircle,
  AlertTriangle,
  Settings2,
  Search,
  Clock,
  Signal,
  MapPin,
  Wifi,
  Hand,
  Layers,
  Play,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Eye,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ─────────────────────────── types ─────────────────────────── */

interface RuleTemplate {
  id: string;
  name: string;
  description: string;
  tags: string[];
  enabled: boolean;
  icon: LucideIcon;
  iconColor: string;
  iconBg: string;
  params: RuleParams;
}

interface RuleParams {
  debounceWindow: number;
  minStayTime: number;
  dedupInterval: number;
  signalThreshold: number;
  gpsAccuracyThreshold: number;
  judgeTimeout: number;
  retryCount: number;
}

interface InOutRecord {
  id: string;
  vehicleCode: string;
  judgeTime: string;
  vehicleId: string;
  judgeType: '入库' | '出库';
  judgeMode: string;
  site: string;
  result: '成功' | '失败' | '异常';
  duration: number;
  rawData: string;
  steps: JudgeStep[];
}

interface JudgeStep {
  name: string;
  time: string;
  status: '通过' | '失败' | '跳过' | '异常';
  detail: string;
}

interface KPICard {
  label: string;
  value: string;
  sub?: string;
  icon: LucideIcon;
  color: string;
  bgColor: string;
}

/* ─────────────────────── mock data ─────────────────────── */

const initialTemplates: RuleTemplate[] = [
  {
    id: 'beacon',
    name: '信标优先模式',
    description: '蓝牙信标信号强度阈值判定，RSSI>-70dBm视为在库',
    tags: ['室内场景', '蓝牙信标'],
    enabled: true,
    icon: Signal,
    iconColor: 'text-primary',
    iconBg: 'bg-primary-light',
    params: {
      debounceWindow: 30,
      minStayTime: 300,
      dedupInterval: 60,
      signalThreshold: -70,
      gpsAccuracyThreshold: 50,
      judgeTimeout: 10,
      retryCount: 3,
    },
  },
  {
    id: 'gateway',
    name: '网关优先模式',
    description: '固定读写器天线覆盖判定，载具ID被扫描即判定',
    tags: ['仓库场景', 'RFID网关'],
    enabled: true,
    icon: Wifi,
    iconColor: 'text-success',
    iconBg: 'bg-success-light',
    params: {
      debounceWindow: 20,
      minStayTime: 180,
      dedupInterval: 45,
      signalThreshold: -85,
      gpsAccuracyThreshold: 30,
      judgeTimeout: 8,
      retryCount: 2,
    },
  },
  {
    id: 'gps',
    name: 'GPS围栏模式',
    description: 'GPS地理坐标+电子围栏，载具进入/离开围栏区域',
    tags: ['室外场景', '地理围栏'],
    enabled: false,
    icon: MapPin,
    iconColor: 'text-info',
    iconBg: 'bg-info-light',
    params: {
      debounceWindow: 60,
      minStayTime: 600,
      dedupInterval: 120,
      signalThreshold: -100,
      gpsAccuracyThreshold: 50,
      judgeTimeout: 15,
      retryCount: 3,
    },
  },
  {
    id: 'combo',
    name: '组合确认模式',
    description: '信标+网关+GPS三重确认，2/3一致才判定',
    tags: ['高精度场景', '多源融合'],
    enabled: true,
    icon: Layers,
    iconColor: 'text-purple',
    iconBg: 'bg-purple-light',
    params: {
      debounceWindow: 45,
      minStayTime: 420,
      dedupInterval: 90,
      signalThreshold: -75,
      gpsAccuracyThreshold: 35,
      judgeTimeout: 20,
      retryCount: 3,
    },
  },
  {
    id: 'manual',
    name: '手动确认模式',
    description: '人工扫码/手动确认，无自动化判定',
    tags: ['备用模式', '人工介入'],
    enabled: false,
    icon: Hand,
    iconColor: 'text-warning',
    iconBg: 'bg-warning-light',
    params: {
      debounceWindow: 0,
      minStayTime: 0,
      dedupInterval: 0,
      signalThreshold: 0,
      gpsAccuracyThreshold: 0,
      judgeTimeout: 300,
      retryCount: 1,
    },
  },
];

const mockRecords: InOutRecord[] = [
  { id: 'R20250123001', vehicleCode: 'ZC-BJ-00123', judgeTime: '2025-01-23 08:12:33', vehicleId: 'V1000231', judgeType: '入库', judgeMode: '信标优先', site: '北京朝阳仓A区', result: '成功', duration: 230, rawData: 'RSSI:-62dBm|GW:GW-B-01', steps: [{ name: '信标检测', time: '08:12:33.120', status: '通过', detail: 'RSSI=-62dBm，高于阈值-70dBm' }, { name: '网关扫描', time: '08:12:33.450', status: '通过', detail: '网关GW-B-01信号正常' }, { name: 'GPS验证', time: '08:12:33.890', status: '跳过', detail: '室内场景GPS信号弱，已跳过' }, { name: '综合判定', time: '08:12:34.010', status: '通过', detail: '信标+网关双重确认通过' }, { name: '结果输出', time: '08:12:34.350', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123002', vehicleCode: 'ZC-SH-00456', judgeTime: '2025-01-23 08:15:07', vehicleId: 'V1000456', judgeType: '出库', judgeMode: '网关优先', site: '上海浦东仓B区', result: '成功', duration: 180, rawData: 'GW:GW-S-03|RSSI:-88dBm', steps: [{ name: '信标检测', time: '08:15:07.200', status: '跳过', detail: 'RSSI=-88dBm低于阈值' }, { name: '网关扫描', time: '08:15:07.380', status: '通过', detail: '网关GW-S-03检测到载具信号消失' }, { name: 'GPS验证', time: '08:15:07.550', status: '跳过', detail: '仓库内GPS信号弱' }, { name: '综合判定', time: '08:15:07.680', status: '通过', detail: '网关信号消失确认出库' }, { name: '结果输出', time: '08:15:07.380', status: '通过', detail: '判定结果：出库成功' }] },
  { id: 'R20250123003', vehicleCode: 'ZC-GZ-00789', judgeTime: '2025-01-23 08:22:18', vehicleId: 'V1000789', judgeType: '入库', judgeMode: 'GPS围栏', site: '广州白云分拨中心', result: '异常', duration: 15230, rawData: 'GPS:23.1832,113.2658|ACC:35m', steps: [{ name: '信标检测', time: '08:22:18.100', status: '跳过', detail: '未检测到蓝牙信标' }, { name: '网关扫描', time: '08:22:18.300', status: '跳过', detail: '室外场景无网关覆盖' }, { name: 'GPS验证', time: '08:22:18.600', status: '异常', detail: 'GPS精度35m，但坐标位于围栏边缘，判定超时' }, { name: '综合判定', time: '08:28:33.400', status: '异常', detail: '判定超时，未能确认入库状态' }, { name: '结果输出', time: '08:28:33.800', status: '异常', detail: '判定结果：入库异常，需人工介入' }] },
  { id: 'R20250123004', vehicleCode: 'ZC-CD-00321', judgeTime: '2025-01-23 08:30:45', vehicleId: 'V1000321', judgeType: '入库', judgeMode: '组合确认', site: '成都双流仓C区', result: '成功', duration: 890, rawData: 'RSSI:-65dBm|GW:GW-C-02|GPS:30.5705,103.9478', steps: [{ name: '信标检测', time: '08:30:45.120', status: '通过', detail: 'RSSI=-65dBm，信号良好' }, { name: '网关扫描', time: '08:30:45.500', status: '通过', detail: '网关GW-C-02检测到载具' }, { name: 'GPS验证', time: '08:30:46.010', status: '通过', detail: 'GPS坐标在围栏范围内' }, { name: '综合判定', time: '08:30:46.450', status: '通过', detail: '三重确认一致，3/3通过' }, { name: '结果输出', time: '08:30:47.010', status: '通过', detail: '判定结果：入库成功（高精度）' }] },
  { id: 'R20250123005', vehicleCode: 'ZC-HZ-00654', judgeTime: '2025-01-23 08:45:12', vehicleId: 'V1000654', judgeType: '出库', judgeMode: '手动确认', site: '杭州萧山仓D区', result: '成功', duration: 45200, rawData: 'SCAN:OP-001|MANUAL', steps: [{ name: '信标检测', time: '08:45:12.000', status: '跳过', detail: '手动模式跳过自动检测' }, { name: '网关扫描', time: '08:45:12.000', status: '跳过', detail: '手动模式跳过自动检测' }, { name: 'GPS验证', time: '08:45:12.000', status: '跳过', detail: '手动模式跳过自动检测' }, { name: '综合判定', time: '08:45:12.000', status: '通过', detail: '操作员OP-001扫码确认出库' }, { name: '结果输出', time: '08:46:02.200', status: '通过', detail: '判定结果：出库成功（人工确认）' }] },
  { id: 'R20250123006', vehicleCode: 'ZC-BJ-00234', judgeTime: '2025-01-23 09:00:33', vehicleId: 'V1000234', judgeType: '入库', judgeMode: '信标优先', site: '北京海淀仓E区', result: '失败', duration: 560, rawData: 'RSSI:-92dBm|GW:N/A', steps: [{ name: '信标检测', time: '09:00:33.300', status: '失败', detail: 'RSSI=-92dBm，低于阈值-70dBm' }, { name: '网关扫描', time: '09:00:33.600', status: '失败', detail: '未检测到网关信号' }, { name: 'GPS验证', time: '09:00:33.860', status: '跳过', detail: '室内场景' }, { name: '综合判定', time: '09:00:34.120', status: '失败', detail: '无有效信号源，无法确认入库' }, { name: '结果输出', time: '09:00:34.860', status: '失败', detail: '判定结果：入库失败' }] },
  { id: 'R20250123007', vehicleCode: 'ZC-SZ-00987', judgeTime: '2025-01-23 09:15:22', vehicleId: 'V1000987', judgeType: '入库', judgeMode: '网关优先', site: '深圳南山仓F区', result: '成功', duration: 210, rawData: 'GW:GW-SZ-01|RSSI:-80dBm', steps: [{ name: '信标检测', time: '09:15:22.100', status: '跳过', detail: 'RSSI信号弱' }, { name: '网关扫描', time: '09:15:22.310', status: '通过', detail: '网关GW-SZ-01确认在库' }, { name: 'GPS验证', time: '09:15:22.520', status: '跳过', detail: '仓库内GPS不可用' }, { name: '综合判定', time: '09:15:22.750', status: '通过', detail: '网关确认在库' }, { name: '结果输出', time: '09:15:22.310', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123008', vehicleCode: 'ZC-WH-00543', judgeTime: '2025-01-23 09:30:11', vehicleId: 'V1000543', judgeType: '出库', judgeMode: 'GPS围栏', site: '武汉光谷分拨中心', result: '成功', duration: 420, rawData: 'GPS:30.5074,114.3979|ACC:12m', steps: [{ name: '信标检测', time: '09:30:11.200', status: '跳过', detail: '未检测到信标' }, { name: '网关扫描', time: '09:30:11.400', status: '跳过', detail: '分拨中心无网关' }, { name: 'GPS验证', time: '09:30:11.620', status: '通过', detail: 'GPS精度12m，坐标已离开围栏区域' }, { name: '综合判定', time: '09:30:11.840', status: '通过', detail: 'GPS围栏外确认出库' }, { name: '结果输出', time: '09:30:11.620', status: '通过', detail: '判定结果：出库成功' }] },
  { id: 'R20250123009', vehicleCode: 'ZC-XA-00876', judgeTime: '2025-01-23 09:45:55', vehicleId: 'V1000876', judgeType: '入库', judgeMode: '组合确认', site: '西安高新仓G区', result: '成功', duration: 1050, rawData: 'RSSI:-68dBm|GW:GW-XA-03|GPS:34.2659,108.9541', steps: [{ name: '信标检测', time: '09:45:55.100', status: '通过', detail: 'RSSI=-68dBm，信号良好' }, { name: '网关扫描', time: '09:45:55.650', status: '通过', detail: 'GW-XA-03检测到载具' }, { name: 'GPS验证', time: '09:45:56.150', status: '失败', detail: 'GPS坐标偏离围栏中心82m' }, { name: '综合判定', time: '09:45:56.600', status: '通过', detail: '2/3确认通过（信标+网关）' }, { name: '结果输出', time: '09:45:57.100', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123010', vehicleCode: 'ZC-NJ-00109', judgeTime: '2025-01-23 10:00:28', vehicleId: 'V1000109', judgeType: '出库', judgeMode: '信标优先', site: '南京江宁仓H区', result: '成功', duration: 280, rawData: 'RSSI:-85dBm|GW:GW-NJ-02', steps: [{ name: '信标检测', time: '10:00:28.200', status: '失败', detail: 'RSSI=-85dBm信号弱，判定离开' }, { name: '网关扫描', time: '10:00:28.480', status: '通过', detail: 'GW-NJ-02信号消失确认出库' }, { name: 'GPS验证', time: '10:00:28.760', status: '跳过', detail: '室内场景' }, { name: '综合判定', time: '10:00:28.480', status: '通过', detail: '信标消失+网关消失确认出库' }, { name: '结果输出', time: '10:00:28.480', status: '通过', detail: '判定结果：出库成功' }] },
  { id: 'R20250123011', vehicleCode: 'ZC-TJ-00432', judgeTime: '2025-01-23 10:15:44', vehicleId: 'V1000432', judgeType: '入库', judgeMode: '手动确认', site: '天津滨海仓I区', result: '成功', duration: 31200, rawData: 'SCAN:OP-012|MANUAL', steps: [{ name: '信标检测', time: '10:15:44.000', status: '跳过', detail: '手动模式' }, { name: '网关扫描', time: '10:15:44.000', status: '跳过', detail: '手动模式' }, { name: 'GPS验证', time: '10:15:44.000', status: '跳过', detail: '手动模式' }, { name: '综合判定', time: '10:16:15.200', status: '通过', detail: '操作员OP-012扫码确认入库' }, { name: '结果输出', time: '10:16:15.200', status: '通过', detail: '判定结果：入库成功（人工）' }] },
  { id: 'R20250123012', vehicleCode: 'ZC-SY-00765', judgeTime: '2025-01-23 10:30:19', vehicleId: 'V1000765', judgeType: '出库', judgeMode: '组合确认', site: '沈阳铁西仓J区', result: '失败', duration: 1850, rawData: 'RSSI:-95dBm|GW:N/A|GPS:41.8057,123.4315', steps: [{ name: '信标检测', time: '10:30:19.300', status: '失败', detail: 'RSSI=-95dBm，信号极弱' }, { name: '网关扫描', time: '10:30:19.600', status: '失败', detail: '未扫描到载具ID' }, { name: 'GPS验证', time: '10:30:19.900', status: '失败', detail: 'GPS坐标在围栏外，精度65m' }, { name: '综合判定', time: '10:30:20.150', status: '失败', detail: '0/3确认失败，无法判定状态' }, { name: '结果输出', time: '10:30:21.150', status: '失败', detail: '判定结果：出库失败' }] },
  { id: 'R20250123013', vehicleCode: 'ZC-BJ-00890', judgeTime: '2025-01-23 10:45:37', vehicleId: 'V1000890', judgeType: '入库', judgeMode: '网关优先', site: '北京通州仓K区', result: '成功', duration: 195, rawData: 'GW:GW-TZ-01|RSSI:-78dBm', steps: [{ name: '信标检测', time: '10:45:37.100', status: '跳过', detail: '信标信号一般' }, { name: '网关扫描', time: '10:45:37.295', status: '通过', detail: 'GW-TZ-01确认检测到载具' }, { name: 'GPS验证', time: '10:45:37.490', status: '跳过', detail: '室内无GPS' }, { name: '综合判定', time: '10:45:37.295', status: '通过', detail: '网关单源确认入库' }, { name: '结果输出', time: '10:45:37.295', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123014', vehicleCode: 'ZC-CS-00333', judgeTime: '2025-01-23 11:00:03', vehicleId: 'V1000333', judgeType: '出库', judgeMode: 'GPS围栏', site: '长沙岳麓分拨中心', result: '异常', duration: 16200, rawData: 'GPS:28.2282,112.9388|ACC:78m', steps: [{ name: '信标检测', time: '11:00:03.200', status: '跳过', detail: '无信标覆盖' }, { name: '网关扫描', time: '11:00:03.400', status: '跳过', detail: '无网关覆盖' }, { name: 'GPS验证', time: '11:00:03.700', status: '异常', detail: 'GPS精度78m，无法确认围栏边界' }, { name: '综合判定', time: '11:04:23.700', status: '异常', detail: '判定超时，GPS精度不足' }, { name: '结果输出', time: '11:04:24.200', status: '异常', detail: '判定结果：出库异常，人工确认' }] },
  { id: 'R20250123015', vehicleCode: 'ZC-BJ-00555', judgeTime: '2025-01-23 11:15:26', vehicleId: 'V1000555', judgeType: '入库', judgeMode: '信标优先', site: '北京大兴仓L区', result: '成功', duration: 340, rawData: 'RSSI:-58dBm|GW:GW-DX-02', steps: [{ name: '信标检测', time: '11:15:26.150', status: '通过', detail: 'RSSI=-58dBm，信号强' }, { name: '网关扫描', time: '11:15:26.490', status: '通过', detail: 'GW-DX-02同时检测到' }, { name: 'GPS验证', time: '11:15:26.830', status: '跳过', detail: '室内场景' }, { name: '综合判定', time: '11:15:26.490', status: '通过', detail: '信标+网关双重确认' }, { name: '结果输出', time: '11:15:26.490', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123016', vehicleCode: 'ZC-QD-00222', judgeTime: '2025-01-23 11:30:51', vehicleId: 'V1000222', judgeType: '出库', judgeMode: '网关优先', site: '青岛黄岛仓M区', result: '成功', duration: 205, rawData: 'GW:GW-HD-03|RSSI:-82dBm', steps: [{ name: '信标检测', time: '11:30:51.100', status: '跳过', detail: '信标信号弱' }, { name: '网关扫描', time: '11:30:51.305', status: '通过', detail: 'GW-HD-03信号消失，确认出库' }, { name: 'GPS验证', time: '11:30:51.510', status: '跳过', detail: '仓库内GPS弱' }, { name: '综合判定', time: '11:30:51.305', status: '通过', detail: '网关信号消失确认出库' }, { name: '结果输出', time: '11:30:51.305', status: '通过', detail: '判定结果：出库成功' }] },
  { id: 'R20250123017', vehicleCode: 'ZC-ZZ-00666', judgeTime: '2025-01-23 11:45:14', vehicleId: 'V1000666', judgeType: '入库', judgeMode: '组合确认', site: '郑州航空仓N区', result: '成功', duration: 920, rawData: 'RSSI:-72dBm|GW:GW-ZZ-01|GPS:34.7466,113.6253', steps: [{ name: '信标检测', time: '11:45:14.200', status: '通过', detail: 'RSSI=-72dBm，略低于阈值但可接受' }, { name: '网关扫描', time: '11:45:14.650', status: '通过', detail: 'GW-ZZ-01检测到载具' }, { name: 'GPS验证', time: '11:45:15.120', status: '通过', detail: 'GPS在围栏内，精度22m' }, { name: '综合判定', time: '11:45:15.120', status: '通过', detail: '3/3全部通过，高精度入库' }, { name: '结果输出', time: '11:45:15.120', status: '通过', detail: '判定结果：入库成功（高精度）' }] },
  { id: 'R20250123018', vehicleCode: 'ZC-NN-00999', judgeTime: '2025-01-23 12:00:42', vehicleId: 'V1000999', judgeType: '出库', judgeMode: '手动确认', site: '南宁江南仓O区', result: '成功', duration: 28700, rawData: 'SCAN:OP-008|MANUAL', steps: [{ name: '信标检测', time: '12:00:42.000', status: '跳过', detail: '手动模式' }, { name: '网关扫描', time: '12:00:42.000', status: '跳过', detail: '手动模式' }, { name: 'GPS验证', time: '12:00:42.000', status: '跳过', detail: '手动模式' }, { name: '综合判定', time: '12:01:10.700', status: '通过', detail: '操作员OP-008扫码确认出库' }, { name: '结果输出', time: '12:01:11.700', status: '通过', detail: '判定结果：出库成功（人工确认）' }] },
  { id: 'R20250123019', vehicleCode: 'ZC-KM-00111', judgeTime: '2025-01-23 12:15:33', vehicleId: 'V1000111', judgeType: '入库', judgeMode: '信标优先', site: '昆明官渡仓P区', result: '成功', duration: 255, rawData: 'RSSI:-63dBm|GW:KM-GD-01', steps: [{ name: '信标检测', time: '12:15:33.100', status: '通过', detail: 'RSSI=-63dBm，信号良好' }, { name: '网关扫描', time: '12:15:33.355', status: '通过', detail: 'KM-GD-01确认' }, { name: 'GPS验证', time: '12:15:33.610', status: '跳过', detail: '室内场景' }, { name: '综合判定', time: '12:15:33.355', status: '通过', detail: '双重确认入库' }, { name: '结果输出', time: '12:15:33.355', status: '通过', detail: '判定结果：入库成功' }] },
  { id: 'R20250123020', vehicleCode: 'ZC-LZ-00777', judgeTime: '2025-01-23 12:30:17', vehicleId: 'V1000777', judgeType: '出库', judgeMode: '网关优先', site: '兰州城关仓Q区', result: '失败', duration: 480, rawData: 'GW:N/A|RSSI:-90dBm', steps: [{ name: '信标检测', time: '12:30:17.200', status: '失败', detail: 'RSSI=-90dBm低于阈值' }, { name: '网关扫描', time: '12:30:17.500', status: '失败', detail: '未扫描到载具，网关故障' }, { name: 'GPS验证', time: '12:30:17.800', status: '跳过', detail: '室内场景' }, { name: '综合判定', time: '12:30:18.100', status: '失败', detail: '无有效信号，无法判定' }, { name: '结果输出', time: '12:30:17.680', status: '失败', detail: '判定结果：出库失败' }] },
];

const kpiCards: KPICard[] = [
  { label: '生效规则数', value: '3', sub: '/ 5 套模板', icon: ShieldCheck, color: 'text-primary', bgColor: 'bg-primary-light' },
  { label: '今日入库判定', value: '1,247', sub: '+8.3% 环比', icon: ArrowDownToLine, color: 'text-success', bgColor: 'bg-success-light' },
  { label: '今日出库判定', value: '1,089', sub: '+5.1% 环比', icon: ArrowUpFromLine, color: 'text-info', bgColor: 'bg-info-light' },
  { label: '判定成功率', value: '98.6%', sub: '目标 ≥95%', icon: CheckCircle, color: 'text-warning', bgColor: 'bg-warning-light' },
  { label: '待处理异常', value: '7', sub: '需人工介入', icon: AlertTriangle, color: 'text-danger', bgColor: 'bg-danger-light' },
];

const tabItems = [
  { value: 'templates', label: '规则模板', icon: ShieldCheck },
  { value: 'records', label: '出入库记录', icon: Clock },
  { value: 'simulation', label: '判定模拟', icon: Play },
];

const paramLabels: { key: keyof RuleParams; label: string; unit: string }[] = [
  { key: 'debounceWindow', label: '防抖时间窗口', unit: '秒' },
  { key: 'minStayTime', label: '最短停留时间', unit: '秒' },
  { key: 'dedupInterval', label: '防重间隔', unit: '秒' },
  { key: 'signalThreshold', label: '信号强度阈值', unit: 'dBm' },
  { key: 'gpsAccuracyThreshold', label: 'GPS精度阈值', unit: '米' },
  { key: 'judgeTimeout', label: '判定超时时间', unit: '秒' },
  { key: 'retryCount', label: '重试次数', unit: '次' },
];

const sites = ['全部网点', '北京朝阳仓A区', '上海浦东仓B区', '广州白云分拨中心', '成都双流仓C区', '杭州萧山仓D区', '北京海淀仓E区', '深圳南山仓F区', '武汉光谷分拨中心', '西安高新仓G区', '南京江宁仓H区', '天津滨海仓I区', '沈阳铁西仓J区', '北京通州仓K区', '长沙岳麓分拨中心', '北京大兴仓L区', '青岛黄岛仓M区', '郑州航空仓N区', '南宁江南仓O区', '昆明官渡仓P区', '兰州城关仓Q区'];

const judgeModes = ['全部模式', '信标优先', '网关优先', 'GPS围栏', '组合确认', '手动确认'];

/* ─────────────────────── helper components ─────────────────────── */

function ResultBadge({ result }: { result: string }) {
  const map: Record<string, { cls: string; icon: LucideIcon }> = {
    '成功': { cls: 'bg-success-light text-success border-success/20', icon: CheckCircle2 },
    '失败': { cls: 'bg-danger-light text-danger border-danger/20', icon: XCircle },
    '异常': { cls: 'bg-warning-light text-warning border-warning/20', icon: AlertCircle },
  };
  const config = map[result] || map['异常'];
  const Icon = config.icon;
  return (
    <Badge variant="outline" className={cn('gap-1', config.cls)}>
      <Icon size={12} />
      {result}
    </Badge>
  );
}

function StepStatusIcon({ status }: { status: string }) {
  if (status === '通过') return <CheckCircle2 size={16} className="text-success shrink-0" />;
  if (status === '失败') return <XCircle size={16} className="text-danger shrink-0" />;
  return <AlertCircle size={16} className="text-neutral-textTertiary shrink-0" />;
}

/* ─────────────────────── main page ─────────────────────── */

export default function InOutRuleEnginePage() {
  const [activeTab, setActiveTab] = useState('templates');
  const [templates, setTemplates] = useState<RuleTemplate[]>(initialTemplates);

  /* -- edit dialog -- */
  const [editOpen, setEditOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<RuleTemplate | null>(null);
  const [editParams, setEditParams] = useState<RuleParams>({
    debounceWindow: 30, minStayTime: 300, dedupInterval: 60,
    signalThreshold: -70, gpsAccuracyThreshold: 50, judgeTimeout: 10, retryCount: 3,
  });

  const openEditDialog = useCallback((t: RuleTemplate) => {
    setEditingTemplate(t);
    setEditParams({ ...t.params });
    setEditOpen(true);
  }, []);

  const saveEdit = useCallback(() => {
    if (!editingTemplate) return;
    setTemplates(prev => prev.map(t => t.id === editingTemplate.id ? { ...t, params: editParams } : t));
    setEditOpen(false);
  }, [editingTemplate, editParams]);

  /* -- rule toggle -- */
  const toggleTemplate = useCallback((id: string) => {
    setTemplates(prev => prev.map(t => t.id === id ? { ...t, enabled: !t.enabled } : t));
  }, []);

  /* -- records filter -- */
  const [timeRange, setTimeRange] = useState('today');
  const [searchCode, setSearchCode] = useState('');
  const [filterSite, setFilterSite] = useState('全部网点');
  const [filterMode, setFilterMode] = useState('全部模式');
  const [filterResult, setFilterResult] = useState('全部');

  const filteredRecords = mockRecords.filter(r => {
    if (searchCode && !r.vehicleCode.toLowerCase().includes(searchCode.toLowerCase()) && !r.vehicleId.toLowerCase().includes(searchCode.toLowerCase())) return false;
    if (filterSite !== '全部网点' && r.site !== filterSite) return false;
    if (filterMode !== '全部模式' && r.judgeMode !== filterMode) return false;
    if (filterResult !== '全部' && r.result !== filterResult) return false;
    return true;
  });

  /* -- detail dialog -- */
  const [detailRecord, setDetailRecord] = useState<InOutRecord | null>(null);

  /* -- simulation -- */
  const [simVehicleId, setSimVehicleId] = useState('V1000231');
  const [simTemplate, setSimTemplate] = useState('beacon');
  const [simRssi, setSimRssi] = useState('-65');
  const [simGateway, setSimGateway] = useState('GW-B-01');
  const [simGps, setSimGps] = useState('39.9042,116.4074');
  const [simResult, setSimResult] = useState<{
    steps: { name: string; status: string; detail: string }[];
    finalResult: string;
    duration: number;
  } | null>(null);
  const [simRunning, setSimRunning] = useState(false);

  const runSimulation = useCallback(() => {
    setSimRunning(true);
    setSimResult(null);
    setTimeout(() => {
      const tmpl = templates.find(t => t.id === simTemplate);
      const rssiVal = parseInt(simRssi, 10) || -100;
      const hasGateway = simGateway.trim().length > 0 && simGateway !== 'N/A';
      const hasGps = simGps.trim().length > 0 && simGps !== 'N/A';

      const steps: { name: string; status: string; detail: string }[] = [];
      let passCount = 0;
      let totalChecks = 0;

      // Step 1: beacon
      if (tmpl?.id === 'manual') {
        steps.push({ name: '信标检测', status: '跳过', detail: '手动模式跳过自动检测' });
      } else {
        totalChecks++;
        if (rssiVal > (tmpl?.params.signalThreshold ?? -70)) {
          steps.push({ name: '信标检测', status: '通过', detail: `RSSI=${rssiVal}dBm，高于阈值${tmpl?.params.signalThreshold ?? -70}dBm` });
          passCount++;
        } else {
          steps.push({ name: '信标检测', status: '失败', detail: `RSSI=${rssiVal}dBm，低于阈值${tmpl?.params.signalThreshold ?? -70}dBm` });
        }
      }

      // Step 2: gateway
      if (tmpl?.id === 'manual') {
        steps.push({ name: '网关扫描', status: '跳过', detail: '手动模式跳过自动检测' });
      } else {
        totalChecks++;
        if (hasGateway) {
          steps.push({ name: '网关扫描', status: '通过', detail: `网关${simGateway}检测到载具信号` });
          passCount++;
        } else {
          steps.push({ name: '网关扫描', status: '失败', detail: '未检测到有效网关信号' });
        }
      }

      // Step 3: GPS
      if (tmpl?.id === 'manual') {
        steps.push({ name: 'GPS验证', status: '跳过', detail: '手动模式跳过自动检测' });
      } else {
        totalChecks++;
        if (hasGps) {
          steps.push({ name: 'GPS验证', status: '通过', detail: `GPS坐标${simGps}在围栏范围内` });
          passCount++;
        } else {
          steps.push({ name: 'GPS验证', status: '失败', detail: '未提供有效GPS坐标' });
        }
      }

      // Step 4: combine
      let finalResult = '';
      if (tmpl?.id === 'manual') {
        steps.push({ name: '综合判定', status: '通过', detail: '人工扫码确认，直接通过' });
        finalResult = '入库（人工确认）';
      } else if (tmpl?.id === 'combo') {
        if (passCount >= 2) {
          steps.push({ name: '综合判定', status: '通过', detail: `${passCount}/3确认通过，满足组合确认条件` });
          finalResult = '入库（组合确认）';
        } else {
          steps.push({ name: '综合判定', status: '失败', detail: `${passCount}/3确认失败，不满足组合条件` });
          finalResult = '未判定（确认不足）';
        }
      } else if (passCount > 0) {
        steps.push({ name: '综合判定', status: '通过', detail: `${passCount}项检测通过，判定有效` });
        finalResult = rssiVal > (tmpl?.params.signalThreshold ?? -70) || hasGateway ? '入库' : '未判定';
      } else {
        steps.push({ name: '综合判定', status: '失败', detail: '所有检测项均未通过' });
        finalResult = '未判定';
      }

      // Step 5: output
      steps.push({ name: '结果输出', status: finalResult.includes('未判定') ? '失败' : '通过', detail: `判定结果：${finalResult}` });

      const duration = Math.floor(Math.random() * 800) + 150;
      setSimResult({ steps, finalResult, duration });
      setSimRunning(false);
    }, 800);
  }, [simTemplate, simRssi, simGateway, simGps, templates]);

  /* ─────────────────────── render ─────────────────────── */

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-neutral-textPrimary">精准出入库判定</h1>
        <p className="text-sm text-neutral-textSecondary mt-1">
          规则模板 · 判定引擎 · 出入库记录
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {kpiCards.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.06 }}
            >
              <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={cn('w-10 h-10 rounded-full flex items-center justify-center shrink-0', kpi.bgColor)}>
                    <Icon size={20} className={kpi.color} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-neutral-textTertiary">{kpi.label}</p>
                    <p className="text-lg font-semibold text-neutral-textPrimary font-number truncate">{kpi.value}</p>
                    {kpi.sub && <p className="text-xs text-neutral-textTertiary">{kpi.sub}</p>}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-neutral-surface-elevated border border-neutral-border h-10 p-1">
          {tabItems.map((tab) => {
            const Icon = tab.icon;
            return (
              <TabsTrigger
                key={tab.value}
                value={tab.value}
                className={cn(
                  'text-xs px-3 py-1.5 rounded-md transition-all data-[state=active]:shadow-sm',
                  activeTab === tab.value
                    ? 'bg-neutral-surface text-neutral-textPrimary font-medium'
                    : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                )}
              >
                <Icon size={14} className="mr-1.5" />
                {tab.label}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {/* ====== Tab 1: Rule Templates ====== */}
        <TabsContent value="templates" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <AnimatePresence>
              {templates.map((tmpl, idx) => {
                const Icon = tmpl.icon;
                return (
                  <motion.div
                    key={tmpl.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: idx * 0.06 }}
                  >
                    <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-all h-full">
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            <div className={cn('w-8 h-8 rounded-full flex items-center justify-center', tmpl.iconBg)}>
                              <Icon size={16} className={tmpl.iconColor} />
                            </div>
                            <CardTitle className="text-sm font-semibold text-neutral-textPrimary">{tmpl.name}</CardTitle>
                          </div>
                          <Badge
                            variant="outline"
                            className={cn(
                              tmpl.enabled
                                ? 'bg-success-light text-success border-success/20'
                                : 'bg-neutral-surface-elevated text-neutral-textTertiary border-neutral-border'
                            )}
                          >
                            {tmpl.enabled ? '已启用' : '未启用'}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3 pt-0">
                        <p className="text-xs text-neutral-textSecondary leading-relaxed">{tmpl.description}</p>
                        <div className="flex flex-wrap gap-1.5">
                          {tmpl.tags.map(tag => (
                            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-full bg-primary-light text-primary border border-primary-border">
                              {tag}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t border-neutral-border">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-neutral-textSecondary">启用</span>
                            <Switch checked={tmpl.enabled} onCheckedChange={() => toggleTemplate(tmpl.id)} />
                          </div>
                          <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => openEditDialog(tmpl)}>
                            <Settings2 size={12} className="mr-1" />
                            编辑参数
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </TabsContent>

        {/* ====== Tab 2: Records ====== */}
        <TabsContent value="records" className="mt-0 space-y-4">
          {/* Filters */}
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-3 items-end">
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">时间范围</label>
                  <Select value={timeRange} onValueChange={setTimeRange}>
                    <SelectTrigger className="w-32 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">今日</SelectItem>
                      <SelectItem value="7days">近7天</SelectItem>
                      <SelectItem value="30days">近30天</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">载具编码</label>
                  <div className="relative">
                    <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
                    <Input
                      placeholder="搜索编码或ID"
                      value={searchCode}
                      onChange={e => setSearchCode(e.target.value)}
                      className="w-44 h-8 text-xs pl-8"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">网点</label>
                  <Select value={filterSite} onValueChange={setFilterSite}>
                    <SelectTrigger className="w-40 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {sites.map(s => (
                        <SelectItem key={s} value={s} className="text-xs">{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">判定模式</label>
                  <Select value={filterMode} onValueChange={setFilterMode}>
                    <SelectTrigger className="w-32 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {judgeModes.map(m => (
                        <SelectItem key={m} value={m} className="text-xs">{m}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">结果</label>
                  <Select value={filterResult} onValueChange={setFilterResult}>
                    <SelectTrigger className="w-28 h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="全部" className="text-xs">全部</SelectItem>
                      <SelectItem value="成功" className="text-xs">成功</SelectItem>
                      <SelectItem value="失败" className="text-xs">失败</SelectItem>
                      <SelectItem value="异常" className="text-xs">异常</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Table */}
          <Card className="bg-neutral-surface border-neutral-border overflow-hidden">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-neutral-surface-elevated hover:bg-neutral-surface-elevated">
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">记录ID</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">载具编码</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">判定时间</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">载具ID</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">判定类型</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">判定模式</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">判定网点</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">判定结果</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">耗时(ms)</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary">原始数据</TableHead>
                    <TableHead className="text-xs font-medium text-neutral-textSecondary w-16">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id} className="hover:bg-neutral-surface-elevated/50">
                      <TableCell className="text-xs text-neutral-textPrimary font-medium">{record.id}</TableCell>
                      <TableCell className="text-xs text-neutral-textPrimary">{record.vehicleCode}</TableCell>
                      <TableCell className="text-xs text-neutral-textSecondary whitespace-nowrap">{record.judgeTime}</TableCell>
                      <TableCell className="text-xs text-neutral-textSecondary">{record.vehicleId}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn(
                          'text-[10px]',
                          record.judgeType === '入库' ? 'bg-success-light text-success border-success/20' : 'bg-info-light text-info border-info/20'
                        )}>
                          {record.judgeType}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-neutral-textSecondary">{record.judgeMode}</TableCell>
                      <TableCell className="text-xs text-neutral-textSecondary max-w-[140px] truncate" title={record.site}>{record.site}</TableCell>
                      <TableCell><ResultBadge result={record.result} /></TableCell>
                      <TableCell className="text-xs font-number text-neutral-textPrimary">{record.duration.toLocaleString()}</TableCell>
                      <TableCell className="text-xs text-neutral-textTertiary max-w-[160px] truncate" title={record.rawData}>{record.rawData}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => setDetailRecord(record)}>
                          <Eye size={14} className="text-neutral-textSecondary" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {filteredRecords.length === 0 && (
              <div className="py-12 text-center text-sm text-neutral-textTertiary">
                暂无匹配记录
              </div>
            )}
          </Card>
        </TabsContent>

        {/* ====== Tab 3: Simulation ====== */}
        <TabsContent value="simulation" className="mt-0 space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Input Panel */}
            <Card className="bg-neutral-surface border-neutral-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-neutral-textPrimary">模拟参数设置</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-0">
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">载具ID</label>
                  <Input value={simVehicleId} onChange={e => setSimVehicleId(e.target.value)} placeholder="如 V1000231" className="h-9 text-xs" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">判定模板</label>
                  <Select value={simTemplate} onValueChange={setSimTemplate}>
                    <SelectTrigger className="h-9 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map(t => (
                        <SelectItem key={t.id} value={t.id} className="text-xs">{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">模拟信标RSSI (dBm)</label>
                  <Input value={simRssi} onChange={e => setSimRssi(e.target.value)} placeholder="如 -65" className="h-9 text-xs" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">模拟网关ID</label>
                  <Input value={simGateway} onChange={e => setSimGateway(e.target.value)} placeholder="如 GW-B-01 或 N/A" className="h-9 text-xs" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs text-neutral-textSecondary">模拟GPS坐标</label>
                  <Input value={simGps} onChange={e => setSimGps(e.target.value)} placeholder="如 39.9042,116.4074 或 N/A" className="h-9 text-xs" />
                </div>
                <Button
                  onClick={runSimulation}
                  disabled={simRunning}
                  className="w-full h-9 text-xs bg-primary hover:bg-primary-hover"
                >
                  <Play size={14} className="mr-1.5" />
                  {simRunning ? '判定运行中...' : '运行判定'}
                </Button>
              </CardContent>
            </Card>

            {/* Result Panel */}
            <Card className="bg-neutral-surface border-neutral-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold text-neutral-textPrimary">判定结果</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                {!simResult && !simRunning && (
                  <div className="py-16 text-center text-sm text-neutral-textTertiary">
                    点击「运行判定」查看模拟结果
                  </div>
                )}
                {simRunning && (
                  <div className="py-16 text-center">
                    <div className="inline-block w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs text-neutral-textSecondary mt-2">正在运行判定引擎...</p>
                  </div>
                )}
                <AnimatePresence>
                  {simResult && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="space-y-4"
                    >
                      {/* Final result badge */}
                      <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-surface-elevated border border-neutral-border">
                        <div>
                          <p className="text-xs text-neutral-textSecondary">最终结果</p>
                          <p className={cn(
                            'text-sm font-semibold mt-0.5',
                            simResult.finalResult.includes('未判定') ? 'text-danger' : 'text-success'
                          )}>
                            {simResult.finalResult}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-neutral-textSecondary">判定耗时</p>
                          <p className="text-sm font-semibold font-number text-neutral-textPrimary mt-0.5">{simResult.duration}ms</p>
                        </div>
                      </div>

                      {/* Steps timeline */}
                      <div className="space-y-0">
                        {simResult.steps.map((step, i) => (
                          <div key={step.name} className="flex gap-3 relative">
                            {i < simResult.steps.length - 1 && (
                              <div className="absolute left-[7px] top-6 w-px h-[calc(100%-12px)] bg-neutral-border" />
                            )}
                            <div className="mt-0.5">
                              <StepStatusIcon status={step.status} />
                            </div>
                            <div className="pb-4">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-medium text-neutral-textPrimary">{step.name}</span>
                                <Badge variant="outline" className={cn('text-[10px]', step.status === '通过' ? 'bg-success-light text-success border-success/20' : step.status === '失败' ? 'bg-danger-light text-danger border-danger/20' : 'bg-neutral-surface-elevated text-neutral-textTertiary border-neutral-border')}>
                                  {step.status}
                                </Badge>
                              </div>
                              <p className="text-xs text-neutral-textSecondary mt-0.5">{step.detail}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* ====== Edit Dialog ====== */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">编辑参数 - {editingTemplate?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            {paramLabels.map(({ key, label, unit }) => (
              <div key={key} className="flex items-center justify-between gap-4">
                <label className="text-xs text-neutral-textSecondary shrink-0">{label}</label>
                <div className="flex items-center gap-2 w-40">
                  <Input
                    type="number"
                    value={editParams[key]}
                    onChange={e => setEditParams(prev => ({ ...prev, [key]: Number(e.target.value) }))}
                    className="h-8 text-xs"
                  />
                  <span className="text-xs text-neutral-textTertiary shrink-0 w-8">{unit}</span>
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setEditOpen(false)}>取消</Button>
            <Button size="sm" className="h-8 text-xs bg-primary hover:bg-primary-hover" onClick={saveEdit}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ====== Detail Dialog ====== */}
      <Dialog open={!!detailRecord} onOpenChange={() => setDetailRecord(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">判定详情 - {detailRecord?.id}</DialogTitle>
          </DialogHeader>
          {detailRecord && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">载具编码</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5">{detailRecord.vehicleCode}</p>
                </div>
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">载具ID</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5">{detailRecord.vehicleId}</p>
                </div>
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">判定类型</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5">{detailRecord.judgeType}</p>
                </div>
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">判定模式</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5">{detailRecord.judgeMode}</p>
                </div>
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">判定网点</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5">{detailRecord.site}</p>
                </div>
                <div className="p-2 rounded bg-neutral-surface-elevated border border-neutral-border">
                  <span className="text-neutral-textTertiary">判定耗时</span>
                  <p className="font-medium text-neutral-textPrimary mt-0.5 font-number">{detailRecord.duration.toLocaleString()} ms</p>
                </div>
              </div>

              <div>
                <p className="text-xs font-medium text-neutral-textSecondary mb-2">判定过程日志</p>
                <div className="space-y-0">
                  {detailRecord.steps.map((step, i) => (
                    <div key={step.name} className="flex gap-3 relative">
                      {i < detailRecord.steps.length - 1 && (
                        <div className="absolute left-[7px] top-6 w-px h-[calc(100%-12px)] bg-neutral-border" />
                      )}
                      <div className="mt-0.5">
                        <StepStatusIcon status={step.status} />
                      </div>
                      <div className="pb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-neutral-textPrimary">{step.name}</span>
                          <Badge variant="outline" className={cn('text-[10px]', step.status === '通过' ? 'bg-success-light text-success border-success/20' : step.status === '失败' ? 'bg-danger-light text-danger border-danger/20' : step.status === '异常' ? 'bg-warning-light text-warning border-warning/20' : 'bg-neutral-surface-elevated text-neutral-textTertiary border-neutral-border')}>
                            {step.status}
                          </Badge>
                        </div>
                        <p className="text-[10px] text-neutral-textTertiary mt-0.5 font-number">{step.time}</p>
                        <p className="text-xs text-neutral-textSecondary mt-0.5">{step.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
