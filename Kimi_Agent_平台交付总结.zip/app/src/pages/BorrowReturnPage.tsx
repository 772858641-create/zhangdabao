import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Package,
  ArrowLeftRight,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Plus,
  Eye,
  Calendar,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type BorrowStatus = '待审批' | '已批准' | '已拒绝' | '已借出' | '已归还';

interface BorrowRecord {
  id: string;
  org: string;
  carrierType: string;
  quantity: number;
  reason: string;
  borrowDate: string;
  dueDate: string;
  status: BorrowStatus;
  approver?: string;
}

interface ReturnRecord {
  id: string;
  borrowId: string;
  carrierType: string;
  quantity: number;
  borrowDate: string;
  dueDate: string;
  actualReturnDate: string;
  overdue: boolean;
  status: '待归还' | '已归还' | '延期处理';
}

interface InventoryItem {
  carrierType: string;
  available: number;
  borrowed: number;
  total: number;
}

/* ------------------------------------------------------------------ */
/*  Mock Data — 25 borrow records                                      */
/* ------------------------------------------------------------------ */

const BORROW_MOCK: BorrowRecord[] = [
  { id: 'B20250401001', org: '华东物流中心', carrierType: '标准托盘', quantity: 120, reason: '旺季备货', borrowDate: '2025-04-01', dueDate: '2025-04-15', status: '已归还', approver: '张经理' },
  { id: 'B20250401002', org: '华南配送中心', carrierType: '折叠箱', quantity: 80, reason: '新品推广活动', borrowDate: '2025-04-01', dueDate: '2025-04-10', status: '已归还', approver: '李主管' },
  { id: 'B20250402003', org: '华北仓储部', carrierType: '仓储笼', quantity: 45, reason: '库存周转', borrowDate: '2025-04-02', dueDate: '2025-04-20', status: '已借出', approver: '王主任' },
  { id: 'B20250403004', org: '西南转运中心', carrierType: '标准托盘', quantity: 200, reason: '大客户订单', borrowDate: '2025-04-03', dueDate: '2025-04-18', status: '已借出', approver: '赵经理' },
  { id: 'B20250403005', org: '华中分拨中心', carrierType: '物流周转箱', quantity: 150, reason: '电商大促', borrowDate: '2025-04-03', dueDate: '2025-04-25', status: '已借出', approver: '陈主管' },
  { id: 'B20250404006', org: '华东物流中心', carrierType: '折叠箱', quantity: 60, reason: '临时仓储', borrowDate: '2025-04-04', dueDate: '2025-04-12', status: '已归还', approver: '张经理' },
  { id: 'B20250405007', org: '东北配送站', carrierType: '仓储笼', quantity: 35, reason: '冷链运输', borrowDate: '2025-04-05', dueDate: '2025-04-22', status: '已借出', approver: '刘主任' },
  { id: 'B20250405008', org: '华南配送中心', carrierType: '标准托盘', quantity: 100, reason: '港口出货', borrowDate: '2025-04-05', dueDate: '2025-04-19', status: '已借出', approver: '李主管' },
  { id: 'B20250406009', org: '华东物流中心', carrierType: '物流周转箱', quantity: 90, reason: '第三方协作', borrowDate: '2025-04-06', dueDate: '2025-04-14', status: '已归还', approver: '张经理' },
  { id: 'B20250407010', org: '西北转运站', carrierType: '标准托盘', quantity: 55, reason: '农产品集运', borrowDate: '2025-04-07', dueDate: '2025-04-21', status: '已借出', approver: '马经理' },
  { id: 'B20250408011', org: '华北仓储部', carrierType: '折叠箱', quantity: 70, reason: '医药物流', borrowDate: '2025-04-08', dueDate: '2025-04-16', status: '已归还', approver: '王主任' },
  { id: 'B20250408012', org: '华中分拨中心', carrierType: '仓储笼', quantity: 40, reason: '汽配运输', borrowDate: '2025-04-08', dueDate: '2025-04-23', status: '已借出', approver: '陈主管' },
  { id: 'B20250409013', org: '华南配送中心', carrierType: '物流周转箱', quantity: 130, reason: '跨境贸易', borrowDate: '2025-04-09', dueDate: '2025-04-26', status: '已借出', approver: '李主管' },
  { id: 'B20250410014', org: '华东物流中心', carrierType: '标准托盘', quantity: 85, reason: '快消品入库', borrowDate: '2025-04-10', dueDate: '2025-04-17', status: '已归还', approver: '张经理' },
  { id: 'B20250411015', org: '西南转运中心', carrierType: '折叠箱', quantity: 50, reason: '生鲜配送', borrowDate: '2025-04-11', dueDate: '2025-04-24', status: '已借出', approver: '赵经理' },
  { id: 'B20250412016', org: '华中分拨中心', carrierType: '标准托盘', quantity: 160, reason: '建材运输', borrowDate: '2025-04-12', dueDate: '2025-04-28', status: '待审批' },
  { id: 'B20250412017', org: '华北仓储部', carrierType: '物流周转箱', quantity: 75, reason: '图书分发', borrowDate: '2025-04-12', dueDate: '2025-04-20', status: '已借出', approver: '王主任' },
  { id: 'B20250413018', org: '华东物流中心', carrierType: '仓储笼', quantity: 30, reason: '精密仪器', borrowDate: '2025-04-13', dueDate: '2025-04-27', status: '已借出', approver: '张经理' },
  { id: 'B20250413019', org: '华南配送中心', carrierType: '标准托盘', quantity: 110, reason: '家电出库', borrowDate: '2025-04-13', dueDate: '2025-04-22', status: '已借出', approver: '李主管' },
  { id: 'B20250414020', org: '东北配送站', carrierType: '折叠箱', quantity: 25, reason: '快递中转', borrowDate: '2025-04-14', dueDate: '2025-04-21', status: '已归还', approver: '刘主任' },
  { id: 'B20250415021', org: '西南转运中心', carrierType: '物流周转箱', quantity: 95, reason: '酒水物流', borrowDate: '2025-04-15', dueDate: '2025-04-30', status: '待审批' },
  { id: 'B20250415022', org: '华中分拨中心', carrierType: '仓储笼', quantity: 55, reason: '服装批发', borrowDate: '2025-04-15', dueDate: '2025-04-29', status: '已批准' },
  { id: 'B20250416023', org: '华东物流中心', carrierType: '标准托盘', quantity: 140, reason: '粮油配送', borrowDate: '2025-04-16', dueDate: '2025-05-01', status: '待审批' },
  { id: 'B20250416024', org: '西北转运站', carrierType: '折叠箱', quantity: 20, reason: '矿产样品', borrowDate: '2025-04-16', dueDate: '2025-04-23', status: '已拒绝', approver: '马经理' },
  { id: 'B20250417025', org: '华北仓储部', carrierType: '物流周转箱', quantity: 65, reason: '电子产品', borrowDate: '2025-04-17', dueDate: '2025-04-24', status: '待审批' },
];

/* ------------------------------------------------------------------ */
/*  Mock Data — 15 return records (5 overdue)                          */
/* ------------------------------------------------------------------ */

const RETURN_MOCK: ReturnRecord[] = [
  { id: 'R20250410001', borrowId: 'B20250401001', carrierType: '标准托盘', quantity: 120, borrowDate: '2025-04-01', dueDate: '2025-04-15', actualReturnDate: '2025-04-14', overdue: false, status: '已归还' },
  { id: 'R20250411002', borrowId: 'B20250401002', carrierType: '折叠箱', quantity: 80, borrowDate: '2025-04-01', dueDate: '2025-04-10', actualReturnDate: '2025-04-10', overdue: false, status: '已归还' },
  { id: 'R20250412003', borrowId: 'B20250404006', carrierType: '折叠箱', quantity: 60, borrowDate: '2025-04-04', dueDate: '2025-04-12', actualReturnDate: '2025-04-11', overdue: false, status: '已归还' },
  { id: 'R20250415004', borrowId: 'B20250406009', carrierType: '物流周转箱', quantity: 90, borrowDate: '2025-04-06', dueDate: '2025-04-14', actualReturnDate: '2025-04-15', overdue: true, status: '已归还' },
  { id: 'R20250417005', borrowId: 'B20250408011', carrierType: '折叠箱', quantity: 70, borrowDate: '2025-04-08', dueDate: '2025-04-16', actualReturnDate: '2025-04-16', overdue: false, status: '已归还' },
  { id: 'R20250418006', borrowId: 'B20250410014', carrierType: '标准托盘', quantity: 85, borrowDate: '2025-04-10', dueDate: '2025-04-17', actualReturnDate: '2025-04-18', overdue: true, status: '已归还' },
  { id: 'R20250420007', borrowId: 'B20250414020', carrierType: '折叠箱', quantity: 25, borrowDate: '2025-04-14', dueDate: '2025-04-21', actualReturnDate: '2025-04-20', overdue: false, status: '已归还' },
  { id: 'R20250421008', borrowId: 'B20250402003', carrierType: '仓储笼', quantity: 45, borrowDate: '2025-04-02', dueDate: '2025-04-20', actualReturnDate: '', overdue: true, status: '待归还' },
  { id: 'R20250421009', borrowId: 'B20250405008', carrierType: '标准托盘', quantity: 100, borrowDate: '2025-04-05', dueDate: '2025-04-19', actualReturnDate: '', overdue: true, status: '延期处理' },
  { id: 'R20250422010', borrowId: 'B20250405007', carrierType: '仓储笼', quantity: 35, borrowDate: '2025-04-05', dueDate: '2025-04-22', actualReturnDate: '', overdue: true, status: '待归还' },
  { id: 'R20250422011', borrowId: 'B20250412017', carrierType: '物流周转箱', quantity: 75, borrowDate: '2025-04-12', dueDate: '2025-04-20', actualReturnDate: '', overdue: false, status: '待归还' },
  { id: 'R20250422012', borrowId: 'B20250403004', carrierType: '标准托盘', quantity: 200, borrowDate: '2025-04-03', dueDate: '2025-04-18', actualReturnDate: '', overdue: true, status: '待归还' },
  { id: 'R20250423013', borrowId: 'B20250407010', carrierType: '标准托盘', quantity: 55, borrowDate: '2025-04-07', dueDate: '2025-04-21', actualReturnDate: '', overdue: false, status: '待归还' },
  { id: 'R20250423014', borrowId: 'B20250413018', carrierType: '仓储笼', quantity: 30, borrowDate: '2025-04-13', dueDate: '2025-04-27', actualReturnDate: '', overdue: false, status: '待归还' },
  { id: 'R20250424015', borrowId: 'B20250409013', carrierType: '物流周转箱', quantity: 130, borrowDate: '2025-04-09', dueDate: '2025-04-26', actualReturnDate: '', overdue: false, status: '待归还' },
];

/* ------------------------------------------------------------------ */
/*  Mock Data — 6 carrier type inventory                               */
/* ------------------------------------------------------------------ */

const INVENTORY_MOCK: InventoryItem[] = [
  { carrierType: '标准托盘', available: 420, borrowed: 980, total: 1400 },
  { carrierType: '折叠箱', available: 180, borrowed: 320, total: 500 },
  { carrierType: '仓储笼', available: 85, borrowed: 265, total: 350 },
  { carrierType: '物流周转箱', available: 210, borrowed: 440, total: 650 },
  { carrierType: '冷链保温箱', available: 45, borrowed: 155, total: 200 },
  { carrierType: '危险品专用箱', available: 120, borrowed: 30, total: 150 },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function getBorrowStatusBadge(status: BorrowStatus) {
  const variants: Record<BorrowStatus, string> = {
    '待审批': 'bg-amber-100 text-amber-700 border-amber-200',
    '已批准': 'bg-sky-100 text-sky-700 border-sky-200',
    '已拒绝': 'bg-red-100 text-red-700 border-red-200',
    '已借出': 'bg-emerald-100 text-emerald-700 border-emerald-200',
    '已归还': 'bg-slate-100 text-slate-600 border-slate-200',
  };
  return (
    <Badge variant="outline" className={variants[status] || ''}>
      {status === '待审批' && <Clock className="mr-1 h-3 w-3" />}
      {status === '已批准' && <CheckCircle className="mr-1 h-3 w-3" />}
      {status === '已拒绝' && <XCircle className="mr-1 h-3 w-3" />}
      {status === '已借出' && <Package className="mr-1 h-3 w-3" />}
      {status === '已归还' && <CheckCircle className="mr-1 h-3 w-3" />}
      {status}
    </Badge>
  );
}

function getReturnStatusBadge(record: ReturnRecord) {
  if (record.status === '已归还') {
    return (
      <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200">
        <CheckCircle className="mr-1 h-3 w-3" />
        已归还
      </Badge>
    );
  }
  if (record.status === '延期处理') {
    return (
      <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200">
        <AlertTriangle className="mr-1 h-3 w-3" />
        延期处理
      </Badge>
    );
  }
  if (record.overdue) {
    return (
      <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
        <AlertTriangle className="mr-1 h-3 w-3" />
        已逾期
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="bg-sky-100 text-sky-700 border-sky-200">
      <Clock className="mr-1 h-3 w-3" />
      待归还
    </Badge>
  );
}

function getBorrowRateColor(rate: number) {
  if (rate > 95) return 'text-red-600';
  if (rate > 80) return 'text-amber-600';
  return 'text-emerald-600';
}

function getBorrowRateBarColor(rate: number) {
  if (rate > 95) return 'bg-red-500';
  if (rate > 80) return 'bg-amber-500';
  return 'bg-emerald-500';
}

/* ------------------------------------------------------------------ */
/*  Chart data builders                                                */
/* ------------------------------------------------------------------ */

function buildTrendData() {
  const types = ['标准托盘', '折叠箱', '仓储笼', '物流周转箱', '冷链保温箱', '危险品专用箱'];
  return types.map((t) => {
    const borrowed = BORROW_MOCK.filter((b) => b.carrierType === t).reduce((s, b) => s + b.quantity, 0);
    return { name: t, 借用量: borrowed };
  });
}

function buildOrgRankingData() {
  const orgMap: Record<string, number> = {};
  BORROW_MOCK.forEach((b) => {
    orgMap[b.org] = (orgMap[b.org] || 0) + b.quantity;
  });
  return Object.entries(orgMap)
    .map(([name, value]) => ({ name, 借用量: value }))
    .sort((a, b) => b.借用量 - a.借用量);
}

/* ------------------------------------------------------------------ */
/*  Main Component                                                     */
/* ------------------------------------------------------------------ */

export default function BorrowReturnPage() {
  const [activeTab, setActiveTab] = useState('borrow');
  const [borrowList, setBorrowList] = useState<BorrowRecord[]>(BORROW_MOCK);
  const [returnList, setReturnList] = useState<ReturnRecord[]>(RETURN_MOCK);
  const [borrowFilter, setBorrowFilter] = useState('');
  const [returnFilter, setReturnFilter] = useState('');

  /* Dialog states */
  const [showNewBorrowDialog, setShowNewBorrowDialog] = useState(false);
  const [showBorrowDetailDialog, setShowBorrowDetailDialog] = useState(false);
  const [showReturnDetailDialog, setShowReturnDetailDialog] = useState(false);
  const [showExtendDialog, setShowExtendDialog] = useState(false);
  const [selectedBorrow, setSelectedBorrow] = useState<BorrowRecord | null>(null);
  const [selectedReturn, setSelectedReturn] = useState<ReturnRecord | null>(null);

  /* New borrow form */
  const [newBorrowOrg, setNewBorrowOrg] = useState('');
  const [newBorrowType, setNewBorrowType] = useState('');
  const [newBorrowQty, setNewBorrowQty] = useState('');
  const [newBorrowReason, setNewBorrowReason] = useState('');
  const [newBorrowDate, setNewBorrowDate] = useState('');
  const [newBorrowDue, setNewBorrowDue] = useState('');

  /* Extend form */
  const [extendDate, setExtendDate] = useState('');

  /* Statistics */
  const thisMonth = '2025-04';
  const thisMonthBorrows = borrowList.filter((b) => b.borrowDate.startsWith(thisMonth)).length;
  const thisMonthReturns = returnList.filter(
    (r) => r.actualReturnDate.startsWith(thisMonth) && r.status === '已归还'
  ).length;
  const overdueCount = returnList.filter((r) => r.overdue).length;
  const overdueRate = returnList.length > 0 ? ((overdueCount / returnList.length) * 100).toFixed(1) : '0.0';
  const currentlyBorrowed = INVENTORY_MOCK.reduce((s, i) => s + i.borrowed, 0);

  /* Chart data */
  const trendData = useMemo(() => buildTrendData(), []);
  const orgRankingData = useMemo(() => buildOrgRankingData(), []);

  /* Filtered lists */
  const filteredBorrows = useMemo(() => {
    return borrowList.filter(
      (b) =>
        b.id.toLowerCase().includes(borrowFilter.toLowerCase()) ||
        b.org.toLowerCase().includes(borrowFilter.toLowerCase()) ||
        b.carrierType.includes(borrowFilter)
    );
  }, [borrowList, borrowFilter]);

  const filteredReturns = useMemo(() => {
    return returnList.filter(
      (r) =>
        r.id.toLowerCase().includes(returnFilter.toLowerCase()) ||
        r.borrowId.toLowerCase().includes(returnFilter.toLowerCase()) ||
        r.carrierType.includes(returnFilter)
    );
  }, [returnList, returnFilter]);

  /* Actions */
  const handleApproveBorrow = (id: string) => {
    setBorrowList((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: '已批准' as BorrowStatus, approver: '当前用户' } : b))
    );
  };

  const handleRejectBorrow = (id: string) => {
    setBorrowList((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: '已拒绝' as BorrowStatus, approver: '当前用户' } : b))
    );
  };

  const handleConfirmReturn = (id: string) => {
    const today = '2025-04-22';
    setReturnList((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const isOverdue = r.dueDate < today;
        return { ...r, status: '已归还' as const, actualReturnDate: today, overdue: isOverdue };
      })
    );
  };

  const handleExtendReturn = (id: string, newDueDate: string) => {
    setReturnList((prev) =>
      prev.map((r) =>
        r.id === id
          ? { ...r, status: '延期处理' as const, dueDate: newDueDate, overdue: false }
          : r
      )
    );
    setShowExtendDialog(false);
    setSelectedReturn(null);
    setExtendDate('');
  };

  const handleCreateBorrow = () => {
    if (!newBorrowOrg || !newBorrowType || !newBorrowQty || !newBorrowReason || !newBorrowDate || !newBorrowDue) return;
    const newRecord: BorrowRecord = {
      id: `B${newBorrowDate.replace(/-/g, '')}${String(borrowList.length + 1).padStart(3, '0')}`,
      org: newBorrowOrg,
      carrierType: newBorrowType,
      quantity: parseInt(newBorrowQty, 10),
      reason: newBorrowReason,
      borrowDate: newBorrowDate,
      dueDate: newBorrowDue,
      status: '待审批',
    };
    setBorrowList((prev) => [newRecord, ...prev]);
    setShowNewBorrowDialog(false);
    setNewBorrowOrg('');
    setNewBorrowType('');
    setNewBorrowQty('');
    setNewBorrowReason('');
    setNewBorrowDate('');
    setNewBorrowDue('');
  };

  const openBorrowDetail = (record: BorrowRecord) => {
    setSelectedBorrow(record);
    setShowBorrowDetailDialog(true);
  };

  const openReturnDetail = (record: ReturnRecord) => {
    setSelectedReturn(record);
    setShowReturnDetailDialog(true);
  };

  const openExtendDialog = (record: ReturnRecord) => {
    setSelectedReturn(record);
    setExtendDate(record.dueDate);
    setShowExtendDialog(true);
  };

  /* ---------------------------------------------------------------- */
  /*  Render                                                            */
  /* ---------------------------------------------------------------- */

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" style={{ color: 'var(--theme-color)' }}>
            载具借用归还管理
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            管理载具借用申请、归还跟踪、库存可用性及数据统计
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-sky-50 text-sky-600">
              <ArrowLeftRight className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">本月借用申请数</p>
              <p className="text-2xl font-bold">{thisMonthBorrows}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-emerald-50 text-emerald-600">
              <CheckCircle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">本月归还数</p>
              <p className="text-2xl font-bold">{thisMonthReturns}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-red-50 text-red-600">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">逾期率</p>
              <p className="text-2xl font-bold">{overdueRate}%</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-amber-50 text-amber-600">
              <Package className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">在借总数</p>
              <p className="text-2xl font-bold">{currentlyBorrowed}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 lg:w-auto">
          <TabsTrigger value="borrow" className="flex items-center gap-2">
            <ArrowLeftRight className="h-4 w-4" />
            借用申请
          </TabsTrigger>
          <TabsTrigger value="return" className="flex items-center gap-2">
            <Package className="h-4 w-4" />
            归还管理
          </TabsTrigger>
          <TabsTrigger value="inventory" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            库存可用性
          </TabsTrigger>
        </TabsList>

        {/* ======================== 借用申请 Tab ======================== */}
        <TabsContent value="borrow" className="space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2 flex-1 min-w-[200px]">
              <Input
                placeholder="搜索申请单号、申请组织、载具类型..."
                value={borrowFilter}
                onChange={(e) => setBorrowFilter(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <Button
              onClick={() => setShowNewBorrowDialog(true)}
              className="gap-2"
              style={{ backgroundColor: 'var(--theme-color)' }}
            >
              <Plus className="h-4 w-4" />
              新增借用申请
            </Button>
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>申请单号</TableHead>
                    <TableHead>申请组织</TableHead>
                    <TableHead>借用载具类型</TableHead>
                    <TableHead className="text-right">数量</TableHead>
                    <TableHead>借用原因</TableHead>
                    <TableHead>借用期限</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredBorrows.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                        暂无数据
                      </TableCell>
                    </TableRow>
                  )}
                  {filteredBorrows.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-mono text-sm">{record.id}</TableCell>
                      <TableCell>{record.org}</TableCell>
                      <TableCell>{record.carrierType}</TableCell>
                      <TableCell className="text-right">{record.quantity}</TableCell>
                      <TableCell className="max-w-[160px] truncate" title={record.reason}>
                        {record.reason}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {record.borrowDate} ~ {record.dueDate}
                        </div>
                      </TableCell>
                      <TableCell>{getBorrowStatusBadge(record.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => openBorrowDetail(record)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {record.status === '待审批' && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 gap-1 text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                                onClick={() => handleApproveBorrow(record.id)}
                              >
                                <CheckCircle className="h-3.5 w-3.5" />
                                批准
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 gap-1 text-red-600 border-red-200 hover:bg-red-50"
                                onClick={() => handleRejectBorrow(record.id)}
                              >
                                <XCircle className="h-3.5 w-3.5" />
                                拒绝
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ======================== 归还管理 Tab ======================== */}
        <TabsContent value="return" className="space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-2 flex-1 min-w-[200px]">
              <Input
                placeholder="搜索归还单号、借用单号、载具类型..."
                value={returnFilter}
                onChange={(e) => setReturnFilter(e.target.value)}
                className="max-w-sm"
              />
            </div>
            {overdueCount > 0 && (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 gap-1 px-3 py-1.5">
                <AlertTriangle className="h-3.5 w-3.5" />
                {overdueCount} 条逾期记录
              </Badge>
            )}
          </div>

          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>归还单号</TableHead>
                    <TableHead>对应借用单号</TableHead>
                    <TableHead>载具类型</TableHead>
                    <TableHead className="text-right">数量</TableHead>
                    <TableHead>借出时间</TableHead>
                    <TableHead>应还时间</TableHead>
                    <TableHead>实际归还时间</TableHead>
                    <TableHead>是否逾期</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReturns.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={10} className="text-center text-muted-foreground py-8">
                        暂无数据
                      </TableCell>
                    </TableRow>
                  )}
                  {filteredReturns.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="font-mono text-sm">{record.id}</TableCell>
                      <TableCell className="font-mono text-sm">{record.borrowId}</TableCell>
                      <TableCell>{record.carrierType}</TableCell>
                      <TableCell className="text-right">{record.quantity}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {record.borrowDate}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {record.dueDate}
                        </div>
                      </TableCell>
                      <TableCell>
                        {record.actualReturnDate ? (
                          <span className="text-sm">{record.actualReturnDate}</span>
                        ) : (
                          <span className="text-sm text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {record.overdue ? (
                          <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 gap-1">
                            <AlertTriangle className="h-3 w-3" />
                            是
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-1">
                            <CheckCircle className="h-3 w-3" />
                            否
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>{getReturnStatusBadge(record)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => openReturnDetail(record)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {(record.status === '待归还' || record.status === '延期处理') && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 gap-1 text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                                onClick={() => handleConfirmReturn(record.id)}
                              >
                                <CheckCircle className="h-3.5 w-3.5" />
                                确认归还
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="h-8 gap-1 text-amber-600 border-amber-200 hover:bg-amber-50"
                                onClick={() => openExtendDialog(record)}
                              >
                                <Clock className="h-3.5 w-3.5" />
                                延期
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ======================== 库存可用性 Tab ======================== */}
        <TabsContent value="inventory" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {INVENTORY_MOCK.map((item) => {
              const rate = Math.round((item.borrowed / item.total) * 100);
              const colorClass = getBorrowRateColor(rate);
              const barColor = getBorrowRateBarColor(rate);
              return (
                <Card key={item.carrierType} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Package className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
                        {item.carrierType}
                      </CardTitle>
                      {rate > 95 && (
                        <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 gap-1">
                          <AlertTriangle className="h-3 w-3" />
                          紧张
                        </Badge>
                      )}
                      {rate > 80 && rate <= 95 && (
                        <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-200 gap-1">
                          <Clock className="h-3 w-3" />
                          趋紧
                        </Badge>
                      )}
                      {rate <= 80 && (
                        <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-1">
                          <CheckCircle className="h-3 w-3" />
                          充足
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-lg bg-slate-50 p-3">
                        <p className="text-xs text-muted-foreground">可借数量</p>
                        <p className="text-lg font-bold text-emerald-600">{item.available}</p>
                      </div>
                      <div className="rounded-lg bg-slate-50 p-3">
                        <p className="text-xs text-muted-foreground">已借数量</p>
                        <p className="text-lg font-bold text-sky-600">{item.borrowed}</p>
                      </div>
                      <div className="rounded-lg bg-slate-50 p-3">
                        <p className="text-xs text-muted-foreground">库存总量</p>
                        <p className="text-lg font-bold text-slate-700">{item.total}</p>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs text-muted-foreground">借用率</span>
                        <span className={`text-sm font-bold ${colorClass}`}>{rate}%</span>
                      </div>
                      <div className="h-2.5 w-full rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${barColor} transition-all duration-500`}
                          style={{ width: `${rate}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* ======================== 数据统计区域 ======================== */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-4">
        {/* 载具类型借用趋势 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              载具类型借用趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={trendData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                  }}
                />
                <Bar dataKey="借用量" radius={[6, 6, 0, 0]} maxBarSize={48}>
                  {trendData.map((_, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={index % 2 === 0 ? 'var(--theme-color)' : '#0ea5e9'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 各组织借用量排名 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Package className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              各组织借用量排名
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart
                data={orgRankingData}
                layout="vertical"
                margin={{ top: 5, right: 20, left: 10, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis type="number" tick={{ fontSize: 12 }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={110} />
                <Tooltip
                  contentStyle={{
                    borderRadius: 8,
                    border: '1px solid #e2e8f0',
                    boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                  }}
                />
                <Bar dataKey="借用量" radius={[0, 6, 6, 0]} maxBarSize={24} fill="var(--theme-color)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* ======================== Dialogs ======================== */}

      {/* 新增借用申请对话框 */}
      <Dialog open={showNewBorrowDialog} onOpenChange={setShowNewBorrowDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              新增借用申请
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-sm font-medium mb-1 block">申请组织</label>
              <Select value={newBorrowOrg} onValueChange={setNewBorrowOrg}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择申请组织" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="华东物流中心">华东物流中心</SelectItem>
                  <SelectItem value="华南配送中心">华南配送中心</SelectItem>
                  <SelectItem value="华北仓储部">华北仓储部</SelectItem>
                  <SelectItem value="华中分拨中心">华中分拨中心</SelectItem>
                  <SelectItem value="西南转运中心">西南转运中心</SelectItem>
                  <SelectItem value="东北配送站">东北配送站</SelectItem>
                  <SelectItem value="西北转运站">西北转运站</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">借用载具类型</label>
              <Select value={newBorrowType} onValueChange={setNewBorrowType}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择载具类型" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="标准托盘">标准托盘</SelectItem>
                  <SelectItem value="折叠箱">折叠箱</SelectItem>
                  <SelectItem value="仓储笼">仓储笼</SelectItem>
                  <SelectItem value="物流周转箱">物流周转箱</SelectItem>
                  <SelectItem value="冷链保温箱">冷链保温箱</SelectItem>
                  <SelectItem value="危险品专用箱">危险品专用箱</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">借用数量</label>
              <Input
                type="number"
                placeholder="请输入借用数量"
                value={newBorrowQty}
                onChange={(e) => setNewBorrowQty(e.target.value)}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">借用原因</label>
              <Input
                placeholder="请输入借用原因"
                value={newBorrowReason}
                onChange={(e) => setNewBorrowReason(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-1 block">借用日期</label>
                <Input
                  type="date"
                  value={newBorrowDate}
                  onChange={(e) => setNewBorrowDate(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">应还日期</label>
                <Input
                  type="date"
                  value={newBorrowDue}
                  onChange={(e) => setNewBorrowDue(e.target.value)}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNewBorrowDialog(false)}>
              取消
            </Button>
            <Button
              onClick={handleCreateBorrow}
              disabled={
                !newBorrowOrg || !newBorrowType || !newBorrowQty || !newBorrowReason || !newBorrowDate || !newBorrowDue
              }
              style={{ backgroundColor: 'var(--theme-color)' }}
            >
              提交申请
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 借用申请详情对话框 */}
      <Dialog open={showBorrowDetailDialog} onOpenChange={setShowBorrowDetailDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              借用申请详情
            </DialogTitle>
          </DialogHeader>
          {selectedBorrow && (
            <div className="space-y-3 py-2 text-sm">
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">申请单号</span>
                <span className="font-mono font-medium">{selectedBorrow.id}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">申请组织</span>
                <span className="font-medium">{selectedBorrow.org}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">载具类型</span>
                <span className="font-medium">{selectedBorrow.carrierType}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">借用数量</span>
                <span className="font-medium">{selectedBorrow.quantity}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">借用原因</span>
                <span className="font-medium max-w-[200px] text-right">{selectedBorrow.reason}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">借用日期</span>
                <span className="font-medium">{selectedBorrow.borrowDate}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">应还日期</span>
                <span className="font-medium">{selectedBorrow.dueDate}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">当前状态</span>
                <span>{getBorrowStatusBadge(selectedBorrow.status)}</span>
              </div>
              {selectedBorrow.approver && (
                <div className="flex justify-between border-b pb-2">
                  <span className="text-muted-foreground">审批人</span>
                  <span className="font-medium">{selectedBorrow.approver}</span>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBorrowDetailDialog(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 归还详情对话框 */}
      <Dialog open={showReturnDetailDialog} onOpenChange={setShowReturnDetailDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              归还详情
            </DialogTitle>
          </DialogHeader>
          {selectedReturn && (
            <div className="space-y-3 py-2 text-sm">
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">归还单号</span>
                <span className="font-mono font-medium">{selectedReturn.id}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">对应借用单号</span>
                <span className="font-mono font-medium">{selectedReturn.borrowId}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">载具类型</span>
                <span className="font-medium">{selectedReturn.carrierType}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">归还数量</span>
                <span className="font-medium">{selectedReturn.quantity}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">借出时间</span>
                <span className="font-medium">{selectedReturn.borrowDate}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">应还时间</span>
                <span className="font-medium">{selectedReturn.dueDate}</span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">实际归还时间</span>
                <span className="font-medium">
                  {selectedReturn.actualReturnDate || '—'}
                </span>
              </div>
              <div className="flex justify-between border-b pb-2">
                <span className="text-muted-foreground">是否逾期</span>
                <span>
                  {selectedReturn.overdue ? (
                    <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200 gap-1">
                      <AlertTriangle className="h-3 w-3" />
                      是
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-1">
                      <CheckCircle className="h-3 w-3" />
                      否
                    </Badge>
                  )}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">状态</span>
                <span>{getReturnStatusBadge(selectedReturn)}</span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReturnDetailDialog(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 延期处理对话框 */}
      <Dialog open={showExtendDialog} onOpenChange={setShowExtendDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" style={{ color: 'var(--theme-color)' }} />
              延期处理
            </DialogTitle>
          </DialogHeader>
          {selectedReturn && (
            <div className="space-y-4 py-2">
              <div className="rounded-lg bg-slate-50 p-4 text-sm space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">归还单号</span>
                  <span className="font-mono font-medium">{selectedReturn.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">载具类型</span>
                  <span className="font-medium">{selectedReturn.carrierType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">当前应还日期</span>
                  <span className="font-medium">{selectedReturn.dueDate}</span>
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">新应还日期</label>
                <Input
                  type="date"
                  value={extendDate}
                  onChange={(e) => setExtendDate(e.target.value)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowExtendDialog(false); setSelectedReturn(null); }}>
              取消
            </Button>
            <Button
              onClick={() => selectedReturn && handleExtendReturn(selectedReturn.id, extendDate)}
              disabled={!extendDate}
              style={{ backgroundColor: 'var(--theme-color)' }}
            >
              确认延期
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
