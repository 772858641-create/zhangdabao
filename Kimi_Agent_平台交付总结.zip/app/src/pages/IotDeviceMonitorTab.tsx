import { useState, useMemo } from 'react';
import { Search, Eye, WifiOff, AlertTriangle, Battery, Signal } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

interface Device {
  id: string;
  name: string;
  type: string;
  site: string;
  status: 'online' | 'offline' | 'alert';
  signal: number;
  battery: number;
  lastReport: string;
}

interface TelemetryItem {
  time: string;
  field: string;
  value: string;
}

const devices: Device[] = [
  { id: 'DEV-001', name: '车载终端-A01', type: '车载终端', site: '上海运营中心', status: 'online', signal: 82, battery: 76, lastReport: '2024-06-15 14:32:05' },
  { id: 'DEV-002', name: '定位器-B12', type: '定位器', site: '华东仓', status: 'online', signal: 65, battery: 45, lastReport: '2024-06-15 14:30:12' },
  { id: 'DEV-003', name: '温湿度传感器-C03', type: '传感器', site: '北京运营中心', status: 'alert', signal: 41, battery: 12, lastReport: '2024-06-15 14:28:44' },
  { id: 'DEV-004', name: '车载终端-A02', type: '车载终端', site: '上海运营中心', status: 'online', signal: 90, battery: 88, lastReport: '2024-06-15 14:31:58' },
  { id: 'DEV-005', name: '定位器-B15', type: '定位器', site: '南方物流园', status: 'offline', signal: 0, battery: 23, lastReport: '2024-06-15 12:15:30' },
  { id: 'DEV-006', name: '门磁传感器-D01', type: '传感器', site: '华东仓', status: 'online', signal: 78, battery: 92, lastReport: '2024-06-15 14:29:10' },
  { id: 'DEV-007', name: '车载终端-A05', type: '车载终端', site: '北京运营中心', status: 'online', signal: 73, battery: 61, lastReport: '2024-06-15 14:32:01' },
  { id: 'DEV-008', name: '定位器-B22', type: '定位器', site: '上海运营中心', status: 'online', signal: 88, battery: 55, lastReport: '2024-06-15 14:31:45' },
  { id: 'DEV-009', name: '温湿度传感器-C07', type: '传感器', site: '南方物流园', status: 'alert', signal: 33, battery: 8, lastReport: '2024-06-15 14:25:18' },
  { id: 'DEV-010', name: '车载终端-A08', type: '车载终端', site: '华东仓', status: 'offline', signal: 0, battery: 34, lastReport: '2024-06-15 10:42:00' },
  { id: 'DEV-011', name: '门磁传感器-D04', type: '传感器', site: '北京运营中心', status: 'online', signal: 95, battery: 80, lastReport: '2024-06-15 14:32:08' },
  { id: 'DEV-012', name: '定位器-B30', type: '定位器', site: '上海运营中心', status: 'online', signal: 70, battery: 67, lastReport: '2024-06-15 14:30:55' },
  { id: 'DEV-013', name: '车载终端-A11', type: '车载终端', site: '南方物流园', status: 'online', signal: 85, battery: 72, lastReport: '2024-06-15 14:31:30' },
  { id: 'DEV-014', name: '温湿度传感器-C11', type: '传感器', site: '华东仓', status: 'offline', signal: 0, battery: 0, lastReport: '2024-06-14 22:10:12' },
  { id: 'DEV-015', name: '门磁传感器-D07', type: '传感器', site: '北京运营中心', status: 'online', signal: 60, battery: 50, lastReport: '2024-06-15 14:28:22' },
];

const statusOptions = ['全部', '在线', '离线', '告警'];
const typeOptions = ['全部', '车载终端', '定位器', '传感器'];

function getStatusBadge(status: Device['status']) {
  switch (status) {
    case 'online':
      return (
        <Badge variant="outline" className="border-success text-success bg-success-light gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-success" />
          在线
        </Badge>
      );
    case 'offline':
      return (
        <Badge variant="outline" className="border-neutral-border-strong text-neutral-textSecondary bg-neutral-background gap-1">
          <WifiOff size={12} />
          离线
        </Badge>
      );
    case 'alert':
      return (
        <Badge variant="outline" className="border-danger text-danger bg-danger-light gap-1">
          <AlertTriangle size={12} />
          告警
        </Badge>
      );
  }
}

function getSignalIcon(signal: number) {
  if (signal >= 80) return <Signal size={14} className="text-success" />;
  if (signal >= 50) return <Signal size={14} className="text-warning" />;
  if (signal > 0) return <Signal size={14} className="text-danger" />;
  return <WifiOff size={14} className="text-neutral-textTertiary" />;
}

function generateMockTelemetry(_deviceId: string): TelemetryItem[] {
  const fields = [
    { field: 'temperature', unit: '°C' },
    { field: 'humidity', unit: '%' },
    { field: 'latitude', unit: '' },
    { field: 'longitude', unit: '' },
    { field: 'speed', unit: 'km/h' },
    { field: 'battery', unit: '%' },
    { field: 'signal', unit: 'dBm' },
    { field: 'status', unit: '' },
    { field: 'doorOpen', unit: '' },
    { field: 'mileage', unit: 'km' },
  ];
  return Array.from({ length: 10 }).map((_, i) => {
    const f = fields[i % fields.length];
    let val = '';
    switch (f.field) {
      case 'temperature': val = `${(20 + Math.random() * 15).toFixed(1)}${f.unit}`; break;
      case 'humidity': val = `${(40 + Math.random() * 40).toFixed(0)}${f.unit}`; break;
      case 'latitude': val = `31.${(2000 + Math.random() * 999).toFixed(4)}`; break;
      case 'longitude': val = `121.${(4000 + Math.random() * 999).toFixed(4)}`; break;
      case 'speed': val = `${(Math.random() * 80).toFixed(1)}${f.unit}`; break;
      case 'battery': val = `${(30 + Math.random() * 70).toFixed(0)}${f.unit}`; break;
      case 'signal': val = `-${(60 + Math.random() * 40).toFixed(0)}${f.unit}`; break;
      case 'status': val = Math.random() > 0.3 ? 'normal' : 'warning'; break;
      case 'doorOpen': val = Math.random() > 0.8 ? 'true' : 'false'; break;
      case 'mileage': val = `${(10000 + Math.random() * 50000).toFixed(1)}${f.unit}`; break;
    }
    const now = new Date();
    now.setMinutes(now.getMinutes() - i * 5);
    return {
      time: now.toISOString().slice(0, 19).replace('T', ' '),
      field: f.field,
      value: val,
    };
  });
}

export default function IotDeviceMonitorTab() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('全部');
  const [typeFilter, setTypeFilter] = useState('全部');
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const filteredDevices = useMemo(() => {
    return devices.filter((d) => {
      const matchSearch =
        !search.trim() ||
        d.id.toLowerCase().includes(search.toLowerCase()) ||
        d.name.toLowerCase().includes(search.toLowerCase()) ||
        d.site.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === '全部' ||
        (statusFilter === '在线' && d.status === 'online') ||
        (statusFilter === '离线' && d.status === 'offline') ||
        (statusFilter === '告警' && d.status === 'alert');
      const matchType = typeFilter === '全部' || d.type === typeFilter;
      return matchSearch && matchStatus && matchType;
    });
  }, [search, statusFilter, typeFilter]);

  const handleViewDetail = (device: Device) => {
    setSelectedDevice(device);
    setDialogOpen(true);
  };

  const telemetry = useMemo(() => {
    if (!selectedDevice) return [];
    return generateMockTelemetry(selectedDevice.id);
  }, [selectedDevice]);

  return (
    <div className="space-y-4">
      {/* Filters */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
              <Input
                placeholder="搜索设备ID、名称、网点..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 h-9 bg-neutral-background border-neutral-border"
              />
            </div>
            <div className="flex gap-2">
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
                {statusOptions.map((s) => (
                  <button
                    key={s}
                    onClick={() => setStatusFilter(s)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      statusFilter === s
                        ? 'bg-primary text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
                {typeOptions.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      typeFilter === t
                        ? 'bg-primary text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card className="bg-neutral-surface border-neutral-border overflow-hidden">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-neutral-border hover:bg-transparent">
                <TableHead className="text-neutral-textSecondary text-xs">设备ID</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">名称</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">类型</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">所属网点</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">状态</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">信号强度</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">电量</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">最后上报</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDevices.map((device) => (
                <TableRow
                  key={device.id}
                  className="border-neutral-border hover:bg-neutral-background cursor-pointer"
                  onClick={() => handleViewDetail(device)}
                >
                  <TableCell className="text-xs font-mono text-neutral-textPrimary">{device.id}</TableCell>
                  <TableCell className="text-xs text-neutral-textPrimary font-medium">{device.name}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary">{device.type}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary">{device.site}</TableCell>
                  <TableCell>{getStatusBadge(device.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {getSignalIcon(device.signal)}
                      <span className="text-xs text-neutral-textSecondary">{device.signal > 0 ? `${device.signal}%` : '—'}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      <Battery size={14} className={cn(
                        device.battery > 50 ? 'text-success' : device.battery > 20 ? 'text-warning' : 'text-danger'
                      )} />
                      <span className="text-xs text-neutral-textSecondary">{device.battery}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-neutral-textTertiary">{device.lastReport}</TableCell>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs text-primary"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleViewDetail(device);
                      }}
                    >
                      <Eye size={14} className="mr-1" />
                      查看
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary">
              设备详情 — {selectedDevice?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-neutral-textTertiary text-xs">设备ID</span>
                <p className="text-neutral-textPrimary font-mono mt-0.5">{selectedDevice?.id}</p>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-neutral-textTertiary text-xs">类型</span>
                <p className="text-neutral-textPrimary mt-0.5">{selectedDevice?.type}</p>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-neutral-textTertiary text-xs">网点</span>
                <p className="text-neutral-textPrimary mt-0.5">{selectedDevice?.site}</p>
              </div>
              <div className="bg-neutral-background rounded-md p-2.5 border border-neutral-border">
                <span className="text-neutral-textTertiary text-xs">状态</span>
                <div className="mt-0.5">{selectedDevice && getStatusBadge(selectedDevice.status)}</div>
              </div>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-neutral-textSecondary mb-2">最近遥测数据</h4>
              <div className="bg-neutral-background rounded-md border border-neutral-border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="border-neutral-border hover:bg-transparent">
                      <TableHead className="text-neutral-textTertiary text-xs h-8">时间</TableHead>
                      <TableHead className="text-neutral-textTertiary text-xs h-8">字段</TableHead>
                      <TableHead className="text-neutral-textTertiary text-xs h-8">值</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {telemetry.map((item, idx) => (
                      <TableRow key={idx} className="border-neutral-border hover:bg-neutral-surface">
                        <TableCell className="text-xs text-neutral-textTertiary font-mono py-1.5">{item.time}</TableCell>
                        <TableCell className="text-xs text-neutral-textSecondary py-1.5">{item.field}</TableCell>
                        <TableCell className="text-xs text-neutral-textPrimary font-mono py-1.5">{item.value}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
