import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { statisticsMockData } from '@/lib/mockDataSupplement';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';
import {
  Package, Warehouse, ArrowLeftRight, Route, Cpu, History, Download, TrendingUp,
  CalendarDays, Building2, ArrowUpRight, ArrowDownRight, Boxes, Activity, Timer,
  CheckCircle2, AlertTriangle, XCircle, BatteryMedium, Wifi, Wrench, Truck, MapPin,
  BarChart3, CircleDot, Gauge, Layers, FileSpreadsheet, FileText, ChevronRight, Filter
} from 'lucide-react';

/* ═══════════════════════════════════════════
   主题常量
   ═══════════════════════════════════════════ */
const COLORS = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#14B8A6'];

const THEME_CSS = {
  primary: '#2563EB',
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  purple: '#8B5CF6',
  pink: '#EC4899',
  cyan: '#06B6D4',
  teal: '#14B8A6',
};

/* ═══════════════════════════════════════════
   扩展模拟数据
   ═══════════════════════════════════════════ */

const carrierStatusData = [
  { name: '在库', value: 892, color: '#2563EB' },
  { name: '在途', value: 156, color: '#10B981' },
  { name: '维修中', value: 47, color: '#F59E0B' },
  { name: '闲置', value: 82, color: '#EF4444' },
  { name: '待报废', value: 108, color: '#8B5CF6' },
];

const carrierRadarData = [
  { metric: '利用率', A_TYPE: 75, B_TYPE: 82, C_TYPE: 79, D_TYPE: 72, E_TYPE: 85 },
  { metric: '周转率', A_TYPE: 4.2, B_TYPE: 4.8, C_TYPE: 4.5, D_TYPE: 3.8, E_TYPE: 5.1 },
  { metric: '在线率', A_TYPE: 92, B_TYPE: 95, C_TYPE: 93, D_TYPE: 89, E_TYPE: 96 },
  { metric: '完好率', A_TYPE: 88, B_TYPE: 91, C_TYPE: 90, D_TYPE: 86, E_TYPE: 93 },
  { metric: '满载率', A_TYPE: 78, B_TYPE: 85, C_TYPE: 82, D_TYPE: 75, E_TYPE: 88 },
];

const routeTrendData = [
  { month: '2025-01', route1: 52, route2: 78, route3: 62, route4: 92 },
  { month: '2025-02', route1: 48, route2: 74, route3: 58, route4: 88 },
  { month: '2025-03', route1: 50, route2: 72, route3: 56, route4: 96 },
  { month: '2025-04', route1: 48, route2: 72, route3: 56, route4: 96 },
];

const routeRadarData = [
  { metric: '准时率', r1: 92, r2: 85, r3: 89, r4: 78 },
  { metric: '速度', r1: 88, r2: 75, r3: 82, r4: 70 },
  { metric: '稳定性', r1: 90, r2: 80, r3: 85, r4: 72 },
  { metric: '成本控制', r1: 85, r2: 78, r3: 80, r4: 75 },
  { metric: '安全性', r1: 94, r2: 88, r3: 90, r4: 82 },
  { metric: '客户满意度', r1: 91, r2: 84, r3: 87, r4: 76 },
];

const deviceOnlineTrend = [
  { month: '2025-01', onlineRate: 91.2, avgBattery: 70.1, weakSignal: 32 },
  { month: '2025-02', onlineRate: 90.5, avgBattery: 69.3, weakSignal: 35 },
  { month: '2025-03', onlineRate: 89.8, avgBattery: 68.4, weakSignal: 38 },
  { month: '2025-04', onlineRate: 89.2, avgBattery: 67.5, weakSignal: 42 },
];

const ioHistoryExtended = [
  { date: '04-01', inbound: 42, outbound: 35, manualInbound: 4, manualOutbound: 3, abnormal: 1 },
  { date: '04-02', inbound: 38, outbound: 40, manualInbound: 2, manualOutbound: 2, abnormal: 0 },
  { date: '04-03', inbound: 55, outbound: 42, manualInbound: 5, manualOutbound: 4, abnormal: 2 },
  { date: '04-04', inbound: 48, outbound: 38, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
  { date: '04-05', inbound: 35, outbound: 30, manualInbound: 2, manualOutbound: 1, abnormal: 0 },
  { date: '04-06', inbound: 28, outbound: 25, manualInbound: 1, manualOutbound: 1, abnormal: 0 },
  { date: '04-07', inbound: 50, outbound: 44, manualInbound: 4, manualOutbound: 3, abnormal: 1 },
  { date: '04-08', inbound: 58, outbound: 48, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
  { date: '04-09', inbound: 44, outbound: 36, manualInbound: 2, manualOutbound: 2, abnormal: 0 },
  { date: '04-10', inbound: 62, outbound: 50, manualInbound: 6, manualOutbound: 4, abnormal: 2 },
  { date: '04-11', inbound: 40, outbound: 35, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
  { date: '04-12', inbound: 46, outbound: 38, manualInbound: 2, manualOutbound: 3, abnormal: 0 },
  { date: '04-13', inbound: 32, outbound: 28, manualInbound: 1, manualOutbound: 1, abnormal: 0 },
  { date: '04-14', inbound: 54, outbound: 45, manualInbound: 4, manualOutbound: 3, abnormal: 1 },
  { date: '04-15', inbound: 60, outbound: 52, manualInbound: 5, manualOutbound: 4, abnormal: 2 },
  { date: '04-16', inbound: 43, outbound: 37, manualInbound: 2, manualOutbound: 2, abnormal: 0 },
  { date: '04-17', inbound: 51, outbound: 42, manualInbound: 3, manualOutbound: 3, abnormal: 1 },
  { date: '04-18', inbound: 37, outbound: 31, manualInbound: 2, manualOutbound: 1, abnormal: 0 },
  { date: '04-19', inbound: 29, outbound: 26, manualInbound: 1, manualOutbound: 1, abnormal: 0 },
  { date: '04-20', inbound: 56, outbound: 47, manualInbound: 4, manualOutbound: 3, abnormal: 1 },
  { date: '04-21', inbound: 64, outbound: 53, manualInbound: 6, manualOutbound: 5, abnormal: 2 },
  { date: '04-22', inbound: 47, outbound: 39, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
  { date: '04-23', inbound: 41, outbound: 34, manualInbound: 2, manualOutbound: 2, abnormal: 0 },
  { date: '04-24', inbound: 53, outbound: 43, manualInbound: 4, manualOutbound: 3, abnormal: 1 },
  { date: '04-25', inbound: 45, outbound: 38, manualInbound: 5, manualOutbound: 3, abnormal: 2 },
  { date: '04-26', inbound: 52, outbound: 41, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
  { date: '04-27', inbound: 48, outbound: 35, manualInbound: 4, manualOutbound: 4, abnormal: 0 },
  { date: '04-28', inbound: 55, outbound: 44, manualInbound: 2, manualOutbound: 3, abnormal: 1 },
  { date: '04-29', inbound: 38, outbound: 29, manualInbound: 1, manualOutbound: 1, abnormal: 0 },
  { date: '04-30', inbound: 50, outbound: 42, manualInbound: 3, manualOutbound: 2, abnormal: 1 },
];

const ioMethodData = [
  { name: '自动入库', value: 65, color: '#2563EB' },
  { name: '自动出库', value: 58, color: '#10B981' },
  { name: '手动入库', value: 12, color: '#F59E0B' },
  { name: '手动出库', value: 10, color: '#EF4444' },
  { name: '异常处理', value: 5, color: '#8B5CF6' },
];

const siteAlertData = [
  { site: '上海浦东', overstock: 12, understock: 5, abnormal: 3 },
  { site: '苏州昆山', overstock: 8, understock: 3, abnormal: 2 },
  { site: '深圳龙岗', overstock: 15, understock: 7, abnormal: 4 },
  { site: '宁德基地', overstock: 6, understock: 2, abnormal: 1 },
  { site: '杭州萧山', overstock: 4, understock: 1, abnormal: 1 },
  { site: '武汉东西湖', overstock: 10, understock: 4, abnormal: 2 },
  { site: '重庆两江', overstock: 7, understock: 3, abnormal: 1 },
  { site: '广州南沙', overstock: 14, understock: 6, abnormal: 3 },
];

const efficiencyHistogram = [
  { range: '0-24h', count: 45, onTime: 42 },
  { range: '24-48h', count: 120, onTime: 108 },
  { range: '48-72h', count: 95, onTime: 82 },
  { range: '72-96h', count: 52, onTime: 42 },
  { range: '96h+', count: 30, onTime: 24 },
];

const reportTypes = [
  { id: 'carrier', name: '载具统计报表', desc: '载具类型、状态、趋势全量数据', icon: Package },
  { id: 'site', name: '网点库存报表', desc: '各网点库存分布与利用率明细', icon: Warehouse },
  { id: 'transfer', name: '调拨统计报表', desc: '调拨趋势与按时完成率分析', icon: ArrowLeftRight },
  { id: 'route', name: '流转效率报表', desc: '各线路流转时长与效率对比', icon: Route },
  { id: 'device', name: '设备统计报表', desc: '设备在线率与类型分布数据', icon: Cpu },
  { id: 'io', name: '进出库报表', desc: '近30天进出库趋势与方式分布', icon: History },
];

const tabConfig = [
  { value: 'carrier', label: '载具统计', icon: Package },
  { value: 'site', label: '网点库存', icon: Warehouse },
  { value: 'transfer', label: '调拨统计', icon: ArrowLeftRight },
  { value: 'route', label: '流转效率', icon: Route },
  { value: 'device', label: '设备统计', icon: Cpu },
  { value: 'io', label: '进出库统计', icon: History },
  { value: 'export', label: '报表导出', icon: Download },
];

/* ═══════════════════════════════════════════
   子组件
   ═══════════════════════════════════════════ */

function KpiCard({ title, value, subtext, trend, trendUp, icon: Icon }: {
  title: string;
  value: string | number;
  subtext?: string;
  trend?: string;
  trendUp?: boolean;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
}) {
  return (
    <Card
      className="relative overflow-hidden transition-shadow hover:shadow-md"
      style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium" style={{ color: 'var(--muted-foreground)' }}>
              {title}
            </p>
            <p className="text-2xl font-bold tracking-tight" style={{ color: 'var(--foreground)' }}>
              {value}
            </p>
            {subtext && (
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                {subtext}
              </p>
            )}
            {trend && (
              <div className={`flex items-center gap-1 text-xs font-medium ${trendUp ? 'text-emerald-600' : 'text-red-500'}`}>
                {trendUp ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : (
                  <ArrowDownRight className="h-3 w-3" />
                )}
                <span>{trend}</span>
              </div>
            )}
          </div>
          <div className="rounded-xl p-2.5" style={{ background: 'var(--accent)' }}>
            <Icon className="h-5 w-5" style={{ color: 'var(--primary)' }} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SectionTitle({ title, icon: Icon }: {
  title: string;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
}) {
  return (
    <div className="mb-3 flex items-center gap-2">
      <Icon className="h-4 w-4" style={{ color: 'var(--primary)' }} />
      <h3 className="text-base font-semibold" style={{ color: 'var(--foreground)' }}>
        {title}
      </h3>
    </div>
  );
}

function SectionHeader({ title, description, icon: Icon }: {
  title: string;
  description?: string;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
}) {
  return (
    <div className="mb-4 flex items-start justify-between">
      <div className="flex items-center gap-2">
        <div className="rounded-lg p-1.5" style={{ background: 'var(--accent)' }}>
          <Icon className="h-4 w-4" style={{ color: 'var(--primary)' }} />
        </div>
        <div>
          <h3 className="text-base font-semibold" style={{ color: 'var(--foreground)' }}>{title}</h3>
          {description && <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{description}</p>}
        </div>
      </div>
    </div>
  );
}

function CustomTooltip({ active, payload, label }: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-lg border bg-white p-3 shadow-lg"
      style={{ borderColor: 'var(--border)' }}
    >
      <p className="mb-2 text-xs font-semibold" style={{ color: 'var(--foreground)' }}>
        {label}
      </p>
      {payload.map((entry, idx) => (
        <div key={idx} className="flex items-center gap-2 text-xs">
          <span
            className="inline-block h-2 w-2 rounded-full"
            style={{ background: entry.color }}
          />
          <span style={{ color: 'var(--muted-foreground)' }}>{entry.name}:</span>
          <span className="font-semibold" style={{ color: 'var(--foreground)' }}>
            {entry.value}
          </span>
        </div>
      ))}
    </div>
  );
}

function MiniBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
      <div
        className="h-full rounded-full transition-all"
        style={{ width: `${pct}%`, background: color }}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════
   主组件
   ═══════════════════════════════════════════ */

export default function StatisticsPage() {
  const [timeRange, setTimeRange] = useState('30d');
  const [orgFilter, setOrgFilter] = useState('all');
  const data = statisticsMockData;

  const exportReport = (type: string) => {
    alert(`正在导出${type}报表...`);
  };

  /* ── Tab1: 载具统计 ── */
  const carrierKpis = useMemo(
    () => [
      {
        title: '在库总数',
        value: data.carrierStats.inStock,
        subtext: `占总量的 ${Math.round((data.carrierStats.inStock / data.carrierStats.total) * 100)}%`,
        trend: '+2.3% 环比',
        trendUp: true,
        icon: Package,
      },
      {
        title: '在途总数',
        value: data.carrierStats.inTransit,
        subtext: `占总量的 ${Math.round((data.carrierStats.inTransit / data.carrierStats.total) * 100)}%`,
        trend: '+5.1% 环比',
        trendUp: true,
        icon: Truck,
      },
      {
        title: '周转率',
        value: data.carrierStats.turnoverRate,
        subtext: '次/月',
        trend: '+0.3 环比',
        trendUp: true,
        icon: TrendingUp,
      },
      {
        title: '利用率',
        value: `${data.carrierStats.utilization}%`,
        subtext: `闲置率 ${data.carrierStats.vacancyRate}%`,
        trend: '+1.2% 环比',
        trendUp: true,
        icon: Activity,
      },
      {
        title: '平均闲置天数',
        value: `${data.carrierStats.avgIdleDays}天`,
        subtext: `最大闲置 ${data.carrierStats.maxIdleDays}天`,
        trend: '-0.5天 环比',
        trendUp: true,
        icon: Timer,
      },
      {
        title: '载具总量',
        value: data.carrierStats.total,
        subtext: `含维修中 ${data.carrierStats.maintaining}`,
        trend: '+2.0% 环比',
        trendUp: true,
        icon: Boxes,
      },
    ],
    [data]
  );

  const carrierTypePie = useMemo(
    () => data.carrierStats.byType.map((t) => ({ name: t.type.replace('_TYPE', '型'), value: t.total })),
    [data]
  );

  /* ── Tab2: 网点库存统计 ── */
  const siteKpis = useMemo(() => {
    const total = data.siteInventoryStats.reduce((s, v) => s + v.total, 0);
    const maxCap = data.siteInventoryStats.reduce((s, v) => s + v.maxCapacity, 0);
    const avgUtil = Math.round(
      data.siteInventoryStats.reduce((s, v) => s + v.utilization, 0) / data.siteInventoryStats.length
    );
    const alertCount = data.siteInventoryStats.reduce((s, v) => s + v.alert, 0);
    return [
      {
        title: '库存载具总数',
        value: total,
        subtext: `最大容量 ${maxCap}`,
        trend: '+3.1% 环比',
        trendUp: true,
        icon: Warehouse,
      },
      {
        title: '平均利用率',
        value: `${avgUtil}%`,
        subtext: '网点加权平均',
        trend: '+1.5% 环比',
        trendUp: true,
        icon: TrendingUp,
      },
      {
        title: '满仓网点数',
        value: data.siteInventoryStats.filter((s) => s.utilization > 85).length,
        subtext: '利用率>85%',
        trend: '-1 环比',
        trendUp: true,
        icon: MapPin,
      },
      {
        title: '预警网点数',
        value: alertCount,
        subtext: '需关注库存积压',
        trend: '+2 环比',
        trendUp: false,
        icon: AlertTriangle,
      },
    ];
  }, [data]);

  const siteStackData = useMemo(
    () =>
      data.siteInventoryStats.map((s) => ({
        name: s.siteName.replace(/仓库|工厂|中转站|生产基地/g, ''),
        空载: s.empty,
        满载: s.full,
        未知: s.unknown,
      })),
    [data]
  );

  /* ── Tab3: 调拨统计 ── */
  const transferKpis = useMemo(
    () => [
      {
        title: '调拨总数',
        value: data.transferStats.totalTransfers,
        subtext: '本月累计',
        trend: '+8.2% 环比',
        trendUp: true,
        icon: ArrowLeftRight,
      },
      {
        title: '按时完成',
        value: data.transferStats.onTime,
        subtext: `占比 ${data.transferStats.onTimeRate}%`,
        trend: '+2.1% 环比',
        trendUp: true,
        icon: CheckCircle2,
      },
      {
        title: '平均时长',
        value: `${data.transferStats.avgDuration}h`,
        subtext: '端到端平均',
        trend: '-1.2h 环比',
        trendUp: true,
        icon: Timer,
      },
      {
        title: '超时调拨',
        value: data.transferStats.timeout,
        subtext: `占比 ${data.transferStats.timeoutRate}%`,
        trend: '-0.5% 环比',
        trendUp: true,
        icon: XCircle,
      },
    ],
    [data]
  );

  /* ── Tab4: 流转效率 ── */
  const routeKpis = useMemo(() => {
    const avgDuration = Math.round(
      data.routeEfficiency.reduce((s, r) => s + r.avgDuration, 0) / data.routeEfficiency.length
    );
    const avgOnTime = (
      data.routeEfficiency.reduce((s, r) => s + r.onTimeRate, 0) / data.routeEfficiency.length
    ).toFixed(1);
    const bestRoute = data.routeEfficiency[0];
    const worstRoute = data.routeEfficiency[data.routeEfficiency.length - 1];
    return [
      {
        title: '平均流转时长',
        value: `${avgDuration}h`,
        subtext: '线路加权平均',
        trend: '-2h 环比',
        trendUp: true,
        icon: Timer,
      },
      {
        title: '平均准时率',
        value: `${avgOnTime}%`,
        subtext: '目标值 90%',
        trend: '+1.3% 环比',
        trendUp: true,
        icon: CheckCircle2,
      },
      {
        title: '最优线路',
        value: bestRoute?.routeName.split('-').slice(0, 2).join('-') ?? '',
        subtext: `准时率 ${bestRoute?.onTimeRate}%`,
        trend: '稳定',
        trendUp: true,
        icon: Route,
      },
      {
        title: '瓶颈线路',
        value: worstRoute?.routeName.split('-').slice(0, 2).join('-') ?? '',
        subtext: '需优化',
        trend: '关注',
        trendUp: false,
        icon: AlertTriangle,
      },
    ];
  }, [data]);

  /* ── Tab5: 设备统计 ── */
  const deviceKpis = useMemo(
    () => [
      {
        title: '设备总数',
        value: data.deviceStats.total,
        subtext: `在线 ${data.deviceStats.online}`,
        trend: '+1.2% 环比',
        trendUp: true,
        icon: Cpu,
      },
      {
        title: '在线率',
        value: `${data.deviceStats.onlineRate}%`,
        subtext: `离线 ${data.deviceStats.offline}`,
        trend: '-0.3% 环比',
        trendUp: false,
        icon: Wifi,
      },
      {
        title: '平均电量',
        value: `${data.deviceStats.avgBattery}%`,
        subtext: `低电量 ${data.deviceStats.lowBatteryCount}`,
        trend: '+2.1% 环比',
        trendUp: true,
        icon: BatteryMedium,
      },
      {
        title: '需维护',
        value: data.deviceStats.maintenanceCount,
        subtext: `弱信号 ${data.deviceStats.weakSignalCount}`,
        trend: '-3 环比',
        trendUp: true,
        icon: Wrench,
      },
    ],
    [data]
  );

  /* ── Tab6: 进出库统计 ── */
  const ioKpis = useMemo(() => {
    const totalInbound = ioHistoryExtended.reduce((s, d) => s + d.inbound, 0);
    const totalOutbound = ioHistoryExtended.reduce((s, d) => s + d.outbound, 0);
    const totalAbnormal = ioHistoryExtended.reduce((s, d) => s + d.abnormal, 0);
    return [
      {
        title: '累计入库',
        value: totalInbound,
        subtext: '近30天',
        trend: '+4.2% 环比',
        trendUp: true,
        icon: Package,
      },
      {
        title: '累计出库',
        value: totalOutbound,
        subtext: '近30天',
        trend: '+3.8% 环比',
        trendUp: true,
        icon: Truck,
      },
      {
        title: '日均吞吐量',
        value: Math.round((totalInbound + totalOutbound) / 30),
        subtext: '进出合计',
        trend: '+2.5% 环比',
        trendUp: true,
        icon: TrendingUp,
      },
      {
        title: '异常处理',
        value: totalAbnormal,
        subtext: `占比 ${((totalAbnormal / totalInbound) * 100).toFixed(1)}%`,
        trend: '-1 环比',
        trendUp: true,
        icon: AlertTriangle,
      },
    ];
  }, []);

  /* ═══════════════════════════════════════════
     渲染
     ═══════════════════════════════════════════ */
  return (
    <div
      className="min-h-screen space-y-6 p-6"
      style={{ background: 'var(--background)', color: 'var(--foreground)' }}
    >
      {/* ── 页面标题 ── */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" style={{ color: 'var(--foreground)' }}>
            数据统计中心
          </h1>
          <p className="mt-1 text-sm" style={{ color: 'var(--muted-foreground)' }}>
            全维度业务数据统计与分析，辅助运营决策
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => exportReport('全部')}
            className="gap-1.5"
          >
            <Download className="h-4 w-4" />
            导出全部报表
          </Button>
        </div>
      </div>

      {/* ── 全局筛选 ── */}
      <Card style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
        <CardContent className="flex flex-wrap items-center gap-4 py-4">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4" style={{ color: 'var(--primary)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
              时间范围
            </span>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">近7天</SelectItem>
                <SelectItem value="30d">近30天</SelectItem>
                <SelectItem value="90d">近90天</SelectItem>
                <SelectItem value="this_month">本月</SelectItem>
                <SelectItem value="last_month">上月</SelectItem>
                <SelectItem value="this_quarter">本季度</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Building2 className="h-4 w-4" style={{ color: 'var(--primary)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
              所属组织
            </span>
            <Select value={orgFilter} onValueChange={setOrgFilter}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部组织</SelectItem>
                <SelectItem value="1">华东运营中心</SelectItem>
                <SelectItem value="2">华南运营中心</SelectItem>
                <SelectItem value="3">上汽集团</SelectItem>
                <SelectItem value="4">宁德时代</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4" style={{ color: 'var(--primary)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
              数据维度
            </span>
            <Select defaultValue="all">
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部维度</SelectItem>
                <SelectItem value="carrier">仅载具</SelectItem>
                <SelectItem value="device">仅设备</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Badge variant="secondary" className="ml-auto text-xs">
            数据更新于 2025-04-30 08:00
          </Badge>
        </CardContent>
      </Card>

      {/* ═══════════════════════════════════════════
          7个Tab
          ═══════════════════════════════════════════ */}
      <Tabs defaultValue="carrier" className="space-y-6">
        <TabsList className="flex h-auto flex-wrap gap-1 bg-transparent p-0">
          {tabConfig.map((tab) => (
            <TabsTrigger
              key={tab.value}
              value={tab.value}
              className="gap-1.5 rounded-lg px-4 py-2.5 text-sm data-[state=active]:shadow-sm"
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {/* ═══════════════════════════════════════════
            Tab 1: 载具统计
            ═══════════════════════════════════════════ */}
        <TabsContent value="carrier" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            {carrierKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="载具类型分布" icon={Package} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={carrierTypePie}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {carrierTypePie.map((_, idx) => (
                        <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="载具状态分布" icon={Activity} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={carrierStatusData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {carrierStatusData.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="载具月度趋势（总量/在库/在途）" icon={TrendingUp} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <LineChart data={data.carrierStats.trend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="total"
                      name="总量"
                      stroke="#2563EB"
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="inStock"
                      name="在库"
                      stroke="#10B981"
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="inTransit"
                      name="在途"
                      stroke="#F59E0B"
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="各类型载具多维能力对比" icon={Gauge} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <RadarChart data={carrierRadarData} cx="50%" cy="50%" outerRadius="70%">
                    <PolarGrid stroke="var(--border)" />
                    <PolarAngleAxis
                      dataKey="metric"
                      tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    />
                    <PolarRadiusAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                    <Radar name="A型" dataKey="A_TYPE" stroke="#2563EB" fill="#2563EB" fillOpacity={0.15} />
                    <Radar name="B型" dataKey="B_TYPE" stroke="#10B981" fill="#10B981" fillOpacity={0.15} />
                    <Radar name="C型" dataKey="C_TYPE" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.15} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="载具类型明细" icon={Boxes} />
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>类型</TableHead>
                      <TableHead className="text-right">总量</TableHead>
                      <TableHead className="text-right">在库</TableHead>
                      <TableHead className="text-right">在途</TableHead>
                      <TableHead className="text-right">利用率(%)</TableHead>
                      <TableHead className="text-right">闲置</TableHead>
                      <TableHead>占比</TableHead>
                      <TableHead>趋势</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.carrierStats.byType.map((row) => {
                      const idle = row.total - row.inStock - row.inTransit;
                      const pct = ((row.total / data.carrierStats.total) * 100).toFixed(1);
                      return (
                        <TableRow key={row.type}>
                          <TableCell className="font-medium">
                            {row.type.replace('_TYPE', '型载具')}
                          </TableCell>
                          <TableCell className="text-right">{row.total}</TableCell>
                          <TableCell className="text-right">{row.inStock}</TableCell>
                          <TableCell className="text-right">{row.inTransit}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <span>{row.utilization}%</span>
                              <MiniBar
                                value={row.utilization}
                                max={100}
                                color={
                                  row.utilization > 80
                                    ? '#10B981'
                                    : row.utilization > 60
                                      ? '#F59E0B'
                                      : '#EF4444'
                                }
                              />
                            </div>
                          </TableCell>
                          <TableCell className="text-right">{idle}</TableCell>
                          <TableCell>
                            <Badge
                              variant={Number(pct) > 30 ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {pct}%
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 text-xs text-emerald-600">
                              <ArrowUpRight className="h-3 w-3" />
                              <span>+{(Math.random() * 3).toFixed(1)}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 2: 网点库存统计
            ═══════════════════════════════════════════ */}
        <TabsContent value="site" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {siteKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="各网点库存分布（空载/满载/未知）" icon={Warehouse} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={360}>
                  <BarChart data={siteStackData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                      interval={0}
                      angle={-20}
                      textAnchor="end"
                      height={60}
                    />
                    <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="空载" stackId="a" fill="#2563EB" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="满载" stackId="a" fill="#10B981" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="未知" stackId="a" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="网点预警分布" icon={AlertTriangle} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={360}>
                  <BarChart data={siteAlertData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="site"
                      tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                      height={50}
                    />
                    <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="overstock" name="库存积压" fill="#F59E0B" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="understock" name="库存不足" fill="#EF4444" radius={[2, 2, 0, 0]} />
                    <Bar dataKey="abnormal" name="异常状态" fill="#8B5CF6" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="网点库存明细" icon={MapPin} />
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>网点名称</TableHead>
                      <TableHead className="text-right">当前库存</TableHead>
                      <TableHead className="text-right">空载</TableHead>
                      <TableHead className="text-right">满载</TableHead>
                      <TableHead className="text-right">未知</TableHead>
                      <TableHead className="text-right">最大容量</TableHead>
                      <TableHead className="text-right">利用率</TableHead>
                      <TableHead>状态</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.siteInventoryStats.map((row) => (
                      <TableRow key={row.siteName}>
                        <TableCell className="font-medium">{row.siteName}</TableCell>
                        <TableCell className="text-right">{row.total}</TableCell>
                        <TableCell className="text-right">{row.empty}</TableCell>
                        <TableCell className="text-right">{row.full}</TableCell>
                        <TableCell className="text-right">{row.unknown}</TableCell>
                        <TableCell className="text-right">{row.maxCapacity}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <span>{row.utilization}%</span>
                            <Progress value={row.utilization} className="h-1.5 w-16" />
                          </div>
                        </TableCell>
                        <TableCell>
                          {row.alert > 0 ? (
                            <Badge variant="destructive" className="text-xs">
                              {row.alert}项预警
                            </Badge>
                          ) : row.utilization > 85 ? (
                            <Badge variant="secondary" className="text-xs">
                              满仓
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs">
                              正常
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 3: 调拨统计
            ═══════════════════════════════════════════ */}
        <TabsContent value="transfer" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {transferKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="调拨月度趋势（总量/按时完成/超时）" icon={BarChart3} />
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={data.transferStats.trend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                  />
                  <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="total" name="调拨总量" fill="#2563EB" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="onTime" name="按时完成" fill="#10B981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="timeout" name="超时" fill="#EF4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-3">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="按时完成率" icon={CheckCircle2} />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                    目标: 90%
                  </span>
                  <span className="text-lg font-bold" style={{ color: THEME_CSS.success }}>
                    {data.transferStats.onTimeRate}%
                  </span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${data.transferStats.onTimeRate}%`,
                      background:
                        data.transferStats.onTimeRate >= 90
                          ? THEME_CSS.success
                          : data.transferStats.onTimeRate >= 80
                            ? THEME_CSS.warning
                            : THEME_CSS.danger,
                    }}
                  />
                </div>
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                  按时完成 {data.transferStats.onTime} 单，共 {data.transferStats.totalTransfers} 单
                </p>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="超时率" icon={XCircle} />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                    警戒线: 10%
                  </span>
                  <span
                    className="text-lg font-bold"
                    style={{
                      color:
                        data.transferStats.timeoutRate > 10
                          ? THEME_CSS.danger
                          : THEME_CSS.warning,
                    }}
                  >
                    {data.transferStats.timeoutRate}%
                  </span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${data.transferStats.timeoutRate * 10}%`,
                      background:
                        data.transferStats.timeoutRate > 10
                          ? THEME_CSS.danger
                          : THEME_CSS.warning,
                    }}
                  />
                </div>
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                  超时 {data.transferStats.timeout} 单，需重点关注
                </p>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="取消率" icon={CircleDot} />
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                    警戒线: 5%
                  </span>
                  <span className="text-lg font-bold" style={{ color: THEME_CSS.warning }}>
                    {((data.transferStats.cancelled / data.transferStats.totalTransfers) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${(data.transferStats.cancelled / data.transferStats.totalTransfers) * 100 * 10}%`,
                      background: THEME_CSS.warning,
                    }}
                  />
                </div>
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                  取消 {data.transferStats.cancelled} 单
                </p>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="调拨效率分布" icon={Layers} />
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={efficiencyHistogram}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis
                    dataKey="range"
                    tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    label={{ value: '调拨时长', position: 'insideBottom', offset: -5, fontSize: 12 }}
                  />
                  <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="count" name="调拨单数" fill="#2563EB" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="onTime" name="按时完成" fill="#10B981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 4: 流转效率
            ═══════════════════════════════════════════ */}
        <TabsContent value="route" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {routeKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="各线路流转效率对比" icon={Route} />
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>线路名称</TableHead>
                        <TableHead className="text-right">平均时长(h)</TableHead>
                        <TableHead className="text-right">准时率(%)</TableHead>
                        <TableHead className="text-right">超时率(%)</TableHead>
                        <TableHead>瓶颈节点</TableHead>
                        <TableHead>评级</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.routeEfficiency.map((row) => (
                        <TableRow key={row.routeName}>
                          <TableCell className="font-medium">{row.routeName}</TableCell>
                          <TableCell className="text-right">{row.avgDuration}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <span>{row.onTimeRate}%</span>
                              <MiniBar
                                value={row.onTimeRate}
                                max={100}
                                color={
                                  row.onTimeRate >= 90
                                    ? '#10B981'
                                    : row.onTimeRate >= 80
                                      ? '#F59E0B'
                                      : '#EF4444'
                                }
                              />
                            </div>
                          </TableCell>
                          <TableCell className="text-right">{row.timeoutRate}%</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {row.bottleneckNode}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                row.onTimeRate >= 90
                                  ? 'default'
                                  : row.onTimeRate >= 80
                                    ? 'secondary'
                                    : 'destructive'
                              }
                              className="text-xs"
                            >
                              {row.onTimeRate >= 90 ? 'A' : row.onTimeRate >= 85 ? 'B' : row.onTimeRate >= 80 ? 'C' : 'D'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="线路综合评分雷达图" icon={Gauge} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={360}>
                  <RadarChart data={routeRadarData} cx="50%" cy="50%" outerRadius="70%">
                    <PolarGrid stroke="var(--border)" />
                    <PolarAngleAxis
                      dataKey="metric"
                      tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    />
                    <PolarRadiusAxis tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }} />
                    <Radar name="沪苏昆线" dataKey="r1" stroke="#2563EB" fill="#2563EB" fillOpacity={0.1} />
                    <Radar name="深广宁德线" dataKey="r2" stroke="#10B981" fill="#10B981" fillOpacity={0.1} />
                    <Radar name="武杭沪线" dataKey="r3" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.1} />
                    <Radar name="渝武深线" dataKey="r4" stroke="#EF4444" fill="#EF4444" fillOpacity={0.1} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="线路流转时长趋势（各线路月度对比）" icon={Timer} />
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={routeTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                  />
                  <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="route1"
                    name="沪苏昆线"
                    stroke="#2563EB"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="route2"
                    name="深广宁德线"
                    stroke="#10B981"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="route3"
                    name="武杭沪线"
                    stroke="#F59E0B"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="route4"
                    name="渝武深线"
                    stroke="#EF4444"
                    strokeWidth={2.5}
                    dot={{ r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 5: 设备统计
            ═══════════════════════════════════════════ */}
        <TabsContent value="device" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {deviceKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="设备类型分布（总数/在线/离线）" icon={Cpu} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={data.deviceStats.byType}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="type"
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="total" name="总数" fill="#2563EB" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="online" name="在线" fill="#10B981" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="offline" name="离线" fill="#EF4444" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="设备在线率趋势与平均电量" icon={Wifi} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={320}>
                  <AreaChart data={deviceOnlineTrend}>
                    <defs>
                      <linearGradient id="colorOnline" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2563EB" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <YAxis
                      yAxisId="left"
                      domain={[80, 100]}
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      domain={[50, 80]}
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="onlineRate"
                      name="在线率(%)"
                      stroke="#2563EB"
                      fillOpacity={1}
                      fill="url(#colorOnline)"
                      strokeWidth={2.5}
                    />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="avgBattery"
                      name="平均电量(%)"
                      stroke="#10B981"
                      strokeWidth={2.5}
                      dot={{ r: 4 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="设备类型明细" icon={Cpu} />
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>设备类型</TableHead>
                      <TableHead className="text-right">总数</TableHead>
                      <TableHead className="text-right">在线</TableHead>
                      <TableHead className="text-right">离线</TableHead>
                      <TableHead className="text-right">休眠</TableHead>
                      <TableHead className="text-right">在线率</TableHead>
                      <TableHead className="text-right">平均电量</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.deviceStats.byType.map((row) => {
                      const rate = ((row.online / row.total) * 100).toFixed(1);
                      const sleeping = row.total - row.online - row.offline;
                      return (
                        <TableRow key={row.type}>
                          <TableCell className="font-medium">{row.type}</TableCell>
                          <TableCell className="text-right">{row.total}</TableCell>
                          <TableCell className="text-right text-emerald-600">{row.online}</TableCell>
                          <TableCell className="text-right text-red-500">{row.offline}</TableCell>
                          <TableCell className="text-right text-amber-600">{sleeping > 0 ? sleeping : 0}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <span>{rate}%</span>
                              <Progress value={Number(rate)} className="h-1.5 w-14" />
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <BatteryMedium className="h-3 w-3" style={{ color: 'var(--muted-foreground)' }} />
                              <span>{row.avgBattery}%</span>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 6: 进出库统计
            ═══════════════════════════════════════════ */}
        <TabsContent value="io" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ioKpis.map((kpi, i) => (
              <KpiCard key={i} {...kpi} />
            ))}
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="近30天进出库趋势（自动/手动）" icon={BarChart3} />
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={340}>
                <BarChart data={ioHistoryExtended}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    interval={2}
                  />
                  <YAxis tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="inbound" name="自动入库" fill="#2563EB" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="outbound" name="自动出库" fill="#10B981" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="manualInbound" name="手动入库" fill="#F59E0B" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="manualOutbound" name="手动出库" fill="#EC4899" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="进出库方式分布" icon={Package} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={ioMethodData}
                      cx="50%"
                      cy="50%"
                      outerRadius={110}
                      dataKey="value"
                      nameKey="name"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {ioMethodData.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader className="pb-2">
                <SectionTitle title="进出库方式对比（横向）" icon={Activity} />
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={ioMethodData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis
                      type="number"
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                    />
                    <YAxis
                      dataKey="name"
                      type="category"
                      tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                      width={80}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="value" name="数量" radius={[0, 4, 4, 0]}>
                      {ioMethodData.map((entry, idx) => (
                        <Cell key={idx} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card
            className="transition-shadow hover:shadow-md"
            style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
          >
            <CardHeader className="pb-2">
              <SectionTitle title="近5日进出库明细" icon={History} />
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>日期</TableHead>
                      <TableHead className="text-right">自动入库</TableHead>
                      <TableHead className="text-right">自动出库</TableHead>
                      <TableHead className="text-right">手动入库</TableHead>
                      <TableHead className="text-right">手动出库</TableHead>
                      <TableHead className="text-right">异常</TableHead>
                      <TableHead className="text-right">当日合计</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...ioHistoryExtended].reverse().slice(0, 5).map((row) => {
                      const dayTotal =
                        row.inbound + row.outbound + row.manualInbound + row.manualOutbound;
                      return (
                        <TableRow key={row.date}>
                          <TableCell className="font-medium">{row.date}</TableCell>
                          <TableCell className="text-right">{row.inbound}</TableCell>
                          <TableCell className="text-right">{row.outbound}</TableCell>
                          <TableCell className="text-right">{row.manualInbound}</TableCell>
                          <TableCell className="text-right">{row.manualOutbound}</TableCell>
                          <TableCell className="text-right">
                            {row.abnormal > 0 ? (
                              <Badge variant="destructive" className="text-xs">
                                {row.abnormal}
                              </Badge>
                            ) : (
                              <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                                0
                              </span>
                            )}
                          </TableCell>
                          <TableCell className="text-right font-semibold">{dayTotal}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ═══════════════════════════════════════════
            Tab 7: 报表导出
            ═══════════════════════════════════════════ */}
        <TabsContent value="export" className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {reportTypes.map((report) => (
              <Card
                key={report.id}
                className="group transition-all hover:shadow-md"
                style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
              >
                <CardContent className="p-5">
                  <div className="mb-3 flex items-center gap-3">
                    <div className="rounded-xl p-2.5" style={{ background: 'var(--accent)' }}>
                      <report.icon className="h-5 w-5" style={{ color: 'var(--primary)' }} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold" style={{ color: 'var(--foreground)' }}>
                        {report.name}
                      </p>
                      <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                        {report.desc}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 flex-1 gap-1 text-xs"
                      onClick={() => exportReport(report.name)}
                    >
                      <FileSpreadsheet className="h-3 w-3" />
                      Excel
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 flex-1 gap-1 text-xs"
                      onClick={() => exportReport(report.name + ' PDF')}
                    >
                      <FileText className="h-3 w-3" />
                      PDF
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 px-2 text-xs"
                      onClick={() => exportReport(report.name + ' CSV')}
                    >
                      <ChevronRight className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader>
                <CardTitle
                  className="text-sm font-semibold"
                  style={{ color: 'var(--foreground)' }}
                >
                  <div className="flex items-center gap-2">
                    <CalendarDays className="h-4 w-4" style={{ color: 'var(--primary)' }} />
                    定时导出设置
                  </div>
                </CardTitle>
                <CardDescription>配置自动化报表导出任务</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: '载具日报', freq: '每日 08:00', format: 'Excel', enabled: true },
                  { name: '网点库存周报', freq: '每周一 08:00', format: 'Excel + PDF', enabled: true },
                  { name: '月度综合报表', freq: '每月1日 08:00', format: 'PDF', enabled: false },
                  { name: '季度分析报表', freq: '每季度首日 08:00', format: 'PDF + PPT', enabled: true },
                ].map((sched) => (
                  <div
                    key={sched.name}
                    className="flex items-center justify-between rounded-lg border p-3"
                    style={{ borderColor: 'var(--border)' }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg p-2" style={{ background: 'var(--accent)' }}>
                        <Download className="h-4 w-4" style={{ color: 'var(--primary)' }} />
                      </div>
                      <div>
                        <p className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                          {sched.name}
                        </p>
                        <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                          {sched.freq} · {sched.format}
                        </p>
                      </div>
                    </div>
                    <Badge
                      variant={sched.enabled ? 'default' : 'outline'}
                      className="text-xs"
                    >
                      {sched.enabled ? '已启用' : '已暂停'}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card
              className="transition-shadow hover:shadow-md"
              style={{ background: 'var(--card)', borderColor: 'var(--border)' }}
            >
              <CardHeader>
                <CardTitle
                  className="text-sm font-semibold"
                  style={{ color: 'var(--foreground)' }}
                >
                  <div className="flex items-center gap-2">
                    <Layers className="h-4 w-4" style={{ color: 'var(--primary)' }} />
                    导出历史记录
                  </div>
                </CardTitle>
                <CardDescription>最近7天的报表导出记录</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: '载具统计报表', date: '2025-04-30 08:00', format: 'Excel', size: '256KB' },
                  { name: '网点库存报表', date: '2025-04-29 08:00', format: 'PDF', size: '1.2MB' },
                  { name: '调拨统计报表', date: '2025-04-28 08:00', format: 'Excel', size: '128KB' },
                  { name: '设备统计报表', date: '2025-04-27 08:00', format: 'Excel', size: '312KB' },
                ].map((log) => (
                  <div
                    key={log.name + log.date}
                    className="flex items-center justify-between rounded-lg border p-3"
                    style={{ borderColor: 'var(--border)' }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="rounded-lg p-2" style={{ background: 'var(--accent)' }}>
                        {log.format === 'Excel' ? (
                          <FileSpreadsheet className="h-4 w-4" style={{ color: 'var(--primary)' }} />
                        ) : (
                          <FileText className="h-4 w-4" style={{ color: 'var(--primary)' }} />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium" style={{ color: 'var(--foreground)' }}>
                          {log.name}
                        </p>
                        <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                          {log.date} · {log.size}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {log.format}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
