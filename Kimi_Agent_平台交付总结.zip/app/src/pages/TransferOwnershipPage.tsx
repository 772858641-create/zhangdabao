import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ArrowLeftRight,
  Building2,
  CheckCircle,
  XCircle,
  Clock,
  Search,
  Plus,
  Eye,
  FileText,
  TrendingUp,
  BarChart3,
  ChevronRight,
  User,
  Calendar,
  AlertTriangle,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';

/* ───────────────────────────────────────────────
   Types
   ─────────────────────────────────────────────── */

type TransferStatus =
  | '待审批'
  | '已批准'
  | '待确认'
  | '已完成'
  | '已驳回';

interface TransferRecord {
  id: string;
  applicationNo: string;
  vehicleId: string;
  vehicleType: string;
  sourceOrg: string;
  targetOrg: string;
  applicant: string;
  applyTime: string;
  status: TransferStatus;
  reason: string;
  approver?: string;
  approveTime?: string;
  approveRemark?: string;
  executor?: string;
  executeTime?: string;
}

interface ApprovalLog {
  id: string;
  applicationNo: string;
  action: '批准' | '驳回';
  operator: string;
  time: string;
  remark: string;
}

/* ───────────────────────────────────────────────
   Mock Data — 20 transfer applications
   ─────────────────────────────────────────────── */

const VEHICLE_TYPES = [
  '重型卡车',
  '厢式货车',
  '冷链运输车',
  '平板拖车',
  '危险品运输车',
];

const ORGS = [
  '华东物流中心',
  '华北配送中心',
  '华南运输公司',
  '西南物流基地',
  '华中分拨中心',
  '东北冷链公司',
];

const MOCK_DATA: TransferRecord[] = [
  {
    id: '1',
    applicationNo: 'T20240601001',
    vehicleId: 'V-10089',
    vehicleType: '重型卡车',
    sourceOrg: '华东物流中心',
    targetOrg: '华北配送中心',
    applicant: '张伟',
    applyTime: '2024-06-01 09:30',
    status: '已完成',
    reason: '业务调配，华北区域运力不足',
    approver: '李经理',
    approveTime: '2024-06-01 14:20',
    approveRemark: '同意调配',
    executor: '王芳',
    executeTime: '2024-06-02 10:00',
  },
  {
    id: '2',
    applicationNo: 'T20240605002',
    vehicleId: 'V-10123',
    vehicleType: '厢式货车',
    sourceOrg: '华南运输公司',
    targetOrg: '华中分拨中心',
    applicant: '刘洋',
    applyTime: '2024-06-05 11:15',
    status: '已完成',
    reason: '华南区域车辆冗余，调配至华中',
    approver: '赵主管',
    approveTime: '2024-06-05 16:45',
    approveRemark: '批准',
    executor: '陈静',
    executeTime: '2024-06-06 09:30',
  },
  {
    id: '3',
    applicationNo: 'T20240610003',
    vehicleId: 'V-10256',
    vehicleType: '冷链运输车',
    sourceOrg: '东北冷链公司',
    targetOrg: '华东物流中心',
    applicant: '王强',
    applyTime: '2024-06-10 08:45',
    status: '待审批',
    reason: '夏季冷链需求激增，需增援华东',
  },
  {
    id: '4',
    applicationNo: 'T20240612004',
    vehicleId: 'V-10301',
    vehicleType: '平板拖车',
    sourceOrg: '华北配送中心',
    targetOrg: '西南物流基地',
    applicant: '李明',
    applyTime: '2024-06-12 13:20',
    status: '已批准',
    reason: '西南基建项目运输需求',
    approver: '张总监',
    approveTime: '2024-06-12 17:00',
    approveRemark: '同意，尽快执行',
  },
  {
    id: '5',
    applicationNo: 'T20240615005',
    vehicleId: 'V-10345',
    vehicleType: '危险品运输车',
    sourceOrg: '华东物流中心',
    targetOrg: '华南运输公司',
    applicant: '赵敏',
    applyTime: '2024-06-15 10:00',
    status: '待确认',
    reason: '危险品运输资质调整',
    approver: '孙经理',
    approveTime: '2024-06-15 15:30',
    approveRemark: '批准过户',
  },
  {
    id: '6',
    applicationNo: 'T20240618006',
    vehicleId: 'V-10402',
    vehicleType: '重型卡车',
    sourceOrg: '华中分拨中心',
    targetOrg: '华北配送中心',
    applicant: '孙磊',
    applyTime: '2024-06-18 14:10',
    status: '已驳回',
    reason: '车辆故障，暂不适合过户',
    approver: '周主任',
    approveTime: '2024-06-18 16:50',
    approveRemark: '车辆检测不合格，驳回',
  },
  {
    id: '7',
    applicationNo: 'T20240620007',
    vehicleId: 'V-10455',
    vehicleType: '厢式货车',
    sourceOrg: '西南物流基地',
    targetOrg: '华东物流中心',
    applicant: '周涛',
    applyTime: '2024-06-20 09:00',
    status: '已完成',
    reason: '华东电商大促运力储备',
    approver: '吴经理',
    approveTime: '2024-06-20 11:30',
    approveRemark: '同意',
    executor: '郑和',
    executeTime: '2024-06-21 08:00',
  },
  {
    id: '8',
    applicationNo: 'T20240622008',
    vehicleId: 'V-10510',
    vehicleType: '冷链运输车',
    sourceOrg: '华南运输公司',
    targetOrg: '东北冷链公司',
    applicant: '吴芳',
    applyTime: '2024-06-22 16:40',
    status: '待审批',
    reason: '东北冬季冷链预置运力',
  },
  {
    id: '9',
    applicationNo: 'T20240625009',
    vehicleId: 'V-10567',
    vehicleType: '平板拖车',
    sourceOrg: '华北配送中心',
    targetOrg: '华中分拨中心',
    applicant: '郑华',
    applyTime: '2024-06-25 07:50',
    status: '已完成',
    reason: '华中工厂搬迁运输需求',
    approver: '钱主管',
    approveTime: '2024-06-25 12:10',
    approveRemark: '批准',
    executor: '冯丽',
    executeTime: '2024-06-26 09:00',
  },
  {
    id: '10',
    applicationNo: 'T20240628010',
    vehicleId: 'V-10630',
    vehicleType: '重型卡车',
    sourceOrg: '华东物流中心',
    targetOrg: '西南物流基地',
    applicant: '钱波',
    applyTime: '2024-06-28 11:25',
    status: '已完成',
    reason: '西南矿区运输专线开通',
    approver: '孙总监',
    approveTime: '2024-06-28 15:00',
    approveRemark: '同意开通专线',
    executor: '褚明',
    executeTime: '2024-06-29 10:30',
  },
  {
    id: '11',
    applicationNo: 'T20240701011',
    vehicleId: 'V-10689',
    vehicleType: '危险品运输车',
    sourceOrg: '华中分拨中心',
    targetOrg: '华南运输公司',
    applicant: '冯刚',
    applyTime: '2024-07-01 08:30',
    status: '待审批',
    reason: '华南化工厂运输合同签订',
  },
  {
    id: '12',
    applicationNo: 'T20240703012',
    vehicleId: 'V-10744',
    vehicleType: '厢式货车',
    sourceOrg: '东北冷链公司',
    targetOrg: '华北配送中心',
    applicant: '褚艳',
    applyTime: '2024-07-03 13:00',
    status: '已批准',
    reason: '华北常温配送网络扩展',
    approver: '卫经理',
    approveTime: '2024-07-03 17:20',
    approveRemark: '批准过户',
  },
  {
    id: '13',
    applicationNo: 'T20240705013',
    vehicleId: 'V-10801',
    vehicleType: '冷链运输车',
    sourceOrg: '华南运输公司',
    targetOrg: '华东物流中心',
    applicant: '卫军',
    applyTime: '2024-07-05 09:45',
    status: '已完成',
    reason: '华东生鲜配送旺季增援',
    approver: '蒋主管',
    approveTime: '2024-07-05 14:00',
    approveRemark: '同意增援',
    executor: '沈红',
    executeTime: '2024-07-06 08:30',
  },
  {
    id: '14',
    applicationNo: 'T20240708014',
    vehicleId: 'V-10860',
    vehicleType: '重型卡车',
    sourceOrg: '西南物流基地',
    targetOrg: '华中分拨中心',
    applicant: '蒋丽',
    applyTime: '2024-07-08 15:20',
    status: '已驳回',
    reason: '车辆年限超过过户标准',
    approver: '韩主任',
    approveTime: '2024-07-08 17:40',
    approveRemark: '车龄8年，不符合过户条件',
  },
  {
    id: '15',
    applicationNo: 'T20240710015',
    vehicleId: 'V-10920',
    vehicleType: '平板拖车',
    sourceOrg: '华北配送中心',
    targetOrg: '华东物流中心',
    applicant: '沈明',
    applyTime: '2024-07-10 10:10',
    status: '待确认',
    reason: '华东港口集装箱接驳需求',
    approver: '杨经理',
    approveTime: '2024-07-10 16:00',
    approveRemark: '批准',
  },
  {
    id: '16',
    applicationNo: 'T20240712016',
    vehicleId: 'V-10985',
    vehicleType: '厢式货车',
    sourceOrg: '华中分拨中心',
    targetOrg: '东北冷链公司',
    applicant: '韩冰',
    applyTime: '2024-07-12 12:30',
    status: '待审批',
    reason: '东北常温货物配送需求',
  },
  {
    id: '17',
    applicationNo: 'T20240715017',
    vehicleId: 'V-11050',
    vehicleType: '危险品运输车',
    sourceOrg: '华东物流中心',
    targetOrg: '西南物流基地',
    applicant: '杨光',
    applyTime: '2024-07-15 14:50',
    status: '已完成',
    reason: '西南油气田运输服务',
    approver: '朱总监',
    approveTime: '2024-07-15 18:00',
    approveRemark: '同意',
    executor: '秦月',
    executeTime: '2024-07-16 09:00',
  },
  {
    id: '18',
    applicationNo: 'T20240718018',
    vehicleId: 'V-11120',
    vehicleType: '冷链运输车',
    sourceOrg: '东北冷链公司',
    targetOrg: '华南运输公司',
    applicant: '朱琳',
    applyTime: '2024-07-18 08:00',
    status: '已完成',
    reason: '华南热带水果冷链运输',
    approver: '秦经理',
    approveTime: '2024-07-18 12:30',
    approveRemark: '批准',
    executor: '尤伟',
    executeTime: '2024-07-19 07:30',
  },
  {
    id: '19',
    applicationNo: 'T20240720019',
    vehicleId: 'V-11195',
    vehicleType: '重型卡车',
    sourceOrg: '华南运输公司',
    targetOrg: '华北配送中心',
    applicant: '秦勇',
    applyTime: '2024-07-20 11:00',
    status: '待审批',
    reason: '华北基建砂石料运输',
  },
  {
    id: '20',
    applicationNo: 'T20240722020',
    vehicleId: 'V-11270',
    vehicleType: '平板拖车',
    sourceOrg: '西南物流基地',
    targetOrg: '东北冷链公司',
    applicant: '尤佳',
    applyTime: '2024-07-22 15:30',
    status: '已批准',
    reason: '东北设备运输临时需求',
    approver: '许主管',
    approveTime: '2024-07-22 18:00',
    approveRemark: '批准，限期归还',
  },
];

const APPROVAL_LOGS: ApprovalLog[] = [
  {
    id: 'L001',
    applicationNo: 'T20240601001',
    action: '批准',
    operator: '李经理',
    time: '2024-06-01 14:20',
    remark: '同意调配',
  },
  {
    id: 'L002',
    applicationNo: 'T20240618006',
    action: '驳回',
    operator: '周主任',
    time: '2024-06-18 16:50',
    remark: '车辆检测不合格，驳回',
  },
  {
    id: 'L003',
    applicationNo: 'T20240628010',
    action: '批准',
    operator: '孙总监',
    time: '2024-06-28 15:00',
    remark: '同意开通专线',
  },
  {
    id: 'L004',
    applicationNo: 'T20240708014',
    action: '驳回',
    operator: '韩主任',
    time: '2024-07-08 17:40',
    remark: '车龄8年，不符合过户条件',
  },
  {
    id: 'L005',
    applicationNo: 'T20240715017',
    action: '批准',
    operator: '朱总监',
    time: '2024-07-15 18:00',
    remark: '同意',
  },
  {
    id: 'L006',
    applicationNo: 'T20240720019',
    action: '批准',
    operator: '许主管',
    time: '2024-07-22 18:00',
    remark: '批准，限期归还',
  },
];

const MONTHLY_TREND = [
  { month: '1月', count: 12, approved: 10, rejected: 2 },
  { month: '2月', count: 15, approved: 12, rejected: 3 },
  { month: '3月', count: 18, approved: 15, rejected: 3 },
  { month: '4月', count: 22, approved: 19, rejected: 3 },
  { month: '5月', count: 20, approved: 17, rejected: 3 },
  { month: '6月', count: 25, approved: 21, rejected: 4 },
  { month: '7月', count: 28, approved: 24, rejected: 4 },
];

const PIE_COLORS = ['var(--primary)', '#22c55e', '#f59e0b', '#ef4444'];

/* ───────────────────────────────────────────────
   Helpers
   ─────────────────────────────────────────────── */

function statusConfig(status: TransferStatus) {
  switch (status) {
    case '待审批':
      return { color: 'bg-amber-500 text-white', icon: Clock };
    case '已批准':
      return { color: 'bg-blue-500 text-white', icon: CheckCircle };
    case '待确认':
      return { color: 'bg-purple-500 text-white', icon: AlertTriangle };
    case '已完成':
      return { color: 'bg-green-500 text-white', icon: CheckCircle };
    case '已驳回':
      return { color: 'bg-red-500 text-white', icon: XCircle };
    default:
      return { color: 'bg-gray-500 text-white', icon: FileText };
  }
}

function StatusBadge({ status }: { status: TransferStatus }) {
  const cfg = statusConfig(status);
  const Icon = cfg.icon;
  return (
    <Badge className={`${cfg.color} flex items-center gap-1 w-fit`}>
      <Icon className="h-3 w-3" />
      {status}
    </Badge>
  );
}

/* ───────────────────────────────────────────────
   Sub-components
   ─────────────────────────────────────────────── */

function KpiCards({ data }: { data: TransferRecord[] }) {
  const currentMonth = '07';
  const monthCount = data.filter((d) => d.applyTime.includes(`-${currentMonth}-`)).length;
  const pendingCount = data.filter((d) => d.status === '待审批').length;
  const completedCount = data.filter((d) => d.status === '已完成').length;
  const successRate =
    data.length > 0
      ? Math.round((completedCount / data.length) * 100)
      : 0;

  const cards = [
    {
      title: '本月过户数',
      value: monthCount,
      icon: ArrowLeftRight,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
    },
    {
      title: '待审批数',
      value: pendingCount,
      icon: Clock,
      color: 'text-amber-600',
      bg: 'bg-amber-50',
    },
    {
      title: '已完成数',
      value: completedCount,
      icon: CheckCircle,
      color: 'text-green-600',
      bg: 'bg-green-50',
    },
    {
      title: '过户成功率',
      value: `${successRate}%`,
      icon: TrendingUp,
      color: 'text-purple-600',
      bg: 'bg-purple-50',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card) => {
        const Icon = card.icon;
        return (
          <Card key={card.title} className="shadow-sm">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{card.title}</p>
                <p className="text-2xl font-bold mt-1">{card.value}</p>
              </div>
              <div className={`${card.bg} p-3 rounded-full`}>
                <Icon className={`h-5 w-5 ${card.color}`} />
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

function FlowTable({ data }: { data: TransferRecord[] }) {
  const completed = data.filter((d) => d.status === '已完成');
  const flows = completed.reduce<
    Record<string, { source: string; target: string; count: number }>
  >((acc, cur) => {
    const key = `${cur.sourceOrg}→${cur.targetOrg}`;
    if (!acc[key]) acc[key] = { source: cur.sourceOrg, target: cur.targetOrg, count: 0 };
    acc[key].count += 1;
    return acc;
  }, {});

  const flowList = Object.values(flows).sort((a, b) => b.count - a.count);

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-primary" />
          组织间过户流向
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="text-xs">原组织</TableHead>
                <TableHead className="text-xs w-16 text-center">方向</TableHead>
                <TableHead className="text-xs">目标组织</TableHead>
                <TableHead className="text-xs text-right">过户次数</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {flowList.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                    暂无过户流向数据
                  </TableCell>
                </TableRow>
              )}
              {flowList.map((f) => (
                <TableRow key={`${f.source}→${f.target}`} className="hover:bg-muted/30">
                  <TableCell className="text-sm font-medium">
                    <div className="flex items-center gap-1">
                      <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                      {f.source}
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <ChevronRight className="h-4 w-4 text-primary inline" />
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    <div className="flex items-center gap-1">
                      <Building2 className="h-3.5 w-3.5 text-muted-foreground" />
                      {f.target}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-right font-semibold">{f.count}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

function MonthlyTrendChart() {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-primary" />
          月度过户趋势
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={MONTHLY_TREND} barCategoryGap="20%">
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} />
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: '1px solid var(--border)',
                background: 'var(--popover)',
              }}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="count" name="总申请" fill="var(--primary)" radius={[4, 4, 0, 0]} />
            <Bar dataKey="approved" name="已通过" fill="#22c55e" radius={[4, 4, 0, 0]} />
            <Bar dataKey="rejected" name="已驳回" fill="#ef4444" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

function StatusPieChart({ data }: { data: TransferRecord[] }) {
  const counts = [
    { name: '待审批', value: data.filter((d) => d.status === '待审批').length },
    { name: '已批准', value: data.filter((d) => d.status === '已批准').length },
    { name: '待确认', value: data.filter((d) => d.status === '待确认').length },
    { name: '已完成', value: data.filter((d) => d.status === '已完成').length },
    { name: '已驳回', value: data.filter((d) => d.status === '已驳回').length },
  ].filter((c) => c.value > 0);

  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary" />
          状态分布
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie
              data={counts}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={4}
              dataKey="value"
              label={({ name, percent }) =>
                `${name} ${(percent * 100).toFixed(0)}%`
              }
            >
              {counts.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={PIE_COLORS[index % PIE_COLORS.length]}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                borderRadius: 8,
                border: '1px solid var(--border)',
                background: 'var(--popover)',
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

/* ───────────────────────────────────────────────
   Main Page
   ─────────────────────────────────────────────── */

export default function TransferOwnershipPage() {
  const [records, setRecords] = useState<TransferRecord[]>(MOCK_DATA);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('全部');
  const [activeTab, setActiveTab] = useState('list');

  // Dialog states
  const [showAdd, setShowAdd] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [showApprove, setShowApprove] = useState(false);
  const [showExecute, setShowExecute] = useState(false);
  const [detailRecord, setDetailRecord] = useState<TransferRecord | null>(null);
  const [approveRecord, setApproveRecord] = useState<TransferRecord | null>(null);
  const [executeRecord, setExecuteRecord] = useState<TransferRecord | null>(null);
  const [approveAction, setApproveAction] = useState<'批准' | '驳回'>('批准');
  const [approveRemark, setApproveRemark] = useState('');
  const [executeRemark, setExecuteRemark] = useState('');

  // Add form
  const [newVehicleId, setNewVehicleId] = useState('');
  const [newVehicleType, setNewVehicleType] = useState('');
  const [newSourceOrg, setNewSourceOrg] = useState('');
  const [newTargetOrg, setNewTargetOrg] = useState('');
  const [newApplicant, setNewApplicant] = useState('');
  const [newReason, setNewReason] = useState('');

  // Detail approval logs
  const [detailLogs, setDetailLogs] = useState<ApprovalLog[]>([]);

  const filtered = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        search === '' ||
        r.applicationNo.toLowerCase().includes(search.toLowerCase()) ||
        r.vehicleId.toLowerCase().includes(search.toLowerCase()) ||
        r.applicant.includes(search) ||
        r.sourceOrg.includes(search) ||
        r.targetOrg.includes(search);
      const matchStatus =
        statusFilter === '全部' || r.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [records, search, statusFilter]);

  const historyFiltered = useMemo(() => {
    return records.filter(
      (r) =>
        r.status === '已完成' ||
        r.status === '已驳回'
    );
  }, [records]);

  function openDetail(record: TransferRecord) {
    setDetailRecord(record);
    setDetailLogs(
      APPROVAL_LOGS.filter((l) => l.applicationNo === record.applicationNo)
    );
    setShowDetail(true);
  }

  function openApprove(record: TransferRecord, action: '批准' | '驳回') {
    setApproveRecord(record);
    setApproveAction(action);
    setApproveRemark('');
    setShowApprove(true);
  }

  function openExecute(record: TransferRecord) {
    setExecuteRecord(record);
    setExecuteRemark('');
    setShowExecute(true);
  }

  function handleApprove() {
    if (!approveRecord) return;
    const newRecords = records.map((r) => {
      if (r.id === approveRecord.id) {
        return {
          ...r,
          status:
            approveAction === '批准'
              ? ('待确认' as TransferStatus)
              : ('已驳回' as TransferStatus),
          approver: '当前用户',
          approveTime: new Date().toLocaleString('zh-CN'),
          approveRemark: approveRemark,
        };
      }
      return r;
    });
    setRecords(newRecords);
    APPROVAL_LOGS.push({
      id: `L${Date.now()}`,
      applicationNo: approveRecord.applicationNo,
      action: approveAction,
      operator: '当前用户',
      time: new Date().toLocaleString('zh-CN'),
      remark: approveRemark,
    });
    setShowApprove(false);
    setApproveRecord(null);
  }

  function handleExecute() {
    if (!executeRecord) return;
    const newRecords = records.map((r) => {
      if (r.id === executeRecord.id) {
        return {
          ...r,
          status: '已完成' as TransferStatus,
          executor: '当前用户',
          executeTime: new Date().toLocaleString('zh-CN'),
        };
      }
      return r;
    });
    setRecords(newRecords);
    setShowExecute(false);
    setExecuteRecord(null);
  }

  function handleAdd() {
    if (
      !newVehicleId ||
      !newVehicleType ||
      !newSourceOrg ||
      !newTargetOrg ||
      !newApplicant
    ) {
      return;
    }
    const no = `T${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(
      records.length + 1
    ).padStart(3, '0')}`;
    const newRecord: TransferRecord = {
      id: String(Date.now()),
      applicationNo: no,
      vehicleId: newVehicleId,
      vehicleType: newVehicleType,
      sourceOrg: newSourceOrg,
      targetOrg: newTargetOrg,
      applicant: newApplicant,
      applyTime: new Date().toLocaleString('zh-CN'),
      status: '待审批',
      reason: newReason,
    };
    setRecords([newRecord, ...records]);
    setShowAdd(false);
    setNewVehicleId('');
    setNewVehicleType('');
    setNewSourceOrg('');
    setNewTargetOrg('');
    setNewApplicant('');
    setNewReason('');
  }

  function resetAddForm() {
    setNewVehicleId('');
    setNewVehicleType('');
    setNewSourceOrg('');
    setNewTargetOrg('');
    setNewApplicant('');
    setNewReason('');
  }

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <ArrowLeftRight className="h-6 w-6 text-primary" />
            载具过户管理
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            管理载具所有权过户申请、审批、执行及历史记录
          </p>
        </div>
        <Button
          onClick={() => {
            resetAddForm();
            setShowAdd(true);
          }}
          className="gap-1"
        >
          <Plus className="h-4 w-4" />
          新增过户申请
        </Button>
      </div>

      {/* KPI Cards */}
      <KpiCards data={records} />

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-4">
          <TabsTrigger value="list" className="text-xs">
            <FileText className="h-3.5 w-3.5 mr-1" />
            申请列表
          </TabsTrigger>
          <TabsTrigger value="approval" className="text-xs">
            <CheckCircle className="h-3.5 w-3.5 mr-1" />
            审批记录
          </TabsTrigger>
          <TabsTrigger value="history" className="text-xs">
            <Calendar className="h-3.5 w-3.5 mr-1" />
            历史记录
          </TabsTrigger>
          <TabsTrigger value="stats" className="text-xs">
            <BarChart3 className="h-3.5 w-3.5 mr-1" />
            数据统计
          </TabsTrigger>
        </TabsList>

        {/* ── Tab: Application List ── */}
        <TabsContent value="list" className="space-y-4 mt-4">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索申请单号、载具编号、申请人..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="状态筛选" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="全部">全部状态</SelectItem>
                <SelectItem value="待审批">待审批</SelectItem>
                <SelectItem value="已批准">已批准</SelectItem>
                <SelectItem value="待确认">待确认</SelectItem>
                <SelectItem value="已完成">已完成</SelectItem>
                <SelectItem value="已驳回">已驳回</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card className="shadow-sm">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs w-[130px]">申请单号</TableHead>
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">载具类型</TableHead>
                      <TableHead className="text-xs">原组织</TableHead>
                      <TableHead className="text-xs">目标组织</TableHead>
                      <TableHead className="text-xs">申请人</TableHead>
                      <TableHead className="text-xs w-[130px]">申请时间</TableHead>
                      <TableHead className="text-xs w-[90px]">状态</TableHead>
                      <TableHead className="text-xs text-right w-[160px]">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={9}
                          className="text-center text-muted-foreground py-12"
                        >
                          <FileText className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          暂无过户申请数据
                        </TableCell>
                      </TableRow>
                    )}
                    {filtered.map((record) => (
                      <TableRow
                        key={record.id}
                        className="hover:bg-muted/30 transition-colors"
                      >
                        <TableCell className="text-sm font-medium">
                          {record.applicationNo}
                        </TableCell>
                        <TableCell className="text-sm">{record.vehicleId}</TableCell>
                        <TableCell className="text-sm">{record.vehicleType}</TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-1">
                            <Building2 className="h-3 w-3 text-muted-foreground" />
                            {record.sourceOrg}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-1">
                            <Building2 className="h-3 w-3 text-muted-foreground" />
                            {record.targetOrg}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            {record.applicant}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {record.applyTime}
                          </div>
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={record.status} />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2"
                              onClick={() => openDetail(record)}
                            >
                              <Eye className="h-3.5 w-3.5" />
                            </Button>
                            {record.status === '待审批' && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 px-2 text-green-600 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => openApprove(record, '批准')}
                                >
                                  <CheckCircle className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => openApprove(record, '驳回')}
                                >
                                  <XCircle className="h-3.5 w-3.5" />
                                </Button>
                              </>
                            )}
                            {record.status === '待确认' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 px-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                                onClick={() => openExecute(record)}
                              >
                                <ArrowLeftRight className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab: Approval Records ── */}
        <TabsContent value="approval" className="space-y-4 mt-4">
          <Card className="shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-primary" />
                审批流水记录
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">审批单号</TableHead>
                      <TableHead className="text-xs">申请单号</TableHead>
                      <TableHead className="text-xs">操作</TableHead>
                      <TableHead className="text-xs">操作人</TableHead>
                      <TableHead className="text-xs">审批时间</TableHead>
                      <TableHead className="text-xs">备注</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {APPROVAL_LOGS.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="text-center text-muted-foreground py-12"
                        >
                          <FileText className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          暂无审批记录
                        </TableCell>
                      </TableRow>
                    )}
                    {APPROVAL_LOGS.map((log) => (
                      <TableRow
                        key={log.id}
                        className="hover:bg-muted/30 transition-colors"
                      >
                        <TableCell className="text-sm font-medium">{log.id}</TableCell>
                        <TableCell className="text-sm">{log.applicationNo}</TableCell>
                        <TableCell>
                          <Badge
                            className={
                              log.action === '批准'
                                ? 'bg-green-500 text-white'
                                : 'bg-red-500 text-white'
                            }
                          >
                            {log.action === '批准' ? (
                              <CheckCircle className="h-3 w-3 mr-1" />
                            ) : (
                              <XCircle className="h-3 w-3 mr-1" />
                            )}
                            {log.action}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            {log.operator}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {log.time}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm max-w-[200px] truncate">
                          {log.remark}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab: History ── */}
        <TabsContent value="history" className="space-y-4 mt-4">
          <div className="flex items-center gap-2">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索历史记录..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Badge variant="outline" className="h-9 px-3">
              <FileText className="h-3.5 w-3.5 mr-1" />
              共 {historyFiltered.length} 条
            </Badge>
          </div>
          <Card className="shadow-sm">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="text-xs">申请单号</TableHead>
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">类型</TableHead>
                      <TableHead className="text-xs">原组织</TableHead>
                      <TableHead className="text-xs">目标组织</TableHead>
                      <TableHead className="text-xs">申请人</TableHead>
                      <TableHead className="text-xs">申请时间</TableHead>
                      <TableHead className="text-xs">状态</TableHead>
                      <TableHead className="text-xs">审批人</TableHead>
                      <TableHead className="text-xs text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {historyFiltered.length === 0 && (
                      <TableRow>
                        <TableCell
                          colSpan={10}
                          className="text-center text-muted-foreground py-12"
                        >
                          <Calendar className="h-8 w-8 mx-auto mb-2 opacity-40" />
                          暂无历史记录
                        </TableCell>
                      </TableRow>
                    )}
                    {historyFiltered.map((record) => (
                      <TableRow
                        key={record.id}
                        className="hover:bg-muted/30 transition-colors"
                      >
                        <TableCell className="text-sm font-medium">
                          {record.applicationNo}
                        </TableCell>
                        <TableCell className="text-sm">{record.vehicleId}</TableCell>
                        <TableCell className="text-sm">{record.vehicleType}</TableCell>
                        <TableCell className="text-sm">{record.sourceOrg}</TableCell>
                        <TableCell className="text-sm">{record.targetOrg}</TableCell>
                        <TableCell className="text-sm">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            {record.applicant}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {record.applyTime}
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={record.status} />
                        </TableCell>
                        <TableCell className="text-sm">
                          {record.approver || '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 px-2"
                            onClick={() => openDetail(record)}
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab: Statistics ── */}
        <TabsContent value="stats" className="space-y-4 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <MonthlyTrendChart />
            <StatusPieChart data={records} />
          </div>
          <FlowTable data={records} />
        </TabsContent>
      </Tabs>

      {/* ── Dialog: Add Application ── */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="sm:max-w-[520px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" />
              新增过户申请
            </DialogTitle>
            <DialogDescription>
              填写载具过户申请信息，提交后将进入审批流程
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">载具编号</label>
                <Input
                  placeholder="如 V-10089"
                  value={newVehicleId}
                  onChange={(e) => setNewVehicleId(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">载具类型</label>
                <Select value={newVehicleType} onValueChange={setNewVehicleType}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择类型" />
                  </SelectTrigger>
                  <SelectContent>
                    {VEHICLE_TYPES.map((t) => (
                      <SelectItem key={t} value={t}>
                        {t}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-sm font-medium">原组织</label>
                <Select value={newSourceOrg} onValueChange={setNewSourceOrg}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择原组织" />
                  </SelectTrigger>
                  <SelectContent>
                    {ORGS.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">目标组织</label>
                <Select value={newTargetOrg} onValueChange={setNewTargetOrg}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择目标组织" />
                  </SelectTrigger>
                  <SelectContent>
                    {ORGS.map((o) => (
                      <SelectItem key={o} value={o}>
                        {o}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">申请人</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="填写申请人姓名"
                  value={newApplicant}
                  onChange={(e) => setNewApplicant(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">过户原因</label>
              <Textarea
                placeholder="请填写过户原因及备注说明..."
                value={newReason}
                onChange={(e) => setNewReason(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdd(false)}>
              取消
            </Button>
            <Button onClick={handleAdd}>
              <CheckCircle className="h-4 w-4 mr-1" />
              提交申请
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Detail ── */}
      <Dialog open={showDetail} onOpenChange={setShowDetail}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-primary" />
              过户申请详情
            </DialogTitle>
            <DialogDescription>
              {detailRecord?.applicationNo}
            </DialogDescription>
          </DialogHeader>
          {detailRecord && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-1">
                  <span className="text-muted-foreground">载具编号</span>
                  <p className="font-medium">{detailRecord.vehicleId}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">载具类型</span>
                  <p className="font-medium">{detailRecord.vehicleType}</p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">原组织</span>
                  <p className="font-medium flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5" />
                    {detailRecord.sourceOrg}
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">目标组织</span>
                  <p className="font-medium flex items-center gap-1">
                    <Building2 className="h-3.5 w-3.5" />
                    {detailRecord.targetOrg}
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">申请人</span>
                  <p className="font-medium flex items-center gap-1">
                    <User className="h-3.5 w-3.5" />
                    {detailRecord.applicant}
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">申请时间</span>
                  <p className="font-medium flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" />
                    {detailRecord.applyTime}
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-muted-foreground">当前状态</span>
                  <div className="mt-1">
                    <StatusBadge status={detailRecord.status} />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-muted-foreground text-sm">过户原因</span>
                <p className="text-sm bg-muted p-3 rounded-md">{detailRecord.reason}</p>
              </div>

              {detailRecord.approver && (
                <div className="space-y-1">
                  <span className="text-muted-foreground text-sm">审批信息</span>
                  <div className="text-sm bg-muted p-3 rounded-md space-y-1">
                    <p>
                      <span className="text-muted-foreground">审批人：</span>
                      {detailRecord.approver}
                    </p>
                    <p>
                      <span className="text-muted-foreground">审批时间：</span>
                      {detailRecord.approveTime}
                    </p>
                    <p>
                      <span className="text-muted-foreground">审批备注：</span>
                      {detailRecord.approveRemark}
                    </p>
                  </div>
                </div>
              )}

              {detailRecord.executor && (
                <div className="space-y-1">
                  <span className="text-muted-foreground text-sm">执行信息</span>
                  <div className="text-sm bg-muted p-3 rounded-md space-y-1">
                    <p>
                      <span className="text-muted-foreground">执行人：</span>
                      {detailRecord.executor}
                    </p>
                    <p>
                      <span className="text-muted-foreground">执行时间：</span>
                      {detailRecord.executeTime}
                    </p>
                  </div>
                </div>
              )}

              {detailLogs.length > 0 && (
                <div className="space-y-2">
                  <span className="text-muted-foreground text-sm">审批流水</span>
                  <div className="space-y-2">
                    {detailLogs.map((log) => (
                      <div
                        key={log.id}
                        className="text-sm border rounded-md p-3 flex items-start gap-3"
                      >
                        <div
                          className={`mt-0.5 p-1 rounded-full ${
                            log.action === '批准' ? 'bg-green-100' : 'bg-red-100'
                          }`}
                        >
                          {log.action === '批准' ? (
                            <CheckCircle
                              className={`h-3.5 w-3.5 ${
                                log.action === '批准' ? 'text-green-600' : 'text-red-600'
                              }`}
                            />
                          ) : (
                            <XCircle className="h-3.5 w-3.5 text-red-600" />
                          )}
                        </div>
                        <div className="flex-1 space-y-0.5">
                          <div className="flex items-center gap-2">
                            <Badge
                              className={
                                log.action === '批准'
                                  ? 'bg-green-500 text-white'
                                  : 'bg-red-500 text-white'
                              }
                            >
                              {log.action}
                            </Badge>
                            <span className="text-muted-foreground text-xs">
                              {log.time}
                            </span>
                          </div>
                          <p className="text-muted-foreground text-xs">
                            操作人：{log.operator}
                          </p>
                          <p className="text-xs">{log.remark}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetail(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Approve / Reject ── */}
      <Dialog open={showApprove} onOpenChange={setShowApprove}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {approveAction === '批准' ? (
                <>
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  批准过户申请
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-600" />
                  驳回过户申请
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {approveRecord?.applicationNo} — {approveRecord?.vehicleId}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="text-sm bg-muted p-3 rounded-md space-y-1">
              <p>
                <span className="text-muted-foreground">载具编号：</span>
                {approveRecord?.vehicleId}
              </p>
              <p>
                <span className="text-muted-foreground">原组织：</span>
                {approveRecord?.sourceOrg}
              </p>
              <p>
                <span className="text-muted-foreground">目标组织：</span>
                {approveRecord?.targetOrg}
              </p>
              <p>
                <span className="text-muted-foreground">申请人：</span>
                {approveRecord?.applicant}
              </p>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">
                审批备注
                {approveAction === '驳回' && (
                  <span className="text-red-500"> *</span>
                )}
              </label>
              <Textarea
                placeholder={`请填写${approveAction}原因...`}
                value={approveRemark}
                onChange={(e) => setApproveRemark(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApprove(false)}>
              取消
            </Button>
            <Button
              onClick={handleApprove}
              variant={approveAction === '批准' ? 'default' : 'destructive'}
            >
              {approveAction === '批准' ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-1" />
                  确认批准
                </>
              ) : (
                <>
                  <XCircle className="h-4 w-4 mr-1" />
                  确认驳回
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Dialog: Execute Confirm ── */}
      <Dialog open={showExecute} onOpenChange={setShowExecute}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowLeftRight className="h-5 w-5 text-blue-600" />
              执行过户确认
            </DialogTitle>
            <DialogDescription>
              {executeRecord?.applicationNo} — {executeRecord?.vehicleId}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="flex items-center justify-center gap-3 py-3">
              <div className="text-center">
                <Building2 className="h-8 w-8 text-muted-foreground mx-auto mb-1" />
                <p className="text-sm font-medium">{executeRecord?.sourceOrg}</p>
                <p className="text-xs text-muted-foreground">原组织</p>
              </div>
              <div className="flex flex-col items-center">
                <ArrowLeftRight className="h-6 w-6 text-primary" />
                <ChevronRight className="h-4 w-4 text-primary" />
              </div>
              <div className="text-center">
                <Building2 className="h-8 w-8 text-primary mx-auto mb-1" />
                <p className="text-sm font-medium">{executeRecord?.targetOrg}</p>
                <p className="text-xs text-muted-foreground">目标组织</p>
              </div>
            </div>
            <div className="text-sm bg-muted p-3 rounded-md space-y-1">
              <p>
                <span className="text-muted-foreground">载具编号：</span>
                {executeRecord?.vehicleId}
              </p>
              <p>
                <span className="text-muted-foreground">载具类型：</span>
                {executeRecord?.vehicleType}
              </p>
              <p>
                <span className="text-muted-foreground">审批人：</span>
                {executeRecord?.approver}
              </p>
              <p>
                <span className="text-muted-foreground">审批备注：</span>
                {executeRecord?.approveRemark}
              </p>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">执行备注</label>
              <Textarea
                placeholder="填写执行备注..."
                value={executeRemark}
                onChange={(e) => setExecuteRemark(e.target.value)}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowExecute(false)}>
              取消
            </Button>
            <Button onClick={handleExecute}>
              <CheckCircle className="h-4 w-4 mr-1" />
              确认执行过户
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
