import { useState, useMemo } from 'react';
import {
  ShieldCheck,
  AlertOctagon,
  GitBranch,
  Save,
  CheckCircle,
  Activity,
  TrendingUp,
  TrendingDown,
  Search,
  Database,
  Server,
  Layers,
  Code,
  Globe,
  ChevronRight,
  Clock,
  RotateCcw,
  HardDrive,
  Calendar,
  Check,
  X,
  Bell,
  FileText,
  ArrowRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

/* ================================================================
   Types
   ================================================================ */

type GovernanceTab = 'quality' | 'lineage' | 'backup';

interface QualityAlert {
  id: string;
  time: string;
  metric: string;
  threshold: string;
  actual: string;
  severity: 'urgent' | 'important' | 'normal';
}

interface LineageRecord {
  id: string;
  dataType: string;
  sourceModule: string;
  chain: string[];
  createdAt: string;
}

interface BackupPolicy {
  id: string;
  name: string;
  type: string;
  frequency: string;
  retention: string;
  lastBackup: string;
  nextBackup: string;
  status: 'success' | 'pending' | 'failed';
  size: string;
}

interface BackupHistory {
  id: string;
  time: string;
  type: string;
  size: string;
  status: 'success' | 'failed';
}

/* ================================================================
   Mock Data
   ================================================================ */

const governanceTabs: { key: GovernanceTab; label: string }[] = [
  { key: 'quality', label: '数据质量' },
  { key: 'lineage', label: '血缘追踪' },
  { key: 'backup', label: '备份恢复' },
];

const qualityAlerts: QualityAlert[] = [
  { id: 'qa-1', time: '2024-12-20 14:32', metric: '设备上报延迟', threshold: '< 5分钟', actual: '12分钟', severity: 'important' },
  { id: 'qa-2', time: '2024-12-20 11:15', metric: '位置数据缺失率', threshold: '< 0.5%', actual: '0.8%', severity: 'normal' },
  { id: 'qa-3', time: '2024-12-20 09:45', metric: '状态变更上报完整率', threshold: '> 99.5%', actual: '99.1%', severity: 'normal' },
  { id: 'qa-4', time: '2024-12-19 22:08', metric: '轨迹点异常率', threshold: '< 1%', actual: '3.2%', severity: 'urgent' },
  { id: 'qa-5', time: '2024-12-19 18:30', metric: '电量数据上报延迟', threshold: '< 30分钟', actual: '45分钟', severity: 'important' },
];

const lineageRecords: LineageRecord[] = [
  {
    id: 'ln-1',
    dataType: '报警事件记录',
    sourceModule: '设备上报服务',
    chain: ['原始设备报文', '清洗规则', '流处理任务', 'Data API', '报警管理模块'],
    createdAt: '2024-12-20 10:30:00',
  },
  {
    id: 'ln-2',
    dataType: '载具位置轨迹',
    sourceModule: 'GPS定位服务',
    chain: ['原始设备报文', '坐标纠偏', '流处理任务', 'Data API', '轨迹查询模块'],
    createdAt: '2024-12-20 09:15:00',
  },
  {
    id: 'ln-3',
    dataType: '空满载状态变更',
    sourceModule: '信标扫描服务',
    chain: ['原始设备报文', '清洗规则', '流处理任务', 'Data API', '统计分析模块'],
    createdAt: '2024-12-20 08:45:00',
  },
  {
    id: 'ln-4',
    dataType: '设备状态记录',
    sourceModule: '心跳检测服务',
    chain: ['原始设备报文', '清洗规则', '流处理任务', 'Data API', '设备管理模块'],
    createdAt: '2024-12-19 16:20:00',
  },
  {
    id: 'ln-5',
    dataType: '出入库事件',
    sourceModule: '网关扫描服务',
    chain: ['原始设备报文', '围栏判定', '流处理任务', 'Data API', '库存管理模块'],
    createdAt: '2024-12-19 14:00:00',
  },
];

const backupPolicies: BackupPolicy[] = [
  { id: 'bp-1', name: '热数据增量备份', type: '增量备份', frequency: '每日 02:00', retention: '30天', lastBackup: '2024-12-20 02:00', nextBackup: '2024-12-21 02:00', status: 'success', size: '2.1GB' },
  { id: 'bp-2', name: '温数据全量备份', type: '全量备份', frequency: '每周日 03:00', retention: '30天', lastBackup: '2024-12-15 03:00', nextBackup: '2024-12-22 03:00', status: 'success', size: '156GB' },
  { id: 'bp-3', name: '冷数据归档备份', type: '归档备份', frequency: '每月1日 04:00', retention: '1年', lastBackup: '2024-12-01 04:00', nextBackup: '2025-01-01 04:00', status: 'success', size: '890GB' },
];

const backupHistory: BackupHistory[] = [
  { id: 'bh-1', time: '2024-12-20 02:00', type: '热数据增量备份', size: '2.1GB', status: 'success' },
  { id: 'bh-2', time: '2024-12-19 02:00', type: '热数据增量备份', size: '1.8GB', status: 'success' },
  { id: 'bh-3', time: '2024-12-18 02:00', type: '热数据增量备份', size: '2.3GB', status: 'success' },
  { id: 'bh-4', time: '2024-12-17 02:00', type: '热数据增量备份', size: '1.9GB', status: 'success' },
  { id: 'bh-5', time: '2024-12-15 03:00', type: '温数据全量备份', size: '156GB', status: 'success' },
  { id: 'bh-6', time: '2024-12-08 03:00', type: '温数据全量备份', size: '148GB', status: 'success' },
  { id: 'bh-7', time: '2024-12-01 04:00', type: '冷数据归档备份', size: '890GB', status: 'success' },
];

function generateQualityTrend() {
  const days = ['12/14', '12/15', '12/16', '12/17', '12/18', '12/19', '12/20'];
  return days.map((date) => ({
    date,
    completeRate: 98.5 + Math.random() * 1.2,
    delayRate: Math.random() * 2,
    abnormalRate: Math.random() * 1.5,
  }));
}

/* ================================================================
   Helpers
   ================================================================ */

function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow duration-200">
      <CardContent className="p-4 flex items-start gap-4">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
          <Icon size={20} style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-neutral-textSecondary mb-1">{title}</p>
          <p className="text-[28px] font-semibold leading-tight text-neutral-textPrimary font-number">{value}</p>
          {subtext && <p className="text-xs text-neutral-textTertiary mt-1">{subtext}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

function SeverityBadge({ severity }: { severity: string }) {
  const config: Record<string, { label: string; color: string; bg: string }> = {
    urgent: { label: '紧急', color: '#EF4444', bg: '#FEF2F2' },
    important: { label: '重要', color: '#F59E0B', bg: '#FFFBEB' },
    normal: { label: '一般', color: '#475569', bg: '#F1F5F9' },
  };
  const c = config[severity] || config.normal;
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color: c.color, backgroundColor: c.bg }}>
      {c.label}
    </span>
  );
}

function StatusIcon({ status }: { status: string }) {
  if (status === 'success') return <Check size={16} className="text-success" />;
  if (status === 'failed') return <X size={16} className="text-danger" />;
  return <Clock size={16} className="text-warning" />;
}

/* ================================================================
   Sub Tabs
   ================================================================ */

function DataQualityTab() {
  const trendData = useMemo(() => generateQualityTrend(), []);

  return (
    <div className="space-y-5">
      {/* Quality Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-neutral-textSecondary">上报完整率</span>
              <div className="w-8 h-8 rounded-full bg-success/10 flex items-center justify-center">
                <CheckCircle size={16} className="text-success" />
              </div>
            </div>
            <p className="text-2xl font-semibold text-neutral-textPrimary font-number">99.2%</p>
            <div className="flex items-center gap-1 mt-1">
              <TrendingUp size={12} className="text-success" />
              <span className="text-xs text-success">+0.3%</span>
              <span className="text-xs text-neutral-textTertiary">环比</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-neutral-textSecondary">上报延迟率</span>
              <div className="w-8 h-8 rounded-full bg-warning/10 flex items-center justify-center">
                <Clock size={16} className="text-warning" />
              </div>
            </div>
            <p className="text-2xl font-semibold text-neutral-textPrimary font-number">0.5%</p>
            <div className="flex items-center gap-1 mt-1">
              <TrendingDown size={12} className="text-success" />
              <span className="text-xs text-success">-0.1%</span>
              <span className="text-xs text-neutral-textTertiary">环比</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-neutral-textSecondary">数据异常率</span>
              <div className="w-8 h-8 rounded-full bg-danger/10 flex items-center justify-center">
                <AlertOctagon size={16} className="text-danger" />
              </div>
            </div>
            <p className="text-2xl font-semibold text-neutral-textPrimary font-number">0.8%</p>
            <div className="flex items-center gap-1 mt-1">
              <TrendingUp size={12} className="text-danger" />
              <span className="text-xs text-danger">+0.2%</span>
              <span className="text-xs text-neutral-textTertiary">环比</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quality Trend Chart */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Activity size={16} className="text-neutral-textSecondary" />
            近7天数据质量趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} domain={[96, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => {
                  const label = name === 'completeRate' ? '上报完整率' : name === 'delayRate' ? '上报延迟率' : '数据异常率';
                  return [`${value.toFixed(2)}%`, label];
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} formatter={(value: string) => {
                const map: Record<string, string> = { completeRate: '上报完整率', delayRate: '上报延迟率', abnormalRate: '数据异常率' };
                return map[value] || value;
              }} />
              <Line type="monotone" dataKey="completeRate" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="delayRate" stroke="#F59E0B" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="abnormalRate" stroke="#EF4444" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Quality Alert List */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Bell size={16} className="text-neutral-textSecondary" />
            质量异常告警列表
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-neutral-surface-elevated">
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">时间</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">指标</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">阈值</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">实际值</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">严重程度</th>
                </tr>
              </thead>
              <tbody>
                {qualityAlerts.map((alert) => (
                  <tr key={alert.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                    <td className="px-4 py-3 text-xs text-neutral-textSecondary font-number whitespace-nowrap">{alert.time}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textPrimary font-medium">{alert.metric}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{alert.threshold}</td>
                    <td className="px-4 py-3 text-sm font-number font-medium" style={{ color: alert.severity === 'urgent' ? '#EF4444' : alert.severity === 'important' ? '#F59E0B' : '#475569' }}>{alert.actual}</td>
                    <td className="px-4 py-3"><SeverityBadge severity={alert.severity} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function LineageTab() {
  const [searchId, setSearchId] = useState('');
  const [searched, setSearched] = useState(false);

  const handleSearch = () => {
    setSearched(true);
  };

  const chainIcons = [Database, Server, Layers, Code, Globe];

  return (
    <div className="space-y-5">
      {/* Search Panel */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-neutral-textSecondary">
              <Search size={16} />
              <span>追踪查询</span>
            </div>
            <div className="flex-1 flex items-center gap-2 w-full sm:w-auto">
              <input
                type="text"
                value={searchId}
                onChange={(e) => setSearchId(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="输入数据ID（如报警记录ID）..."
                className="flex-1 h-9 px-3 border border-neutral-border rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
              />
              <Button size="sm" className="h-9 text-xs" onClick={handleSearch}>
                <Search size={14} className="mr-1" />
                查询血缘
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lineage Chain Visualization */}
      {searched && (
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <GitBranch size={16} className="text-neutral-textSecondary" />
              数据血缘链路
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center justify-center gap-2 py-4 overflow-x-auto">
              {['原始设备报文', '清洗规则', '流处理任务', 'Data API', '业务模块'].map((step, i, arr) => {
                const Icon = chainIcons[i];
                return (
                  <div key={step} className="flex items-center gap-2">
                    <div className="flex flex-col items-center gap-1.5 px-4 py-3 rounded-lg border border-neutral-border bg-neutral-background min-w-[100px]">
                      <Icon size={18} className="text-primary" />
                      <span className="text-xs font-medium text-neutral-textPrimary whitespace-nowrap">{step}</span>
                    </div>
                    {i < arr.length - 1 && (
                      <ArrowRight size={16} className="text-neutral-textTertiary hidden md:block flex-shrink-0" />
                    )}
                    {i < arr.length - 1 && (
                      <ChevronRight size={16} className="text-neutral-textTertiary block md:hidden rotate-90" />
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Lineage Records Table */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <FileText size={16} className="text-neutral-textSecondary" />
            血缘记录列表
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-neutral-surface-elevated">
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">记录ID</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">数据类型</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">来源模块</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">处理链路</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">生成时间</th>
                </tr>
              </thead>
              <tbody>
                {lineageRecords.map((record) => (
                  <tr key={record.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                    <td className="px-4 py-3 text-sm font-mono text-neutral-textPrimary">{record.id}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textPrimary font-medium">{record.dataType}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary">{record.sourceModule}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-0.5 flex-wrap">
                        {record.chain.map((step, i, arr) => (
                          <span key={step} className="flex items-center gap-0.5">
                            <span className="text-xs text-neutral-textSecondary">{step}</span>
                            {i < arr.length - 1 && <ChevronRight size={10} className="text-neutral-textTertiary" />}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-neutral-textSecondary font-number whitespace-nowrap">{record.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function BackupTab() {
  const [selectedBackup, setSelectedBackup] = useState('');

  return (
    <div className="space-y-5">
      {/* Backup Policies */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <HardDrive size={16} className="text-neutral-textSecondary" />
            备份策略列表
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-neutral-surface-elevated">
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">备份类型</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">频率</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">保留时长</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">最后备份</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">下次备份</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">大小</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">状态</th>
                </tr>
              </thead>
              <tbody>
                {backupPolicies.map((bp) => (
                  <tr key={bp.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-sm font-medium text-neutral-textPrimary">{bp.name}</p>
                        <p className="text-xs text-neutral-textTertiary">{bp.type}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary">{bp.frequency}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{bp.retention}</td>
                    <td className="px-4 py-3 text-xs text-neutral-textSecondary font-number whitespace-nowrap">{bp.lastBackup}</td>
                    <td className="px-4 py-3 text-xs text-neutral-textSecondary font-number whitespace-nowrap">{bp.nextBackup}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{bp.size}</td>
                    <td className="px-4 py-3"><StatusIcon status={bp.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Backup History */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Calendar size={16} className="text-neutral-textSecondary" />
              备份历史
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[400px] overflow-y-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-neutral-surface-elevated sticky top-0">
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">时间</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">类型</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">大小</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">状态</th>
                  </tr>
                </thead>
                <tbody>
                  {backupHistory.map((bh) => (
                    <tr
                      key={bh.id}
                      onClick={() => setSelectedBackup(bh.id)}
                      className={cn(
                        'border-b border-neutral-border hover:bg-neutral-background transition-colors cursor-pointer',
                        selectedBackup === bh.id && 'bg-primary/5'
                      )}
                    >
                      <td className="px-4 py-3 text-xs text-neutral-textSecondary font-number whitespace-nowrap">{bh.time}</td>
                      <td className="px-4 py-3 text-sm text-neutral-textPrimary">{bh.type}</td>
                      <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{bh.size}</td>
                      <td className="px-4 py-3"><StatusIcon status={bh.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Recovery Panel */}
        <Card className="bg-neutral-surface border-neutral-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <RotateCcw size={16} className="text-neutral-textSecondary" />
              恢复操作面板
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1.5 block">选择备份点</label>
              <select
                value={selectedBackup}
                onChange={(e) => setSelectedBackup(e.target.value)}
                className="w-full h-9 px-3 border border-neutral-border rounded-md text-sm focus:outline-none focus:border-primary bg-white"
              >
                <option value="">请选择备份点</option>
                {backupHistory.map((bh) => (
                  <option key={bh.id} value={bh.id}>{bh.time} - {bh.type} ({bh.size})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs text-neutral-textSecondary mb-1.5 block">恢复范围 - 载具</label>
              <input
                type="text"
                placeholder="输入载具编号，多个用逗号分隔，留空恢复全部"
                className="w-full h-9 px-3 border border-neutral-border rounded-md text-sm focus:outline-none focus:border-primary bg-white"
              />
            </div>

            <div>
              <label className="text-xs text-neutral-textSecondary mb-1.5 block">恢复范围 - 时间</label>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  className="flex-1 h-9 px-3 border border-neutral-border rounded-md text-sm focus:outline-none focus:border-primary bg-white"
                />
                <span className="text-xs text-neutral-textTertiary">至</span>
                <input
                  type="date"
                  className="flex-1 h-9 px-3 border border-neutral-border rounded-md text-sm focus:outline-none focus:border-primary bg-white"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-neutral-textSecondary mb-1.5 block">恢复范围 - 数据类型</label>
              <div className="flex flex-wrap gap-2">
                {['原始报文', '位置轨迹', '状态变更', '报警事件', '操作日志'].map((type) => (
                  <label key={type} className="flex items-center gap-1.5 text-xs text-neutral-textSecondary cursor-pointer">
                    <input type="checkbox" className="rounded border-neutral-border" />
                    {type}
                  </label>
                ))}
              </div>
            </div>

            <Button
              disabled={!selectedBackup}
              className="w-full h-9 text-sm"
              variant={selectedBackup ? 'default' : 'outline'}
            >
              <RotateCcw size={14} className="mr-1.5" />
              {selectedBackup ? '开始恢复' : '请先选择备份点'}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function DataGovernanceTab() {
  const [activeTab, setActiveTab] = useState<GovernanceTab>('quality');

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="数据完整率" value="99.2%" subtext="高质量" color="#10B981" icon={ShieldCheck} />
        <KPICard title="数据异常率" value="0.8%" subtext="需关注" color="#EF4444" icon={AlertOctagon} />
        <KPICard title="血缘追踪记录" value="12,450" subtext="条" color="#8B5CF6" icon={GitBranch} />
        <KPICard title="备份任务状态" value="成功" subtext="上次备份 2小时前" color="#06B6D4" icon={Save} />
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="flex items-center border-b border-neutral-border px-4">
          {governanceTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative px-4 py-3 text-sm font-medium transition-colors',
                activeTab === tab.key
                  ? 'text-primary'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
              )}
            >
              {tab.label}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-full" />
              )}
            </button>
          ))}
        </div>
        <div className="p-4">
          {activeTab === 'quality' && <DataQualityTab />}
          {activeTab === 'lineage' && <LineageTab />}
          {activeTab === 'backup' && <BackupTab />}
        </div>
      </div>
    </div>
  );
}
