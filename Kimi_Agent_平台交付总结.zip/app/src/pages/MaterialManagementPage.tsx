import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts';
import {
  Package,
  Search,
  Download,
  Boxes,
  AlertTriangle,
  TrendingUp,
  History,
  ArrowUpDown,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Material {
  id: string;
  code: string;
  name: string;
  type: string;
  spec: string;
  unit: string;
  carrierId: string;
  location: string;
  quantity: number;
  safetyStock: number;
  staleThreshold: number;
  lastInbound: string;
  lastOutbound: string;
  status: 'normal' | 'stale' | 'scrap';
}

interface UnbindRecord {
  id: string;
  time: string;
  operator: string;
  carrierId: string;
  materialCode: string;
  materialName: string;
  quantity: number;
  reason: string;
  site: string;
  transferNo: string;
}

interface FlowHistory {
  time: string;
  event: string;
  carrier: string;
  site: string;
  operator: string;
}

const materials: Material[] = [
  { id: 'M001', code: 'M-2025-001', name: '发动机支架', type: '半成品', spec: 'AZ-200×150', unit: '件', carrierId: 'CA-20250401-001', location: '上海浦东仓库-A区', quantity: 120, safetyStock: 50, staleThreshold: 30, lastInbound: '2025-04-20', lastOutbound: '2025-04-28', status: 'normal' },
  { id: 'M002', code: 'M-2025-002', name: '底盘加强板', type: '原材料', spec: 'DP-300×200', unit: '件', carrierId: 'CA-20250401-015', location: '苏州昆山工厂-1号仓', quantity: 45, safetyStock: 60, staleThreshold: 20, lastInbound: '2025-04-15', lastOutbound: '2025-04-25', status: 'stale' },
  { id: 'M003', code: 'M-2025-003', name: '仪表盘总成', type: '成品', spec: 'DB-15寸', unit: '套', carrierId: 'CA-20250402-032', location: '宁波北仑物流园-B仓', quantity: 88, safetyStock: 30, staleThreshold: 45, lastInbound: '2025-04-22', lastOutbound: '2025-04-29', status: 'normal' },
  { id: 'M004', code: 'M-2025-004', name: '座椅骨架', type: '半成品', spec: 'ST-450×380', unit: '件', carrierId: 'CA-20250403-008', location: '武汉东西湖仓库', quantity: 32, safetyStock: 40, staleThreshold: 25, lastInbound: '2025-04-10', lastOutbound: '2025-04-18', status: 'stale' },
  { id: 'M005', code: 'M-2025-005', name: '轮胎螺栓', type: '原材料', spec: 'BL-M12×45', unit: '个', carrierId: 'CA-20250404-021', location: '合肥经开区网点', quantity: 500, safetyStock: 200, staleThreshold: 60, lastInbound: '2025-04-25', lastOutbound: '2025-04-29', status: 'normal' },
  { id: 'M006', code: 'M-2025-006', name: '前保险杠', type: '成品', spec: 'BP-2.1m白', unit: '件', carrierId: 'CA-20250405-009', location: '重庆两江仓库-C区', quantity: 18, safetyStock: 20, staleThreshold: 15, lastInbound: '2025-03-28', lastOutbound: '2025-04-05', status: 'stale' },
  { id: 'M007', code: 'M-2025-007', name: '车窗玻璃', type: '成品', spec: 'GL-前挡夹层', unit: '片', carrierId: 'CA-20250406-044', location: '成都龙泉驿仓库', quantity: 76, safetyStock: 40, staleThreshold: 30, lastInbound: '2025-04-18', lastOutbound: '2025-04-27', status: 'normal' },
  { id: 'M008', code: 'M-2025-008', name: '制动盘', type: '半成品', spec: 'BR-φ280mm', unit: '件', carrierId: 'CA-20250407-011', location: '长沙雨花物流园', quantity: 210, safetyStock: 100, staleThreshold: 35, lastInbound: '2025-04-23', lastOutbound: '2025-04-29', status: 'normal' },
  { id: 'M009', code: 'M-2025-009', name: '线束总成', type: '原材料', spec: 'WI-整车配套', unit: '套', carrierId: 'CA-20250408-029', location: '郑州经开仓库', quantity: 15, safetyStock: 25, staleThreshold: 20, lastInbound: '2025-04-01', lastOutbound: '2025-04-10', status: 'stale' },
  { id: 'M010', code: 'M-2025-010', name: '空调压缩机', type: '成品', spec: 'AC-12V涡旋', unit: '台', carrierId: 'CA-20250409-017', location: '深圳龙岗仓库', quantity: 60, safetyStock: 30, staleThreshold: 40, lastInbound: '2025-04-19', lastOutbound: '2025-04-28', status: 'normal' },
  { id: 'M011', code: 'M-2025-011', name: '燃油泵总成', type: '半成品', spec: 'FP-电子无刷', unit: '件', carrierId: 'CA-20250410-055', location: '天津滨海物流园', quantity: 42, safetyStock: 35, staleThreshold: 25, lastInbound: '2025-04-16', lastOutbound: '2025-04-24', status: 'normal' },
  { id: 'M012', code: 'M-2025-012', name: '转向节', type: '原材料', spec: 'KN-锻造合金', unit: '件', carrierId: 'CA-20250411-003', location: '青岛黄岛仓库', quantity: 95, safetyStock: 50, staleThreshold: 30, lastInbound: '2025-04-21', lastOutbound: '2025-04-29', status: 'normal' },
  { id: 'M013', code: 'M-2025-013', name: '排气管中段', type: '成品', spec: 'EX-不锈钢304', unit: '件', carrierId: 'CA-20250412-067', location: '无锡惠山网点', quantity: 8, safetyStock: 15, staleThreshold: 20, lastInbound: '2025-03-15', lastOutbound: '2025-03-25', status: 'stale' },
  { id: 'M014', code: 'M-2025-014', name: '离合器片', type: '半成品', spec: 'CL-φ240mm', unit: '片', carrierId: 'CA-20250413-022', location: '南京江宁仓库', quantity: 130, safetyStock: 60, staleThreshold: 35, lastInbound: '2025-04-24', lastOutbound: '2025-04-29', status: 'normal' },
  { id: 'M015', code: 'M-2025-015', name: '减震器', type: '成品', spec: 'SH-双筒液压', unit: '支', carrierId: 'CA-20250414-041', location: '杭州萧山物流园', quantity: 55, safetyStock: 30, staleThreshold: 28, lastInbound: '2025-04-17', lastOutbound: '2025-04-26', status: 'normal' },
];

const unbindRecords: UnbindRecord[] = [
  { id: 'UB001', time: '2025-04-29 09:30', operator: '张伟', carrierId: 'CA-20250401-001', materialCode: 'M-2025-001', materialName: '发动机支架', quantity: 30, reason: '到达卸货', site: '上海浦东仓库', transferNo: 'TB-20250428-0089' },
  { id: 'UB002', time: '2025-04-28 16:45', operator: '李强', carrierId: 'CA-20250402-032', materialCode: 'M-2025-003', materialName: '仪表盘总成', quantity: 12, reason: '更换载具', site: '宁波北仑物流园', transferNo: 'TB-20250427-0076' },
  { id: 'UB003', time: '2025-04-28 11:20', operator: '王芳', carrierId: 'CA-20250405-009', materialCode: 'M-2025-006', materialName: '前保险杠', quantity: 5, reason: '物料报废', site: '重庆两江仓库', transferNo: '-' },
  { id: 'UB004', time: '2025-04-27 14:00', operator: '赵磊', carrierId: 'CA-20250408-029', materialCode: 'M-2025-009', materialName: '线束总成', quantity: 8, reason: '到达卸货', site: '郑州经开仓库', transferNo: 'TB-20250426-0054' },
  { id: 'UB005', time: '2025-04-27 08:15', operator: '孙丽', carrierId: 'CA-20250410-055', materialCode: 'M-2025-011', materialName: '燃油泵总成', quantity: 20, reason: '到达卸货', site: '天津滨海物流园', transferNo: 'TB-20250425-0043' },
  { id: 'UB006', time: '2025-04-26 17:30', operator: '周杰', carrierId: 'CA-20250414-041', materialCode: 'M-2025-015', materialName: '减震器', quantity: 15, reason: '更换载具', site: '杭州萧山物流园', transferNo: '-' },
  { id: 'UB007', time: '2025-04-25 10:00', operator: '吴敏', carrierId: 'CA-20250401-015', materialCode: 'M-2025-002', materialName: '底盘加强板', quantity: 40, reason: '到达卸货', site: '苏州昆山工厂', transferNo: 'TB-20250424-0032' },
  { id: 'UB008', time: '2025-04-24 09:45', operator: '郑华', carrierId: 'CA-20250407-011', materialCode: 'M-2025-008', materialName: '制动盘', quantity: 50, reason: '到达卸货', site: '长沙雨花物流园', transferNo: 'TB-20250423-0021' },
  { id: 'UB009', time: '2025-04-23 15:20', operator: '陈静', carrierId: 'CA-20250412-067', materialCode: 'M-2025-013', materialName: '排气管中段', quantity: 10, reason: '物料报废', site: '无锡惠山网点', transferNo: '-' },
  { id: 'UB010', time: '2025-04-22 11:00', operator: '刘洋', carrierId: 'CA-20250406-044', materialCode: 'M-2025-007', materialName: '车窗玻璃', quantity: 20, reason: '到达卸货', site: '成都龙泉驿仓库', transferNo: 'TB-20250421-0010' },
];

const flowHistoryMock: FlowHistory[] = [
  { time: '2025-04-20 10:30', event: '绑定载具', carrier: 'CA-20250401-001', site: '上海浦东仓库', operator: '张伟' },
  { time: '2025-04-18 14:00', event: '解绑入库', carrier: 'CA-20250401-001', site: '上海浦东仓库', operator: '李强' },
  { time: '2025-04-15 09:00', event: '绑定载具', carrier: 'CA-20250328-015', site: '宁波北仑物流园', operator: '王芳' },
  { time: '2025-04-10 16:30', event: '调拨出库', carrier: 'CA-20250328-015', site: '宁波北仑物流园', operator: '赵磊' },
  { time: '2025-04-05 08:00', event: '采购入库', carrier: '-', site: '宁波北仑物流园', operator: '系统' },
];

const COLORS = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

function getStatusBadge(status: string) {
  switch (status) {
    case 'normal':
      return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">正常</Badge>;
    case 'stale':
      return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">呆滞</Badge>;
    case 'scrap':
      return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">报废</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

function getTypeBadge(type: string) {
  const colorMap: Record<string, string> = {
    原材料: 'bg-blue-100 text-blue-700',
    半成品: 'bg-purple-100 text-purple-700',
    成品: 'bg-green-100 text-green-700',
    辅料: 'bg-gray-100 text-gray-700',
  };
  return (
    <Badge className={cn(colorMap[type] || 'bg-gray-100 text-gray-700')}>
      {type}
    </Badge>
  );
}

export default function MaterialManagementPage() {
  const [activeTab, setActiveTab] = useState('materials');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const [reasonFilter, setReasonFilter] = useState('all');

  const filteredMaterials = useMemo(() => {
    return materials.filter((m) => {
      const matchSearch =
        search === '' ||
        m.code.toLowerCase().includes(search.toLowerCase()) ||
        m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.carrierId.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || m.status === statusFilter;
      const matchType = typeFilter === 'all' || m.type === typeFilter;
      return matchSearch && matchStatus && matchType;
    });
  }, [search, statusFilter, typeFilter]);

  const filteredUnbind = useMemo(() => {
    return unbindRecords.filter((r) => {
      return reasonFilter === 'all' || r.reason === reasonFilter;
    });
  }, [reasonFilter]);

  const chartData = useMemo(() => {
    const groups: Record<string, number> = {};
    materials.forEach((m) => {
      groups[m.type] = (groups[m.type] || 0) + m.quantity;
    });
    return Object.entries(groups).map(([type, quantity]) => ({ type, quantity }));
  }, []);

  const totalTypes = new Set(materials.map((m) => m.code)).size;
  const totalStock = materials.reduce((sum, m) => sum + m.quantity, 0);
  const staleCount = materials.filter((m) => m.status === 'stale').length;
  const lowStockCount = materials.filter((m) => m.quantity < m.safetyStock).length;
  const todayInOut = 47;

  const openDetail = (m: Material) => {
    setSelectedMaterial(m);
    setDetailOpen(true);
  };

  const exportData = () => {
    alert('正在导出物料数据...');
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">物料管理</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">
            物料绑定 · 库存追踪 · 解绑记录
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
            <Input
              placeholder="搜索物料编码/名称/载具..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 w-[260px]"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="全部状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="normal">正常</SelectItem>
              <SelectItem value="stale">呆滞</SelectItem>
              <SelectItem value="scrap">报废</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[130px]">
              <SelectValue placeholder="全部类型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部类型</SelectItem>
              <SelectItem value="原材料">原材料</SelectItem>
              <SelectItem value="半成品">半成品</SelectItem>
              <SelectItem value="成品">成品</SelectItem>
              <SelectItem value="辅料">辅料</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={exportData}>
            <Download className="w-4 h-4 mr-2" />导出
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '物料品种数', value: String(totalTypes), icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '总库存数', value: String(totalStock), icon: Boxes, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '呆滞物料', value: String(staleCount), icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '低库存预警', value: String(lowStockCount), icon: TrendingUp, color: 'text-red-600', bg: 'bg-red-50' },
          { label: '今日出入库', value: String(todayInOut), icon: ArrowUpDown, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', stat.bg)}>
                  <stat.icon className={cn('w-5 h-5', stat.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{stat.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{stat.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:w-[360px]">
          <TabsTrigger value="materials">物料列表</TabsTrigger>
          <TabsTrigger value="unbind">解绑记录</TabsTrigger>
        </TabsList>

        {/* Materials Tab */}
        <TabsContent value="materials" className="space-y-4">
          {/* Chart */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">各类型物料库存分布</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--neutral-border)" />
                    <XAxis dataKey="type" tick={{ fill: 'var(--neutral-text-secondary)', fontSize: 12 }} />
                    <YAxis tick={{ fill: 'var(--neutral-text-secondary)', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'var(--neutral-surface)',
                        borderColor: 'var(--neutral-border)',
                        color: 'var(--neutral-text-primary)',
                      }}
                    />
                    <Bar dataKey="quantity" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Table */}
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">物料编码</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">物料名称</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">规格</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">绑定载具</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">当前位置</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">库存</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">安全库存</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">最近入库</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMaterials.map((m) => (
                    <TableRow key={m.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{m.code}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{m.name}</TableCell>
                      <TableCell>{getTypeBadge(m.type)}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.spec}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.carrierId}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.location}</TableCell>
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{m.quantity}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.safetyStock}</TableCell>
                      <TableCell>{getStatusBadge(m.status)}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.lastInbound}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" onClick={() => openDetail(m)}>
                          查看详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Unbind Records Tab */}
        <TabsContent value="unbind" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-[var(--neutral-text-secondary)]">
              共 {filteredUnbind.length} 条解绑记录
            </div>
            <Select value={reasonFilter} onValueChange={setReasonFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="全部原因" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部原因</SelectItem>
                <SelectItem value="到达卸货">到达卸货</SelectItem>
                <SelectItem value="更换载具">更换载具</SelectItem>
                <SelectItem value="物料报废">物料报废</SelectItem>
                <SelectItem value="其他">其他</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">解绑编号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">解绑时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">操作人</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">原绑定载具</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">物料编码</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">物料名称</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">数量</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">解绑原因</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">解绑网点</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">关联调拨单</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUnbind.map((r) => (
                    <TableRow key={r.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{r.id}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.time}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.operator}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.carrierId}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.materialCode}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{r.materialName}</TableCell>
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{r.quantity}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{r.reason}</Badge>
                      </TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.site}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{r.transferNo}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>物料详情</DialogTitle>
          </DialogHeader>
          {selectedMaterial && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">物料编码</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedMaterial.code}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">物料名称</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedMaterial.name}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">类型</div>
                  <div className="mt-1">{getTypeBadge(selectedMaterial.type)}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">规格型号</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedMaterial.spec}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">绑定载具</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedMaterial.carrierId}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">当前位置</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedMaterial.location}</div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">库存数量 / 安全库存</div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">
                    {selectedMaterial.quantity} / {selectedMaterial.safetyStock}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">状态</div>
                  <div className="mt-1">{getStatusBadge(selectedMaterial.status)}</div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-[var(--neutral-text-primary)] mb-2 flex items-center gap-2">
                  <History className="w-4 h-4" /> 流转历史
                </h4>
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[var(--neutral-background)]">
                      <TableHead className="text-[var(--neutral-text-secondary)]">时间</TableHead>
                      <TableHead className="text-[var(--neutral-text-secondary)]">事件</TableHead>
                      <TableHead className="text-[var(--neutral-text-secondary)]">载具</TableHead>
                      <TableHead className="text-[var(--neutral-text-secondary)]">网点</TableHead>
                      <TableHead className="text-[var(--neutral-text-secondary)]">操作人</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {flowHistoryMock.map((f, idx) => (
                      <TableRow key={idx} className="hover:bg-[var(--neutral-background)]">
                        <TableCell className="text-[var(--neutral-text-secondary)]">{f.time}</TableCell>
                        <TableCell className="text-[var(--neutral-text-primary)]">{f.event}</TableCell>
                        <TableCell className="text-[var(--neutral-text-secondary)]">{f.carrier}</TableCell>
                        <TableCell className="text-[var(--neutral-text-secondary)]">{f.site}</TableCell>
                        <TableCell className="text-[var(--neutral-text-secondary)]">{f.operator}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
