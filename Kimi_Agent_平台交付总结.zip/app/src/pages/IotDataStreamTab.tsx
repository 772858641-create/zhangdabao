import { useState, useEffect, useRef, useCallback } from 'react';
import { Pause, Play, Activity, MessageSquare, Server, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface StreamMessage {
  id: string;
  timestamp: string;
  deviceId: string;
  topic: string;
  payload: string;
  size: number;
}

const TOPICS = ['telemetry', 'signal', 'alert', 'heartbeat'];
const DEVICE_IDS = ['DEV-001', 'DEV-002', 'DEV-003', 'DEV-004', 'DEV-005', 'DEV-006', 'DEV-007', 'DEV-008'];

function generateMockMessage(): StreamMessage {
  const topic = TOPICS[Math.floor(Math.random() * TOPICS.length)];
  const deviceId = DEVICE_IDS[Math.floor(Math.random() * DEVICE_IDS.length)];
  const now = new Date();
  let payload: Record<string, unknown> = {};

  switch (topic) {
    case 'telemetry':
      payload = {
        temp: +(20 + Math.random() * 30).toFixed(1),
        humidity: +(30 + Math.random() * 50).toFixed(1),
        lat: +(31.2 + Math.random() * 0.1).toFixed(6),
        lng: +(121.4 + Math.random() * 0.1).toFixed(6),
      };
      break;
    case 'signal':
      payload = { rssi: -(40 + Math.random() * 60).toFixed(0), snr: +(5 + Math.random() * 15).toFixed(1), band: 'LTE-B3' };
      break;
    case 'alert':
      payload = { type: ['over_temp', 'low_battery', 'geo_fence', 'shock'][Math.floor(Math.random() * 4)], level: 'warning', triggeredAt: now.toISOString() };
      break;
    case 'heartbeat':
      payload = { uptime: Math.floor(Math.random() * 86400), version: 'v2.1.4', freeMem: Math.floor(Math.random() * 1024) };
      break;
  }

  const payloadStr = JSON.stringify(payload);
  return {
    id: `${now.getTime()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: now.toISOString().slice(0, 19).replace('T', ' ') + '.' + String(now.getMilliseconds()).padStart(3, '0'),
    deviceId,
    topic: `devices/${deviceId}/${topic}`,
    payload: payloadStr,
    size: new Blob([payloadStr]).size,
  };
}

function getTopicBadgeColor(topic: string) {
  if (topic.includes('telemetry')) return 'bg-primary-light text-primary border-primary-border';
  if (topic.includes('signal')) return 'bg-info-light text-info border-info';
  if (topic.includes('alert')) return 'bg-danger-light text-danger border-danger';
  if (topic.includes('heartbeat')) return 'bg-warning-light text-warning border-warning';
  return 'bg-neutral-background text-neutral-textSecondary border-neutral-border';
}

export default function IotDataStreamTab() {
  const [messages, setMessages] = useState<StreamMessage[]>(() => {
    const initial: StreamMessage[] = [];
    for (let i = 0; i < 8; i++) {
      const msg = generateMockMessage();
      msg.timestamp = new Date(Date.now() - (8 - i) * 2000).toISOString().slice(0, 19).replace('T', ' ') + '.000';
      initial.push(msg);
    }
    return initial;
  });
  const [isPaused, setIsPaused] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const addMessage = useCallback(() => {
    setMessages((prev) => {
      const next = [...prev, generateMockMessage()];
      if (next.length > 50) next.shift();
      return next;
    });
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(addMessage, 2000);
    return () => clearInterval(interval);
  }, [isPaused, addMessage]);

  useEffect(() => {
    if (bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const msgRate = messages.length > 1
    ? (messages.length / ((new Date(messages[messages.length - 1].timestamp.slice(0, 19)).getTime() - new Date(messages[0].timestamp.slice(0, 19)).getTime()) / 1000 || 1)).toFixed(1)
    : '0.0';

  const uniqueDevices = new Set(messages.map((m) => m.deviceId)).size;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-primary-light flex items-center justify-center">
              <Activity size={18} className="text-primary" />
            </div>
            <div>
              <p className="text-xs text-neutral-textTertiary">消息速率</p>
              <p className="text-lg font-semibold text-neutral-textPrimary font-number">{msgRate} <span className="text-xs font-normal text-neutral-textSecondary">msg/s</span></p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-success-light flex items-center justify-center">
              <MessageSquare size={18} className="text-success" />
            </div>
            <div>
              <p className="text-xs text-neutral-textTertiary">今日总量</p>
              <p className="text-lg font-semibold text-neutral-textPrimary font-number">{messages.length.toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-info-light flex items-center justify-center">
              <Server size={18} className="text-info" />
            </div>
            <div>
              <p className="text-xs text-neutral-textTertiary">活跃设备</p>
              <p className="text-lg font-semibold text-neutral-textPrimary font-number">{uniqueDevices}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-neutral-surface border-neutral-border">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-warning-light flex items-center justify-center">
              <Clock size={18} className="text-warning" />
            </div>
            <div>
              <p className="text-xs text-neutral-textTertiary">队列长度</p>
              <p className="text-lg font-semibold text-neutral-textPrimary font-number">{messages.length}<span className="text-xs font-normal text-neutral-textSecondary"> / 50</span></p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stream Panel */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary">实时消息流</CardTitle>
          <Button
            size="sm"
            variant={isPaused ? 'default' : 'outline'}
            className="h-8 text-xs"
            onClick={() => setIsPaused((p) => !p)}
          >
            {isPaused ? <Play size={14} className="mr-1" /> : <Pause size={14} className="mr-1" />}
            {isPaused ? '继续' : '暂停'}
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <div className="bg-neutral-background rounded-md border border-neutral-border mx-6 mb-6">
            <ScrollArea className="h-[480px]" ref={scrollRef}>
              <div className="p-3 space-y-1 font-mono text-xs">
                {messages.map((msg) => (
                  <div key={msg.id} className="flex items-start gap-2 py-1 hover:bg-neutral-surface-elevated rounded px-1 transition-colors">
                    <span className="text-neutral-textTertiary whitespace-nowrap shrink-0">{msg.timestamp}</span>
                    <Badge variant="outline" className={cn('shrink-0 text-[10px] px-1.5 py-0 h-4', getTopicBadgeColor(msg.topic))}>
                      {msg.topic.split('/').pop()}
                    </Badge>
                    <span className="text-neutral-textSecondary whitespace-nowrap shrink-0">{msg.deviceId}</span>
                    <span className="text-neutral-textPrimary break-all">{msg.payload}</span>
                    <span className="text-neutral-textTertiary whitespace-nowrap shrink-0 ml-auto">{msg.size}B</span>
                  </div>
                ))}
                <div ref={bottomRef} />
              </div>
            </ScrollArea>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
