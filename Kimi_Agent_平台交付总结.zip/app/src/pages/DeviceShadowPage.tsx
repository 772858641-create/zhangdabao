import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronRight, Eye, Search, Radio, Wifi, WifiOff, Braces, FileJson } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DeviceShadow {
  id: string;
  deviceId: string;
  deviceName: string;
  deviceType: string;
  online: boolean;
  shadowVersion: number;
  lastUpdate: string;
  reported: Record<string, unknown>;
  desired: Record<string, unknown>;
  metadata: Record<string, unknown>;
}

interface AICorrectionLog {
  id: string;
  deviceId: string;
  deviceName: string;
  rawPosition: string;
  correctedPosition: string;
  confidence: string;
  correctionType: string;
  time: string;
  reason: string;
}

const deviceShadows: DeviceShadow[] = [
  {
    id: 'S001', deviceId: 'DEV-20250401-001', deviceName: '定位器-A001', deviceType: '定位器', online: true, shadowVersion: 128, lastUpdate: '2025-04-29 14:30:25',
    reported: { position: { lat: 31.2304, lng: 121.4737, source: 'GPS', accuracy: 12, timestamp: '2025-04-29T14:30:20Z' }, battery: { level: 78, voltage: 3.72, health: 'good' }, signal: { rssi: -68, network: '4G', operator: 'CMCC' }, temperature: 28.5, motion: 'moving', speed: 45.2 },
    desired: { position: { reportInterval: 300 }, battery: { lowPowerMode: false }, signal: { roaming: false }, config: { heartbeat: 600, sleepMode: 'auto' } },
    metadata: { position: { lastUpdated: '2025-04-29T14:30:20Z', version: 127 }, battery: { lastUpdated: '2025-04-29T14:28:10Z', version: 126 }, aiCorrected: { lat: 31.2305, lng: 121.4739, confidence: 0.94, method: 'GPS+基站+WiFi融合定位', reason: '高楼遮挡导致GPS漂移，AI纠偏后精度提升35%' } },
  },
  {
    id: 'S002', deviceId: 'DEV-20250401-015', deviceName: '定位器-A015', deviceType: '定位器', online: true, shadowVersion: 95, lastUpdate: '2025-04-29 14:28:10',
    reported: { position: { lat: 31.3804, lng: 120.9807, source: 'LBS', accuracy: 150, timestamp: '2025-04-29T14:28:05Z' }, battery: { level: 22, voltage: 3.45, health: 'low' }, signal: { rssi: -85, network: '2G', operator: 'CUCC' }, temperature: 32.1, motion: 'stationary', speed: 0 },
    desired: { position: { reportInterval: 60 }, battery: { lowPowerMode: true }, signal: { roaming: true }, config: { heartbeat: 300, sleepMode: 'disabled' } },
    metadata: { position: { lastUpdated: '2025-04-29T14:28:05Z', version: 94 }, battery: { lastUpdated: '2025-04-29T14:25:00Z', version: 93 }, aiCorrected: { lat: 31.3802, lng: 120.9809, confidence: 0.82, method: 'LBS+路网匹配', reason: '2G信号弱，AI通过路网约束修正定位偏差' } },
  },
  {
    id: 'S003', deviceId: 'DEV-20250402-032', deviceName: '固定网关-B032', deviceType: '固定网关', online: true, shadowVersion: 256, lastUpdate: '2025-04-29 14:29:45',
    reported: { status: 'online', scannedTags: 48, lastScan: '2025-04-29T14:29:40Z', temperature: 26.3, cpuUsage: 12, memoryUsage: 45, uptime: '72h30m' },
    desired: { scanInterval: 90, tagFilter: ['CA-2025*'], power: { transmit: 20, sensitivity: -75 }, network: { dhcp: true, staticIP: null } },
    metadata: { status: { lastUpdated: '2025-04-29T14:29:40Z', version: 255 }, scannedTags: { lastUpdated: '2025-04-29T14:29:40Z', version: 255 }, aiCorrected: { scanAccuracy: 0.97, tagMissingWarning: 2, method: '多周期扫描去噪', reason: 'AI检测到2个标签信号异常弱，疑似标签脱落' } },
  },
  {
    id: 'S004', deviceId: 'DEV-20250403-008', deviceName: '车载网关-C008', deviceType: '车载网关', online: false, shadowVersion: 312, lastUpdate: '2025-04-29 12:15:30',
    reported: { position: { lat: 30.5904, lng: 114.3107, source: 'GPS', accuracy: 8, timestamp: '2025-04-29T12:15:25Z' }, battery: { level: 92, voltage: 12.4, health: 'good' }, vehicle: { vin: 'LGWEF4A55LF123456', speed: 80, heading: 135, odometer: 128500 }, temperature: 35.2, motion: 'moving' },
    desired: { position: { reportInterval: 60 }, vehicle: { speedLimit: 120, geofenceEnabled: true }, config: { heartbeat: 300, dataUpload: 'realtime' } },
    metadata: { position: { lastUpdated: '2025-04-29T12:15:25Z', version: 311 }, vehicle: { lastUpdated: '2025-04-29T12:15:20Z', version: 310 }, aiCorrected: { lat: 30.5905, lng: 114.3108, confidence: 0.91, method: 'GPS+IMU+车速融合', reason: '隧道内GPS信号丢失，AI通过IMU惯性导航和车速推算修正位置' } },
  },
  {
    id: 'S005', deviceId: 'DEV-20250404-021', deviceName: '标签-D021', deviceType: '标签', online: true, shadowVersion: 45, lastUpdate: '2025-04-29 14:27:55',
    reported: { proximity: { gatewayId: 'DEV-20250402-032', rssi: -52, distance: 2.3 }, battery: { level: 65, voltage: 2.85, health: 'good' }, temperature: 25.8, motion: 'stationary' },
    desired: { broadcastInterval: 500, powerLevel: 'medium', config: { encryption: true, pairingMode: false } },
    metadata: { proximity: { lastUpdated: '2025-04-29T14:27:55Z', version: 44 }, battery: { lastUpdated: '2025-04-29T14:20:00Z', version: 43 }, aiCorrected: { rssi: -50, distance: 2.1, confidence: 0.88, method: 'RSSI衰减模型+环境补偿', reason: '金属货架导致信号衰减，AI补偿后距离估算更准确' } },
  },
  {
    id: 'S006', deviceId: 'DEV-20250405-009', deviceName: '信标-E009', deviceType: '信标', online: true, shadowVersion: 67, lastUpdate: '2025-04-29 14:26:40',
    reported: { zone: 'A区-货架03', scannedBy: ['DEV-20250402-032', 'DEV-20250402-033'], battery: { level: 45, voltage: 2.72, health: 'medium' }, temperature: 24.5, transmitPower: -4, uptime: '168h' },
    desired: { transmitPower: -4, broadcastInterval: 1000, config: { iBeacon: { major: 10001, minor: 3009 } } },
    metadata: { zone: { lastUpdated: '2025-04-29T14:26:40Z', version: 66 }, battery: { lastUpdated: '2025-04-29T14:00:00Z', version: 65 }, aiCorrected: { zone: 'A区-货架03（置信度92%）', confidence: 0.92, method: '多网关三角定位', reason: 'AI通过3个网关的信号强度交叉验证，确认信标位置在A区-货架03' } },
  },
  {
    id: 'S007', deviceId: 'DEV-20250406-044', deviceName: '定位器-A044', deviceType: '定位器', online: true, shadowVersion: 178, lastUpdate: '2025-04-29 14:30:00',
    reported: { position: { lat: 29.9189, lng: 121.8458, source: 'GPS', accuracy: 6, timestamp: '2025-04-29T14:29:55Z' }, battery: { level: 55, voltage: 3.62, health: 'good' }, signal: { rssi: -62, network: '5G', operator: 'CMCC' }, temperature: 26.8, motion: 'moving', speed: 60.5 },
    desired: { position: { reportInterval: 300 }, battery: { lowPowerMode: false }, config: { heartbeat: 600, sleepMode: 'auto' } },
    metadata: { position: { lastUpdated: '2025-04-29T14:29:55Z', version: 177 }, aiCorrected: { lat: 29.9190, lng: 121.8459, confidence: 0.96, method: 'GPS+5G基站+北斗融合', reason: '5G高精度定位辅助，AI融合北斗数据，定位精度达亚米级' } },
  },
  {
    id: 'S008', deviceId: 'DEV-20250407-011', deviceName: '车载网关-C011', deviceType: '车载网关', online: true, shadowVersion: 198, lastUpdate: '2025-04-29 14:28:30',
    reported: { position: { lat: 30.6204, lng: 114.1458, source: 'GPS', accuracy: 10, timestamp: '2025-04-29T14:28:25Z' }, vehicle: { vin: 'LGWEF4A55LF654321', speed: 45, heading: 270, odometer: 85600 }, temperature: 33.5, motion: 'moving' },
    desired: { position: { reportInterval: 120 }, vehicle: { speedLimit: 100, geofenceEnabled: true }, config: { heartbeat: 300 } },
    metadata: { position: { lastUpdated: '2025-04-29T14:28:25Z', version: 197 }, aiCorrected: { lat: 30.6203, lng: 114.1459, confidence: 0.89, method: 'GPS+地图匹配', reason: '车辆在高架桥下行驶，GPS信号受遮挡，AI通过地图路网匹配修正位置' } },
  },
];

const aiLogs: AICorrectionLog[] = [
  { id: 'AC001', deviceId: 'DEV-20250401-001', deviceName: '定位器-A001', rawPosition: '31.2301, 121.4732', correctedPosition: '31.2304, 121.4737', confidence: '94%', correctionType: '多源融合', time: '2025-04-29 14:30:20', reason: '高楼遮挡导致GPS漂移，融合基站和WiFi数据后精度提升35%' },
  { id: 'AC002', deviceId: 'DEV-20250401-015', deviceName: '定位器-A015', rawPosition: '31.3810, 120.9795', correctedPosition: '31.3802, 120.9809', confidence: '82%', correctionType: '路网匹配', time: '2025-04-29 14:28:05', reason: '2G信号弱，定位精度差，通过路网约束修正到最近道路上' },
  { id: 'AC003', deviceId: 'DEV-20250403-008', deviceName: '车载网关-C008', rawPosition: '30.5900, 114.3100', correctedPosition: '30.5905, 114.3108', confidence: '91%', correctionType: '惯性导航', time: '2025-04-29 12:15:25', reason: '隧道内GPS信号丢失，通过IMU+车速推算位置' },
  { id: 'AC004', deviceId: 'DEV-20250404-021', deviceName: '标签-D021', rawPosition: 'RSSI: -58, Est: 3.2m', correctedPosition: 'RSSI: -50, Est: 2.1m', confidence: '88%', correctionType: '环境补偿', time: '2025-04-29 14:27:55', reason: '金属货架导致信号衰减，环境补偿模型修正距离估算' },
  { id: 'AC005', deviceId: 'DEV-20250405-009', deviceName: '信标-E009', rawPosition: 'A区-货架02（单网关定位）', correctedPosition: 'A区-货架03（三角定位）', confidence: '92%', correctionType: '三角定位', time: '2025-04-29 14:26:40', reason: '多网关信号交叉验证后修正到正确货架位置' },
  { id: 'AC006', deviceId: 'DEV-20250406-044', deviceName: '定位器-A044', rawPosition: '29.9185, 121.8450', correctedPosition: '29.9190, 121.8459', confidence: '96%', correctionType: '多源融合', time: '2025-04-29 14:30:00', reason: '5G+北斗+GPS三模融合，亚米级精度定位' },
  { id: 'AC007', deviceId: 'DEV-20250407-011', deviceName: '车载网关-C011', rawPosition: '30.6210, 114.1445', correctedPosition: '30.6203, 114.1459', confidence: '89%', correctionType: '地图匹配', time: '2025-04-29 14:28:25', reason: '高架桥下GPS受遮挡，通过地图路网匹配修正' },
];

function JsonTree({ data, level = 0 }: { data: unknown; level?: number }) {
  if (data === null) return <span className="text-gray-400">null</span>;
  if (typeof data === 'string') return <span className="text-emerald-600">"{data}"</span>;
  if (typeof data === 'number') return <span className="text-blue-600">{data}</span>;
  if (typeof data === 'boolean') return <span className="text-purple-600">{String(data)}</span>;
  if (Array.isArray(data)) {
    return (
      <span className="text-[var(--neutral-text-primary)]">
        [{data.length} items]
      </span>
    );
  }
  if (typeof data === 'object') {
    const entries = Object.entries(data as Record<string, unknown>);
    return (
      <div className="space-y-0.5">
        {entries.map(([key, val]) => (
          <div key={key} className={cn("flex items-start gap-1", level > 0 && "pl-4 border-l border-[var(--neutral-border)]")}>
            <span className="text-amber-600 shrink-0">{key}:</span>
            <div className="text-sm">
              <JsonTree data={val} level={level + 1} />
            </div>
          </div>
        ))}
      </div>
    );
  }
  return <span>{String(data)}</span>;
}

export default function DeviceShadowPage() {
  const [search, setSearch] = useState('');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedShadow, setSelectedShadow] = useState<DeviceShadow | null>(null);
  const [activeTab, setActiveTab] = useState('list');
  const [typeFilter, setTypeFilter] = useState('all');

  const filtered = useMemo(() => {
    return deviceShadows.filter(s => {
      const matchSearch = s.deviceName.toLowerCase().includes(search.toLowerCase()) || s.deviceId.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === 'all' || s.deviceType === typeFilter;
      return matchSearch && matchType;
    });
  }, [search, typeFilter]);

  const stats = useMemo(() => ({
    total: deviceShadows.length,
    online: deviceShadows.filter(s => s.online).length,
    offline: deviceShadows.filter(s => !s.online).length,
    avgVersion: Math.round(deviceShadows.reduce((sum, s) => sum + s.shadowVersion, 0) / deviceShadows.length),
    aiCorrections: aiLogs.length,
  }), []);

  const openDetail = (shadow: DeviceShadow) => {
    setSelectedShadow(shadow);
    setDetailOpen(true);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">设备影子</h1>
        <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">Reported · Desired · Metadata · AI纠偏</p>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '影子总数', value: stats.total, icon: Braces, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '在线设备', value: stats.online, icon: Wifi, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '离线设备', value: stats.offline, icon: WifiOff, color: 'text-gray-600', bg: 'bg-gray-50' },
          { label: '平均版本', value: stats.avgVersion, icon: FileJson, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'AI纠偏', value: stats.aiCorrections, icon: Radio, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-2 lg:w-[240px]">
          <TabsTrigger value="list">设备影子</TabsTrigger>
          <TabsTrigger value="ai">AI纠偏日志</TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索设备..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[130px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部类型</SelectItem>
                <SelectItem value="定位器">定位器</SelectItem>
                <SelectItem value="固定网关">固定网关</SelectItem>
                <SelectItem value="车载网关">车载网关</SelectItem>
                <SelectItem value="标签">标签</SelectItem>
                <SelectItem value="信标">信标</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">设备</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">影子版本</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">上次更新</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">Reported摘要</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">AI纠偏</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(s => (
                    <TableRow key={s.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell>
                        <div className="font-medium text-[var(--neutral-text-primary)]">{s.deviceName}</div>
                        <div className="text-xs text-[var(--neutral-text-tertiary)]">{s.deviceId}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline">{s.deviceType}</Badge></TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {s.online ? <Wifi className="w-3 h-3 text-emerald-500" /> : <WifiOff className="w-3 h-3 text-gray-400" />}
                          <span className={s.online ? 'text-emerald-600' : 'text-gray-400'}>{s.online ? '在线' : '离线'}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)] font-medium">v{s.shadowVersion}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{s.lastUpdate}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs max-w-[200px] truncate">
                        {'position' in s.reported ? `位置: ${(s.reported.position as Record<string, unknown>)?.lat}, ${(s.reported.position as Record<string, unknown>)?.lng}` : `状态: ${s.reported.status}`}
                      </TableCell>
                      <TableCell>
                        {'aiCorrected' in s.metadata ? (
                          <Badge className="bg-blue-100 text-blue-700">{(s.metadata.aiCorrected as Record<string, unknown>)?.confidence as string}% 置信度</Badge>
                        ) : <span className="text-[var(--neutral-text-tertiary)]">-</span>}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-7" onClick={() => openDetail(s)}>
                          <Eye className="w-3 h-3 mr-1" />查看影子
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">设备</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">原始位置</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">AI纠偏后</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">置信度</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">纠偏类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">纠偏原因</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {aiLogs.map(log => (
                    <TableRow key={log.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell>
                        <div className="font-medium text-[var(--neutral-text-primary)]">{log.deviceName}</div>
                        <div className="text-xs text-[var(--neutral-text-tertiary)]">{log.deviceId}</div>
                      </TableCell>
                      <TableCell className="text-red-500 text-xs max-w-[150px] truncate">{log.rawPosition}</TableCell>
                      <TableCell className="text-emerald-600 text-xs max-w-[150px] truncate font-medium">{log.correctedPosition}</TableCell>
                      <TableCell><Badge className="bg-blue-100 text-blue-700">{log.confidence}</Badge></TableCell>
                      <TableCell><Badge variant="outline">{log.correctionType}</Badge></TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{log.time}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs max-w-[200px] truncate">{log.reason}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Shadow Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-auto">
          <DialogHeader><DialogTitle>设备影子详情</DialogTitle></DialogHeader>
          {selectedShadow && (
            <div className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-[var(--neutral-text-primary)]">{selectedShadow.deviceName}</span>
                  <Badge variant="outline">{selectedShadow.deviceType}</Badge>
                  {selectedShadow.online ? <Badge className="bg-emerald-100 text-emerald-700">在线</Badge> : <Badge className="bg-gray-100 text-gray-700">离线</Badge>}
                </div>
                <span className="text-xs text-[var(--neutral-text-tertiary)]">版本 v{selectedShadow.shadowVersion} · 更新于 {selectedShadow.lastUpdate}</span>
              </div>

              {/* AI Corrected */}
              {'aiCorrected' in selectedShadow.metadata && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <div className="text-xs text-blue-600 mb-1 font-medium">AI纠偏信息</div>
                  <div className="text-sm text-blue-800">
                    方法：{(selectedShadow.metadata.aiCorrected as Record<string, unknown>).method as string} · 置信度：{(selectedShadow.metadata.aiCorrected as Record<string, unknown>).confidence as string}<br/>
                    原因：{(selectedShadow.metadata.aiCorrected as Record<string, unknown>).reason as string}
                  </div>
                </div>
              )}

              {/* Three layers */}
              <div className="grid grid-cols-3 gap-3">
                <div className="border border-[var(--neutral-border)] rounded-lg p-3">
                  <div className="flex items-center gap-1 mb-2">
                    <Radio className="w-3 h-3 text-emerald-500" />
                    <span className="text-xs font-medium text-[var(--neutral-text-primary)]">Reported（设备上报）</span>
                  </div>
                  <div className="text-xs text-[var(--neutral-text-primary)]">
                    <JsonTree data={selectedShadow.reported} />
                  </div>
                </div>
                <div className="border border-[var(--neutral-border)] rounded-lg p-3">
                  <div className="flex items-center gap-1 mb-2">
                    <ChevronRight className="w-3 h-3 text-blue-500" />
                    <span className="text-xs font-medium text-[var(--neutral-text-primary)]">Desired（云端期望）</span>
                  </div>
                  <div className="text-xs text-[var(--neutral-text-primary)]">
                    <JsonTree data={selectedShadow.desired} />
                  </div>
                </div>
                <div className="border border-[var(--neutral-border)] rounded-lg p-3">
                  <div className="flex items-center gap-1 mb-2">
                    <Braces className="w-3 h-3 text-purple-500" />
                    <span className="text-xs font-medium text-[var(--neutral-text-primary)]">Metadata（元数据）</span>
                  </div>
                  <div className="text-xs text-[var(--neutral-text-primary)]">
                    <JsonTree data={selectedShadow.metadata} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
