import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Box,
  Search,
  Plus,
  Eye,
  Copy,
  Trash2,
  Hash,
  Gauge,
  Command,
  Factory,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import {
  type ThingModel,
  thingModels,
  getDeviceTypeIcon,
  getStatusBadge,
} from './types';

interface ThingModelListProps {
  selectedModel: ThingModel | null;
  onSelectModel: (model: ThingModel) => void;
  onCopyModel: (model: ThingModel) => void;
  onDeprecateModel: (model: ThingModel) => void;
}

export default function ThingModelList({
  selectedModel,
  onSelectModel,
  onCopyModel,
  onDeprecateModel,
}: ThingModelListProps) {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('全部');
  const [statusFilter, setStatusFilter] = useState<string>('全部');

  const typeOptions = ['全部', '定位器', '网关', '标签', '信标'];
  const statusOptions = ['全部', '已发布', '草稿', '已废弃'];

  const filteredModels = useMemo(() => {
    return thingModels.filter((m) => {
      const matchSearch =
        !search.trim() ||
        m.id.toLowerCase().includes(search.toLowerCase()) ||
        m.name.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === '全部' || m.deviceType === typeFilter;
      const matchStatus = statusFilter === '全部' || m.status === statusFilter;
      return matchSearch && matchType && matchStatus;
    });
  }, [search, typeFilter, statusFilter]);

  return (
    <div className="w-full flex flex-col min-h-0 gap-4">
      {/* ─── Top Bar: Search & Filters ─── */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-3 items-start lg:items-center">
            <div className="relative flex-1 w-full lg:w-auto">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
              <Input
                placeholder="搜索物模型ID或名称..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 h-9 bg-neutral-background border-neutral-border w-full"
              />
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
                {typeOptions.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTypeFilter(t)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      typeFilter === t
                        ? 'bg-primary text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-1 bg-neutral-background rounded-md border border-neutral-border px-2 h-9">
                {statusOptions.map((s) => (
                  <button
                    key={s}
                    onClick={() => setStatusFilter(s)}
                    className={cn(
                      'px-2.5 py-1 text-xs rounded transition-colors',
                      statusFilter === s
                        ? 'bg-primary text-white'
                        : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <Button size="sm" className="h-9 text-xs ml-auto">
              <Plus size={14} className="mr-1" />
              新增物模型
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* ─── Table ─── */}
      <Card className="bg-neutral-surface border-neutral-border flex-1 overflow-hidden flex flex-col">
        <CardHeader className="pb-2 flex-shrink-0">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Box size={16} className="text-primary" />
            物模型列表
            <span className="text-xs font-normal text-neutral-textTertiary ml-1">
              (共 {filteredModels.length} 条)
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-1 overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-neutral-surface z-10">
              <tr className="border-b border-neutral-border">
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-4 py-2.5">物模型ID</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">模型名称</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">设备类型</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">版本</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Hash size={11} />属性
                  </div>
                </th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Gauge size={11} />遥测
                  </div>
                </th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Command size={11} />命令
                  </div>
                </th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <Factory size={11} />适配
                  </div>
                </th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">状态</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">创建时间</th>
                <th className="text-left text-xs text-neutral-textSecondary font-medium px-3 py-2.5">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredModels.map((model) => (
                <motion.tr
                  key={model.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={cn(
                    'border-b border-neutral-border cursor-pointer transition-colors',
                    selectedModel?.id === model.id
                      ? 'bg-primary/5 hover:bg-primary/10'
                      : 'hover:bg-neutral-background'
                  )}
                  onClick={() => onSelectModel(model)}
                >
                  <td className="px-4 py-2.5">
                    <span className="text-xs font-mono text-neutral-textPrimary">{model.id}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textPrimary font-medium">{model.name}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1.5">
                      {getDeviceTypeIcon(model.deviceType)}
                      <span className="text-xs text-neutral-textSecondary">{model.deviceType}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs font-mono text-primary">{model.version}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textSecondary">{model.propertyCount}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textSecondary">{model.telemetryCount}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textSecondary">{model.commandCount}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textSecondary">{model.vendorAdapterCount}</span>
                  </td>
                  <td className="px-3 py-2.5">{getStatusBadge(model.status)}</td>
                  <td className="px-3 py-2.5">
                    <span className="text-xs text-neutral-textTertiary">{model.createdAt.split(' ')[0]}</span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-0.5">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 w-7 p-0 text-primary"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectModel(model);
                        }}
                        title="查看"
                      >
                        <Eye size={13} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 w-7 p-0 text-neutral-textSecondary"
                        onClick={(e) => {
                          e.stopPropagation();
                          onCopyModel(model);
                        }}
                        title="复制"
                      >
                        <Copy size={13} />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 w-7 p-0 text-danger"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeprecateModel(model);
                        }}
                        title="废弃"
                      >
                        <Trash2 size={13} />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
          {filteredModels.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-neutral-textTertiary">
              <Box size={40} className="mb-3 opacity-30" />
              <p className="text-sm">暂无匹配的物模型</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
