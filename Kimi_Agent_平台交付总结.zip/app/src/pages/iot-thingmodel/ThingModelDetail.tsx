import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Settings2,
  Gauge,
  Command,
  Bell,
  Factory,
  ChevronRight,
  Clock,
  X,
  History,
  ArrowRight,
} from 'lucide-react';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import {
  type ThingModel,
  type ThingProperty,
  type ThingTelemetry,
  type ThingCommand,
  type ThingEvent,
  type VendorAdapter,
  getDeviceTypeIcon,
  getDataTypeBadge,
  getAccessModeBadge,
  getStatusBadge,
  getEventLevelBadge,
} from './types';

interface ThingModelDetailProps {
  model: ThingModel;
  onClose: () => void;
  onOpenVersionDialog: () => void;
}

export default function ThingModelDetail({ model, onClose, onOpenVersionDialog }: ThingModelDetailProps) {
  const [activeDetailTab, setActiveDetailTab] = useState('properties');
  const [expandedVendor, setExpandedVendor] = useState<string | null>(null);

  return (
    <motion.div
      key={model.id}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.2 }}
      className="h-full"
    >
      <Card className="bg-neutral-surface border-neutral-border h-full flex flex-col">
        {/* Detail Header */}
        <CardHeader className="pb-2 flex-shrink-0 border-b border-neutral-border">
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2 mb-1">
                {getDeviceTypeIcon(model.deviceType)}
                {model.name}
                {getStatusBadge(model.status)}
              </CardTitle>
              <p className="text-xs text-neutral-textTertiary font-mono">{model.id}</p>
              <p className="text-xs text-neutral-textSecondary mt-1 line-clamp-2">{model.description}</p>
            </div>
            <div className="flex items-center gap-1 ml-2 flex-shrink-0">
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs text-neutral-textSecondary"
                onClick={onOpenVersionDialog}
              >
                <History size={13} className="mr-1" />
                版本
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 w-7 p-0 text-neutral-textSecondary"
                onClick={onClose}
              >
                <X size={14} />
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-2 px-4 py-3 border-b border-neutral-border flex-shrink-0">
          <div className="bg-neutral-background rounded-md p-2 text-center border border-neutral-border">
            <div className="text-lg font-semibold text-neutral-textPrimary">{model.propertyCount}</div>
            <div className="text-[10px] text-neutral-textTertiary">属性</div>
          </div>
          <div className="bg-neutral-background rounded-md p-2 text-center border border-neutral-border">
            <div className="text-lg font-semibold text-neutral-textPrimary">{model.telemetryCount}</div>
            <div className="text-[10px] text-neutral-textTertiary">遥测</div>
          </div>
          <div className="bg-neutral-background rounded-md p-2 text-center border border-neutral-border">
            <div className="text-lg font-semibold text-neutral-textPrimary">{model.commandCount}</div>
            <div className="text-[10px] text-neutral-textTertiary">命令</div>
          </div>
          <div className="bg-neutral-background rounded-md p-2 text-center border border-neutral-border">
            <div className="text-lg font-semibold text-neutral-textPrimary">{model.vendorAdapterCount}</div>
            <div className="text-[10px] text-neutral-textTertiary">适配</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
          <Tabs value={activeDetailTab} onValueChange={setActiveDetailTab} className="flex flex-col h-full">
            <TabsList className="w-full rounded-none bg-neutral-background border-b border-neutral-border px-2 pt-1 h-9 flex-shrink-0 gap-0">
              <TabsTrigger value="properties" className="text-xs data-[state=active]:bg-neutral-surface rounded-b-none px-3">
                <Settings2 size={12} className="mr-1" />
                属性
              </TabsTrigger>
              <TabsTrigger value="telemetry" className="text-xs data-[state=active]:bg-neutral-surface rounded-b-none px-3">
                <Gauge size={12} className="mr-1" />
                遥测
              </TabsTrigger>
              <TabsTrigger value="commands" className="text-xs data-[state=active]:bg-neutral-surface rounded-b-none px-3">
                <Command size={12} className="mr-1" />
                命令
              </TabsTrigger>
              <TabsTrigger value="events" className="text-xs data-[state=active]:bg-neutral-surface rounded-b-none px-3">
                <Bell size={12} className="mr-1" />
                事件
              </TabsTrigger>
              <TabsTrigger value="vendor" className="text-xs data-[state=active]:bg-neutral-surface rounded-b-none px-3">
                <Factory size={12} className="mr-1" />
                适配
              </TabsTrigger>
            </TabsList>

            <TabsContent value="properties" className="flex-1 overflow-auto mt-0 p-0">
              <PropertiesTab properties={model.properties} />
            </TabsContent>
            <TabsContent value="telemetry" className="flex-1 overflow-auto mt-0 p-0">
              <TelemetryTab telemetries={model.telemetries} />
            </TabsContent>
            <TabsContent value="commands" className="flex-1 overflow-auto mt-0 p-0">
              <CommandsTab commands={model.commands} />
            </TabsContent>
            <TabsContent value="events" className="flex-1 overflow-auto mt-0 p-0">
              <EventsTab events={model.events} />
            </TabsContent>
            <TabsContent value="vendor" className="flex-1 overflow-auto mt-0 p-0">
              <VendorTab
                adapters={model.vendorAdapters}
                expandedVendor={expandedVendor}
                onToggleVendor={(name) => setExpandedVendor(expandedVendor === name ? null : name)}
              />
            </TabsContent>
          </Tabs>
        </div>
      </Card>
    </motion.div>
  );
}

function PropertiesTab({ properties }: { properties: ThingProperty[] }) {
  return (
    <div className="p-3">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-neutral-border">
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">属性名</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">标识符</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">类型</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">权限</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5">描述</th>
          </tr>
        </thead>
        <tbody>
          {properties.map((prop) => (
            <tr key={prop.identifier} className="border-b border-neutral-border/50 hover:bg-neutral-background/50">
              <td className="py-2 pr-2">
                <span className="text-xs font-medium text-neutral-textPrimary">{prop.name}</span>
              </td>
              <td className="py-2 pr-2">
                <span className="text-[10px] font-mono text-neutral-textTertiary">{prop.identifier}</span>
              </td>
              <td className="py-2 pr-2">{getDataTypeBadge(prop.dataType)}</td>
              <td className="py-2 pr-2">{getAccessModeBadge(prop.accessMode)}</td>
              <td className="py-2">
                <span className="text-[10px] text-neutral-textTertiary">{prop.description}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function TelemetryTab({ telemetries }: { telemetries: ThingTelemetry[] }) {
  return (
    <div className="p-3">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-neutral-border">
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">遥测名</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">标识符</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">类型</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">频率</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5">描述</th>
          </tr>
        </thead>
        <tbody>
          {telemetries.map((tel) => (
            <tr key={tel.identifier} className="border-b border-neutral-border/50 hover:bg-neutral-background/50">
              <td className="py-2 pr-2">
                <span className="text-xs font-medium text-neutral-textPrimary">{tel.name}</span>
                {tel.unit && <span className="text-[10px] text-neutral-textTertiary ml-1">({tel.unit})</span>}
              </td>
              <td className="py-2 pr-2">
                <span className="text-[10px] font-mono text-neutral-textTertiary">{tel.identifier}</span>
              </td>
              <td className="py-2 pr-2">{getDataTypeBadge(tel.dataType)}</td>
              <td className="py-2 pr-2">
                <span className="text-[10px] text-neutral-textSecondary flex items-center gap-1">
                  <Clock size={10} />
                  {tel.frequency}
                </span>
              </td>
              <td className="py-2">
                <span className="text-[10px] text-neutral-textTertiary">{tel.description}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CommandsTab({ commands }: { commands: ThingCommand[] }) {
  return (
    <div className="p-3 space-y-3">
      {commands.map((cmd) => (
        <div key={cmd.identifier} className="border border-neutral-border rounded-lg p-3 bg-neutral-background">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Command size={13} className="text-primary" />
              <span className="text-xs font-semibold text-neutral-textPrimary">{cmd.name}</span>
              <span className="text-[10px] font-mono text-neutral-textTertiary bg-neutral-surface px-1.5 py-0.5 rounded border border-neutral-border">
                {cmd.identifier}
              </span>
            </div>
            <span className="text-[10px] text-neutral-textTertiary flex items-center gap-1">
              <Clock size={10} />
              {cmd.timeout}s
            </span>
          </div>
          <p className="text-[10px] text-neutral-textSecondary mb-2">{cmd.description}</p>
          {cmd.params.length > 0 && (
            <div className="mt-2">
              <span className="text-[10px] text-neutral-textTertiary font-medium">参数列表:</span>
              <div className="mt-1 space-y-1">
                {cmd.params.map((param, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-[10px] px-2 py-1 bg-neutral-surface rounded border border-neutral-border">
                    <span className="font-mono text-neutral-textPrimary">{param.name}</span>
                    {getDataTypeBadge(param.dataType)}
                    {param.required && <Badge variant="outline" className="text-[8px] h-4 border-danger text-danger">必填</Badge>}
                    <span className="text-neutral-textTertiary">{param.description}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function EventsTab({ events }: { events: ThingEvent[] }) {
  return (
    <div className="p-3">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-neutral-border">
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">事件名</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">标识符</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5 pr-2">类型</th>
            <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1.5">描述</th>
          </tr>
        </thead>
        <tbody>
          {events.map((evt) => (
            <tr key={evt.identifier} className="border-b border-neutral-border/50 hover:bg-neutral-background/50">
              <td className="py-2 pr-2">
                <div className="flex items-center gap-1.5">
                  <Bell size={11} className="text-warning" />
                  <span className="text-xs font-medium text-neutral-textPrimary">{evt.name}</span>
                </div>
              </td>
              <td className="py-2 pr-2">
                <span className="text-[10px] font-mono text-neutral-textTertiary">{evt.identifier}</span>
              </td>
              <td className="py-2 pr-2">{getEventLevelBadge(evt.level)}</td>
              <td className="py-2">
                <span className="text-[10px] text-neutral-textTertiary">{evt.description}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function VendorTab({
  adapters,
  expandedVendor,
  onToggleVendor,
}: {
  adapters: VendorAdapter[];
  expandedVendor: string | null;
  onToggleVendor: (name: string) => void;
}) {
  return (
    <div className="p-3 space-y-2">
      {adapters.map((adapter) => (
        <div key={adapter.vendorName} className="border border-neutral-border rounded-lg bg-neutral-background overflow-hidden">
          <div
            className="flex items-center justify-between p-3 cursor-pointer hover:bg-neutral-surface transition-colors"
            onClick={() => onToggleVendor(adapter.vendorName)}
          >
            <div className="flex items-center gap-2">
              <Factory size={13} className={adapter.status === 'active' ? 'text-primary' : 'text-neutral-textTertiary'} />
              <span className="text-xs font-medium text-neutral-textPrimary">{adapter.vendorName}</span>
              <Badge
                variant="outline"
                className={cn(
                  'text-[10px] h-5',
                  adapter.status === 'active'
                    ? 'border-success text-success bg-success-light'
                    : 'border-neutral-border text-neutral-textTertiary'
                )}
              >
                {adapter.status === 'active' ? '启用' : '停用'}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-neutral-textTertiary">{adapter.mappingCount} 条映射</span>
              <ChevronRight
                size={12}
                className={cn(
                  'text-neutral-textTertiary transition-transform',
                  expandedVendor === adapter.vendorName && 'rotate-90'
                )}
              />
            </div>
          </div>
          <AnimatePresence>
            {expandedVendor === adapter.vendorName && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="px-3 pb-3 border-t border-neutral-border">
                  <table className="w-full mt-2">
                    <thead>
                      <tr className="border-b border-neutral-border">
                        <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1 pr-2">原始字段</th>
                        <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1 pr-1"></th>
                        <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1 pr-2">标准字段</th>
                        <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1 pr-2">类型转换</th>
                        <th className="text-left text-[10px] text-neutral-textTertiary font-medium py-1">换算公式</th>
                      </tr>
                    </thead>
                    <tbody>
                      {adapter.mappings.map((map, idx) => (
                        <tr key={idx} className="border-b border-neutral-border/40">
                          <td className="py-1.5 pr-2">
                            <span className="text-[10px] font-mono text-danger">{map.originalField}</span>
                          </td>
                          <td className="py-1.5 pr-1">
                            <ArrowRight size={10} className="text-neutral-textTertiary" />
                          </td>
                          <td className="py-1.5 pr-2">
                            <span className="text-[10px] font-mono text-success">{map.standardField}</span>
                          </td>
                          <td className="py-1.5 pr-2">
                            <span className="text-[10px] text-neutral-textSecondary">{map.dataTypeConversion}</span>
                          </td>
                          <td className="py-1.5">
                            <code className="text-[10px] font-mono bg-neutral-surface px-1.5 py-0.5 rounded border border-neutral-border text-neutral-textPrimary">
                              {map.formula}
                            </code>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
}
