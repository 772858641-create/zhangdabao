import {
  Cpu,
  Wifi,
  Tag,
  Bluetooth,
  CheckCircle,
  FileCode,
  XCircle,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// ─── Types ───

export type DeviceType = '定位器' | '网关' | '标签' | '信标';
export type ModelStatus = '已发布' | '草稿' | '已废弃';
export type DataType = 'int' | 'float' | 'string' | 'bool';
export type AccessMode = 'R' | 'W' | 'RW';
export type EventLevel = 'info' | 'warning' | 'error';

export interface ThingProperty {
  name: string;
  identifier: string;
  dataType: DataType;
  unit: string;
  accessMode: AccessMode;
  description: string;
}

export interface ThingTelemetry {
  name: string;
  identifier: string;
  dataType: DataType;
  unit: string;
  frequency: string;
  description: string;
}

export interface ThingCommand {
  name: string;
  identifier: string;
  params: { name: string; dataType: DataType; required: boolean; description: string }[];
  timeout: number;
  description: string;
}

export interface ThingEvent {
  name: string;
  identifier: string;
  level: EventLevel;
  description: string;
}

export interface VendorMapping {
  originalField: string;
  standardField: string;
  dataTypeConversion: string;
  formula: string;
}

export interface VendorAdapter {
  vendorName: string;
  deviceType: DeviceType;
  mappingCount: number;
  status: 'active' | 'inactive';
  mappings: VendorMapping[];
}

export interface ModelVersion {
  version: string;
  releaseTime: string;
  changelog: string;
  compatibleDevices: string[];
}

export interface ThingModel {
  id: string;
  name: string;
  deviceType: DeviceType;
  version: string;
  propertyCount: number;
  telemetryCount: number;
  commandCount: number;
  vendorAdapterCount: number;
  status: ModelStatus;
  createdAt: string;
  updatedAt: string;
  description: string;
  properties: ThingProperty[];
  telemetries: ThingTelemetry[];
  commands: ThingCommand[];
  events: ThingEvent[];
  vendorAdapters: VendorAdapter[];
  versionHistory: ModelVersion[];
}

// ─── Mock Data ───

export const thingModels: ThingModel[] = [
  {
    id: 'TM-4GLOC-001',
    name: '4G定位器物模型',
    deviceType: '定位器',
    version: 'v2.1.0',
    propertyCount: 4,
    telemetryCount: 6,
    commandCount: 3,
    vendorAdapterCount: 2,
    status: '已发布',
    createdAt: '2023-08-15 09:30:00',
    updatedAt: '2024-05-20 14:22:10',
    description: '4G定位器标准物模型，支持GPS定位、电量监测、温度检测等功能',
    properties: [
      { name: '固件版本', identifier: 'firmware_version', dataType: 'string', unit: '', accessMode: 'R', description: '设备当前固件版本号' },
      { name: '设备序列号', identifier: 'serial_number', dataType: 'string', unit: '', accessMode: 'R', description: '唯一设备序列号' },
      { name: 'IMEI', identifier: 'imei', dataType: 'string', unit: '', accessMode: 'R', description: '设备IMEI编号' },
      { name: '工作模式', identifier: 'work_mode', dataType: 'int', unit: '', accessMode: 'RW', description: '0=正常模式, 1=省电模式, 2=追踪模式' },
    ],
    telemetries: [
      { name: 'GPS纬度', identifier: 'gps_lat', dataType: 'float', unit: '°', frequency: '30s', description: 'GPS纬度坐标' },
      { name: 'GPS经度', identifier: 'gps_lon', dataType: 'float', unit: '°', frequency: '30s', description: 'GPS经度坐标' },
      { name: '电池电量', identifier: 'battery_level', dataType: 'int', unit: '%', frequency: '5min', description: '当前电池剩余电量百分比' },
      { name: '设备温度', identifier: 'device_temp', dataType: 'float', unit: '°C', frequency: '1min', description: '设备内部温度' },
      { name: '信号强度', identifier: 'signal_rssi', dataType: 'int', unit: 'dBm', frequency: '1min', description: '4G网络信号强度' },
      { name: '在线状态', identifier: 'online_status', dataType: 'bool', unit: '', frequency: '实时', description: '设备是否在线' },
    ],
    commands: [
      {
        name: '远程重启', identifier: 'device_reboot', params: [], timeout: 30,
        description: '远程重启设备',
      },
      {
        name: '设置上报频率', identifier: 'set_report_interval', params: [
          { name: 'interval', dataType: 'int', required: true, description: '上报间隔秒数' },
          { name: 'type', dataType: 'string', required: true, description: '上报类型: gps/battery/all' },
        ], timeout: 10,
        description: '修改设备数据上报频率',
      },
      {
        name: '固件升级', identifier: 'ota_upgrade', params: [
          { name: 'url', dataType: 'string', required: true, description: '固件包下载地址' },
          { name: 'version', dataType: 'string', required: true, description: '目标版本号' },
          { name: 'force', dataType: 'bool', required: false, description: '是否强制升级' },
        ], timeout: 300,
        description: '远程固件OTA升级',
      },
    ],
    events: [
      { name: '低电量告警', identifier: 'low_battery_alert', level: 'warning', description: '电池电量低于20%时触发' },
      { name: '高温告警', identifier: 'high_temp_alert', level: 'warning', description: '设备温度超过60°C时触发' },
      { name: '信号丢失', identifier: 'signal_lost', level: 'error', description: '设备信号丢失超过5分钟' },
      { name: '开机上报', identifier: 'device_boot', level: 'info', description: '设备开机时上报' },
    ],
    vendorAdapters: [
      {
        vendorName: '锐明技术',
        deviceType: '定位器',
        mappingCount: 3,
        status: 'active',
        mappings: [
          { originalField: 'voltage', standardField: 'battery_level', dataTypeConversion: 'int → int', formula: '(voltage-3300)/(4200-3300)*100' },
          { originalField: 'temp_raw', standardField: 'device_temp', dataTypeConversion: 'int → float', formula: '(temp_raw-500)/10.0' },
          { originalField: 'csq', standardField: 'signal_rssi', dataTypeConversion: 'int → int', formula: '-113+csq*2' },
        ],
      },
      {
        vendorName: '移远通信',
        deviceType: '定位器',
        mappingCount: 2,
        status: 'active',
        mappings: [
          { originalField: 'batt_pct', standardField: 'battery_level', dataTypeConversion: 'int → int', formula: 'batt_pct' },
          { originalField: 'rssi_dbm', standardField: 'signal_rssi', dataTypeConversion: 'int → int', formula: 'rssi_dbm' },
        ],
      },
    ],
    versionHistory: [
      { version: 'v2.1.0', releaseTime: '2024-05-20 14:22:10', changelog: '新增信号强度遥测，优化低电量告警阈值', compatibleDevices: ['L100-A', 'L200-B', 'L300-Pro'] },
      { version: 'v2.0.0', releaseTime: '2024-02-10 09:15:00', changelog: '新增工作模式属性，支持远程切换', compatibleDevices: ['L200-B', 'L300-Pro'] },
      { version: 'v1.3.0', releaseTime: '2023-11-05 16:40:00', changelog: '初始发布版本', compatibleDevices: ['L100-A', 'L200-B'] },
    ],
  },
  {
    id: 'TM-BT-TAG-002',
    name: '蓝牙标签物模型',
    deviceType: '标签',
    version: 'v1.3.0',
    propertyCount: 3,
    telemetryCount: 4,
    commandCount: 2,
    vendorAdapterCount: 2,
    status: '已发布',
    createdAt: '2023-09-01 10:00:00',
    updatedAt: '2024-04-18 11:30:25',
    description: '蓝牙BLE标签标准物模型，支持RSSI监测、电量检测、广播频率配置',
    properties: [
      { name: 'MAC地址', identifier: 'mac_address', dataType: 'string', unit: '', accessMode: 'R', description: '蓝牙MAC地址' },
      { name: '标签名称', identifier: 'tag_name', dataType: 'string', unit: '', accessMode: 'RW', description: '标签显示名称' },
      { name: '标签类型', identifier: 'tag_type', dataType: 'int', unit: '', accessMode: 'R', description: '1=资产标签, 2=人员标签, 3=车辆标签' },
    ],
    telemetries: [
      { name: 'RSSI信号强度', identifier: 'rssi', dataType: 'int', unit: 'dBm', frequency: '10s', description: '蓝牙信号强度指示' },
      { name: '电池电量', identifier: 'battery_level', dataType: 'int', unit: '%', frequency: '1h', description: '纽扣电池剩余电量' },
      { name: '广播频率', identifier: 'adv_interval', dataType: 'int', unit: 'ms', frequency: '实时', description: '当前广播间隔' },
      { name: '温度', identifier: 'ambient_temp', dataType: 'float', unit: '°C', frequency: '5min', description: '环境温度' },
    ],
    commands: [
      {
        name: '修改广播间隔', identifier: 'set_adv_interval', params: [
          { name: 'interval_ms', dataType: 'int', required: true, description: '广播间隔(100ms~10000ms)' },
        ], timeout: 10,
        description: '修改蓝牙广播间隔',
      },
      {
        name: '蜂鸣器控制', identifier: 'buzzer_control', params: [
          { name: 'duration', dataType: 'int', required: true, description: '蜂鸣时长(ms)' },
          { name: 'times', dataType: 'int', required: false, description: '蜂鸣次数' },
        ], timeout: 15,
        description: '控制标签蜂鸣器发声定位',
      },
    ],
    events: [
      { name: '低电量告警', identifier: 'low_battery', level: 'warning', description: '电池电量低于15%' },
      { name: '信号丢失', identifier: 'rssi_lost', level: 'error', description: 'RSSI信号丢失超过阈值' },
    ],
    vendorAdapters: [
      {
        vendorName: 'Nordic方案',
        deviceType: '标签',
        mappingCount: 3,
        status: 'active',
        mappings: [
          { originalField: 'adv_raw', standardField: 'adv_interval', dataTypeConversion: 'int → int', formula: 'adv_raw*0.625' },
          { originalField: 'batt_mv', standardField: 'battery_level', dataTypeConversion: 'int → int', formula: '(batt_mv-2100)/(3000-2100)*100' },
          { originalField: 'temp_sensor', standardField: 'ambient_temp', dataTypeConversion: 'int → float', formula: 'temp_sensor/100.0' },
        ],
      },
      {
        vendorName: 'TI方案',
        deviceType: '标签',
        mappingCount: 2,
        status: 'active',
        mappings: [
          { originalField: 'battery_pct', standardField: 'battery_level', dataTypeConversion: 'int → int', formula: 'battery_pct' },
          { originalField: 'beacon_period', standardField: 'adv_interval', dataTypeConversion: 'int → int', formula: 'beacon_period' },
        ],
      },
    ],
    versionHistory: [
      { version: 'v1.3.0', releaseTime: '2024-04-18 11:30:25', changelog: '新增环境温度遥测，优化RSSI采集精度', compatibleDevices: ['BT-Tag-A1', 'BT-Tag-Pro'] },
      { version: 'v1.2.0', releaseTime: '2023-12-20 08:45:00', changelog: '新增蜂鸣器命令', compatibleDevices: ['BT-Tag-A1'] },
      { version: 'v1.0.0', releaseTime: '2023-09-01 10:00:00', changelog: '初始发布', compatibleDevices: ['BT-Tag-A1'] },
    ],
  },
  {
    id: 'TM-FIX-GW-003',
    name: '固定网关物模型',
    deviceType: '网关',
    version: 'v1.5.0',
    propertyCount: 2,
    telemetryCount: 4,
    commandCount: 2,
    vendorAdapterCount: 3,
    status: '已发布',
    createdAt: '2023-07-20 14:00:00',
    updatedAt: '2024-03-12 16:10:05',
    description: '固定安装蓝牙网关，支持扫描周期配置、在线监测',
    properties: [
      { name: '安装位置', identifier: 'install_location', dataType: 'string', unit: '', accessMode: 'RW', description: '网关安装位置描述' },
      { name: '扫描模式', identifier: 'scan_mode', dataType: 'int', unit: '', accessMode: 'RW', description: '0=被动扫描, 1=主动扫描, 2=混合模式' },
    ],
    telemetries: [
      { name: '扫描周期', identifier: 'scan_interval', dataType: 'int', unit: 'ms', frequency: '实时', description: '蓝牙扫描间隔' },
      { name: '在线状态', identifier: 'online', dataType: 'bool', unit: '', frequency: '实时', description: '网关在线状态' },
      { name: '信号强度', identifier: 'rssi', dataType: 'int', unit: 'dBm', frequency: '1min', description: 'WiFi信号强度' },
      { name: '连接设备数', identifier: 'connected_count', dataType: 'int', unit: '个', frequency: '30s', description: '当前连接蓝牙设备数' },
    ],
    commands: [
      {
        name: '重启网关', identifier: 'gateway_reboot', params: [], timeout: 60,
        description: '远程重启网关设备',
      },
      {
        name: '设置扫描参数', identifier: 'set_scan_params', params: [
          { name: 'interval', dataType: 'int', required: true, description: '扫描间隔(ms)' },
          { name: 'window', dataType: 'int', required: true, description: '扫描窗口(ms)' },
          { name: 'type', dataType: 'int', required: false, description: '扫描类型' },
        ], timeout: 10,
        description: '配置蓝牙扫描参数',
      },
    ],
    events: [
      { name: '设备离线', identifier: 'gateway_offline', level: 'error', description: '网关超过心跳周期未上报' },
      { name: '设备重连', identifier: 'gateway_reconnect', level: 'info', description: '网关恢复连接' },
      { name: '设备过载', identifier: 'device_overload', level: 'warning', description: '连接设备数超过阈值' },
    ],
    vendorAdapters: [
      {
        vendorName: 'nRF网关方案',
        deviceType: '网关',
        mappingCount: 2,
        status: 'active',
        mappings: [
          { originalField: 'scan_window_us', standardField: 'scan_interval', dataTypeConversion: 'int → int', formula: 'scan_window_us/1000' },
          { originalField: 'num_peers', standardField: 'connected_count', dataTypeConversion: 'int → int', formula: 'num_peers' },
        ],
      },
      {
        vendorName: 'ESP32方案',
        deviceType: '网关',
        mappingCount: 3,
        status: 'active',
        mappings: [
          { originalField: 'wifi_rssi', standardField: 'rssi', dataTypeConversion: 'int → int', formula: 'wifi_rssi' },
          { originalField: 'ble_count', standardField: 'connected_count', dataTypeConversion: 'int → int', formula: 'ble_count' },
          { originalField: 'scan_period', standardField: 'scan_interval', dataTypeConversion: 'int → int', formula: 'scan_period' },
        ],
      },
      {
        vendorName: '瑞芯微方案',
        deviceType: '网关',
        mappingCount: 2,
        status: 'inactive',
        mappings: [
          { originalField: 'bt_dev_num', standardField: 'connected_count', dataTypeConversion: 'int → int', formula: 'bt_dev_num' },
          { originalField: 'wlan_signal', standardField: 'rssi', dataTypeConversion: 'int → int', formula: 'wlan_signal' },
        ],
      },
    ],
    versionHistory: [
      { version: 'v1.5.0', releaseTime: '2024-03-12 16:10:05', changelog: '新增设备过载事件，优化扫描参数配置', compatibleDevices: ['GW-Fixed-V2', 'GW-Fixed-Pro'] },
      { version: 'v1.4.0', releaseTime: '2023-12-01 10:20:00', changelog: '新增瑞芯微方案适配', compatibleDevices: ['GW-Fixed-V2'] },
      { version: 'v1.0.0', releaseTime: '2023-07-20 14:00:00', changelog: '初始发布', compatibleDevices: ['GW-Fixed-V2'] },
    ],
  },
  {
    id: 'TM-CAR-GW-004',
    name: '车载网关物模型',
    deviceType: '网关',
    version: 'v2.0.0',
    propertyCount: 3,
    telemetryCount: 5,
    commandCount: 3,
    vendorAdapterCount: 2,
    status: '草稿',
    createdAt: '2023-10-05 08:30:00',
    updatedAt: '2024-06-10 09:45:30',
    description: '车载移动网关，集成GPS定位、速度检测、蓝牙标签扫描',
    properties: [
      { name: '车辆编号', identifier: 'vehicle_id', dataType: 'string', unit: '', accessMode: 'RW', description: '绑定的车辆编号' },
      { name: '驾驶员工号', identifier: 'driver_id', dataType: 'string', unit: '', accessMode: 'RW', description: '当前驾驶员工号' },
      { name: '运行模式', identifier: 'run_mode', dataType: 'int', unit: '', accessMode: 'RW', description: '0=停运, 1=运输中, 2=待命' },
    ],
    telemetries: [
      { name: 'GPS纬度', identifier: 'gps_lat', dataType: 'float', unit: '°', frequency: '10s', description: '车辆纬度坐标' },
      { name: 'GPS经度', identifier: 'gps_lon', dataType: 'float', unit: '°', frequency: '10s', description: '车辆经度坐标' },
      { name: '速度', identifier: 'speed', dataType: 'float', unit: 'km/h', frequency: '10s', description: '车辆行驶速度' },
      { name: '航向角', identifier: 'heading', dataType: 'float', unit: '°', frequency: '30s', description: '车辆行驶方向角' },
      { name: '扫描标签列表', identifier: 'scanned_tags', dataType: 'string', unit: '', frequency: '30s', description: '扫描到的蓝牙标签MAC列表' },
      { name: '信号强度', identifier: 'lte_rssi', dataType: 'int', unit: 'dBm', frequency: '1min', description: '4G LTE信号强度' },
    ],
    commands: [
      {
        name: '远程重启', identifier: 'reboot', params: [], timeout: 60,
        description: '远程重启车载网关',
      },
      {
        name: '设置工作模式', identifier: 'set_mode', params: [
          { name: 'mode', dataType: 'int', required: true, description: '0=停运, 1=运输中, 2=待命' },
        ], timeout: 10,
        description: '设置车辆运行模式',
      },
      {
        name: '强制标签扫描', identifier: 'force_scan', params: [
          { name: 'duration', dataType: 'int', required: true, description: '扫描持续时间(秒)' },
        ], timeout: 120,
        description: '强制启动蓝牙标签扫描',
      },
    ],
    events: [
      { name: '超速告警', identifier: 'overspeed', level: 'warning', description: '车速超过设定阈值' },
      { name: '偏离路线', identifier: 'route_deviation', level: 'error', description: '车辆偏离预设路线' },
      { name: '标签丢失', identifier: 'tag_missing', level: 'warning', description: '检测到标签从扫描列表消失' },
      { name: 'GPS信号丢失', identifier: 'gps_lost', level: 'error', description: 'GPS信号丢失超过3分钟' },
    ],
    vendorAdapters: [
      {
        vendorName: '华为车载模组',
        deviceType: '网关',
        mappingCount: 3,
        status: 'active',
        mappings: [
          { originalField: 'velocity', standardField: 'speed', dataTypeConversion: 'float → float', formula: 'velocity*3.6' },
          { originalField: 'direction', standardField: 'heading', dataTypeConversion: 'float → float', formula: 'direction' },
          { originalField: 'lte_csq', standardField: 'lte_rssi', dataTypeConversion: 'int → int', formula: '-113+lte_csq*2' },
        ],
      },
      {
        vendorName: '移远车载模组',
        deviceType: '网关',
        mappingCount: 2,
        status: 'active',
        mappings: [
          { originalField: 'spd_kmh', standardField: 'speed', dataTypeConversion: 'float → float', formula: 'spd_kmh' },
          { originalField: 'cog_deg', standardField: 'heading', dataTypeConversion: 'float → float', formula: 'cog_deg' },
        ],
      },
    ],
    versionHistory: [
      { version: 'v2.0.0', releaseTime: '2024-06-10 09:45:30', changelog: '草稿版本：新增航向角遥测，优化GPS采集频率', compatibleDevices: ['VGW-M100'] },
      { version: 'v1.2.0', releaseTime: '2024-01-15 13:20:00', changelog: '新增标签扫描功能', compatibleDevices: ['VGW-M100', 'VGW-M80'] },
      { version: 'v1.0.0', releaseTime: '2023-10-05 08:30:00', changelog: '初始发布', compatibleDevices: ['VGW-M100'] },
    ],
  },
  {
    id: 'TM-BT-BCN-005',
    name: '蓝牙信标物模型',
    deviceType: '信标',
    version: 'v1.0.0',
    propertyCount: 3,
    telemetryCount: 4,
    commandCount: 2,
    vendorAdapterCount: 2,
    status: '已废弃',
    createdAt: '2023-06-01 11:00:00',
    updatedAt: '2024-01-30 15:00:00',
    description: '蓝牙BLE信标，支持iBeacon/Eddystone协议（已废弃，建议迁移至标签物模型）',
    properties: [
      { name: 'UUID', identifier: 'ibeacon_uuid', dataType: 'string', unit: '', accessMode: 'RW', description: 'iBeacon UUID' },
      { name: 'Major', identifier: 'ibeacon_major', dataType: 'int', unit: '', accessMode: 'RW', description: 'iBeacon Major值' },
      { name: 'Minor', identifier: 'ibeacon_minor', dataType: 'int', unit: '', accessMode: 'RW', description: 'iBeacon Minor值' },
    ],
    telemetries: [
      { name: '发射功率', identifier: 'tx_power', dataType: 'int', unit: 'dBm', frequency: '实时', description: '蓝牙发射功率' },
      { name: '电池电量', identifier: 'battery_level', dataType: 'int', unit: '%', frequency: '1h', description: '纽扣电池电量' },
      { name: '温度', identifier: 'temperature', dataType: 'float', unit: '°C', frequency: '5min', description: '环境温度' },
      { name: '运行时长', identifier: 'uptime', dataType: 'int', unit: 'h', frequency: '1h', description: '累计运行小时数' },
    ],
    commands: [
      {
        name: '修改UUID', identifier: 'set_uuid', params: [
          { name: 'uuid', dataType: 'string', required: true, description: '新的UUID字符串' },
        ], timeout: 10,
        description: '修改iBeacon UUID',
      },
      {
        name: '设置发射功率', identifier: 'set_tx_power', params: [
          { name: 'power', dataType: 'int', required: true, description: '发射功率(-40~+4 dBm)' },
        ], timeout: 10,
        description: '设置蓝牙发射功率等级',
      },
    ],
    events: [
      { name: '低电量', identifier: 'low_battery', level: 'warning', description: '电池电量低于10%' },
      { name: '倾倒检测', identifier: 'tilt_detected', level: 'info', description: '信标被移动或倾倒' },
    ],
    vendorAdapters: [
      {
        vendorName: 'Kontakt.io',
        deviceType: '信标',
        mappingCount: 2,
        status: 'inactive',
        mappings: [
          { originalField: 'power_level', standardField: 'tx_power', dataTypeConversion: 'int → int', formula: 'power_level' },
          { originalField: 'battery_percent', standardField: 'battery_level', dataTypeConversion: 'int → int', formula: 'battery_percent' },
        ],
      },
      {
        vendorName: 'Estimote',
        deviceType: '信标',
        mappingCount: 2,
        status: 'inactive',
        mappings: [
          { originalField: 'tx_dbm', standardField: 'tx_power', dataTypeConversion: 'int → int', formula: 'tx_dbm' },
          { originalField: 'battery_volts', standardField: 'battery_level', dataTypeConversion: 'float → int', formula: '(battery_volts-1.8)/(3.0-1.8)*100' },
        ],
      },
    ],
    versionHistory: [
      { version: 'v1.0.0', releaseTime: '2023-06-01 11:00:00', changelog: '初始发布（已废弃）', compatibleDevices: ['BCN-Estimote'] },
    ],
  },
];

// ─── Helpers ───

export function getDeviceTypeIcon(type: DeviceType) {
  switch (type) {
    case '定位器': return <Cpu size={14} className="text-info" />;
    case '网关': return <Wifi size={14} className="text-primary" />;
    case '标签': return <Tag size={14} className="text-warning" />;
    case '信标': return <Bluetooth size={14} className="text-success" />;
  }
}

export function getDataTypeBadge(type: DataType) {
  const colorMap: Record<DataType, string> = {
    int: 'bg-blue-50 text-blue-700 border-blue-200',
    float: 'bg-cyan-50 text-cyan-700 border-cyan-200',
    string: 'bg-purple-50 text-purple-700 border-purple-200',
    bool: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  };
  return (
    <span className={cn('inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium border', colorMap[type])}>
      {type}
    </span>
  );
}

export function getAccessModeBadge(mode: AccessMode) {
  switch (mode) {
    case 'R': return <Badge variant="outline" className="text-[10px] h-5 border-info text-info bg-info-light">只读</Badge>;
    case 'W': return <Badge variant="outline" className="text-[10px] h-5 border-warning text-warning bg-warning-light">只写</Badge>;
    case 'RW': return <Badge variant="outline" className="text-[10px] h-5 border-success text-success bg-success-light">读写</Badge>;
  }
}

export function getStatusBadge(status: ModelStatus) {
  switch (status) {
    case '已发布':
      return (
        <Badge variant="outline" className="border-success text-success bg-success-light gap-1">
          <CheckCircle size={10} />
          已发布
        </Badge>
      );
    case '草稿':
      return (
        <Badge variant="outline" className="border-warning text-warning bg-warning-light gap-1">
          <FileCode size={10} />
          草稿
        </Badge>
      );
    case '已废弃':
      return (
        <Badge variant="outline" className="border-danger text-danger bg-danger-light gap-1">
          <XCircle size={10} />
          已废弃
        </Badge>
      );
  }
}

export function getEventLevelBadge(level: EventLevel) {
  switch (level) {
    case 'info': return <Badge variant="outline" className="border-info text-info bg-info-light text-[10px]">信息</Badge>;
    case 'warning': return <Badge variant="outline" className="border-warning text-warning bg-warning-light text-[10px]">告警</Badge>;
    case 'error': return <Badge variant="outline" className="border-danger text-danger bg-danger-light text-[10px]">错误</Badge>;
  }
}
