import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Radio,
  Sparkles,
  Zap,
  Database,
  Globe,
  ShieldCheck,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import DataAccessTab from './DataAccessTab';
import DataCleanTab from './DataCleanTab';
import StreamComputeTab from './StreamComputeTab';
import TimeSeriesStorageTab from './TimeSeriesStorageTab';
import DataAPITab from './DataAPITab';
import DataGovernanceTab from './DataGovernanceTab';

/* ─── KPI Stats ─── */
interface StatCard {
  label: string;
  value: string;
  sub: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

const stats: StatCard[] = [
  {
    label: '今日接入消息',
    value: '124.5K',
    sub: '+8.2% 环比',
    icon: Radio,
    color: 'text-primary',
    bgColor: 'bg-primary-light',
  },
  {
    label: '清洗通过率',
    value: '99.2%',
    sub: '2,356条异常已过滤',
    icon: Sparkles,
    color: 'text-success',
    bgColor: 'bg-success-light',
  },
  {
    label: '流任务运行中',
    value: '6/6',
    sub: '平均延迟 230ms',
    icon: Zap,
    color: 'text-warning',
    bgColor: 'bg-warning-light',
  },
  {
    label: 'API今日调用',
    value: '245.8K',
    sub: '平均响应 45ms',
    icon: Globe,
    color: 'text-info',
    bgColor: 'bg-info-light',
  },
];

/* ─── Tab Configuration ─── */
const tabs = [
  { value: 'access', label: '数据接入', icon: Radio },
  { value: 'clean', label: '数据清洗', icon: Sparkles },
  { value: 'stream', label: '流处理', icon: Zap },
  { value: 'storage', label: '时序存储', icon: Database },
  { value: 'api', label: 'Data API', icon: Globe },
  { value: 'governance', label: '数据治理', icon: ShieldCheck },
];

export default function DataMiddlePlatformPage() {
  const [activeTab, setActiveTab] = useState('access');

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold text-neutral-textPrimary">数据中台</h1>
        <p className="text-sm text-neutral-textSecondary mt-1">
          数据接入 · 清洗标准化 · 实时计算 · 时序存储 · API服务 · 数据治理
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.06 }}
            >
              <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={cn('w-10 h-10 rounded-full flex items-center justify-center shrink-0', stat.bgColor)}>
                    <Icon size={20} className={stat.color} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-neutral-textTertiary">{stat.label}</p>
                    <p className="text-lg font-semibold text-neutral-textPrimary font-number truncate">{stat.value}</p>
                    <p className="text-xs text-neutral-textTertiary">{stat.sub}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="bg-neutral-surface-elevated border border-neutral-border rounded-xl p-1 flex flex-wrap gap-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.value;
          return (
            <button
              key={tab.value}
              onClick={() => setActiveTab(tab.value)}
              className={cn(
                'flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-all duration-200',
                isActive
                  ? 'bg-primary-light text-primary shadow-sm'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary hover:bg-neutral-background'
              )}
            >
              <Icon size={14} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {activeTab === 'access' && (
          <motion.div
            key="access"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <DataAccessTab />
          </motion.div>
        )}
        {activeTab === 'clean' && (
          <motion.div
            key="clean"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <DataCleanTab />
          </motion.div>
        )}
        {activeTab === 'stream' && (
          <motion.div
            key="stream"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <StreamComputeTab />
          </motion.div>
        )}
        {activeTab === 'storage' && (
          <motion.div
            key="storage"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <TimeSeriesStorageTab />
          </motion.div>
        )}
        {activeTab === 'api' && (
          <motion.div
            key="api"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <DataAPITab />
          </motion.div>
        )}
        {activeTab === 'governance' && (
          <motion.div
            key="governance"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <DataGovernanceTab />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
