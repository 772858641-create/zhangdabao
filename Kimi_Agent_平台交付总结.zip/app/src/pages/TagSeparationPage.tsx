import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Unlink, AlertTriangle, CheckCircle, Clock, Eye, Radio, Bluetooth, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SeparationAlarm {
  id: string;
  alarmNo: string;
  carrierId: string;
  tagId: string;
  tagName: string;
  locatorId: string;
  locatorName: string;
  gatewayRssi: number;
  locatorPosition: string;
  separationTime: string;
  observationPeriod: string;
  status: 'observing' | 'confirmed' | 'resolved';
  separationType: string;
  threshold: string;
}

interface SeparationRule {
  id: string;
  name: string;
  deviceType: string;
  observationMinutes: number;
  rssiThreshold: number;
  distanceThreshold: number;
  enabled: boolean;
}

const separationAlarms: SeparationAlarm[] = [
  { id: 'SA001', alarmNo: 'SEP-20250429-2001', carrierId: 'CA-20250401-015', tagId: 'TAG-001', tagName: '蓝牙标签-015', locatorId: 'DEV-20250401-001', locatorName: '定位器-A001', gatewayRssi: -82, locatorPosition: '31.2304, 121.4737', separationTime: '2025-04-29 08:00:00', observationPeriod: '30分钟', status: 'confirmed', separationType: '标签脱离载具', threshold: 'RSSI < -75dBm 持续30分钟' },
  { id: 'SA002', alarmNo: 'SEP-20250429-2002', carrierId: 'CA-20250402-032', tagId: 'TAG-032', tagName: '蓝牙标签-032', locatorId: 'DEV-20250402-032', locatorName: '固定网关-B032', gatewayRssi: -88, locatorPosition: '31.3804, 120.9807', separationTime: '2025-04-29 09:15:00', observationPeriod: '30分钟', status: 'observing', separationType: '标签未扫描到', threshold: '网关扫描缺失持续30分钟' },
  { id: 'SA003', alarmNo: 'SEP-20250429-2003', carrierId: 'CA-20250403-008', tagId: 'TAG-008', tagName: '蓝牙标签-008', locatorId: 'DEV-20250403-008', locatorName: '车载网关-C008', gatewayRssi: -75, locatorPosition: '30.5904, 114.3107', separationTime: '2025-04-29 10:30:00', observationPeriod: '30分钟', status: 'resolved', separationType: '标签信号弱', threshold: 'RSSI < -70dBm 持续30分钟' },
  { id: 'SA004', alarmNo: 'SEP-20250429-2004', carrierId: 'CA-20250404-021', tagId: 'TAG-021', tagName: '蓝牙标签-021', locatorId: 'DEV-20250404-021', locatorName: '标签-D021', gatewayRssi: -91, locatorPosition: '29.9189, 121.8458', separationTime: '2025-04-29 11:00:00', observationPeriod: '30分钟', status: 'confirmed', separationType: '标签脱离载具', threshold: 'RSSI < -75dBm 持续30分钟' },
  { id: 'SA005', alarmNo: 'SEP-20250429-2005', carrierId: 'CA-20250405-009', tagId: 'TAG-009', tagName: '蓝牙标签-009', locatorId: 'DEV-20250405-009', locatorName: '信标-E009', gatewayRssi: -78, locatorPosition: '30.6204, 114.1458', separationTime: '2025-04-29 12:30:00', observationPeriod: '30分钟', status: 'observing', separationType: '标签未扫描到', threshold: '网关扫描缺失持续30分钟' },
  { id: 'SA006', alarmNo: 'SEP-20250429-2006', carrierId: 'CA-20250406-044', tagId: 'TAG-044', tagName: '蓝牙标签-044', locatorId: 'DEV-20250406-044', locatorName: '定位器-A044', gatewayRssi: -85, locatorPosition: '31.2305, 121.4739', separationTime: '2025-04-29 13:45:00', observationPeriod: '30分钟', status: 'resolved', separationType: '标签信号弱', threshold: 'RSSI < -70dBm 持续30分钟' },
];

const separationRules: SeparationRule[] = [
  { id: 'SR001', name: '定位器标签分离规则', deviceType: '定位器', observationMinutes: 30, rssiThreshold: -75, distanceThreshold: 5, enabled: true },
  { id: 'SR002', name: '固定网关标签分离规则', deviceType: '固定网关', observationMinutes: 30, rssiThreshold: -80, distanceThreshold: 8, enabled: true },
  { id: 'SR003', name: '车载网关标签分离规则', deviceType: '车载网关', observationMinutes: 20, rssiThreshold: -70, distanceThreshold: 3, enabled: false },
  { id: 'SR004', name: '信标标签分离规则', deviceType: '信标', observationMinutes: 45, rssiThreshold: -85, distanceThreshold: 10, enabled: true },
];

function getStatusBadge(status: string) {
  switch (status) {
    case 'observing': return <Badge className="bg-amber-100 text-amber-700">观察中</Badge>;
    case 'confirmed': return <Badge className="bg-red-100 text-red-700">已确认</Badge>;
    case 'resolved': return <Badge className="bg-emerald-100 text-emerald-700">已解决</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function TagSeparationPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [alarms] = useState(separationAlarms);
  const [rules, setRules] = useState(separationRules);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedAlarm, setSelectedAlarm] = useState<SeparationAlarm | null>(null);

  const filtered = useMemo(() => {
    return alarms.filter(a => {
      const matchSearch = a.alarmNo.toLowerCase().includes(search.toLowerCase()) || a.carrierId.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || a.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [alarms, search, statusFilter]);

  const stats = useMemo(() => ({
    observing: alarms.filter(a => a.status === 'observing').length,
    confirmed: alarms.filter(a => a.status === 'confirmed').length,
    resolved: alarms.filter(a => a.status === 'resolved').length,
    total: alarms.length,
  }), [alarms]);

  const toggleRule = (id: string) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  const openDetail = (alarm: SeparationAlarm) => {
    setSelectedAlarm(alarm);
    setDetailOpen(true);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">标签分离报警</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">网关扫描 · 4G定位器交叉验证 · 30分钟观察期 · 分离阈值配置</p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {[
          { label: '观察中', value: stats.observing, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '已确认', value: stats.confirmed, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
          { label: '已解决', value: stats.resolved, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '报警总数', value: stats.total, icon: Unlink, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs className="space-y-4" defaultValue="alarms">
        <TabsList className="grid w-full grid-cols-2 lg:w-[240px]">
          <TabsTrigger value="alarms">分离报警</TabsTrigger>
          <TabsTrigger value="rules">阈值配置</TabsTrigger>
        </TabsList>

        <TabsContent value="alarms" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索报警编号或载具ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="observing">观察中</SelectItem>
                <SelectItem value="confirmed">已确认</SelectItem>
                <SelectItem value="resolved">已解决</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">报警编号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具ID</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">标签</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">定位器</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">网关RSSI</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">分离时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">分离类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(a => (
                    <TableRow key={a.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{a.alarmNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{a.carrierId}</TableCell>
                      <TableCell>
                        <div className="text-[var(--neutral-text-primary)]">{a.tagName}</div>
                        <div className="text-xs text-[var(--neutral-text-tertiary)]">{a.tagId}</div>
                      </TableCell>
                      <TableCell>
                        <div className="text-[var(--neutral-text-primary)]">{a.locatorName}</div>
                        <div className="text-xs text-[var(--neutral-text-tertiary)]">{a.locatorId}</div>
                      </TableCell>
                      <TableCell className={cn("font-medium", a.gatewayRssi < -80 ? "text-red-600" : a.gatewayRssi < -75 ? "text-amber-600" : "text-emerald-600")}>{a.gatewayRssi} dBm</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{a.separationTime}</TableCell>
                      <TableCell>{getStatusBadge(a.status)}</TableCell>
                      <TableCell><Badge variant="outline">{a.separationType}</Badge></TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-7" onClick={() => openDetail(a)}>
                          <Eye className="w-3 h-3 mr-1" />详情
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rules" className="space-y-4">
          <div className="space-y-3">
            {rules.map(rule => (
              <Card key={rule.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-[var(--neutral-text-primary)]">{rule.name}</span>
                        <Badge variant="outline">{rule.deviceType}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-[var(--neutral-text-secondary)]">
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> 观察期：{rule.observationMinutes} 分钟</span>
                        <span className="flex items-center gap-1"><Bluetooth className="w-3 h-3" /> RSSI阈值：{rule.rssiThreshold} dBm</span>
                        <span className="flex items-center gap-1"><Radio className="w-3 h-3" /> 距离阈值：{rule.distanceThreshold} 米</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => alert('编辑规则：' + rule.name)}>
                        <Settings className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>分离报警详情</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-[var(--neutral-text-secondary)]">报警编号：</span><span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">载具ID：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.carrierId}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">标签：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.tagName}（{selectedAlarm.tagId}）</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">定位器：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.locatorName}（{selectedAlarm.locatorId}）</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">网关RSSI：</span><span className={cn("font-medium", selectedAlarm.gatewayRssi < -80 ? "text-red-600" : "text-amber-600")}>{selectedAlarm.gatewayRssi} dBm</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">分离时间：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.separationTime}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">观察期：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.observationPeriod}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">状态：</span>{getStatusBadge(selectedAlarm.status)}</div>
              </div>
              <div className="bg-[var(--neutral-background)] rounded-lg p-3">
                <div className="text-xs text-[var(--neutral-text-secondary)] mb-1">分离阈值规则</div>
                <div className="text-sm text-[var(--neutral-text-primary)]">{selectedAlarm.threshold}</div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <div className="text-xs text-blue-600 mb-1">交叉验证过程</div>
                <div className="text-sm text-blue-800 space-y-1">
                  <div>1. 蓝牙标签信号检测：RSSI = {selectedAlarm.gatewayRssi} dBm</div>
                  <div>2. 4G定位器位置：{selectedAlarm.locatorPosition}</div>
                  <div>3. 网关扫描验证：标签连续30分钟未被扫描到</div>
                  <div>4. 交叉验证结论：标签与载具物理分离已确认</div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
