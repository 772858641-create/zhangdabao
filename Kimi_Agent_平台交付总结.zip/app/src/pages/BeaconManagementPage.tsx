import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Bluetooth,
  Wifi,
  BatteryWarning,
  Warehouse,
  ScanLine,
  Search,
  Pencil,
  Eye,
  Radio,
  Signal,
  MapPin,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

interface StatCard {
  label: string;
  value: string;
  sub: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
}

const stats: StatCard[] = [
  {
    label: '信标总数',
    value: '128',
    sub: '全部网点',
    icon: Bluetooth,
    color: 'text-primary',
    bgColor: 'bg-primary-light',
  },
  {
    label: '在线信标',
    value: '112',
    sub: '87.5% 在线率',
    icon: Wifi,
    color: 'text-success',
    bgColor: 'bg-success-light',
  },
  {
    label: '低电量信标',
    value: '9',
    sub: '需更换电池',
    icon: BatteryWarning,
    color: 'text-warning',
    bgColor: 'bg-warning-light',
  },
  {
    label: '绑定网点数',
    value: '24',
    sub: '已配置网点',
    icon: Warehouse,
    color: 'text-info',
    bgColor: 'bg-info-light',
  },
  {
    label: '今日扫描次数',
    value: '45.2K',
    sub: '+8.3% 环比',
    icon: ScanLine,
    color: 'text-purple',
    bgColor: 'bg-purple-light',
  },
];

interface BeaconItem {
  id: string;
  name: string;
  mac: string;
  site: string;
  power: number;
  radius: number;
  battery: number;
  lastScan: string;
  status: 'online' | 'offline' | 'low_battery';
}

const beaconData: BeaconItem[] = [
  { id: 'BCN-001', name: 'A区入口信标', mac: 'AC:23:3F:A0:01:01', site: '上海中心仓', power: -12, radius: 80, battery: 92, lastScan: '2025-04-30 09:42:18', status: 'online' },
  { id: 'BCN-002', name: 'A区货架信标', mac: 'AC:23:3F:A0:01:02', site: '上海中心仓', power: -12, radius: 80, battery: 88, lastScan: '2025-04-30 09:41:05', status: 'online' },
  { id: 'BCN-003', name: 'B区装卸信标', mac: 'AC:23:3F:A0:01:03', site: '上海中心仓', power: -8, radius: 120, battery: 76, lastScan: '2025-04-30 09:38:22', status: 'online' },
  { id: 'BCN-004', name: 'C区冷链信标', mac: 'AC:23:3F:A0:01:04', site: '北京冷链仓', power: -16, radius: 60, battery: 45, lastScan: '2025-04-30 09:15:33', status: 'low_battery' },
  { id: 'BCN-005', name: 'C区出口信标', mac: 'AC:23:3F:A0:01:05', site: '北京冷链仓', power: -12, radius: 80, battery: 95, lastScan: '2025-04-30 09:40:11', status: 'online' },
  { id: 'BCN-006', name: 'D区暂存信标', mac: 'AC:23:3F:A0:01:06', site: '广州分拨中心', power: -8, radius: 120, battery: 82, lastScan: '2025-04-30 09:35:47', status: 'online' },
  { id: 'BCN-007', name: 'D区分拣信标', mac: 'AC:23:3F:A0:01:07', site: '广州分拨中心', power: -12, radius: 80, battery: 67, lastScan: '2025-04-30 09:30:19', status: 'online' },
  { id: 'BCN-008', name: 'E区月台信标', mac: 'AC:23:3F:A0:01:08', site: '深圳转运仓', power: -8, radius: 120, battery: 91, lastScan: '2025-04-30 09:39:55', status: 'online' },
  { id: 'BCN-009', name: 'F区打包信标', mac: 'AC:23:3F:A0:01:09', site: '杭州电商仓', power: -16, radius: 60, battery: 23, lastScan: '2025-04-30 08:50:02', status: 'low_battery' },
  { id: 'BCN-010', name: 'G区高架信标', mac: 'AC:23:3F:A0:01:0A', site: '杭州电商仓', power: -12, radius: 80, battery: 89, lastScan: '2025-04-29 22:10:45', status: 'offline' },
  { id: 'BCN-011', name: 'H区质检信标', mac: 'AC:23:3F:A0:01:0B', site: '武汉中转仓', power: -8, radius: 120, battery: 78, lastScan: '2025-04-30 09:36:28', status: 'online' },
  { id: 'BCN-012', name: 'I区发运信标', mac: 'AC:23:3F:A0:01:0C', site: '成都西南仓', power: -12, radius: 80, battery: 55, lastScan: '2025-04-30 09:20:14', status: 'online' },
];

const sites = ['全部网点', '上海中心仓', '北京冷链仓', '广州分拨中心', '深圳转运仓', '杭州电商仓', '武汉中转仓', '成都西南仓'];

interface HeatmapCell {
  zone: string;
  cell: string;
  count: number;
}

const heatmapData: HeatmapCell[] = [
  // A区 4x3
  { zone: 'A', cell: 'A-01', count: 12 }, { zone: 'A', cell: 'A-02', count: 8 }, { zone: 'A', cell: 'A-03', count: 15 },
  { zone: 'A', cell: 'A-04', count: 6 }, { zone: 'A', cell: 'A-05', count: 22 }, { zone: 'A', cell: 'A-06', count: 9 },
  { zone: 'A', cell: 'A-07', count: 4 }, { zone: 'A', cell: 'A-08', count: 18 }, { zone: 'A', cell: 'A-09', count: 11 },
  { zone: 'A', cell: 'A-10', count: 7 }, { zone: 'A', cell: 'A-11', count: 14 }, { zone: 'A', cell: 'A-12', count: 5 },
  // B区 4x3
  { zone: 'B', cell: 'B-01', count: 3 }, { zone: 'B', cell: 'B-02', count: 9 }, { zone: 'B', cell: 'B-03', count: 16 },
  { zone: 'B', cell: 'B-04', count: 20 }, { zone: 'B', cell: 'B-05', count: 11 }, { zone: 'B', cell: 'B-06', count: 6 },
  { zone: 'B', cell: 'B-07', count: 13 }, { zone: 'B', cell: 'B-08', count: 8 }, { zone: 'B', cell: 'B-09', count: 19 },
  { zone: 'B', cell: 'B-10', count: 5 }, { zone: 'B', cell: 'B-11', count: 10 }, { zone: 'B', cell: 'B-12', count: 14 },
  // C区 4x3
  { zone: 'C', cell: 'C-01', count: 7 }, { zone: 'C', cell: 'C-02', count: 12 }, { zone: 'C', cell: 'C-03', count: 4 },
  { zone: 'C', cell: 'C-04', count: 18 }, { zone: 'C', cell: 'C-05', count: 21 }, { zone: 'C', cell: 'C-06', count: 9 },
  { zone: 'C', cell: 'C-07', count: 6 }, { zone: 'C', cell: 'C-08', count: 15 }, { zone: 'C', cell: 'C-09', count: 11 },
  { zone: 'C', cell: 'C-10', count: 8 }, { zone: 'C', cell: 'C-11', count: 3 }, { zone: 'C', cell: 'C-12', count: 17 },
];

interface CoverageItem {
  site: string;
  beaconCount: number;
  avgRadius: number;
  blindSpots: number;
  overlapAreas: number;
}

const coverageData: CoverageItem[] = [
  { site: '上海中心仓', beaconCount: 3, avgRadius: 93, blindSpots: 1, overlapAreas: 2 },
  { site: '北京冷链仓', beaconCount: 2, avgRadius: 70, blindSpots: 2, overlapAreas: 1 },
  { site: '广州分拨中心', beaconCount: 2, avgRadius: 100, blindSpots: 0, overlapAreas: 1 },
  { site: '深圳转运仓', beaconCount: 1, avgRadius: 120, blindSpots: 1, overlapAreas: 0 },
  { site: '杭州电商仓', beaconCount: 2, avgRadius: 70, blindSpots: 3, overlapAreas: 1 },
  { site: '武汉中转仓', beaconCount: 1, avgRadius: 120, blindSpots: 0, overlapAreas: 0 },
  { site: '成都西南仓', beaconCount: 1, avgRadius: 80, blindSpots: 1, overlapAreas: 0 },
  { site: '南京华东仓', beaconCount: 4, avgRadius: 85, blindSpots: 1, overlapAreas: 3 },
];

function getHeatmapColor(count: number): string {
  if (count >= 20) return '#1e3a8a'; // dark blue
  if (count >= 15) return '#2563eb'; // blue
  if (count >= 10) return '#60a5fa'; // light blue
  if (count >= 6) return '#93c5fd'; // lighter blue
  return '#dbeafe'; // very light blue
}

function StatusBadge({ status }: { status: BeaconItem['status'] }) {
  const config = {
    online: { label: '在线', className: 'bg-success-light text-success hover:bg-success-light' },
    offline: { label: '离线', className: 'bg-neutral-surface-elevated text-neutral-textTertiary hover:bg-neutral-surface-elevated' },
    low_battery: { label: '低电量', className: 'bg-warning-light text-warning hover:bg-warning-light' },
  };
  const { label, className } = config[status];
  return <Badge className={cn('font-medium', className)}>{label}</Badge>;
}

export default function BeaconManagementPage() {
  const [activeTab, setActiveTab] = useState('list');
  const [search, setSearch] = useState('');
  const [siteFilter, setSiteFilter] = useState('全部网点');

  const filteredBeacons = useMemo(() => {
    return beaconData.filter((item) => {
      const matchSearch =
        search === '' ||
        item.id.toLowerCase().includes(search.toLowerCase()) ||
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.mac.toLowerCase().includes(search.toLowerCase());
      const matchSite = siteFilter === '全部网点' || item.site === siteFilter;
      return matchSearch && matchSite;
    });
  }, [search, siteFilter]);

  const aCells = heatmapData.filter((c) => c.zone === 'A');
  const bCells = heatmapData.filter((c) => c.zone === 'B');
  const cCells = heatmapData.filter((c) => c.zone === 'C');

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div>
        <h1 className="text-xl font-bold text-neutral-textPrimary">蓝牙信标管理</h1>
        <p className="text-sm text-neutral-textSecondary mt-1">
          信标绑定 · 发射功率 · 扫描热力图 · 覆盖半径
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: idx * 0.06 }}
            >
              <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={cn('w-10 h-10 rounded-full flex items-center justify-center shrink-0', stat.bgColor)}>
                    <Icon size={20} className={stat.color} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs text-neutral-textTertiary">{stat.label}</p>
                    <p className="text-lg font-semibold text-neutral-textPrimary font-number truncate">{stat.value}</p>
                    <p className="text-xs text-neutral-textTertiary">{stat.sub}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-neutral-surface-elevated border border-neutral-border h-10 p-1">
          <TabsTrigger
            value="list"
            className={cn(
              'text-xs px-3 py-1.5 rounded-md transition-all data-[state=active]:shadow-sm',
              activeTab === 'list'
                ? 'bg-neutral-surface text-neutral-textPrimary font-medium'
                : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
            )}
          >
            <Bluetooth size={14} className="mr-1.5" />
            信标列表
          </TabsTrigger>
          <TabsTrigger
            value="heatmap"
            className={cn(
              'text-xs px-3 py-1.5 rounded-md transition-all data-[state=active]:shadow-sm',
              activeTab === 'heatmap'
                ? 'bg-neutral-surface text-neutral-textPrimary font-medium'
                : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
            )}
          >
            <Signal size={14} className="mr-1.5" />
            扫描热力图
          </TabsTrigger>
          <TabsTrigger
            value="coverage"
            className={cn(
              'text-xs px-3 py-1.5 rounded-md transition-all data-[state=active]:shadow-sm',
              activeTab === 'coverage'
                ? 'bg-neutral-surface text-neutral-textPrimary font-medium'
                : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
            )}
          >
            <Radio size={14} className="mr-1.5" />
            覆盖分析
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: 信标列表 */}
        <TabsContent value="list" className="mt-0">
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4 space-y-4">
              {/* Search + Filter */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
                  <Input
                    placeholder="搜索信标编号 / 名称 / MAC地址"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9 h-9 bg-neutral-surface-elevated border-neutral-border text-sm"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={siteFilter}
                    onChange={(e) => setSiteFilter(e.target.value)}
                    className="h-9 px-3 rounded-md border border-neutral-border bg-neutral-surface-elevated text-sm text-neutral-textPrimary focus:outline-none focus:ring-2 focus:ring-primary/20"
                  >
                    {sites.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Table */}
              <div className="border border-neutral-border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-neutral-surface-elevated hover:bg-neutral-surface-elevated">
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">信标编号</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">名称</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">MAC地址</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">绑定网点</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">发射功率(dBm)</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">扫描半径(m)</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">电池电量(%)</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">最近扫描时间</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">状态</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredBeacons.map((item) => (
                      <TableRow key={item.id} className="border-b border-neutral-border">
                        <TableCell className="text-sm text-neutral-textPrimary font-medium">{item.id}</TableCell>
                        <TableCell className="text-sm text-neutral-textPrimary">{item.name}</TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-mono">{item.mac}</TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary">
                          <div className="flex items-center gap-1">
                            <MapPin size={12} className="text-neutral-textTertiary" />
                            {item.site}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">{item.power}</TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">{item.radius}</TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">
                          <span
                            className={cn(
                              item.battery <= 30
                                ? 'text-warning'
                                : item.battery <= 50
                                  ? 'text-neutral-textSecondary'
                                  : 'text-success'
                            )}
                          >
                            {item.battery}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-neutral-textTertiary">{item.lastScan}</TableCell>
                        <TableCell>
                          <StatusBadge status={item.status} />
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-primary hover:bg-primary-light">
                            <Pencil size={14} className="mr-1" />
                            编辑
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredBeacons.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={10} className="text-center py-8 text-neutral-textTertiary text-sm">
                          暂无匹配数据
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: 扫描热力图 */}
        <TabsContent value="heatmap" className="mt-0">
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-4">
                {/* A Zone */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-primary-light text-primary hover:bg-primary-light">A区</Badge>
                    <span className="text-xs text-neutral-textSecondary">收货区 / 入库通道</span>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                    {aCells.map((cell) => (
                      <div
                        key={cell.cell}
                        className="rounded-md p-3 flex flex-col items-center justify-center gap-1 text-white transition-transform hover:scale-105 cursor-pointer"
                        style={{ backgroundColor: getHeatmapColor(cell.count) }}
                        title={`${cell.cell}: ${cell.count} 个信标扫描`}
                      >
                        <span className="text-xs font-medium opacity-90">{cell.cell}</span>
                        <span className="text-sm font-bold font-number">{cell.count}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* B Zone */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-success-light text-success hover:bg-success-light">B区</Badge>
                    <span className="text-xs text-neutral-textSecondary">存储区 / 高架库</span>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                    {bCells.map((cell) => (
                      <div
                        key={cell.cell}
                        className="rounded-md p-3 flex flex-col items-center justify-center gap-1 text-white transition-transform hover:scale-105 cursor-pointer"
                        style={{ backgroundColor: getHeatmapColor(cell.count) }}
                        title={`${cell.cell}: ${cell.count} 个信标扫描`}
                      >
                        <span className="text-xs font-medium opacity-90">{cell.cell}</span>
                        <span className="text-sm font-bold font-number">{cell.count}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* C Zone */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className="bg-warning-light text-warning hover:bg-warning-light">C区</Badge>
                    <span className="text-xs text-neutral-textSecondary">发货区 / 月台</span>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                    {cCells.map((cell) => (
                      <div
                        key={cell.cell}
                        className="rounded-md p-3 flex flex-col items-center justify-center gap-1 text-white transition-transform hover:scale-105 cursor-pointer"
                        style={{ backgroundColor: getHeatmapColor(cell.count) }}
                        title={`${cell.cell}: ${cell.count} 个信标扫描`}
                      >
                        <span className="text-xs font-medium opacity-90">{cell.cell}</span>
                        <span className="text-sm font-bold font-number">{cell.count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Legend */}
              <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-neutral-border">
                <span className="text-xs text-neutral-textSecondary">图例：</span>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#1e3a8a' }} />
                  <span className="text-xs text-neutral-textSecondary">≥20 (密集)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#2563eb' }} />
                  <span className="text-xs text-neutral-textSecondary">15-19 (较多)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#60a5fa' }} />
                  <span className="text-xs text-neutral-textSecondary">10-14 (中等)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#93c5fd' }} />
                  <span className="text-xs text-neutral-textSecondary">6-9 (较少)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded" style={{ backgroundColor: '#dbeafe' }} />
                  <span className="text-xs text-neutral-textSecondary">&lt;6 (稀疏)</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: 覆盖分析 */}
        <TabsContent value="coverage" className="mt-0">
          <Card className="bg-neutral-surface border-neutral-border">
            <CardContent className="p-4">
              <div className="border border-neutral-border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-neutral-surface-elevated hover:bg-neutral-surface-elevated">
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">网点名称</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">信标数量</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">平均覆盖半径(m)</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">盲区数量</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs">信号重叠区域</TableHead>
                      <TableHead className="text-neutral-textSecondary font-medium text-xs text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {coverageData.map((item) => (
                      <TableRow key={item.site} className="border-b border-neutral-border">
                        <TableCell className="text-sm text-neutral-textPrimary font-medium">
                          <div className="flex items-center gap-1.5">
                            <MapPin size={14} className="text-primary" />
                            {item.site}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">{item.beaconCount}</TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">{item.avgRadius}</TableCell>
                        <TableCell className="text-sm">
                          <span
                            className={cn(
                              'font-number',
                              item.blindSpots === 0
                                ? 'text-success'
                                : item.blindSpots >= 3
                                  ? 'text-danger'
                                  : 'text-warning'
                            )}
                          >
                            {item.blindSpots}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-neutral-textSecondary font-number">{item.overlapAreas}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" className="h-7 px-2 text-primary hover:bg-primary-light">
                            <Eye size={14} className="mr-1" />
                            查看
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
