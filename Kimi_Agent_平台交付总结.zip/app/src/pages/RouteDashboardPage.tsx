import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Route, Clock, AlertTriangle, TrendingUp, Activity,
  Search, MapPin, ChevronRight, Package, Timer,
  Zap, ArrowRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
interface RouteLine {
  id: string;
  code: string;
  name: string;
  fromSite: string;
  toSite: string;
  nodes: RouteNode[];
  avgDuration: string;
  status: 'active' | 'suspended' | 'inactive';
  carrierCount: number;
  completionRate: number;
}

interface RouteNode {
  id: string;
  name: string;
  type: 'start' | 'transit' | 'end';
  duration: string;
  staleThreshold: string;
  currentCarriers: number;
  staleCarriers: number;
}

interface NodeMonitor {
  id: string;
  nodeName: string;
  routeName: string;
  carrierId: string;
  enterTime: string;
  expectedLeave: string;
  actualLeave?: string;
  status: 'normal' | 'stale' | 'critical';
  duration: string;
}

interface EfficiencyStat {
  id: string;
  routeName: string;
  month: string;
  totalTransfers: number;
  avgDuration: string;
  onTimeRate: string;
  cycleCount: number;
  loopExceedCount: number;
}

interface LoopAlarm {
  id: string;
  routeName: string;
  carrierId: string;
  loopCount: number;
  maxLoops: number;
  exceedTime: string;
  site: string;
}

// ==================== Mock Data ====================
const routeLines: RouteLine[] = [
  {
    id: 'R001', code: 'RT-SH-GZ-001', name: '上海浦东 → 广州白云',
    fromSite: '上海浦东仓库', toSite: '广州白云物流园',
    nodes: [
      { id: 'N001', name: '上海浦东仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 120, staleCarriers: 5 },
      { id: 'N002', name: '杭州萧山中转', type: 'transit', duration: '4h', staleThreshold: '6h', currentCarriers: 45, staleCarriers: 2 },
      { id: 'N003', name: '南昌向塘中转', type: 'transit', duration: '8h', staleThreshold: '12h', currentCarriers: 30, staleCarriers: 8 },
      { id: 'N004', name: '广州白云物流园', type: 'end', duration: '12h', staleThreshold: '24h', currentCarriers: 85, staleCarriers: 3 },
    ],
    avgDuration: '12小时', status: 'active', carrierCount: 280, completionRate: 92,
  },
  {
    id: 'R002', code: 'RT-BJ-SZ-002', name: '北京亦庄 → 深圳龙岗',
    fromSite: '北京亦庄仓库', toSite: '深圳龙岗物流园',
    nodes: [
      { id: 'N005', name: '北京亦庄仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 85, staleCarriers: 3 },
      { id: 'N006', name: '济南中转', type: 'transit', duration: '6h', staleThreshold: '8h', currentCarriers: 22, staleCarriers: 1 },
      { id: 'N007', name: '南京中转', type: 'transit', duration: '10h', staleThreshold: '12h', currentCarriers: 38, staleCarriers: 5 },
      { id: 'N008', name: '深圳龙岗物流园', type: 'end', duration: '16h', staleThreshold: '24h', currentCarriers: 60, staleCarriers: 2 },
    ],
    avgDuration: '16小时', status: 'active', carrierCount: 205, completionRate: 88,
  },
  {
    id: 'R003', code: 'RT-CD-SH-003', name: '成都龙泉驿 → 上海浦东',
    fromSite: '成都龙泉驿仓库', toSite: '上海浦东仓库',
    nodes: [
      { id: 'N009', name: '成都龙泉驿仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 65, staleCarriers: 2 },
      { id: 'N010', name: '西安中转', type: 'transit', duration: '8h', staleThreshold: '12h', currentCarriers: 28, staleCarriers: 6 },
      { id: 'N011', name: '武汉东西湖中转', type: 'transit', duration: '14h', staleThreshold: '18h', currentCarriers: 42, staleCarriers: 4 },
      { id: 'N012', name: '上海浦东仓库', type: 'end', duration: '20h', staleThreshold: '24h', currentCarriers: 55, staleCarriers: 1 },
    ],
    avgDuration: '20小时', status: 'active', carrierCount: 190, completionRate: 85,
  },
  {
    id: 'R004', code: 'RT-WH-NB-004', name: '武汉东西湖 → 宁波北仑',
    fromSite: '武汉东西湖仓库', toSite: '宁波北仑物流园',
    nodes: [
      { id: 'N013', name: '武汉东西湖仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 50, staleCarriers: 4 },
      { id: 'N014', name: '合肥中转', type: 'transit', duration: '4h', staleThreshold: '6h', currentCarriers: 18, staleCarriers: 2 },
      { id: 'N015', name: '杭州萧山中转', type: 'transit', duration: '8h', staleThreshold: '10h', currentCarriers: 32, staleCarriers: 3 },
      { id: 'N016', name: '宁波北仑物流园', type: 'end', duration: '10h', staleThreshold: '24h', currentCarriers: 40, staleCarriers: 1 },
    ],
    avgDuration: '10小时', status: 'active', carrierCount: 140, completionRate: 94,
  },
  {
    id: 'R005', code: 'RT-TJ-KM-005', name: '天津滨海 → 昆明呈贡',
    fromSite: '天津滨海仓库', toSite: '昆明呈贡物流园',
    nodes: [
      { id: 'N017', name: '天津滨海仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 35, staleCarriers: 1 },
      { id: 'N018', name: '郑州中转', type: 'transit', duration: '8h', staleThreshold: '10h', currentCarriers: 15, staleCarriers: 3 },
      { id: 'N019', name: '贵阳中转', type: 'transit', duration: '18h', staleThreshold: '24h', currentCarriers: 22, staleCarriers: 7 },
      { id: 'N020', name: '昆明呈贡物流园', type: 'end', duration: '24h', staleThreshold: '30h', currentCarriers: 30, staleCarriers: 2 },
    ],
    avgDuration: '24小时', status: 'suspended', carrierCount: 102, completionRate: 78,
  },
  {
    id: 'R006', code: 'RT-QD-FS-006', name: '青岛黄岛 → 佛山南海',
    fromSite: '青岛黄岛仓库', toSite: '佛山南海物流园',
    nodes: [
      { id: 'N021', name: '青岛黄岛仓库', type: 'start', duration: '0h', staleThreshold: '24h', currentCarriers: 40, staleCarriers: 2 },
      { id: 'N022', name: '连云港中转', type: 'transit', duration: '4h', staleThreshold: '6h', currentCarriers: 12, staleCarriers: 1 },
      { id: 'N023', name: '南京中转', type: 'transit', duration: '10h', staleThreshold: '12h', currentCarriers: 25, staleCarriers: 4 },
      { id: 'N024', name: '佛山南海物流园', type: 'end', duration: '18h', staleThreshold: '24h', currentCarriers: 35, staleCarriers: 2 },
    ],
    avgDuration: '18小时', status: 'active', carrierCount: 112, completionRate: 90,
  },
];

const nodeMonitors: NodeMonitor[] = [
  { id: 'M001', nodeName: '杭州萧山中转', routeName: '上海浦东 → 广州白云', carrierId: 'CA-20250401-015', enterTime: '2025-04-28 10:00', expectedLeave: '2025-04-28 16:00', status: 'stale', duration: '46小时' },
  { id: 'M002', nodeName: '南昌向塘中转', routeName: '上海浦东 → 广州白云', carrierId: 'CA-20250402-032', enterTime: '2025-04-27 08:00', expectedLeave: '2025-04-27 20:00', status: 'critical', duration: '72小时' },
  { id: 'M003', nodeName: '南京中转', routeName: '北京亦庄 → 深圳龙岗', carrierId: 'CA-20250403-008', enterTime: '2025-04-28 14:00', expectedLeave: '2025-04-29 02:00', status: 'stale', duration: '42小时' },
  { id: 'M004', nodeName: '西安中转', routeName: '成都龙泉驿 → 上海浦东', carrierId: 'CA-20250404-021', enterTime: '2025-04-28 20:00', expectedLeave: '2025-04-29 08:00', status: 'normal', duration: '10小时' },
  { id: 'M005', nodeName: '贵阳中转', routeName: '天津滨海 → 昆明呈贡', carrierId: 'CA-20250405-009', enterTime: '2025-04-27 12:00', expectedLeave: '2025-04-28 12:00', status: 'critical', duration: '60小时' },
  { id: 'M006', nodeName: '合肥中转', routeName: '武汉东西湖 → 宁波北仑', carrierId: 'CA-20250406-044', enterTime: '2025-04-29 06:00', expectedLeave: '2025-04-29 12:00', status: 'normal', duration: '4小时' },
  { id: 'M007', nodeName: '南京中转', routeName: '青岛黄岛 → 佛山南海', carrierId: 'CA-20250407-011', enterTime: '2025-04-28 08:00', expectedLeave: '2025-04-28 20:00', status: 'stale', duration: '48小时' },
  { id: 'M008', nodeName: '杭州萧山中转', routeName: '上海浦东 → 广州白云', carrierId: 'CA-20250408-029', enterTime: '2025-04-29 02:00', expectedLeave: '2025-04-29 08:00', status: 'normal', duration: '2小时' },
  { id: 'M009', nodeName: '济南中转', routeName: '北京亦庄 → 深圳龙岗', carrierId: 'CA-20250410-055', enterTime: '2025-04-28 18:00', expectedLeave: '2025-04-29 02:00', status: 'stale', duration: '36小时' },
  { id: 'M010', nodeName: '武汉东西湖中转', routeName: '成都龙泉驿 → 上海浦东', carrierId: 'CA-20250411-003', enterTime: '2025-04-29 04:00', expectedLeave: '2025-04-29 22:00', status: 'normal', duration: '6小时' },
];

const efficiencyStats: EfficiencyStat[] = [
  { id: 'E001', routeName: '上海浦东 → 广州白云', month: '2025-04', totalTransfers: 1560, avgDuration: '11.5小时', onTimeRate: '92%', cycleCount: 3200, loopExceedCount: 45 },
  { id: 'E002', routeName: '北京亦庄 → 深圳龙岗', month: '2025-04', totalTransfers: 1280, avgDuration: '15.8小时', onTimeRate: '88%', cycleCount: 2600, loopExceedCount: 62 },
  { id: 'E003', routeName: '成都龙泉驿 → 上海浦东', month: '2025-04', totalTransfers: 980, avgDuration: '19.2小时', onTimeRate: '85%', cycleCount: 2100, loopExceedCount: 78 },
  { id: 'E004', routeName: '武汉东西湖 → 宁波北仑', month: '2025-04', totalTransfers: 1120, avgDuration: '9.8小时', onTimeRate: '94%', cycleCount: 2400, loopExceedCount: 28 },
  { id: 'E005', routeName: '天津滨海 → 昆明呈贡', month: '2025-04', totalTransfers: 680, avgDuration: '25.5小时', onTimeRate: '78%', cycleCount: 1400, loopExceedCount: 95 },
  { id: 'E006', routeName: '青岛黄岛 → 佛山南海', month: '2025-04', totalTransfers: 820, avgDuration: '17.2小时', onTimeRate: '90%', cycleCount: 1750, loopExceedCount: 52 },
];

const loopAlarms: LoopAlarm[] = [
  { id: 'L001', routeName: '上海浦东 → 广州白云', carrierId: 'CA-20250401-015', loopCount: 35, maxLoops: 30, exceedTime: '2025-04-29 08:00', site: '广州白云物流园' },
  { id: 'L002', routeName: '北京亦庄 → 深圳龙岗', carrierId: 'CA-20250402-032', loopCount: 28, maxLoops: 25, exceedTime: '2025-04-29 06:30', site: '深圳龙岗物流园' },
  { id: 'L003', routeName: '成都龙泉驿 → 上海浦东', carrierId: 'CA-20250403-008', loopCount: 42, maxLoops: 35, exceedTime: '2025-04-29 10:00', site: '上海浦东仓库' },
  { id: 'L004', routeName: '武汉东西湖 → 宁波北仑', carrierId: 'CA-20250404-021', loopCount: 18, maxLoops: 20, exceedTime: '2025-04-28 14:00', site: '宁波北仑物流园' },
  { id: 'L005', routeName: '天津滨海 → 昆明呈贡', carrierId: 'CA-20250405-009', loopCount: 38, maxLoops: 30, exceedTime: '2025-04-29 09:00', site: '昆明呈贡物流园' },
  { id: 'L006', routeName: '青岛黄岛 → 佛山南海', carrierId: 'CA-20250406-044', loopCount: 22, maxLoops: 25, exceedTime: '2025-04-28 16:00', site: '佛山南海物流园' },
  { id: 'L007', routeName: '上海浦东 → 广州白云', carrierId: 'CA-20250407-011', loopCount: 32, maxLoops: 30, exceedTime: '2025-04-29 07:00', site: '广州白云物流园' },
  { id: 'L008', routeName: '北京亦庄 → 深圳龙岗', carrierId: 'CA-20250408-029', loopCount: 26, maxLoops: 25, exceedTime: '2025-04-28 22:00', site: '深圳龙岗物流园' },
];

// ==================== Helpers ====================
function getStatusBadge(status: string) {
  switch (status) {
    case 'active': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">运行中</Badge>;
    case 'suspended': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">暂停</Badge>;
    case 'inactive': return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">停用</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

function getNodeStatusBadge(status: string) {
  switch (status) {
    case 'normal': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">正常</Badge>;
    case 'stale': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">滞留</Badge>;
    case 'critical': return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">严重滞留</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function RouteDashboardPage() {
  const [activeTab, setActiveTab] = useState('overview');
  const [search, setSearch] = useState('');
  const [selectedRoute, setSelectedRoute] = useState<RouteLine | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  const filteredRoutes = useMemo(() => {
    return routeLines.filter(r => r.name.toLowerCase().includes(search.toLowerCase()) || r.code.toLowerCase().includes(search.toLowerCase()));
  }, [search]);

  const stats = useMemo(() => ({
    total: routeLines.length,
    active: routeLines.filter(r => r.status === 'active').length,
    avgDuration: '15.3小时',
    staleNodes: nodeMonitors.filter(n => n.status === 'stale' || n.status === 'critical').length,
    loopAlarms: loopAlarms.length,
  }), []);

  const openRouteDetail = (route: RouteLine) => {
    setSelectedRoute(route);
    setDetailOpen(true);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">流转看板</h1>
        <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">线路监控 · 节点滞留 · 流转效率 · 循环超期</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '线路总数', value: stats.total, icon: Route, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '运行中', value: stats.active, icon: Activity, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '平均时长', value: stats.avgDuration, icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: '滞留节点', value: stats.staleNodes, icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '循环超期', value: stats.loopAlarms, icon: TrendingUp, color: 'text-red-600', bg: 'bg-red-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-[480px]">
          <TabsTrigger value="overview">线路总览</TabsTrigger>
          <TabsTrigger value="nodes">节点监控</TabsTrigger>
          <TabsTrigger value="efficiency">流转效率</TabsTrigger>
          <TabsTrigger value="loops">超期报警</TabsTrigger>
        </TabsList>

        {/* Tab 1: Route Overview */}
        <TabsContent value="overview" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索线路名称或编码..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {filteredRoutes.map(route => (
              <motion.div key={route.id} initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}>
                <Card className={cn("cursor-pointer hover:shadow-md transition-shadow", route.status === 'suspended' && "opacity-80")} onClick={() => openRouteDetail(route)}>
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-[var(--neutral-text-primary)]">{route.name}</span>
                      {getStatusBadge(route.status)}
                    </div>
                    <div className="text-xs text-[var(--neutral-text-tertiary)]">{route.code}</div>
                    <div className="flex items-center gap-1 text-sm text-[var(--neutral-text-secondary)]">
                      <MapPin className="w-3.5 h-3.5" /> {route.fromSite}
                      <ChevronRight className="w-3 h-3" />
                      <MapPin className="w-3.5 h-3.5" /> {route.toSite}
                    </div>
                    <div className="flex items-center gap-4 text-xs text-[var(--neutral-text-secondary)]">
                      <span className="flex items-center gap-1"><Package className="w-3 h-3" /> {route.carrierCount} 载具</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {route.avgDuration}</span>
                      <span className="flex items-center gap-1"><Activity className="w-3 h-3" /> {route.completionRate}% 完成率</span>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-[var(--neutral-text-secondary)]">流转进度</span>
                        <span className="text-[var(--neutral-text-primary)] font-medium">{route.completionRate}%</span>
                      </div>
                      <Progress value={route.completionRate} className="h-2" />
                    </div>
                    <div className="flex gap-1 pt-1">
                      {route.nodes.map((node, idx) => (
                        <div key={node.id} className="flex items-center gap-1">
                          <div className={cn("w-2.5 h-2.5 rounded-full", node.staleCarriers > 5 ? "bg-red-500" : node.staleCarriers > 0 ? "bg-amber-400" : "bg-emerald-400")} />
                          <span className="text-[10px] text-[var(--neutral-text-secondary)] truncate max-w-[60px]">{node.name}</span>
                          {idx < route.nodes.length - 1 && <ArrowRight className="w-2 h-2 text-[var(--neutral-text-tertiary)]" />}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Tab 2: Node Monitor */}
        <TabsContent value="nodes" className="space-y-4">
          <div className="flex items-center gap-3">
            <Select defaultValue="all">
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="节点状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="normal">正常</SelectItem>
                <SelectItem value="stale">滞留</SelectItem>
                <SelectItem value="critical">严重滞留</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">节点名称</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">所属线路</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">载具编号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">进入时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">预计离开</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">当前时长</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {nodeMonitors.map(m => (
                    <TableRow key={m.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{m.nodeName}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{m.routeName}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.carrierId}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.enterTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{m.expectedLeave}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)] font-medium">{m.duration}</TableCell>
                      <TableCell>{getNodeStatusBadge(m.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Efficiency */}
        <TabsContent value="efficiency" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">线路名称</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">统计月份</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">调拨次数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">平均时长</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">准点率</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">循环次数</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">超期次数</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {efficiencyStats.map(e => (
                    <TableRow key={e.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{e.routeName}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{e.month}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{e.totalTransfers}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{e.avgDuration}</TableCell>
                      <TableCell>
                        <span className={cn("font-medium", (parseInt(e.onTimeRate) >= 90) ? "text-emerald-600" : (parseInt(e.onTimeRate) >= 80) ? "text-amber-600" : "text-red-600")}>
                          {e.onTimeRate}
                        </span>
                      </TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{e.cycleCount}</TableCell>
                      <TableCell className="text-red-600 font-medium">{e.loopExceedCount}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 4: Loop Alarms */}
        <TabsContent value="loops" className="space-y-4">
          <div className="space-y-3">
            {loopAlarms.map(alarm => (
              <Card key={alarm.id} className="border-l-4 border-l-red-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[var(--neutral-text-primary)]">{alarm.carrierId}</span>
                        <Badge className="bg-red-100 text-red-700">循环超期</Badge>
                      </div>
                      <div className="text-sm text-[var(--neutral-text-primary)]">
                        线路：<span className="text-[var(--neutral-text-secondary)]">{alarm.routeName}</span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-[var(--neutral-text-secondary)]">
                        <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> 当前循环：{alarm.loopCount} 次</span>
                        <span className="flex items-center gap-1"><Timer className="w-3 h-3" /> 阈值：{alarm.maxLoops} 次</span>
                        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> 当前位置：{alarm.site}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> 超期时间：{alarm.exceedTime}</span>
                      </div>
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-[var(--neutral-text-secondary)]">循环进度 ({alarm.loopCount}/{alarm.maxLoops})</span>
                          <span className="text-red-600 font-medium">超期 {alarm.loopCount - alarm.maxLoops} 次</span>
                        </div>
                        <div className="h-2 bg-[var(--neutral-background)] rounded-full overflow-hidden">
                          <div className="h-full bg-red-500 rounded-full" style={{ width: `${Math.min((alarm.loopCount / alarm.maxLoops) * 100, 100)}%` }} />
                        </div>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => alert(`处理循环超期：${alarm.carrierId}`)}>处理</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Route Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>线路详情</DialogTitle></DialogHeader>
          {selectedRoute && (
            <div className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-[var(--neutral-text-primary)]">{selectedRoute.name}</div>
                  <div className="text-xs text-[var(--neutral-text-tertiary)]">{selectedRoute.code}</div>
                </div>
                {getStatusBadge(selectedRoute.status)}
              </div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">
                {selectedRoute.fromSite} → {selectedRoute.toSite}
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-[var(--neutral-background)] rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-[var(--neutral-text-primary)]">{selectedRoute.carrierCount}</div>
                  <div className="text-xs text-[var(--neutral-text-secondary)]">载具总数</div>
                </div>
                <div className="bg-[var(--neutral-background)] rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-[var(--neutral-text-primary)]">{selectedRoute.avgDuration}</div>
                  <div className="text-xs text-[var(--neutral-text-secondary)]">平均时长</div>
                </div>
                <div className="bg-[var(--neutral-background)] rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-[var(--neutral-text-primary)]">{selectedRoute.completionRate}%</div>
                  <div className="text-xs text-[var(--neutral-text-secondary)]">完成率</div>
                </div>
              </div>
              <div>
                <div className="text-sm font-medium text-[var(--neutral-text-primary)] mb-3">节点时间轴</div>
                <div className="space-y-3">
                  {selectedRoute.nodes.map((node, idx) => (
                    <div key={node.id} className="flex items-start gap-3">
                      <div className="flex flex-col items-center">
                        <div className={cn("w-3 h-3 rounded-full", idx === 0 ? "bg-emerald-500" : idx === selectedRoute.nodes.length - 1 ? "bg-blue-500" : "bg-amber-400")} />
                        {idx < selectedRoute.nodes.length - 1 && <div className="w-0.5 h-8 bg-[var(--neutral-border)] mt-1" />}
                      </div>
                      <div className="flex-1 pb-3">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-[var(--neutral-text-primary)]">{node.name}</span>
                          <Badge variant="outline" className="text-[10px]">{node.type === 'start' ? '起点' : node.type === 'end' ? '终点' : '中转'}</Badge>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-[var(--neutral-text-secondary)] mt-1">
                          <span>流转时长：{node.duration}</span>
                          <span>呆滞阈值：{node.staleThreshold}</span>
                          <span>在库载具：{node.currentCarriers}</span>
                          {node.staleCarriers > 0 && <span className="text-red-500">滞留：{node.staleCarriers}</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
