import { useState, useMemo, useCallback } from 'react';
import {
  Plus,
  Upload,
  Download,
  Search,
  ChevronDown,
  Filter,
  MoreHorizontal,
  Eye,
  Pencil,
  ArrowLeftRight,
  Settings2,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Check,
  FileSpreadsheet,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import type { Carrier } from '@/lib/mockData';
import { getStatusLabel, getStatusColor } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
} from '@/components/ui/drawer';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// --- Types ---
type SortField = 'code' | 'name' | 'type' | 'status' | 'orgName' | 'siteName' | 'createdAt';
type SortDirection = 'asc' | 'desc';
type CommType = 'all' | 'GPS' | 'bluetooth';

// --- Status Tag Component ---
function StatusTag({ status, text }: { status: string; text: string }) {
  const color = getStatusColor(status);
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: `${color}15`, color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {text}
    </span>
  );
}

// --- KPI Card ---
function KPICard({ label, value, subtext, color }: { label: string; value: string; subtext?: string; color: string }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-card flex-1">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1 h-4 rounded-full" style={{ backgroundColor: color }} />
        <span className="text-xs text-[#475569]">{label}</span>
      </div>
      <div className="text-[28px] font-semibold text-[#0F172A] leading-tight">{value}</div>
      {subtext && <div className="text-xs text-[#94A3B8] mt-1">{subtext}</div>}
    </div>
  );
}

// --- Pagination Component ---
function PaginationBar({
  page,
  totalPages,
  pageSize,
  onPageChange,
  onPageSizeChange,
  total,
}: {
  page: number;
  totalPages: number;
  pageSize: number;
  onPageChange: (p: number) => void;
  onPageSizeChange: (s: number) => void;
  total: number;
}) {
  const pageSizes = [20, 50, 100];
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
      <div className="flex items-center gap-2 text-sm text-[#475569]">
        <span>每页</span>
        <Select
          value={String(pageSize)}
          onValueChange={(v) => onPageSizeChange(Number(v))}
        >
          <SelectTrigger className="h-8 w-[70px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {pageSizes.map((s) => (
              <SelectItem key={s} value={String(s)}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span>条</span>
        <span className="ml-4">共 {total} 条</span>
      </div>
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(Math.max(1, page - 1))}
          disabled={page <= 1}
        >
          <ChevronLeft size={16} />
        </Button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let pageNum: number;
          if (totalPages <= 5) {
            pageNum = i + 1;
          } else if (page <= 3) {
            pageNum = i + 1;
          } else if (page >= totalPages - 2) {
            pageNum = totalPages - 4 + i;
          } else {
            pageNum = page - 2 + i;
          }
          return (
            <Button
              key={pageNum}
              variant={pageNum === page ? 'default' : 'ghost'}
              size="icon-sm"
              className={cn(
                'w-8 h-8 text-xs',
                pageNum === page && 'bg-[#2563EB] text-white'
              )}
              onClick={() => onPageChange(pageNum)}
            >
              {pageNum}
            </Button>
          );
        })}
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={() => onPageChange(Math.min(totalPages, page + 1))}
          disabled={page >= totalPages}
        >
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
}

// --- Threshold Settings Dialog ---
function ThresholdDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>阈值设置</DialogTitle>
          <DialogDescription>配置载具报警阈值参数</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">呆滞阈值（天）</label>
            <Input type="number" defaultValue={7} />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">超时阈值（小时）</label>
            <Input type="number" defaultValue={24} />
          </div>
          <div className="col-span-2 flex items-center justify-between py-2">
            <span className="text-sm text-[#475569]">空满载检测</span>
            <Switch defaultChecked />
          </div>
          <div className="col-span-2 flex items-center justify-between py-2">
            <span className="text-sm text-[#475569]">标签分离报警</span>
            <Switch defaultChecked />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">温度下限（°C）</label>
            <Input type="number" defaultValue={-20} />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">温度上限（°C）</label>
            <Input type="number" defaultValue={60} />
          </div>
          <div className="col-span-2 flex items-center justify-between py-2">
            <span className="text-sm text-[#475569]">丢失报警</span>
            <Switch defaultChecked />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Transfer Dialog ---
function TransferDialog({ open, onClose, carrier }: { open: boolean; onClose: () => void; carrier?: Carrier }) {
  const [step, setStep] = useState(0);
  const steps = ['选择调拨类型', '选择目标网点', '确认提交'];

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); setStep(0); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>载具调拨</DialogTitle>
          <DialogDescription>
            {carrier && `调拨载具：${carrier.code} ${carrier.name}`}
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center gap-2 py-4">
          {steps.map((s, i) => (
            <div key={i} className="flex items-center gap-2 flex-1">
              <div className={cn(
                'w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium',
                i <= step ? 'bg-[#2563EB] text-white' : 'bg-[#E2E8F0] text-[#94A3B8]'
              )}>
                {i < step ? <Check size={14} /> : i + 1}
              </div>
              <span className={cn('text-xs', i <= step ? 'text-[#0F172A]' : 'text-[#94A3B8]')}>{s}</span>
              {i < steps.length - 1 && <div className={cn('h-px flex-1', i < step ? 'bg-[#2563EB]' : 'bg-[#E2E8F0]')} />}
            </div>
          ))}
        </div>
        {step === 0 && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">调拨类型</label>
              <Select defaultValue="normal">
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="normal">普通调拨</SelectItem>
                  <SelectItem value="urgent">紧急调拨</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}
        {step === 1 && (
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">目标网点</label>
              <Select>
                <SelectTrigger><SelectValue placeholder="选择目标网点" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="site-1">上海浦东工厂仓库A</SelectItem>
                  <SelectItem value="site-2">上海浦东工厂仓库B</SelectItem>
                  <SelectItem value="site-3">宁波生产基地仓库</SelectItem>
                  <SelectItem value="site-4">广州仓储中心</SelectItem>
                  <SelectItem value="site-5">深圳配送中心</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">期望到达时间</label>
              <Input type="datetime-local" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">备注</label>
              <textarea className="w-full min-h-[80px] rounded-md border border-[#E2E8F0] px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]/10" placeholder="请输入备注" />
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="py-4 space-y-3">
            <div className="bg-[#F8FAFC] rounded-lg p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-[#475569]">载具</span><span className="text-[#0F172A]">{carrier?.code}</span></div>
              <div className="flex justify-between"><span className="text-[#475569]">调拨类型</span><span className="text-[#0F172A]">普通调拨</span></div>
              <div className="flex justify-between"><span className="text-[#475569]">目标网点</span><span className="text-[#0F172A]">广州仓储中心</span></div>
            </div>
          </div>
        )}
        <DialogFooter>
          {step > 0 && <Button variant="outline" onClick={() => setStep(step - 1)}>上一步</Button>}
          {step < 2 ? (
            <Button onClick={() => setStep(step + 1)}>下一步</Button>
          ) : (
            <Button onClick={onClose}>确认提交</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Import Dialog ---
function ImportDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>批量导入载具</DialogTitle>
          <DialogDescription>上传 Excel 文件批量导入载具数据</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <FileSpreadsheet size={16} className="text-[#10B981]" />
            <span className="text-[#2563EB] cursor-pointer hover:underline">下载导入模板</span>
          </div>
          <div className="border-2 border-dashed border-[#CBD5E1] rounded-lg p-8 text-center hover:border-[#2563EB] hover:bg-[#EFF6FF] transition-colors cursor-pointer">
            <Upload size={32} className="mx-auto mb-2 text-[#94A3B8]" />
            <p className="text-sm text-[#475569]">拖拽文件到此处，或点击上传</p>
            <p className="text-xs text-[#94A3B8] mt-1">支持 .xlsx, .xls 格式，最大 10MB</p>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">冲突处理策略</label>
            <Select defaultValue="skip">
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="skip">跳过重复</SelectItem>
                <SelectItem value="overwrite">覆盖重复</SelectItem>
                <SelectItem value="prompt">提示处理</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>开始导入</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Detail Drawer ---
function CarrierDetailDrawer({ carrier, open, onClose, onEdit }: {
  carrier?: Carrier;
  open: boolean;
  onClose: () => void;
  onEdit: () => void;
}) {
  if (!carrier) return null;

  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[560px] w-3/4">
        <DrawerHeader>
          <div className="flex items-center justify-between">
            <DrawerTitle className="text-xl font-semibold font-mono">{carrier.code}</DrawerTitle>
            <StatusTag status={carrier.status} text={getStatusLabel(carrier.status)} />
          </div>
          <DrawerDescription>{carrier.name}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4">
          <Tabs defaultValue="basic">
            <TabsList className="w-full">
              <TabsTrigger value="basic" className="flex-1">基本信息</TabsTrigger>
              <TabsTrigger value="device" className="flex-1">绑定设备</TabsTrigger>
              <TabsTrigger value="material" className="flex-1">绑定物料</TabsTrigger>
              <TabsTrigger value="threshold" className="flex-1">阈值设置</TabsTrigger>
              <TabsTrigger value="transfer" className="flex-1">调拨记录</TabsTrigger>
              <TabsTrigger value="log" className="flex-1">操作日志</TabsTrigger>
            </TabsList>
            <TabsContent value="basic" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                {[
                  ['载具编号', carrier.code],
                  ['载具名称', carrier.name],
                  ['载具类型', carrier.type],
                  ['状态', getStatusLabel(carrier.status)],
                  ['所属组织', carrier.orgName],
                  ['当前网点', carrier.siteName],
                  ['绑定设备', carrier.deviceName || '未绑定'],
                  ['购买日期', carrier.purchaseDate],
                  ['价格', `¥${carrier.price}`],
                  ['当前位置', carrier.currentLocation],
                  ['最近使用', carrier.lastUsedAt],
                  ['创建时间', carrier.createdAt],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div className="text-xs text-[#94A3B8] mb-1">{label}</div>
                    <div className="text-sm text-[#0F172A]">{value}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex justify-end">
                <Button onClick={onEdit}><Pencil size={14} className="mr-2" />编辑</Button>
              </div>
            </TabsContent>
            <TabsContent value="device" className="mt-4">
              {carrier.deviceName ? (
                <div className="space-y-3">
                  <div className="bg-[#F8FAFC] rounded-lg p-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div><div className="text-xs text-[#94A3B8]">设备名称</div><div className="text-sm">{carrier.deviceName}</div></div>
                      <div><div className="text-xs text-[#94A3B8]">设备类型</div><div className="text-sm">GPS定位器</div></div>
                      <div><div className="text-xs text-[#94A3B8]">IMEI</div><div className="text-sm font-mono">86000000000000{carrier.code.slice(-2)}</div></div>
                      <div><div className="text-xs text-[#94A3B8]">在线状态</div><StatusTag status="online" text="在线" /></div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-[#94A3B8]">未绑定设备</div>
              )}
            </TabsContent>
            <TabsContent value="material" className="mt-4">
              <div className="text-center py-8 text-[#94A3B8]">未绑定物料</div>
            </TabsContent>
            <TabsContent value="threshold" className="mt-4">
              <div className="space-y-4">
                {[
                  ['呆滞阈值', '7 天'],
                  ['超时阈值', '24 小时'],
                  ['空满载检测', '已开启'],
                  ['标签分离报警', '已开启'],
                  ['温度报警范围', '-20°C ~ 60°C'],
                  ['丢失报警', '已开启'],
                ].map(([label, value]) => (
                  <div key={label} className="flex justify-between py-2 border-b border-[#E2E8F0]">
                    <span className="text-sm text-[#475569]">{label}</span>
                    <span className="text-sm text-[#0F172A]">{value}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="transfer" className="mt-4">
              <div className="space-y-3">
                {[
                  { date: '2024-12-15 10:30', from: '上海浦东工厂仓库A', to: '宁波生产基地仓库', status: 'completed' },
                  { date: '2024-12-01 14:00', from: '宁波生产基地仓库', to: '上海浦东工厂仓库A', status: 'completed' },
                ].map((t, i) => (
                  <div key={i} className="bg-[#F8FAFC] rounded-lg p-3 text-sm">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[#94A3B8]">{t.date}</span>
                      <StatusTag status={t.status} text={getStatusLabel(t.status)} />
                    </div>
                    <div className="flex items-center gap-2 text-[#475569]">
                      <span>{t.from}</span>
                      <ArrowLeftRight size={14} />
                      <span>{t.to}</span>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="log" className="mt-4">
              <div className="space-y-3">
                {[
                  { time: '2024-12-20 09:00', action: '状态变更', user: '张三', detail: '状态从"正常"变更为"维修中"' },
                  { time: '2024-12-15 10:30', action: '调拨', user: '系统', detail: '从上海浦东工厂仓库A调拨至宁波生产基地仓库' },
                  { time: '2024-12-01 08:00', action: '创建', user: '管理员', detail: '载具入库' },
                ].map((log, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-[#2563EB]" />
                      {i < 2 && <div className="w-px h-full bg-[#E2E8F0]" />}
                    </div>
                    <div className="pb-4">
                      <div className="text-xs text-[#94A3B8]">{log.time}</div>
                      <div className="text-sm font-medium text-[#0F172A]">{log.action} · {log.user}</div>
                      <div className="text-sm text-[#475569]">{log.detail}</div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>关闭</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

// --- Edit/Create Form Drawer ---
function CarrierFormDrawer({ carrier, open, onClose }: {
  carrier?: Carrier;
  open: boolean;
  onClose: () => void;
}) {
  const isEdit = !!carrier;
  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[560px] w-3/4">
        <DrawerHeader>
          <DrawerTitle>{isEdit ? '编辑载具' : '新增载具'}</DrawerTitle>
          <DrawerDescription>{isEdit ? `编辑载具 ${carrier?.code}` : '填写载具信息'}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">载具编号 {isEdit ? '' : '*'}</label>
              <Input defaultValue={carrier?.code} disabled={isEdit} placeholder="CJ000001" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">载具名称 *</label>
              <Input defaultValue={carrier?.name} placeholder="请输入载具名称" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">载具类型 *</label>
              <Select defaultValue={carrier?.type || '托盘'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="托盘">托盘</SelectItem>
                  <SelectItem value="周转箱">周转箱</SelectItem>
                  <SelectItem value="料架">料架</SelectItem>
                  <SelectItem value="集装箱">集装箱</SelectItem>
                  <SelectItem value="笼车">笼车</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">规格参数</label>
              <Input placeholder="如 1200×1000×150mm" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">所属组织</label>
              <Select defaultValue={carrier?.orgId || 'org-2'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="org-1">云载科技（总部）</SelectItem>
                  <SelectItem value="org-2">华东汽车制造有限公司</SelectItem>
                  <SelectItem value="org-3">南方物流集团</SelectItem>
                  <SelectItem value="org-4">北方供应链管理有限公司</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">当前网点</label>
              <Select defaultValue={carrier?.siteId || 'site-1'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="site-1">上海浦东工厂仓库A</SelectItem>
                  <SelectItem value="site-2">上海浦东工厂仓库B</SelectItem>
                  <SelectItem value="site-3">宁波生产基地仓库</SelectItem>
                  <SelectItem value="site-4">广州仓储中心</SelectItem>
                  <SelectItem value="site-5">深圳配送中心</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">备注</label>
            <textarea className="w-full min-h-[80px] rounded-md border border-[#E2E8F0] px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]/10" placeholder="请输入备注" />
          </div>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>{isEdit ? '保存' : '创建'}</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

// ==================== MAIN PAGE ====================
export default function VehicleManagementPage() {
  const { carriers } = useMockData();

  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [commType, setCommType] = useState<CommType>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [orgFilter, setOrgFilter] = useState<string>('all');
  const [siteFilter, setSiteFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDir, setSortDir] = useState<SortDirection>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showAdvancedFilter, setShowAdvancedFilter] = useState(false);

  // Dialog/Drawer states
  const [detailCarrier, setDetailCarrier] = useState<Carrier | undefined>();
  const [showDetail, setShowDetail] = useState(false);
  const [editCarrier, setEditCarrier] = useState<Carrier | undefined>();
  const [showForm, setShowForm] = useState(false);
  const [showThreshold, setShowThreshold] = useState(false);
  const [showTransfer, setShowTransfer] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Mock enrich carrier with extra display fields
  const enrichedCarriers = useMemo(() => {
    const commTypes: Array<'GPS' | '蓝牙'> = ['GPS', '蓝牙', 'GPS', '蓝牙', 'GPS'];
    const projects = ['汽车零部件项目', '电子产品项目', '食品冷链项目', '化工原料项目', '医药配送项目'];
    const loadStatuses = ['空载', '满载', '半载', '空载', '满载'];
    const transferStatuses = ['normal', 'in_transit', 'completed', 'normal', 'pending_receipt'];

    return carriers.map((c, i) => ({
      ...c,
      commType: c.deviceId ? commTypes[i % commTypes.length] : '无',
      project: projects[i % projects.length],
      loadStatus: loadStatuses[i % loadStatuses.length],
      transferStatus: transferStatuses[i % transferStatuses.length],
    }));
  }, [carriers]);

  // Filter & Sort
  const filtered = useMemo(() => {
    let data = [...enrichedCarriers];

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      data = data.filter((c) =>
        c.code.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.type.includes(q)
      );
    }

    // Comm type
    if (commType !== 'all') {
      data = data.filter((c) => c.commType === commType);
    }

    // Status
    if (statusFilter !== 'all') {
      data = data.filter((c) => c.status === statusFilter);
    }

    // Org
    if (orgFilter !== 'all') {
      data = data.filter((c) => c.orgId === orgFilter);
    }

    // Site
    if (siteFilter !== 'all') {
      data = data.filter((c) => c.siteId === siteFilter);
    }

    // Sort
    data.sort((a, b) => {
      const dir = sortDir === 'asc' ? 1 : -1;
      if (sortField === 'code') return dir * a.code.localeCompare(b.code);
      if (sortField === 'name') return dir * a.name.localeCompare(b.name);
      if (sortField === 'type') return dir * a.type.localeCompare(b.type);
      if (sortField === 'status') return dir * a.status.localeCompare(b.status);
      if (sortField === 'orgName') return dir * a.orgName.localeCompare(b.orgName);
      if (sortField === 'siteName') return dir * a.siteName.localeCompare(b.siteName);
      return dir * a.createdAt.localeCompare(b.createdAt);
    });

    return data;
  }, [enrichedCarriers, searchQuery, commType, statusFilter, orgFilter, siteFilter, sortField, sortDir]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Selection
  const allSelectedOnPage = pageData.length > 0 && pageData.every((c) => selectedIds.has(c.id));
  const someSelected = selectedIds.size > 0;

  const toggleSelectAll = useCallback(() => {
    if (allSelectedOnPage) {
      const next = new Set(selectedIds);
      pageData.forEach((c) => next.delete(c.id));
      setSelectedIds(next);
    } else {
      const next = new Set(selectedIds);
      pageData.forEach((c) => next.add(c.id));
      setSelectedIds(next);
    }
  }, [allSelectedOnPage, pageData, selectedIds]);

  const toggleSelectOne = useCallback((id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  }, [selectedIds]);

  const clearSelection = useCallback(() => setSelectedIds(new Set()), []);

  const handleSort = useCallback((field: SortField) => {
    setSortField((prev) => {
      if (prev === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return prev;
      }
      setSortDir('asc');
      return field;
    });
  }, []);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronDown size={12} className="text-[#CBD5E1]" />;
    return sortDir === 'asc'
      ? <ChevronDown size={12} className="text-[#2563EB] rotate-180" />
      : <ChevronDown size={12} className="text-[#2563EB]" />;
  };

  // KPI data
  const kpiData = [
    { label: '载具总数', value: String(carriers.length), subtext: '全部载具', color: '#2563EB' },
    { label: '正常载具', value: String(carriers.filter((c) => c.status === 'normal').length), subtext: `${(carriers.filter((c) => c.status === 'normal').length / carriers.length * 100).toFixed(1)}%`, color: '#10B981' },
    { label: '在途载具', value: String(carriers.filter((c) => c.status === 'cleaning').length), subtext: '运输中', color: '#06B6D4' },
    { label: '今日报警', value: '23', subtext: '需关注', color: '#EF4444' },
  ];

  const statusOptions = [
    { value: 'all', label: '全部状态' },
    { value: 'normal', label: '正常' },
    { value: 'repairing', label: '维修中' },
    { value: 'cleaning', label: '清洁中' },
    { value: 'damaged', label: '已损坏' },
    { value: 'scrapped', label: '已报废' },
  ];

  const orgOptions = [
    { value: 'all', label: '全部组织' },
    { value: 'org-2', label: '华东汽车制造有限公司' },
    { value: 'org-3', label: '南方物流集团' },
    { value: 'org-4', label: '北方供应链管理有限公司' },
  ];

  const siteOptions = [
    { value: 'all', label: '全部网点' },
    { value: 'site-1', label: '上海浦东工厂仓库A' },
    { value: 'site-2', label: '上海浦东工厂仓库B' },
    { value: 'site-3', label: '宁波生产基地仓库' },
    { value: 'site-4', label: '广州仓储中心' },
    { value: 'site-5', label: '深圳配送中心' },
    { value: 'site-6', label: '天津港仓库' },
    { value: 'site-7', label: '青岛物流中心' },
    { value: 'site-8', label: '杭州运营中心仓库' },
  ];

  const handleExport = (type: string) => {
    setShowExportMenu(false);
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `载具数据_${type}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 animate-fade-in-up">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">载具管理</h1>
          <Badge variant="secondary" className="text-xs">共 {filtered.length} 条</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => { setEditCarrier(undefined); setShowForm(true); }}>
            <Plus size={16} className="mr-1" />新增载具
          </Button>
          <Button variant="outline" onClick={() => setShowImport(true)}>
            <Upload size={16} className="mr-1" />导入
          </Button>
          <DropdownMenu open={showExportMenu} onOpenChange={setShowExportMenu}>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download size={16} className="mr-1" />导出
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleExport('current')}>导出当前页</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExport('all')}>导出全部</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExport('selected')}>导出选中项</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="flex gap-4">
        {kpiData.map((kpi) => (
          <KPICard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg p-4 shadow-card space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          {/* Comm type tabs */}
          <div className="flex items-center bg-[#F1F5F9] rounded-md p-[3px]">
            {([
              { key: 'all', label: '全部' },
              { key: 'GPS', label: 'GPS' },
              { key: 'bluetooth', label: '蓝牙' },
            ] as const).map((tab) => (
              <button
                key={tab.key}
                onClick={() => setCommType(tab.key)}
                className={cn(
                  'px-3 py-1.5 text-xs font-medium rounded-md transition-all',
                  commType === tab.key
                    ? 'bg-white text-[#2563EB] shadow-sm'
                    : 'text-[#475569] hover:text-[#0F172A]'
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Status filter */}
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 w-[140px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Org filter */}
          <Select value={orgFilter} onValueChange={setOrgFilter}>
            <SelectTrigger className="h-8 w-[180px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {orgOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Site filter */}
          <Select value={siteFilter} onValueChange={setSiteFilter}>
            <SelectTrigger className="h-8 w-[160px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {siteOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex-1" />

          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              placeholder="搜索载具编号、名称..."
              className="h-8 w-[240px] pl-8 text-xs"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-xs"
            onClick={() => setShowAdvancedFilter(!showAdvancedFilter)}
          >
            <Filter size={14} className="mr-1" />
            高级筛选
            <ChevronDown size={12} className={cn('ml-1 transition-transform', showAdvancedFilter && 'rotate-180')} />
          </Button>
        </div>

        {/* Advanced filters */}
        {showAdvancedFilter && (
          <div className="pt-3 border-t border-[#E2E8F0] grid grid-cols-4 gap-3">
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">载具编号</label>
              <Input placeholder="模糊搜索" className="h-8 text-xs" />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">载具类型</label>
              <Select>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部类型" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="托盘">托盘</SelectItem>
                  <SelectItem value="周转箱">周转箱</SelectItem>
                  <SelectItem value="料架">料架</SelectItem>
                  <SelectItem value="集装箱">集装箱</SelectItem>
                  <SelectItem value="笼车">笼车</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">通信方式</label>
              <Select>
                <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="全部" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="GPS">GPS</SelectItem>
                  <SelectItem value="bluetooth">蓝牙</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <label className="text-xs text-[#94A3B8]">绑定设备</label>
              <Input placeholder="设备编号/IMEI" className="h-8 text-xs" />
            </div>
            <div className="col-span-4 flex justify-end gap-2">
              <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => {
                setStatusFilter('all');
                setOrgFilter('all');
                setSiteFilter('all');
                setCommType('all');
                setSearchQuery('');
              }}>重置</Button>
              <Button size="sm" className="h-8 text-xs">筛选</Button>
            </div>
          </div>
        )}
      </div>

      {/* Batch Operation Bar */}
      {someSelected && (
        <div className="bg-[#EFF6FF] rounded-md px-4 py-2 flex items-center justify-between animate-fade-in-up">
          <div className="flex items-center gap-3 text-sm">
            <span className="text-[#0F172A]">已选中 <strong className="text-[#2563EB]">{selectedIds.size}</strong> 项</span>
            <button className="text-[#2563EB] text-xs hover:underline" onClick={toggleSelectAll}>全选当前页</button>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="h-7 text-xs"><ArrowLeftRight size={12} className="mr-1" />批量调拨</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs"><Settings2 size={12} className="mr-1" />批量设置状态</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs"><Download size={12} className="mr-1" />批量导出</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs text-[#EF4444] hover:text-[#EF4444]"><Trash2 size={12} className="mr-1" />批量删除</Button>
            <button className="text-xs text-[#475569] hover:text-[#0F172A] ml-2" onClick={clearSelection}>取消选择</button>
          </div>
        </div>
      )}

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="w-[40px]">
                  <Checkbox
                    checked={allSelectedOnPage}
                    onCheckedChange={toggleSelectAll}
                    aria-label="Select all"
                  />
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('code')}>
                  <div className="flex items-center gap-1">载具编号 <SortIcon field="code" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('name')}>
                  <div className="flex items-center gap-1">载具名称 <SortIcon field="name" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('type')}>
                  <div className="flex items-center gap-1">类型 <SortIcon field="type" /></div>
                </TableHead>
                <TableHead>运维状态</TableHead>
                <TableHead>所属组织</TableHead>
                <TableHead>所属项目</TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('siteName')}>
                  <div className="flex items-center gap-1">当前网点 <SortIcon field="siteName" /></div>
                </TableHead>
                <TableHead>定位方式</TableHead>
                <TableHead>空满载</TableHead>
                <TableHead>调拨状态</TableHead>
                <TableHead className="w-[120px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={12} className="text-center py-16 text-[#94A3B8]">
                    <div className="flex flex-col items-center gap-2">
                      <Search size={48} className="text-[#CBD5E1]" />
                      <p className="text-sm">未找到匹配的载具</p>
                      <Button variant="outline" size="sm" onClick={() => {
                        setSearchQuery('');
                        setStatusFilter('all');
                        setCommType('all');
                        setOrgFilter('all');
                        setSiteFilter('all');
                      }}>清除筛选</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                pageData.map((carrier, idx) => (
                  <TableRow
                    key={carrier.id}
                    className={cn(
                      'h-12',
                      idx % 2 === 1 && 'bg-[#F8FAFC]',
                      selectedIds.has(carrier.id) && 'bg-[#EFF6FF] border-l-[3px] border-l-[#2563EB]'
                    )}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.has(carrier.id)}
                        onCheckedChange={() => toggleSelectOne(carrier.id)}
                        aria-label={`Select ${carrier.code}`}
                      />
                    </TableCell>
                    <TableCell>
                      <button
                        className="font-mono text-[13px] text-[#2563EB] hover:underline"
                        onClick={() => { setDetailCarrier(carrier); setShowDetail(true); }}
                      >
                        {carrier.code}
                      </button>
                    </TableCell>
                    <TableCell className="text-sm text-[#0F172A]">{carrier.name}</TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#F1F5F9] text-[#475569]">
                        {carrier.type}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusTag status={carrier.status} text={getStatusLabel(carrier.status)} />
                    </TableCell>
                    <TableCell className="text-sm text-[#475569]">{carrier.orgName}</TableCell>
                    <TableCell className="text-sm text-[#475569]">{carrier.project}</TableCell>
                    <TableCell className="text-sm text-[#475569]">{carrier.siteName}</TableCell>
                    <TableCell>
                      {carrier.commType !== '无' ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#EFF6FF] text-[#2563EB]">
                          {carrier.commType}
                        </span>
                      ) : (
                        <span className="text-xs text-[#94A3B8]">未绑定</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className={cn(
                        'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
                        carrier.loadStatus === '满载' ? 'bg-[#ECFDF5] text-[#10B981]' :
                        carrier.loadStatus === '空载' ? 'bg-[#F1F5F9] text-[#475569]' :
                        'bg-[#FFFBEB] text-[#F59E0B]'
                      )}>
                        {carrier.loadStatus}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusTag status={carrier.transferStatus} text={getStatusLabel(carrier.transferStatus)} />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setDetailCarrier(carrier); setShowDetail(true); }}>
                          <Eye size={14} className="text-[#475569]" />
                        </Button>
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setEditCarrier(carrier); setShowForm(true); }}>
                          <Pencil size={14} className="text-[#475569]" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" className="h-7 w-7">
                              <MoreHorizontal size={14} className="text-[#475569]" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => { setDetailCarrier(carrier); setShowTransfer(true); }}>
                              <ArrowLeftRight size={14} className="mr-2" />调拨
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setShowThreshold(true)}>
                              <Settings2 size={14} className="mr-2" />阈值设置
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => { setEditCarrier(carrier); setShowForm(true); }}>
                              <Pencil size={14} className="mr-2" />编辑
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-[#EF4444]">
                              <Trash2 size={14} className="mr-2" />删除
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <PaginationBar
          page={currentPage}
          totalPages={totalPages}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={(s) => { setPageSize(s); setPage(1); }}
          total={filtered.length}
        />
      </div>

      {/* Detail Drawer */}
      <CarrierDetailDrawer
        carrier={detailCarrier}
        open={showDetail}
        onClose={() => setShowDetail(false)}
        onEdit={() => { setShowDetail(false); setEditCarrier(detailCarrier); setShowForm(true); }}
      />

      {/* Form Drawer */}
      <CarrierFormDrawer
        carrier={editCarrier}
        open={showForm}
        onClose={() => setShowForm(false)}
      />

      {/* Threshold Dialog */}
      <ThresholdDialog open={showThreshold} onClose={() => setShowThreshold(false)} />

      {/* Transfer Dialog */}
      <TransferDialog open={showTransfer} onClose={() => setShowTransfer(false)} carrier={detailCarrier} />

      {/* Import Dialog */}
      <ImportDialog open={showImport} onClose={() => setShowImport(false)} />
    </div>
  );
}
