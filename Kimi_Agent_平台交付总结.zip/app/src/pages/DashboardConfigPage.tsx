import { useState, useCallback, useMemo } from 'react';
import GridLayout from 'react-grid-layout';
import { useContainerWidth } from 'react-grid-layout';
import type { Layout } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Pencil,
  Copy,
  Trash2,
  Eye,
  EyeOff,
  Download,
  Share2,
  Save,
  LayoutTemplate,
  Settings,
  GripVertical,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import WidgetRenderer from '@/components/dashboard/WidgetRenderer';
import {
  AddWidgetDialog,
  EditWidgetDialog,
  ShareDialog,
  PageManageDialog,
} from '@/components/dashboard/DashboardDialogs';

export interface WidgetConfig {
  i: string;
  type:
    | 'kpi'
    | 'bar'
    | 'line'
    | 'pie'
    | 'table'
    | 'rank'
    | 'combo'
    | 'funnel'
    | 'heatmap'
    | 'map';
  title: string;
  dataSource: string;
  dimension: string;
  metric: string;
  aggregation: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface DashboardPage {
  id: string;
  name: string;
  widgets: WidgetConfig[];
  filters: Record<string, string>;
}

const TEMPLATES: { id: string; name: string; widgets: WidgetConfig[] }[] = [
  {
    id: 'ops',
    name: '运营总览',
    widgets: [
      {
        i: 't1-kpi-1',
        type: 'kpi',
        title: '总载具数',
        dataSource: 'vehicle',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't1-kpi-2',
        type: 'kpi',
        title: '在途数量',
        dataSource: 'transfer',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 3,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't1-kpi-3',
        type: 'kpi',
        title: '设备在线率',
        dataSource: 'device',
        dimension: 'org',
        metric: 'percentage',
        aggregation: 'avg',
        x: 6,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't1-kpi-4',
        type: 'kpi',
        title: '本月调拨量',
        dataSource: 'transfer',
        dimension: 'time',
        metric: 'count',
        aggregation: 'count',
        x: 9,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't1-line-1',
        type: 'line',
        title: '运营趋势',
        dataSource: 'vehicle',
        dimension: 'time',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 2,
        w: 6,
        h: 5,
      },
      {
        i: 't1-bar-1',
        type: 'bar',
        title: '各组织载具分布',
        dataSource: 'vehicle',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 6,
        y: 2,
        w: 6,
        h: 5,
      },
    ],
  },
  {
    id: 'device',
    name: '设备监控',
    widgets: [
      {
        i: 't2-kpi-1',
        type: 'kpi',
        title: '设备总数',
        dataSource: 'device',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't2-kpi-2',
        type: 'kpi',
        title: '在线设备',
        dataSource: 'device',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 3,
        y: 0,
        w: 3,
        h: 2,
      },
      {
        i: 't2-table-1',
        type: 'table',
        title: '设备状态明细',
        dataSource: 'device',
        dimension: 'site',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 2,
        w: 6,
        h: 6,
      },
      {
        i: 't2-pie-1',
        type: 'pie',
        title: '设备类型分布',
        dataSource: 'device',
        dimension: 'type',
        metric: 'count',
        aggregation: 'count',
        x: 6,
        y: 2,
        w: 6,
        h: 6,
      },
    ],
  },
  {
    id: 'inventory',
    name: '库存管理',
    widgets: [
      {
        i: 't3-kpi-1',
        type: 'kpi',
        title: '库存总量',
        dataSource: 'material',
        dimension: 'org',
        metric: 'count',
        aggregation: 'sum',
        x: 0,
        y: 0,
        w: 4,
        h: 2,
      },
      {
        i: 't3-kpi-2',
        type: 'kpi',
        title: '呆滞库存',
        dataSource: 'material',
        dimension: 'org',
        metric: 'count',
        aggregation: 'sum',
        x: 4,
        y: 0,
        w: 4,
        h: 2,
      },
      {
        i: 't3-kpi-3',
        type: 'kpi',
        title: '周转天数',
        dataSource: 'material',
        dimension: 'org',
        metric: 'time',
        aggregation: 'avg',
        x: 8,
        y: 0,
        w: 4,
        h: 2,
      },
      {
        i: 't3-bar-1',
        type: 'bar',
        title: '库存趋势',
        dataSource: 'material',
        dimension: 'time',
        metric: 'count',
        aggregation: 'sum',
        x: 0,
        y: 2,
        w: 6,
        h: 5,
      },
      {
        i: 't3-table-1',
        type: 'table',
        title: '库存明细',
        dataSource: 'material',
        dimension: 'site',
        metric: 'count',
        aggregation: 'sum',
        x: 6,
        y: 2,
        w: 6,
        h: 5,
      },
    ],
  },
  {
    id: 'transport',
    name: '运输效率',
    widgets: [
      {
        i: 't4-line-1',
        type: 'line',
        title: '运输时效趋势',
        dataSource: 'transfer',
        dimension: 'time',
        metric: 'time',
        aggregation: 'avg',
        x: 0,
        y: 0,
        w: 6,
        h: 5,
      },
      {
        i: 't4-combo-1',
        type: 'combo',
        title: '运量与时效',
        dataSource: 'transfer',
        dimension: 'time',
        metric: 'count',
        aggregation: 'count',
        x: 6,
        y: 0,
        w: 6,
        h: 5,
      },
      {
        i: 't4-map-1',
        type: 'map',
        title: '网点分布',
        dataSource: 'site',
        dimension: 'site',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 5,
        w: 12,
        h: 4,
      },
    ],
  },
  {
    id: 'project',
    name: '项目视角',
    widgets: [
      {
        i: 't5-funnel-1',
        type: 'funnel',
        title: '项目转化漏斗',
        dataSource: 'project',
        dimension: 'org',
        metric: 'count',
        aggregation: 'count',
        x: 0,
        y: 0,
        w: 6,
        h: 5,
      },
      {
        i: 't5-heatmap-1',
        type: 'heatmap',
        title: '项目活跃度热力图',
        dataSource: 'project',
        dimension: 'time',
        metric: 'count',
        aggregation: 'count',
        x: 6,
        y: 0,
        w: 6,
        h: 5,
      },
      {
        i: 't5-rank-1',
        type: 'rank',
        title: '项目进度排名',
        dataSource: 'project',
        dimension: 'org',
        metric: 'percentage',
        aggregation: 'avg',
        x: 0,
        y: 5,
        w: 12,
        h: 4,
      },
    ],
  },
];

function createDefaultPages(): DashboardPage[] {
  return [
    {
      id: 'page-1',
      name: '页面一',
      widgets: [
        {
          i: 'w1',
          type: 'kpi',
          title: '总载具数',
          dataSource: 'vehicle',
          dimension: 'org',
          metric: 'count',
          aggregation: 'count',
          x: 0,
          y: 0,
          w: 3,
          h: 2,
        },
        {
          i: 'w2',
          type: 'kpi',
          title: '在途数量',
          dataSource: 'transfer',
          dimension: 'org',
          metric: 'count',
          aggregation: 'count',
          x: 3,
          y: 0,
          w: 3,
          h: 2,
        },
        {
          i: 'w3',
          type: 'bar',
          title: '载具类型分布',
          dataSource: 'vehicle',
          dimension: 'type',
          metric: 'count',
          aggregation: 'count',
          x: 0,
          y: 2,
          w: 6,
          h: 5,
        },
        {
          i: 'w4',
          type: 'line',
          title: '使用趋势',
          dataSource: 'vehicle',
          dimension: 'time',
          metric: 'count',
          aggregation: 'count',
          x: 6,
          y: 0,
          w: 6,
          h: 7,
        },
      ],
      filters: {
        timeRange: 'week',
        org: 'self',
        site: 'all',
        vehicleType: 'all',
        dimension: 'time',
      },
    },
    {
      id: 'page-2',
      name: '页面二',
      widgets: [
        {
          i: 'w5',
          type: 'pie',
          title: '网点分布',
          dataSource: 'site',
          dimension: 'site',
          metric: 'count',
          aggregation: 'count',
          x: 0,
          y: 0,
          w: 4,
          h: 5,
        },
        {
          i: 'w6',
          type: 'table',
          title: '报警记录',
          dataSource: 'alarm',
          dimension: 'time',
          metric: 'count',
          aggregation: 'count',
          x: 4,
          y: 0,
          w: 8,
          h: 5,
        },
      ],
      filters: {
        timeRange: 'today',
        org: 'self',
        site: 'all',
        vehicleType: 'all',
        dimension: 'time',
      },
    },
  ];
}

export default function DashboardConfigPage() {
  const [pages, setPages] = useState<DashboardPage[]>(createDefaultPages);
  const [currentPageId, setCurrentPageId] = useState<string>('page-1');
  const [isPreview, setIsPreview] = useState(false);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [editWidget, setEditWidget] = useState<WidgetConfig | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [shareDialogOpen, setShareDialogOpen] = useState(false);
  const [pageManageOpen, setPageManageOpen] = useState(false);
  const [tempFilters, setTempFilters] = useState<Record<string, string>>({});
  const { width, containerRef } = useContainerWidth();

  const currentPage = useMemo(
    () => pages.find((p) => p.id === currentPageId)!,
    [pages, currentPageId]
  );

  const layout = useMemo(
    () =>
      currentPage.widgets.map((w) => ({
        i: w.i,
        x: w.x,
        y: w.y,
        w: w.w,
        h: w.h,
        minW: 1,
        minH: 1,
      })),
    [currentPage.widgets]
  );

  const handleLayoutChange = useCallback(
    (newLayout: Layout) => {
      setPages((prev) =>
        prev.map((p) => {
          if (p.id !== currentPageId) return p;
          return {
            ...p,
            widgets: p.widgets.map((w) => {
              const l = newLayout.find((item) => item.i === w.i);
              if (!l) return w;
              return { ...w, x: l.x, y: l.y, w: l.w, h: l.h };
            }),
          };
        })
      );
    },
    [currentPageId]
  );

  const handleAddWidget = useCallback(
    (config: Omit<WidgetConfig, 'i' | 'x' | 'y'>) => {
      const id = `widget-${Date.now()}`;
      const existingLayout = currentPage.widgets.map((w) => ({
        i: w.i,
        x: w.x,
        y: w.y,
        w: w.w,
        h: w.h,
      }));
      let y = 0;
      if (existingLayout.length > 0) {
        y = Math.max(...existingLayout.map((l) => l.y + l.h));
      }
      const newWidget: WidgetConfig = {
        ...config,
        i: id,
        x: 0,
        y,
      };
      setPages((prev) =>
        prev.map((p) =>
          p.id === currentPageId
            ? { ...p, widgets: [...p.widgets, newWidget] }
            : p
        )
      );
    },
    [currentPage, currentPageId]
  );

  const handleEditWidget = useCallback((widget: WidgetConfig) => {
    setEditWidget(widget);
    setEditDialogOpen(true);
  }, []);

  const handleSaveEdit = useCallback(
    (updated: WidgetConfig) => {
      setPages((prev) =>
        prev.map((p) => {
          if (p.id !== currentPageId) return p;
          return {
            ...p,
            widgets: p.widgets.map((w) => (w.i === updated.i ? updated : w)),
          };
        })
      );
    },
    [currentPageId]
  );

  const handleCopyWidget = useCallback(
    (widget: WidgetConfig) => {
      const id = `widget-${Date.now()}`;
      const newWidget: WidgetConfig = {
        ...widget,
        i: id,
        x: (widget.x + widget.w) % 12,
        y: widget.y + widget.h,
      };
      setPages((prev) =>
        prev.map((p) =>
          p.id === currentPageId
            ? { ...p, widgets: [...p.widgets, newWidget] }
            : p
        )
      );
    },
    [currentPageId]
  );

  const handleDeleteWidget = useCallback(
    (widgetId: string) => {
      setPages((prev) =>
        prev.map((p) =>
          p.id === currentPageId
            ? { ...p, widgets: p.widgets.filter((w) => w.i !== widgetId) }
            : p
        )
      );
    },
    [currentPageId]
  );

  const addPage = useCallback(() => {
    const id = `page-${Date.now()}`;
    setPages((prev) => [
      ...prev,
      {
        id,
        name: `页面 ${prev.length + 1}`,
        widgets: [],
        filters: {
          timeRange: 'week',
          org: 'self',
          site: 'all',
          vehicleType: 'all',
          dimension: 'time',
        },
      },
    ]);
    setCurrentPageId(id);
  }, []);

  const renamePage = useCallback((id: string, name: string) => {
    setPages((prev) => prev.map((p) => (p.id === id ? { ...p, name } : p)));
  }, []);

  const deletePage = useCallback(
    (id: string) => {
      if (pages.length <= 1) return;
      setPages((prev) => prev.filter((p) => p.id !== id));
      if (currentPageId === id) {
        const first = pages.find((p) => p.id !== id);
        if (first) setCurrentPageId(first.id);
      }
    },
    [pages, currentPageId]
  );

  const applyTemplate = useCallback(
    (templateId: string) => {
      const template = TEMPLATES.find((t) => t.id === templateId);
      if (!template) return;
      const newWidgets = template.widgets.map((w) => ({
        ...w,
        i: `${templateId}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      }));
      setPages((prev) =>
        prev.map((p) =>
          p.id === currentPageId ? { ...p, widgets: newWidgets } : p
        )
      );
    },
    [currentPageId]
  );

  const applyFilters = useCallback(() => {
    setPages((prev) =>
      prev.map((p) =>
        p.id === currentPageId ? { ...p, filters: { ...p.filters, ...tempFilters } } : p
      )
    );
  }, [currentPageId, tempFilters]);

  const activeFilters = currentPage.filters;

  return (
    <div className="flex flex-col h-full bg-neutral-background">
      {/* Template bar */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-neutral-border bg-neutral-surface shrink-0">
        <div className="flex items-center gap-1.5 text-sm font-semibold text-neutral-textSecondary">
          <LayoutTemplate className="size-4" />
          模板
        </div>
        <div className="flex gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              onClick={() => applyTemplate(t.id)}
              className="flex items-center gap-1 rounded-md border border-neutral-border bg-neutral-background px-3 py-1.5 text-xs text-neutral-textPrimary hover:border-primary hover:text-primary transition-colors"
            >
              {t.name}
              <ChevronRight className="size-3" />
            </button>
          ))}
        </div>
      </div>

      {/* Global filters */}
      <div className="flex items-center gap-3 px-4 py-2.5 border-b border-neutral-border bg-neutral-surface shrink-0 flex-wrap">
        <div className="flex items-center gap-1.5 text-sm text-neutral-textSecondary">
          <Filter className="size-4" />
          筛选
        </div>
        <Select
          value={tempFilters.timeRange || activeFilters.timeRange || 'week'}
          onValueChange={(v) =>
            setTempFilters((prev) => ({ ...prev, timeRange: v }))
          }
        >
          <SelectTrigger className="h-8 text-xs w-[120px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">今日</SelectItem>
            <SelectItem value="week">本周</SelectItem>
            <SelectItem value="month">本月</SelectItem>
            <SelectItem value="year">本年</SelectItem>
            <SelectItem value="custom">自定义</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={tempFilters.org || activeFilters.org || 'self'}
          onValueChange={(v) =>
            setTempFilters((prev) => ({ ...prev, org: v }))
          }
        >
          <SelectTrigger className="h-8 text-xs w-[120px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="self">本组织</SelectItem>
            <SelectItem value="all">全部组织</SelectItem>
            <SelectItem value="sub">下级组织</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={tempFilters.site || activeFilters.site || 'all'}
          onValueChange={(v) =>
            setTempFilters((prev) => ({ ...prev, site: v }))
          }
        >
          <SelectTrigger className="h-8 text-xs w-[120px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部网点</SelectItem>
            <SelectItem value="beijing">北京</SelectItem>
            <SelectItem value="shanghai">上海</SelectItem>
            <SelectItem value="guangzhou">广州</SelectItem>
            <SelectItem value="shenzhen">深圳</SelectItem>
          </SelectContent>
        </Select>

        <Select
          value={tempFilters.vehicleType || activeFilters.vehicleType || 'all'}
          onValueChange={(v) =>
            setTempFilters((prev) => ({ ...prev, vehicleType: v }))
          }
        >
          <SelectTrigger className="h-8 text-xs w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部类型</SelectItem>
            <SelectItem value="box">周转箱</SelectItem>
            <SelectItem value="pallet">托盘</SelectItem>
            <SelectItem value="cart">手推车</SelectItem>
            <SelectItem value="tote">料箱</SelectItem>
          </SelectContent>
        </Select>

        <Button size="sm" variant="default" className="h-8 text-xs" onClick={applyFilters}>
          应用筛选
        </Button>
      </div>

      {/* Page tabs + toolbar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-neutral-border bg-neutral-surface shrink-0">
        <div className="flex items-center gap-1">
          {pages.map((page) => (
            <button
              key={page.id}
              onClick={() => setCurrentPageId(page.id)}
              className={cn(
                'relative flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm transition-colors',
                page.id === currentPageId
                  ? 'bg-primary-light text-primary font-medium'
                  : 'text-neutral-textSecondary hover:text-neutral-textPrimary hover:bg-neutral-surface-elevated'
              )}
            >
              {page.name}
              {page.id === currentPageId && (
                <motion.div
                  layoutId="active-tab"
                  className="absolute inset-0 rounded-md border border-primary"
                  transition={{ type: 'spring', bounce: 0.15, duration: 0.4 }}
                />
              )}
            </button>
          ))}
          <Button
            size="sm"
            variant="ghost"
            className="h-7 px-2 text-neutral-textTertiary"
            onClick={() => setPageManageOpen(true)}
          >
            <Settings className="size-4" />
          </Button>
        </div>

        <div className="flex items-center gap-1.5">
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs"
            onClick={() => setAddDialogOpen(true)}
          >
            <Plus className="size-3.5 mr-1" />
            添加组件
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs"
            onClick={() => setIsPreview((v) => !v)}
          >
            {isPreview ? (
              <>
                <EyeOff className="size-3.5 mr-1" />
                编辑
              </>
            ) : (
              <>
                <Eye className="size-3.5 mr-1" />
                预览
              </>
            )}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs"
            onClick={() => alert('导出 JSON / PNG 功能模拟')}
          >
            <Download className="size-3.5 mr-1" />
            导出
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs"
            onClick={() => setShareDialogOpen(true)}
          >
            <Share2 className="size-3.5 mr-1" />
            分享
          </Button>
          <Button
            size="sm"
            variant="default"
            className="h-8 text-xs"
            onClick={() => alert('看板保存成功')}
          >
            <Save className="size-3.5 mr-1" />
            保存
          </Button>
        </div>
      </div>

      {/* Grid canvas */}
      <div ref={containerRef} className="flex-1 overflow-auto p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPageId}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
          >
            {currentPage.widgets.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[300px] text-neutral-textTertiary">
                <LayoutTemplate className="size-10 mb-3" />
                <p className="text-sm">当前页面暂无组件，点击右上角“添加组件”开始配置</p>
              </div>
            ) : (
              <GridLayout
                width={width}
                gridConfig={{ cols: 12, rowHeight: 60, margin: [10, 10], containerPadding: [0, 0], maxRows: Infinity }}
                dragConfig={{ enabled: !isPreview, bounded: false, threshold: 3 }}
                resizeConfig={{ enabled: !isPreview, handles: ['se'] }}
                layout={layout}
                onLayoutChange={handleLayoutChange}
                className="min-h-[200px]"
              >
                {currentPage.widgets.map((widget) => (
                  <div
                    key={widget.i}
                    className={cn(
                      'bg-neutral-surface rounded-lg border border-neutral-border shadow-card overflow-hidden',
                      !isPreview && 'group'
                    )}
                  >
                    {!isPreview && (
                      <div className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditWidget(widget);
                          }}
                          className="flex items-center justify-center w-7 h-7 rounded-md bg-neutral-surface border border-neutral-border text-neutral-textSecondary hover:text-primary hover:border-primary transition-colors"
                        >
                          <Pencil className="size-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCopyWidget(widget);
                          }}
                          className="flex items-center justify-center w-7 h-7 rounded-md bg-neutral-surface border border-neutral-border text-neutral-textSecondary hover:text-primary hover:border-primary transition-colors"
                        >
                          <Copy className="size-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteWidget(widget.i);
                          }}
                          className="flex items-center justify-center w-7 h-7 rounded-md bg-neutral-surface border border-neutral-border text-neutral-textSecondary hover:text-danger hover:border-danger transition-colors"
                        >
                          <Trash2 className="size-3" />
                        </button>
                      </div>
                    )}
                    <div
                      className={cn(
                        'flex items-center gap-1.5 px-3 py-2 border-b border-neutral-border text-sm font-medium text-neutral-textPrimary',
                        !isPreview && 'cursor-move'
                      )}
                    >
                      {!isPreview && <GripVertical className="size-3.5 text-neutral-textTertiary shrink-0" />}
                      <span className="truncate">{widget.title}</span>
                    </div>
                    <div className="h-[calc(100%-36px)]">
                      <WidgetRenderer widget={widget} filters={activeFilters} />
                    </div>
                  </div>
                ))}
              </GridLayout>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Add component button at bottom */}
        {!isPreview && (
          <div className="flex justify-center mt-6 mb-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setAddDialogOpen(true)}
              className="gap-1 text-neutral-textSecondary"
            >
              <Plus className="size-4" />
              添加组件
            </Button>
          </div>
        )}
      </div>

      {/* Dialogs */}
      <AddWidgetDialog
        open={addDialogOpen}
        onOpenChange={setAddDialogOpen}
        onAdd={handleAddWidget}
      />
      <EditWidgetDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        widget={editWidget}
        onSave={handleSaveEdit}
      />
      <ShareDialog open={shareDialogOpen} onOpenChange={setShareDialogOpen} />
      <PageManageDialog
        open={pageManageOpen}
        onOpenChange={setPageManageOpen}
        pages={pages}
        currentPageId={currentPageId}
        onAddPage={addPage}
        onRenamePage={renamePage}
        onDeletePage={deletePage}
        onSwitchPage={setCurrentPageId}
      />
    </div>
  );
}
