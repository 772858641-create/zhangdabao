import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Download,
  FileSpreadsheet,
  FileText,
  FileCode,
  Clock,
  Calendar,
  RotateCw,
  Trash2,
  CheckCircle,
  XCircle,
  Search,
  Plus,
  Filter,
  FileDown,
  FileSearch,
  Package,
  ArrowRightLeft,
  Bell,
  BarChart3,
  Users,
  Loader2,
  Eye,
  X,
  Play,
  FolderArchive,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';

// ------------------------------------------------------------------
// Types
// ------------------------------------------------------------------
type ExportModule = 'carrier' | 'transfer' | 'alarm' | 'statistics' | 'user' | 'vehicle' | 'device';
type ExportType = 'excel' | 'csv' | 'pdf';
type ExportStatus = 'generating' | 'completed' | 'failed' | 'expired';
type ScheduleCycle = 'daily' | 'weekly' | 'monthly';
type ScheduleStatus = 'enabled' | 'disabled';

interface ExportRecord {
  id: string;
  module: ExportModule;
  type: ExportType;
  filterSummary: string;
  operator: string;
  createdAt: string;
  completedAt: string | null;
  fileSize: string | null;
  status: ExportStatus;
  progress?: number;
}

interface ScheduledTask {
  id: string;
  name: string;
  module: ExportModule;
  type: ExportType;
  cycle: ScheduleCycle;
  nextRunAt: string;
  lastRunAt: string | null;
  status: ScheduleStatus;
}

// ------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------
const MODULE_CONFIG: Record<ExportModule, { label: string; icon: React.ElementType; color: string }> = {
  carrier: { label: '载具管理', icon: Package, color: '#2563EB' },
  transfer: { label: '调拨管理', icon: ArrowRightLeft, color: '#8B5CF6' },
  alarm: { label: '报警中心', icon: Bell, color: '#EF4444' },
  statistics: { label: '数据统计', icon: BarChart3, color: '#10B981' },
  user: { label: '用户管理', icon: Users, color: '#F59E0B' },
  vehicle: { label: '车辆管理', icon: Package, color: '#06B6D4' },
  device: { label: '设备管理', icon: Package, color: '#EC4899' },
};

const TYPE_CONFIG: Record<ExportType, { label: string; icon: React.ElementType; color: string; ext: string }> = {
  excel: { label: 'Excel', icon: FileSpreadsheet, color: '#10B981', ext: 'xlsx' },
  csv: { label: 'CSV', icon: FileCode, color: '#06B6D4', ext: 'csv' },
  pdf: { label: 'PDF', icon: FileText, color: '#EF4444', ext: 'pdf' },
};

const STATUS_CONFIG: Record<ExportStatus, { color: string; bg: string; label: string; icon: React.ElementType }> = {
  generating: { color: '#2563EB', bg: '#EFF6FF', label: '生成中', icon: Loader2 },
  completed: { color: '#10B981', bg: '#ECFDF5', label: '已完成', icon: CheckCircle },
  failed: { color: '#EF4444', bg: '#FEF2F2', label: '失败', icon: XCircle },
  expired: { color: '#94A3B8', bg: '#F1F5F9', label: '已过期', icon: Clock },
};

const CYCLE_CONFIG: Record<ScheduleCycle, { label: string }> = {
  daily: { label: '每天' },
  weekly: { label: '每周' },
  monthly: { label: '每月' },
};

const SCHEDULE_STATUS_CONFIG: Record<ScheduleStatus, { color: string; bg: string; label: string }> = {
  enabled: { color: '#10B981', bg: '#ECFDF5', label: '启用' },
  disabled: { color: '#94A3B8', bg: '#F1F5F9', label: '停用' },
};

const TAB_OPTIONS = [
  { key: 'records', label: '导出记录', icon: FileDown },
  { key: 'scheduled', label: '定时任务', icon: Clock },
] as const;

const MODULE_OPTIONS: { key: ExportModule | 'all'; label: string }[] = [
  { key: 'all', label: '全部模块' },
  { key: 'carrier', label: '载具管理' },
  { key: 'transfer', label: '调拨管理' },
  { key: 'alarm', label: '报警中心' },
  { key: 'statistics', label: '数据统计' },
  { key: 'user', label: '用户管理' },
  { key: 'vehicle', label: '车辆管理' },
  { key: 'device', label: '设备管理' },
];

const STATUS_OPTIONS: { key: ExportStatus | 'all'; label: string }[] = [
  { key: 'all', label: '全部状态' },
  { key: 'completed', label: '已完成' },
  { key: 'generating', label: '生成中' },
  { key: 'failed', label: '失败' },
  { key: 'expired', label: '已过期' },
];

// ------------------------------------------------------------------
// Mock Data
// ------------------------------------------------------------------
const MODULES: ExportModule[] = ['carrier', 'transfer', 'alarm', 'statistics', 'user', 'vehicle', 'device'];
const TYPES: ExportType[] = ['excel', 'csv', 'pdf'];
const STATUSES: ExportStatus[] = ['completed', 'completed', 'completed', 'completed', 'completed', 'completed', 'generating', 'failed', 'failed', 'failed', 'expired', 'expired'];
const OPERATORS = ['系统管理员', '张三', '李四', '王五', '赵六', '孙七', '周八'];

const MOCK_RECORDS: ExportRecord[] = Array.from({ length: 25 }, (_, i) => {
  const idx = i + 1;
  const module = MODULES[i % MODULES.length];
  const type = TYPES[i % TYPES.length];
  const status = STATUSES[i % STATUSES.length];
  const operator = OPERATORS[i % OPERATORS.length];
  const day = (i % 30) + 1;
  const createdAt = `2024-12-${String(day).padStart(2, '0')} ${String((i % 24)).padStart(2, '0')}:${String((i % 60)).padStart(2, '0')}:00`;
  const completedAt = status !== 'generating'
    ? `2024-12-${String(day).padStart(2, '0')} ${String(((i % 24) + 1) % 24).padStart(2, '0')}:${String((i % 60)).padStart(2, '0')}:00`
    : null;
  const fileSize = status === 'completed' || status === 'expired'
    ? `${(Math.random() * 10 + 0.5).toFixed(1)} MB`
    : null;

  const filterSummaries = [
    '全部数据',
    '上海运营中心',
    '2024-12-01 ~ 2024-12-31',
    '状态=正常',
    '类型=托盘',
    '未处理报警',
    '本周数据',
    '华东大区',
    '活跃载具',
    '按网点分组',
  ];

  return {
    id: `EXP${String(idx).padStart(6, '0')}`,
    module,
    type,
    filterSummary: filterSummaries[i % filterSummaries.length],
    operator,
    createdAt,
    completedAt,
    fileSize,
    status,
    progress: status === 'generating' ? Math.floor(Math.random() * 80 + 10) : undefined,
  };
});

const MOCK_SCHEDULED_TASKS: ScheduledTask[] = [
  { id: 'SCH001', name: '每日载具报表', module: 'carrier', type: 'excel', cycle: 'daily', nextRunAt: '2024-12-21 06:00:00', lastRunAt: '2024-12-20 06:00:00', status: 'enabled' },
  { id: 'SCH002', name: '周度调拨汇总', module: 'transfer', type: 'pdf', cycle: 'weekly', nextRunAt: '2024-12-23 08:00:00', lastRunAt: '2024-12-16 08:00:00', status: 'enabled' },
  { id: 'SCH003', name: '月度统计报告', module: 'statistics', type: 'excel', cycle: 'monthly', nextRunAt: '2025-01-01 09:00:00', lastRunAt: '2024-12-01 09:00:00', status: 'enabled' },
  { id: 'SCH004', name: '报警记录导出', module: 'alarm', type: 'csv', cycle: 'daily', nextRunAt: '2024-12-21 07:30:00', lastRunAt: '2024-12-20 07:30:00', status: 'enabled' },
  { id: 'SCH005', name: '用户数据备份', module: 'user', type: 'excel', cycle: 'weekly', nextRunAt: '2024-12-22 02:00:00', lastRunAt: '2024-12-15 02:00:00', status: 'disabled' },
  { id: 'SCH006', name: '车辆运营日报', module: 'vehicle', type: 'pdf', cycle: 'daily', nextRunAt: '2024-12-21 10:00:00', lastRunAt: '2024-12-20 10:00:00', status: 'enabled' },
  { id: 'SCH007', name: '设备状态周报', module: 'device', type: 'csv', cycle: 'weekly', nextRunAt: '2024-12-23 11:00:00', lastRunAt: '2024-12-16 11:00:00', status: 'enabled' },
  { id: 'SCH008', name: '季度综合分析', module: 'statistics', type: 'excel', cycle: 'monthly', nextRunAt: '2025-01-01 14:00:00', lastRunAt: '2024-10-01 14:00:00', status: 'disabled' },
];

// ------------------------------------------------------------------
// Sub-components
// ------------------------------------------------------------------

function Tag({ label, color, bg, className }: { label: string; color: string; bg: string; className?: string }) {
  return (
    <span
      className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', className)}
      style={{ color, backgroundColor: bg }}
    >
      {label}
    </span>
  );
}

function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4 hover:shadow-card-hover transition-shadow duration-200">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-[#475569] mb-1">{title}</p>
        <p className="text-[28px] font-semibold leading-tight" style={{ color: '#0F172A' }}>{value}</p>
        {subtext && <p className="text-xs text-[#94A3B8] mt-1">{subtext}</p>}
      </div>
    </div>
  );
}

/** Add Scheduled Task Modal */
function AddScheduleModal({ onClose, onSave }: { onClose: () => void; onSave: (task: ScheduledTask) => void }) {
  const [form, setForm] = useState<Partial<ScheduledTask>>({
    name: '',
    module: 'carrier',
    type: 'excel',
    cycle: 'daily',
    status: 'enabled',
  });

  const handleSave = () => {
    if (!form.name) {
      alert('请输入任务名称');
      return;
    }
    const newTask: ScheduledTask = {
      id: `SCH${String(Date.now()).slice(-3)}`,
      name: form.name || '',
      module: (form.module as ExportModule) || 'carrier',
      type: (form.type as ExportType) || 'excel',
      cycle: (form.cycle as ScheduleCycle) || 'daily',
      nextRunAt: '2024-12-21 06:00:00',
      lastRunAt: null,
      status: (form.status as ScheduleStatus) || 'enabled',
    };
    onSave(newTask);
    onClose();
  };

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-50"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[560px] bg-white rounded-xl shadow-modal z-50 flex flex-col max-h-[85vh]"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
            <h3 className="text-base font-semibold text-[#0F172A]">新增定时导出任务</h3>
            <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
              <X size={18} className="text-[#94A3B8]" />
            </button>
          </div>
          <div className="p-6 space-y-4 overflow-y-auto">
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">任务名称 <span className="text-[#EF4444]">*</span></label>
              <input
                value={form.name || ''}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="请输入任务名称，如：每日载具报表"
                className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">导出模块</label>
                <select
                  value={form.module}
                  onChange={(e) => setForm({ ...form, module: e.target.value as ExportModule })}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  {MODULE_OPTIONS.filter(m => m.key !== 'all').map(m => (
                    <option key={m.key} value={m.key}>{m.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">导出类型</label>
                <select
                  value={form.type}
                  onChange={(e) => setForm({ ...form, type: e.target.value as ExportType })}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value="excel">Excel</option>
                  <option value="csv">CSV</option>
                  <option value="pdf">PDF</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">执行周期</label>
                <select
                  value={form.cycle}
                  onChange={(e) => setForm({ ...form, cycle: e.target.value as ScheduleCycle })}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value="daily">每天</option>
                  <option value="weekly">每周</option>
                  <option value="monthly">每月</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#0F172A] mb-1">初始状态</label>
                <select
                  value={form.status}
                  onChange={(e) => setForm({ ...form, status: e.target.value as ScheduleStatus })}
                  className="w-full h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
                >
                  <option value="enabled">启用</option>
                  <option value="disabled">停用</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#0F172A] mb-1">备注说明</label>
              <textarea
                placeholder="请输入备注说明（可选）"
                className="w-full h-20 px-3 py-2 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus resize-none"
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#E2E8F0]">
            <button onClick={onClose} className="h-9 px-4 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC]">取消</button>
            <button onClick={handleSave} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8]">保存</button>
          </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}

/** File Preview Drawer */
function FilePreviewDrawer({ record, onClose }: { record: ExportRecord | null; onClose: () => void }) {
  if (!record) return null;
  const moduleCfg = MODULE_CONFIG[record.module];
  const typeCfg = TYPE_CONFIG[record.type];
  const statusCfg = STATUS_CONFIG[record.status];

  return (
    <AnimatePresence>
      {record && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="fixed right-0 top-14 bottom-0 w-[480px] bg-white shadow-modal z-50 flex flex-col"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0]">
              <div className="flex items-center gap-3">
                <span className="text-base font-semibold text-[#0F172A]">文件预览</span>
                <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-md hover:bg-[#F1F5F9] flex items-center justify-center">
                <X size={18} className="text-[#94A3B8]" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* File Info */}
              <div className="bg-[#F8FAFC] rounded-lg p-6 text-center">
                <div className="w-16 h-16 rounded-xl mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: `${typeCfg.color}15` }}>
                  <typeCfg.icon size={32} style={{ color: typeCfg.color }} />
                </div>
                <p className="text-sm font-medium text-[#0F172A]">{record.id}.{typeCfg.ext}</p>
                <p className="text-xs text-[#94A3B8] mt-1">{record.fileSize || '-'}</p>
              </div>

              {/* Details */}
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">导出编号</span>
                  <span className="text-sm font-mono text-[#0F172A]">{record.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">导出模块</span>
                  <span className="text-sm text-[#0F172A]">{moduleCfg.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">导出类型</span>
                  <span className="text-sm text-[#0F172A]">{typeCfg.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">筛选条件</span>
                  <span className="text-sm text-[#0F172A]">{record.filterSummary}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">操作人</span>
                  <span className="text-sm text-[#0F172A]">{record.operator}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">创建时间</span>
                  <span className="text-sm text-[#0F172A]">{record.createdAt}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-[#475569]">完成时间</span>
                  <span className="text-sm text-[#0F172A]">{record.completedAt || '-'}</span>
                </div>
              </div>

              {/* Actions */}
              {record.status === 'completed' && (
                <div className="space-y-2">
                  <button
                    onClick={() => { alert(`开始下载：${record.id}.${typeCfg.ext}`); }}
                    className="w-full h-10 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center justify-center gap-2 transition-colors"
                  >
                    <Download size={16} /> 下载文件
                  </button>
                  <button
                    onClick={() => { alert('分享链接已复制到剪贴板'); }}
                    className="w-full h-10 rounded-md border border-[#E2E8F0] text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center justify-center gap-2 transition-colors"
                  >
                    <FileSearch size={16} /> 复制分享链接
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ------------------------------------------------------------------
// Export Records Tab
// ------------------------------------------------------------------
function ExportRecordsTab() {
  const [moduleFilter, setModuleFilter] = useState<ExportModule | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<ExportStatus | 'all'>('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [previewRecord, setPreviewRecord] = useState<ExportRecord | null>(null);
  const [records, setRecords] = useState<ExportRecord[]>(MOCK_RECORDS);
  const pageSize = 10;

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      if (moduleFilter !== 'all' && r.module !== moduleFilter) return false;
      if (statusFilter !== 'all' && r.status !== statusFilter) return false;
      if (searchKeyword) {
        const kw = searchKeyword.toLowerCase();
        return (
          r.id.toLowerCase().includes(kw) ||
          r.operator.toLowerCase().includes(kw) ||
          r.filterSummary.toLowerCase().includes(kw)
        );
      }
      return true;
    });
  }, [records, moduleFilter, statusFilter, searchKeyword]);

  const totalPages = Math.ceil(filteredRecords.length / pageSize);
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, currentPage]);

  const toggleRow = (id: string) => {
    const next = new Set(selectedRows);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedRows(next);
  };

  const toggleAll = () => {
    if (selectedRows.size === paginatedRecords.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(paginatedRecords.map(r => r.id)));
    }
  };

  const handleBatchDownload = () => {
    alert(`批量下载 ${selectedRows.size} 个文件（模拟）`);
    setSelectedRows(new Set());
  };

  const handleBatchDelete = () => {
    if (confirm(`确定删除选中的 ${selectedRows.size} 条导出记录吗？`)) {
      setRecords(prev => prev.filter(r => !selectedRows.has(r.id)));
      setSelectedRows(new Set());
    }
  };

  const handleDelete = (id: string) => {
    if (confirm('确定删除该导出记录吗？')) {
      setRecords(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleRegenerate = (record: ExportRecord) => {
    setRecords(prev => prev.map(r =>
      r.id === record.id
        ? { ...r, status: 'generating' as ExportStatus, progress: 0, completedAt: null, fileSize: null }
        : r
    ));
    // Simulate progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      setRecords(prev => prev.map(r =>
        r.id === record.id ? { ...r, progress } : r
      ));
      if (progress >= 100) {
        clearInterval(interval);
        setRecords(prev => prev.map(r =>
          r.id === record.id
            ? { ...r, status: 'completed' as ExportStatus, progress: 100, completedAt: new Date().toLocaleString('zh-CN'), fileSize: `${(Math.random() * 10 + 0.5).toFixed(1)} MB` }
            : r
        ));
      }
    }, 500);
  };

  const handleDownload = (record: ExportRecord) => {
    const typeCfg = TYPE_CONFIG[record.type];
    alert(`开始下载：${record.id}.${typeCfg.ext}`);
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select
            value={moduleFilter}
            onChange={(e) => { setModuleFilter(e.target.value as ExportModule | 'all'); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {MODULE_OPTIONS.map(m => <option key={m.key} value={m.key}>{m.label}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value as ExportStatus | 'all'); setCurrentPage(1); }}
            className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
          >
            {STATUS_OPTIONS.map(s => <option key={s.key} value={s.key}>{s.label}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              type="text"
              value={searchKeyword}
              onChange={(e) => { setSearchKeyword(e.target.value); setCurrentPage(1); }}
              placeholder="搜索导出编号、操作人、筛选条件..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
        <button
          onClick={handleBatchDownload}
          disabled={selectedRows.size === 0}
          className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2 transition-colors"
        >
          <Download size={15} /> 批量下载
        </button>
      </div>

      {/* Batch Operation Bar */}
      <AnimatePresence>
        {selectedRows.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="bg-[#EFF6FF] border border-[#BFDBFE] rounded-lg px-4 py-3 flex items-center justify-between"
          >
            <span className="text-sm text-[#2563EB]">已选择 <strong>{selectedRows.size}</strong> 条导出记录</span>
            <div className="flex items-center gap-2">
              <button onClick={handleBatchDownload} className="h-8 px-3 rounded-md bg-[#2563EB] text-white text-xs hover:bg-[#1D4ED8] flex items-center gap-1 transition-colors">
                <Download size={14} /> 批量下载
              </button>
              <button onClick={handleBatchDelete} className="h-8 px-3 rounded-md bg-[#EF4444] text-white text-xs hover:bg-[#DC2626] flex items-center gap-1 transition-colors">
                <Trash2 size={14} /> 批量删除
              </button>
              <button onClick={() => setSelectedRows(new Set())} className="h-8 px-3 rounded-md border border-[#BFDBFE] text-[#2563EB] text-xs hover:bg-white transition-colors">
                取消选择
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="w-10 px-3 py-2.5">
                  <input
                    type="checkbox"
                    checked={paginatedRecords.length > 0 && selectedRows.size === paginatedRecords.length}
                    onChange={toggleAll}
                    className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]"
                  />
                </th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">导出编号</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">导出模块</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">导出类型</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">筛选条件</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作人</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">创建时间</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">文件状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">文件大小</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedRecords.map((record, idx) => {
                const moduleCfg = MODULE_CONFIG[record.module];
                const typeCfg = TYPE_CONFIG[record.type];
                const statusCfg = STATUS_CONFIG[record.status];
                const isSelected = selectedRows.has(record.id);
                const ModuleIcon = moduleCfg.icon;
                const StatusIcon = statusCfg.icon;

                return (
                  <motion.tr
                    key={record.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: idx * 0.03 }}
                    className={cn(
                      'group border-b border-[#E2E8F0] transition-colors duration-150',
                      isSelected ? 'bg-[#EFF6FF]' : 'hover:bg-[#F8FAFC]'
                    )}
                  >
                    <td className="px-3 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleRow(record.id)}
                        className="w-4 h-4 rounded border-[#CBD5E1] text-[#2563EB] focus:ring-[#2563EB]"
                      />
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm font-mono text-[#0F172A]">{record.id}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${moduleCfg.color}15` }}>
                          <ModuleIcon size={14} style={{ color: moduleCfg.color }} />
                        </div>
                        <span className="text-sm text-[#0F172A]">{moduleCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1.5">
                        <typeCfg.icon size={14} style={{ color: typeCfg.color }} />
                        <span className="text-xs font-medium" style={{ color: typeCfg.color }}>{typeCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569] max-w-[140px] truncate block" title={record.filterSummary}>{record.filterSummary}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm text-[#475569]">{record.operator}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#475569] font-mono">{record.createdAt}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1.5">
                          <StatusIcon size={14} style={{ color: statusCfg.color }} />
                          <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
                        </div>
                        {record.status === 'generating' && record.progress !== undefined && (
                          <div className="w-24 h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ backgroundColor: statusCfg.color }}
                              initial={{ width: 0 }}
                              animate={{ width: `${record.progress}%` }}
                              transition={{ duration: 0.3 }}
                            />
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#94A3B8]">{record.fileSize || '-'}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {record.status === 'completed' && (
                          <button onClick={() => handleDownload(record)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="下载">
                            <Download size={14} className="text-[#2563EB]" />
                          </button>
                        )}
                        {record.status === 'failed' && (
                          <button onClick={() => handleRegenerate(record)} className="w-7 h-7 rounded hover:bg-[#FFFBEB] flex items-center justify-center" title="重新生成">
                            <RotateCw size={14} className="text-[#F59E0B]" />
                          </button>
                        )}
                        <button onClick={() => setPreviewRecord(record)} className="w-7 h-7 rounded hover:bg-[#F1F5F9] flex items-center justify-center" title="预览">
                          <Eye size={14} className="text-[#475569]" />
                        </button>
                        <button onClick={() => handleDelete(record.id)} className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="删除">
                          <Trash2 size={14} className="text-[#EF4444]" />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {paginatedRecords.length === 0 && (
                <tr>
                  <td colSpan={10} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <FolderArchive size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无导出记录</p>
                      <p className="text-sm text-[#94A3B8]">当前筛选条件下没有符合条件的导出记录</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredRecords.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">
              共 <strong>{filteredRecords.length}</strong> 条，第 <strong>{currentPage}</strong> / {totalPages} 页
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={cn(
                      'w-8 h-8 rounded-md text-sm font-medium transition-colors',
                      currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]'
                    )}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Preview Drawer */}
      <FilePreviewDrawer record={previewRecord} onClose={() => setPreviewRecord(null)} />
    </div>
  );
}

// ------------------------------------------------------------------
// Scheduled Tasks Tab
// ------------------------------------------------------------------
function ScheduledTasksTab() {
  const [tasks, setTasks] = useState<ScheduledTask[]>(MOCK_SCHEDULED_TASKS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ScheduleStatus | 'all'>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (statusFilter !== 'all' && t.status !== statusFilter) return false;
      if (search) {
        const kw = search.toLowerCase();
        return t.name.toLowerCase().includes(kw) || t.id.toLowerCase().includes(kw);
      }
      return true;
    });
  }, [tasks, statusFilter, search]);

  const totalPages = Math.ceil(filteredTasks.length / pageSize);
  const paginatedTasks = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredTasks.slice(start, start + pageSize);
  }, [filteredTasks, currentPage]);

  const toggleTaskStatus = (id: string) => {
    setTasks(prev => prev.map(t =>
      t.id === id ? { ...t, status: t.status === 'enabled' ? 'disabled' as ScheduleStatus : 'enabled' as ScheduleStatus } : t
    ));
  };

  const handleDeleteTask = (id: string) => {
    if (confirm('确定删除该定时任务吗？')) {
      setTasks(prev => prev.filter(t => t.id !== id));
    }
  };

  const handleAddTask = (task: ScheduledTask) => {
    setTasks(prev => [task, ...prev]);
  };

  const handleRunNow = (task: ScheduledTask) => {
    alert(`立即执行任务：${task.name}（模拟）`);
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value as ScheduleStatus | 'all'); setCurrentPage(1); }}
          className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white"
        >
          <option value="all">全部状态</option>
          <option value="enabled">启用</option>
          <option value="disabled">停用</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
              placeholder="搜索任务名称、编号..."
              className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus"
            />
          </div>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors"
        >
          <Plus size={15} /> 新增定时任务
        </button>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-[#F1F5F9]">
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">任务编号</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">任务名称</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">导出模块</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">导出类型</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">执行周期</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">下次执行</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">上次执行</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">状态</th>
                <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedTasks.map((task, idx) => {
                const moduleCfg = MODULE_CONFIG[task.module];
                const typeCfg = TYPE_CONFIG[task.type];
                const statusCfg = SCHEDULE_STATUS_CONFIG[task.status];
                const ModuleIcon = moduleCfg.icon;

                return (
                  <motion.tr
                    key={task.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: idx * 0.03 }}
                    className="group border-b border-[#E2E8F0] hover:bg-[#F8FAFC] transition-colors"
                  >
                    <td className="px-3 py-3">
                      <span className="text-sm font-mono text-[#0F172A]">{task.id}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-sm font-medium text-[#0F172A]">{task.name}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${moduleCfg.color}15` }}>
                          <ModuleIcon size={14} style={{ color: moduleCfg.color }} />
                        </div>
                        <span className="text-sm text-[#0F172A]">{moduleCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1.5">
                        <typeCfg.icon size={14} style={{ color: typeCfg.color }} />
                        <span className="text-xs font-medium" style={{ color: typeCfg.color }}>{typeCfg.label}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <Tag label={CYCLE_CONFIG[task.cycle].label} color="#2563EB" bg="#EFF6FF" />
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#475569] font-mono">{task.nextRunAt}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className="text-xs text-[#94A3B8] font-mono">{task.lastRunAt || '-'}</span>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => toggleTaskStatus(task.id)}
                          className={cn(
                            'relative w-9 h-5 rounded-full transition-colors',
                            task.status === 'enabled' ? 'bg-[#10B981]' : 'bg-[#CBD5E1]'
                          )}
                          title={task.status === 'enabled' ? '点击停用' : '点击启用'}
                        >
                          <span className={cn(
                            'absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform',
                            task.status === 'enabled' ? 'translate-x-4' : 'translate-x-0'
                          )} />
                        </button>
                        <Tag label={statusCfg.label} color={statusCfg.color} bg={statusCfg.bg} />
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleRunNow(task)} className="w-7 h-7 rounded hover:bg-[#EFF6FF] flex items-center justify-center" title="立即执行">
                          <Play size={14} className="text-[#2563EB]" />
                        </button>
                        <button className="w-7 h-7 rounded hover:bg-[#FEF2F2] flex items-center justify-center" title="删除">
                          <Trash2 size={14} className="text-[#EF4444]" onClick={() => handleDeleteTask(task.id)} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {paginatedTasks.length === 0 && (
                <tr>
                  <td colSpan={9} className="py-16 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <Clock size={48} className="text-[#CBD5E1]" />
                      <p className="text-base text-[#475569]">暂无定时任务</p>
                      <p className="text-sm text-[#94A3B8]">当前筛选条件下没有符合条件的定时任务</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filteredTasks.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
            <span className="text-sm text-[#475569]">
              共 <strong>{filteredTasks.length}</strong> 条，第 <strong>{currentPage}</strong> / {totalPages} 页
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                上一页
              </button>
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let page: number;
                if (totalPages <= 5) page = i + 1;
                else if (currentPage <= 3) page = i + 1;
                else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
                else page = currentPage - 2 + i;
                return (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={cn(
                      'w-8 h-8 rounded-md text-sm font-medium transition-colors',
                      currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]'
                    )}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                下一页
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add Modal */}
      {showAddModal && <AddScheduleModal onClose={() => setShowAddModal(false)} onSave={handleAddTask} />}
    </div>
  );
}

// ------------------------------------------------------------------
// Main Page Component
// ------------------------------------------------------------------
export default function ExportRecordPage() {
  const [activeTab, setActiveTab] = useState<'records' | 'scheduled'>('records');
  const { alarms } = useMockData();

  // KPI data calculation
  const kpiData = useMemo(() => {
    const allRecords = MOCK_RECORDS;
    const today = allRecords.filter(r => r.createdAt.startsWith('2024-12-20')).length;
    const thisWeek = allRecords.filter(r => {
      const day = parseInt(r.createdAt.split('-')[2].split(' ')[0]);
      return day >= 15 && day <= 21;
    }).length;
    const total = allRecords.length;
    const successCount = allRecords.filter(r => r.status === 'completed').length;
    const successRate = total > 0 ? ((successCount / total) * 100).toFixed(1) : '0';
    return { today, thisWeek, total, successRate };
  }, []);

  void alarms;

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-[#0F172A]">导出记录管理</h1>
        <div className="flex items-center gap-3">
          <button className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
            <Download size={15} /> 导出全部
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-4 gap-4">
        <KPICard
          title="今日导出次数"
          value={kpiData.today}
          subtext="24小时内新增"
          color="#2563EB"
          icon={FileDown}
        />
        <KPICard
          title="本周导出次数"
          value={kpiData.thisWeek}
          subtext="近7天统计"
          color="#8B5CF6"
          icon={Calendar}
        />
        <KPICard
          title="累计导出次数"
          value={kpiData.total}
          subtext="历史累计"
          color="#10B981"
          icon={FolderArchive}
        />
        <KPICard
          title="导出成功率"
          value={`${kpiData.successRate}%`}
          subtext="已完成 / 总记录"
          color="#F59E0B"
          icon={CheckCircle}
        />
      </div>

      {/* Tab Navigation */}
      <div>
        <div className="flex border-b border-[#E2E8F0]">
          {TAB_OPTIONS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex items-center gap-2 px-5 py-3 text-sm font-medium transition-colors',
                activeTab === tab.key ? 'text-[#2563EB]' : 'text-[#475569] hover:text-[#0F172A]'
              )}
            >
              <tab.icon size={16} />
              {tab.label}
              {activeTab === tab.key && (
                <motion.div
                  layoutId="exportTabIndicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2563EB] rounded-full"
                  transition={{ duration: 0.2 }}
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'records' && <ExportRecordsTab />}
          {activeTab === 'scheduled' && <ScheduledTasksTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
