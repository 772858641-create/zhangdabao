import { useState, useEffect, type FormEvent } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  Building2,
  AlertCircle,
  Check,
  MapPin,
  BarChart3,
  Bell,
  ArrowLeftRight,
  Loader2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';

const easeOutExpo = [0.16, 1, 0.3, 1] as [number, number, number, number];

const features = [
  {
    icon: MapPin,
    title: '实时位置监控',
    desc: 'GPS + 蓝牙双模定位，毫秒级位置更新',
  },
  {
    icon: BarChart3,
    title: '全生命周期管理',
    desc: '从入库到报废，完整数字化追踪',
  },
  {
    icon: Bell,
    title: '智能异常预警',
    desc: '17 种报警类型，自动发现即时通知',
  },
  {
    icon: ArrowLeftRight,
    title: '高效调拨流转',
    desc: '批量调拨、轨迹回放、智能路线规划',
  },
];

const orgOptions = [
  { value: 'org-1', label: '云载科技（总部）' },
  { value: 'org-2', label: '华东汽车制造有限公司' },
  { value: 'org-3', label: '南方物流集团' },
  { value: 'org-4', label: '北方供应链管理有限公司' },
  { value: 'org-1-1-1', label: '上海运营中心' },
  { value: 'org-1-2-1', label: '北京运营中心' },
];

export default function LoginPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { login, isAuthenticated } = useAuth();

  const [account, setAccount] = useState('');
  const [password, setPassword] = useState('');
  const [orgId, setOrgId] = useState('org-1');
  const [remember, setRemember] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loginSuccess, setLoginSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shakeButton, setShakeButton] = useState(false);

  const expired = searchParams.get('expired') === '1';

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  // Show expired message
  useEffect(() => {
    if (expired) {
      setError('会话已过期，请重新登录');
    }
  }, [expired]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!account.trim()) {
      setError('请输入账号');
      setShakeButton(true);
      setTimeout(() => setShakeButton(false), 300);
      return;
    }
    if (!password.trim()) {
      setError('请输入密码');
      setShakeButton(true);
      setTimeout(() => setShakeButton(false), 300);
      return;
    }

    setIsLoading(true);

    try {
      await login(account, password, orgId, remember);
      setLoginSuccess(true);
      setTimeout(() => {
        navigate('/');
      }, 500);
    } catch {
      setError('登录失败，请检查账号密码');
      setShakeButton(true);
      setTimeout(() => setShakeButton(false), 300);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-[100dvh]">
      {/* ===== LEFT SIDE: Brand area ===== */}
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden">
        {/* Background image with animation */}
        <motion.div
          initial={{ scale: 1.05 }}
          animate={{ scale: 1 }}
          transition={{ duration: 8, ease: 'easeOut' }}
          className="absolute inset-0"
        >
          <img
            src="./login-bg.jpg"
            alt=""
            className="w-full h-full object-cover"
          />
        </motion.div>

        {/* Dark overlay */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(135deg, rgba(15,23,42,0.92) 0%, rgba(30,41,59,0.88) 50%, rgba(15,23,42,0.95) 100%)',
          }}
        />

        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center h-full px-[60px]">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: easeOutExpo }}
          >
            <img
              src="./logo.svg"
              alt="载具云"
              className="h-10 brightness-0 invert opacity-90"
            />
            <h2 className="text-2xl font-semibold text-white mt-2">
              载具数字化管理平台
            </h2>
            <p className="text-[13px] text-white/50 mt-1 tracking-[0.05em]">
              Vehicle Digital Management Platform
            </p>
          </motion.div>

          {/* Slogan */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: easeOutExpo, delay: 0.1 }}
            className="mt-12"
          >
            <h1 className="text-4xl font-bold text-white leading-[1.2]">
              让每一台载具，尽在掌控
            </h1>
            <p className="text-base text-white/70 leading-relaxed mt-4 max-w-[480px]">
              覆盖采购、使用、调拨、报废全生命周期，实时定位，智能预警，高效流转
            </p>
          </motion.div>

          {/* Feature highlights */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.5 }}
            className="mt-10 space-y-5"
          >
            {features.map((f, idx) => {
              const Icon = f.icon;
              return (
                <motion.div
                  key={f.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{
                    duration: 0.3,
                    ease: easeOutExpo,
                    delay: 0.5 + idx * 0.08,
                  }}
                  className="flex items-start gap-3"
                >
                  <Icon size={22} className="text-primary mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-white font-medium">{f.title}</p>
                    <p className="text-[13px] text-white/60 mt-0.5">{f.desc}</p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Copyright */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4, delay: 1 }}
            className="absolute bottom-10 left-[60px]"
          >
            <p className="text-xs text-white/40">
              &copy; 2024 载具数字化管理平台. All rights reserved.
            </p>
            <p className="text-xs text-white/30 mt-0.5">部署于腾讯云服务器</p>
          </motion.div>
        </div>
      </div>

      {/* ===== RIGHT SIDE: Login form ===== */}
      <div className="flex-1 flex items-center justify-center bg-white relative">
        {/* Mobile background (visible only on small screens) */}
        <div
          className="absolute inset-0 lg:hidden bg-cover bg-center"
          style={{ backgroundImage: 'url(./login-bg.jpg)' }}
        >
          <div
            className="absolute inset-0"
            style={{
              background:
                'linear-gradient(135deg, rgba(15,23,42,0.92) 0%, rgba(30,41,59,0.88) 50%, rgba(15,23,42,0.95) 100%)',
            }}
          />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: easeOutExpo, delay: 0.3 }}
          className="relative z-10 w-full max-w-[400px] px-6 sm:px-10"
        >
          {/* Mobile logo */}
          <div className="lg:hidden flex justify-center mb-6">
            <img src="./logo.svg" alt="载具云" className="h-10" />
          </div>

          {/* Welcome title */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.2 }}
          >
            <h2 className="text-[28px] font-bold text-neutral-textPrimary">
              欢迎回来
            </h2>
            <p className="text-sm text-neutral-textTertiary mt-1">
              请登录您的账号以继续
            </p>
          </motion.div>

          {/* Error message */}
          <AnimatePresence>
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2, ease: easeOutExpo }}
                className="mt-5 flex items-start gap-2 bg-danger-light border border-red-200 rounded-md px-3.5 py-2.5"
              >
                <AlertCircle
                  size={16}
                  className="text-danger flex-shrink-0 mt-0.5"
                />
                <span className="text-sm text-danger">{error}</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Login form */}
          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            {/* Account */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.3 + 0 * 0.08 }}
            >
              <label className="block text-xs font-medium text-neutral-textSecondary mb-1.5">
                账号
              </label>
              <div className="relative">
                <User
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary"
                />
                <input
                  type="text"
                  value={account}
                  onChange={(e) => setAccount(e.target.value)}
                  placeholder="请输入账号/手机号/邮箱"
                  className="w-full h-10 pl-9 pr-3 text-sm border border-neutral-border-strong rounded-md text-neutral-textPrimary placeholder:text-neutral-textTertiary focus:outline-none focus:border-primary focus:shadow-focus transition-all duration-150"
                />
              </div>
            </motion.div>

            {/* Password */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.3 + 1 * 0.08 }}
            >
              <label className="block text-xs font-medium text-neutral-textSecondary mb-1.5">
                密码
              </label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary"
                />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="请输入密码"
                  className="w-full h-10 pl-9 pr-9 text-sm border border-neutral-border-strong rounded-md text-neutral-textPrimary placeholder:text-neutral-textTertiary focus:outline-none focus:border-primary focus:shadow-focus transition-all duration-150"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary hover:text-neutral-textSecondary transition-colors duration-150"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </motion.div>

            {/* Organization */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.3 + 2 * 0.08 }}
            >
              <label className="block text-xs font-medium text-neutral-textSecondary mb-1.5">
                组织
              </label>
              <div className="relative">
                <Building2
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary z-10 pointer-events-none"
                />
                <select
                  value={orgId}
                  onChange={(e) => setOrgId(e.target.value)}
                  className="w-full h-10 pl-9 pr-8 text-sm border border-neutral-border-strong rounded-md text-neutral-textPrimary bg-white focus:outline-none focus:border-primary focus:shadow-focus transition-all duration-150 appearance-none cursor-pointer"
                >
                  {orgOptions.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
                <ChevronDownIcon className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary pointer-events-none" />
              </div>
            </motion.div>

            {/* Remember me + forgot password */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.3 + 3 * 0.08 }}
              className="flex items-center justify-between"
            >
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="w-4 h-4 rounded border-2 border-neutral-border-strong text-primary focus:ring-primary/20"
                />
                <span className="text-sm text-neutral-textSecondary">记住我</span>
              </label>
              <button
                type="button"
                className="text-sm text-primary hover:underline"
              >
                忘记密码？
              </button>
            </motion.div>

            {/* Login button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, ease: easeOutExpo, delay: 0.3 + 4 * 0.08 }}
            >
              <button
                type="submit"
                disabled={isLoading || loginSuccess}
                className={cn(
                  'w-full h-11 rounded-md text-sm font-medium text-white transition-all duration-150 flex items-center justify-center gap-2',
                  loginSuccess
                    ? 'bg-success'
                    : 'bg-primary hover:bg-primary-hover',
                  (isLoading || loginSuccess) && 'opacity-70 cursor-not-allowed',
                  shakeButton && 'animate-shake'
                )}
              >
                {isLoading && (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    登录中...
                  </>
                )}
                {!isLoading && loginSuccess && (
                  <>
                    <Check size={16} />
                    登录成功
                  </>
                )}
                {!isLoading && !loginSuccess && '登 录'}
              </button>
            </motion.div>
          </form>

          {/* Help link */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3, delay: 0.8 }}
            className="mt-8 text-center text-[13px] text-neutral-textTertiary"
          >
            遇到问题？
            <button className="text-primary hover:underline">联系技术支持</button>
          </motion.p>
        </motion.div>
      </div>
    </div>
  );
}

function ChevronDownIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  );
}
