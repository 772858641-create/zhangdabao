import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  
  
  
  
  Scale,
  Warehouse,
  
  Calendar,
  
  Search,
  Filter,
  Download,
  
  
  PieChart as 
  
  
  ChevronRight,
  
  
  ArrowLeftRight,
  
  
  
  
  
  
  
  Eye,
  RefreshCw,
  Database,
  
  
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
} from 'recharts';

/* ================================================================
   Types
   ================================================================ */

// Tab 1: 空满载记录
type LoadStatus = '空载' | '满载' | '未知';
type TriggerMethod = '自动判定' | '手动设置' | '调拨触发' | '系统默认';
type TriggerLocation = '网点' | '仓库' | '区域' | '在途';

interface EmptyFullRecord {
  id: string;
  carrierCode: string;
  carrierType: string;
  carrierModel: string;
  changeTime: string;
  beforeStatus: LoadStatus;
  afterStatus: LoadStatus;
  triggerMethod: TriggerMethod;
  triggerLocation: TriggerLocation;
  transferOrderNo: string | null;
  relatedProject: string | null;
  operator: string | null;
  remark: string | null;
}

// Tab 2: 库存快照
type Dimension = '网点' | '仓库' | '区域' | '组织' | '项目';

interface InventorySnapshot {
  id: string;
  snapshotTime: string;
  dimension: Dimension;
  dimensionName: string;
  totalCount: number;
  inStockCount: number;
  inTransitCount: number;
  emptyCount: number;
  fullCount: number;
  stagnantCount: number;
  typeBreakdown: Record<string, number>;
  changeFromLast: number; // 环比变化
}

// Tab 3: 进出库记录
type IoType = '入库' | '出库';
type JudgeMethod = '围栏判定' | '信标扫描' | '网关扫描' | '时间兜底' | '手动确认';
type IoResult = '成功' | '失败' | '异常';

interface IoRecord {
  id: string;
  ioType: IoType;
  carrierCode: string;
  carrierType: string;
  carrierModel: string;
  operationTime: string;
  siteName: string;
  warehouseName: string;
  judgeMethod: JudgeMethod;
  judgeRuleName: string;
  judgeDetail: string;
  beforeLocation: string;
  afterLocation: string;
  transferOrderNo: string | null;
  relatedProject: string | null;
  operator: string | null;
  result: IoResult;
  abnormalReason: string | null;
}

/* ================================================================
   Colors
   ================================================================ */
const COLORS = [
  '#2563EB',
  '#10B981',
  '#F59E0B',
  '#EF4444',
  '#8B5CF6',
  '#06B6D4',
  '#EC4899',
  '#14B8A6',
];

/* ================================================================
   Mock Data Generators
   ================================================================ */

const CARRIER_CODES = [
  'CA-20250401-001', 'CA-20250401-015', 'CA-20250402-032', 'CA-20250403-008',
  'CA-20250404-045', 'CA-20250405-019', 'CA-20250406-067', 'CA-20250407-088',
  'CA-20250408-023', 'CA-20250409-091', 'CA-20250410-055', 'CA-20250411-012',
  'CA-20250412-078', 'CA-20250413-033', 'CA-20250414-099', 'CA-20250415-041',
  'CA-20250416-076', 'CA-20250417-027', 'CA-20250418-063', 'CA-20250419-011',
];

const CARRIER_TYPES = ['A_TYPE', 'B_TYPE', 'C_TYPE', 'D_TYPE', 'E_TYPE'];
const CARRIER_MODELS = ['STD-1000', 'STD-1200', 'HVY-1500', 'LGT-800', 'FLD-2000'];

const LOAD_STATUSES: LoadStatus[] = ['空载', '满载', '未知'];
const TRIGGER_METHODS: TriggerMethod[] = ['自动判定', '手动设置', '调拨触发', '系统默认'];
const TRIGGER_LOCATIONS: TriggerLocation[] = ['网点', '仓库', '区域', '在途'];

const SITES = ['上海浦东仓库', '苏州昆山工厂', '深圳龙岗仓库', '宁德生产基地', '杭州萧山中转站', '武汉东西湖仓库', '重庆两江仓库', '广州南沙仓库'];
const PROJECTS = ['上汽乘用车项目', '宁德时代电池项目', '特斯拉出口项目', '比亚迪零部件项目', null];
const OPERATORS = ['张明', '李华', '王强', '赵敏', '陈涛', '刘洋', null];

function randomPick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomDateInRange(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function formatDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const h = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  const s = String(d.getSeconds()).padStart(2, '0');
  return `${y}-${m}-${day} ${h}:${min}:${s}`;
}

function formatDateShort(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${m}-${day}`;
}

// Generate 30 empty-full records
const MOCK_EMPTY_FULL_RECORDS: EmptyFullRecord[] = Array.from({ length: 30 }, (_, i) => {
  const start = new Date('2025-03-30');
  const end = new Date('2025-04-29');
  const changeTime = randomDateInRange(start, end);
  const beforeStatus = randomPick(LOAD_STATUSES);
  let afterStatus = randomPick(LOAD_STATUSES);
  while (afterStatus === beforeStatus) {
    afterStatus = randomPick(LOAD_STATUSES);
  }
  const triggerMethod = randomPick(TRIGGER_METHODS);
  return {
    id: `EF${String(i + 1).padStart(6, '0')}`,
    carrierCode: CARRIER_CODES[i % CARRIER_CODES.length],
    carrierType: CARRIER_TYPES[i % CARRIER_TYPES.length],
    carrierModel: CARRIER_MODELS[i % CARRIER_MODELS.length],
    changeTime: formatDate(changeTime),
    beforeStatus,
    afterStatus,
    triggerMethod,
    triggerLocation: randomPick(TRIGGER_LOCATIONS),
    transferOrderNo: triggerMethod === '调拨触发' ? `TB-202504${String((i % 28) + 1).padStart(2, '0')}-${String((i % 99) + 1).padStart(3, '0')}` : null,
    relatedProject: randomPick(PROJECTS),
    operator: triggerMethod === '手动设置' ? randomPick(OPERATORS.filter(o => o !== null) as string[]) : null,
    remark: i % 5 === 0 ? '系统自动记录' : null,
  };
}).sort((a, b) => new Date(b.changeTime).getTime() - new Date(a.changeTime).getTime());

// Generate 20 inventory snapshots
const DIMENSIONS: Dimension[] = ['网点', '仓库', '区域', '组织', '项目'];
const DIMENSION_NAMES = [
  '上海浦东仓库', '苏州昆山工厂', '深圳龙岗仓库', '宁德生产基地', '杭州萧山中转站',
  '武汉东西湖仓库', '重庆两江仓库', '广州南沙仓库',
  '华东大区', '华南大区', '上汽乘用车项目', '宁德时代电池项目', '特斯拉出口项目',
  'A仓库', 'B仓库', 'C仓库', 'D仓库',
  '上海区域', '深圳区域', '武汉区域',
];

const MOCK_INVENTORY_SNAPSHOTS: InventorySnapshot[] = Array.from({ length: 20 }, (_, i) => {
  const start = new Date('2025-03-30');
  const end = new Date('2025-04-29');
  const snapshotTime = randomDateInRange(start, end);
  const dim = DIMENSIONS[i % DIMENSIONS.length];
  const totalCount = Math.floor(Math.random() * 200) + 50;
  const inTransitCount = Math.floor(Math.random() * 30);
  const inStockCount = totalCount - inTransitCount;
  const emptyCount = Math.floor(inStockCount * 0.4);
  const fullCount = Math.floor(inStockCount * 0.5);
  const stagnantCount = inStockCount - emptyCount - fullCount;
  return {
    id: `SN${String(i + 1).padStart(6, '0')}`,
    snapshotTime: formatDate(snapshotTime),
    dimension: dim,
    dimensionName: DIMENSION_NAMES[i % DIMENSION_NAMES.length],
    totalCount,
    inStockCount,
    inTransitCount,
    emptyCount,
    fullCount,
    stagnantCount: Math.max(0, stagnantCount),
    typeBreakdown: {
      A_TYPE: Math.floor(totalCount * 0.35),
      B_TYPE: Math.floor(totalCount * 0.3),
      C_TYPE: Math.floor(totalCount * 0.2),
      D_TYPE: Math.floor(totalCount * 0.1),
      E_TYPE: Math.floor(totalCount * 0.05),
    },
    changeFromLast: Math.floor(Math.random() * 40) - 20,
  };
}).sort((a, b) => new Date(b.snapshotTime).getTime() - new Date(a.snapshotTime).getTime());

// Generate 40 IO records
const IO_TYPES: IoType[] = ['入库', '出库'];
const JUDGE_METHODS: JudgeMethod[] = ['围栏判定', '信标扫描', '网关扫描', '时间兜底', '手动确认'];
const IO_RESULT_WEIGHTS = ['成功', '成功', '成功', '成功', '成功', '成功', '成功', '成功', '失败', '异常'];

const MOCK_IO_RECORDS: IoRecord[] = Array.from({ length: 40 }, (_, i) => {
  const start = new Date('2025-03-30');
  const end = new Date('2025-04-29');
  const operationTime = randomDateInRange(start, end);
  const ioType = IO_TYPES[i % 2];
  const judgeMethod = randomPick(JUDGE_METHODS);
  const result = IO_RESULT_WEIGHTS[Math.floor(Math.random() * IO_RESULT_WEIGHTS.length)] as IoResult;
  return {
    id: `IO${String(i + 1).padStart(6, '0')}`,
    ioType,
    carrierCode: CARRIER_CODES[i % CARRIER_CODES.length],
    carrierType: CARRIER_TYPES[i % CARRIER_TYPES.length],
    carrierModel: CARRIER_MODELS[i % CARRIER_MODELS.length],
    operationTime: formatDate(operationTime),
    siteName: SITES[i % SITES.length],
    warehouseName: `仓库-${String((i % 4) + 1)}`,
    judgeMethod,
    judgeRuleName: `${judgeMethod}规则v${(i % 3) + 1}`,
    judgeDetail: judgeMethod === '围栏判定' ? `RSSI=${-60 - (i % 20)}dBm，命中围栏` : judgeMethod === '信标扫描' ? '扫描到3个信标' : judgeMethod === '网关扫描' ? '网关ID=GW-001，信号强度良好' : judgeMethod === '时间兜底' ? '超过阈值时间${12 + (i % 12)}h自动判定' : '手动确认操作',
    beforeLocation: ioType === '入库' ? '在途' : SITES[(i + 1) % SITES.length],
    afterLocation: ioType === '入库' ? SITES[i % SITES.length] : '在途',
    transferOrderNo: i % 3 === 0 ? `TB-202504${String((i % 28) + 1).padStart(2, '0')}-${String((i % 99) + 1).padStart(3, '0')}` : null,
    relatedProject: randomPick(PROJECTS),
    operator: judgeMethod === '手动确认' ? randomPick(OPERATORS.filter(o => o !== null) as string[]) : null,
    result,
    abnormalReason: result === '异常' ? '信号不稳定导致判定失败' : result === '失败' ? '未匹配到目标网点' : null,
  };
}).sort((a, b) => new Date(b.operationTime).getTime() - new Date(a.operationTime).getTime());

/* ================================================================
   Helpers
   ================================================================ */

function statusBadgeClass(status: string) {
  switch (status) {
    case '空载': return 'bg-[#F59E0B]/10 text-[#F59E0B]';
    case '满载': return 'bg-[#10B981]/10 text-[#10B981]';
    case '未知': return 'bg-[#94A3B8]/10 text-[#94A3B8]';
    case '成功': return 'bg-[#10B981]/10 text-[#10B981]';
    case '失败': return 'bg-[#EF4444]/10 text-[#EF4444]';
    case '异常': return 'bg-[#F59E0B]/10 text-[#F59E0B]';
    case '入库': return 'bg-[#2563EB]/10 text-[#2563EB]';
    case '出库': return 'bg-[#8B5CF6]/10 text-[#8B5CF6]';
    default: return 'bg-[#F1F5F9] text-[#475569]';
  }
}

function triggerMethodBadgeClass(method: string) {
  switch (method) {
    case '自动判定': return 'bg-[#2563EB]/10 text-[#2563EB]';
    case '手动设置': return 'bg-[#8B5CF6]/10 text-[#8B5CF6]';
    case '调拨触发': return 'bg-[#10B981]/10 text-[#10B981]';
    case '系统默认': return 'bg-[#94A3B8]/10 text-[#94A3B8]';
    default: return 'bg-[#F1F5F9] text-[#475569]';
  }
}

function judgeMethodBadgeClass(method: string) {
  switch (method) {
    case '围栏判定': return 'bg-[#2563EB]/10 text-[#2563EB]';
    case '信标扫描': return 'bg-[#10B981]/10 text-[#10B981]';
    case '网关扫描': return 'bg-[#8B5CF6]/10 text-[#8B5CF6]';
    case '时间兜底': return 'bg-[#F59E0B]/10 text-[#F59E0B]';
    case '手动确认': return 'bg-[#06B6D4]/10 text-[#06B6D4]';
    default: return 'bg-[#F1F5F9] text-[#475569]';
  }
}

/* ================================================================
   Sub-components
   ================================================================ */

function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-start gap-4 hover:shadow-card-hover transition-shadow duration-200">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-[#475569] mb-1">{title}</p>
        <p className="text-[28px] font-semibold leading-tight" style={{ color: '#0F172A' }}>{value}</p>
        {subtext && <p className="text-xs text-[#94A3B8] mt-1">{subtext}</p>}
      </div>
    </div>
  );
}

function Tag({ label, color, bg, className }: { label: string; color: string; bg: string; className?: string }) {
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', className)} style={{ color, backgroundColor: bg }}>
      {label}
    </span>
  );
}

/* ================================================================
   Pagination Component
   ================================================================ */
function Pagination({ currentPage, totalPages, totalItems, onPageChange }: {
  currentPage: number; totalPages: number; totalItems: number; onPageChange: (p: number) => void;
}) {
  if (totalPages <= 0) return null;
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
      <span className="text-sm text-[#475569]">
        共 <strong>{totalItems}</strong> 条，第 <strong>{currentPage}</strong> / {totalPages} 页
      </span>
      <div className="flex items-center gap-1">
        <button
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
          className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >上一页</button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let page: number;
          if (totalPages <= 5) page = i + 1;
          else if (currentPage <= 3) page = i + 1;
          else if (currentPage >= totalPages - 2) page = totalPages - 4 + i;
          else page = currentPage - 2 + i;
          return (
            <button
              key={page}
              onClick={() => onPageChange(page)}
              className={cn('w-8 h-8 rounded-md text-sm font-medium transition-colors', currentPage === page ? 'bg-[#2563EB] text-white' : 'text-[#475569] hover:bg-[#F1F5F9]')}
            >{page}</button>
          );
        })}
        <button
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
          className="h-8 px-3 rounded-md border border-[#E2E8F0] text-sm text-[#475569] hover:bg-[#F8FAFC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
        >下一页</button>
      </div>
    </div>
  );
}

/* ================================================================
   Tab 1: Empty-Full Records
   ================================================================ */
function EmptyFullTab() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [statusChangeFilter, setStatusChangeFilter] = useState('all');
  const [triggerFilter, setTriggerFilter] = useState('all');
  const [projectFilter, setProjectFilter] = useState('all');
  const [timeRange, setTimeRange] = useState('30d');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const filtered = useMemo(() => {
    return MOCK_EMPTY_FULL_RECORDS.filter((r) => {
      if (search) {
        const kw = search.toLowerCase();
        if (!r.carrierCode.toLowerCase().includes(kw) && !r.carrierType.toLowerCase().includes(kw) && !r.id.toLowerCase().includes(kw)) return false;
      }
      if (typeFilter !== 'all' && r.carrierType !== typeFilter) return false;
      if (triggerFilter !== 'all' && r.triggerMethod !== triggerFilter) return false;
      if (projectFilter !== 'all' && r.relatedProject !== projectFilter) return false;
      if (statusChangeFilter !== 'all') {
        const change = `${r.beforeStatus}->${r.afterStatus}`;
        if (statusChangeFilter === '空->满' && change !== '空载->满载') return false;
        if (statusChangeFilter === '满->空' && change !== '满载->空载') return false;
        if (statusChangeFilter === '未知->空' && change !== '未知->空载') return false;
        if (statusChangeFilter === '未知->满' && change !== '未知->满载') return false;
      }
      if (timeRange !== 'all') {
        const date = new Date(r.changeTime);
        const now = new Date('2025-04-29');
        const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
        const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
        if (date < cutoff) return false;
      }
      return true;
    });
  }, [search, typeFilter, statusChangeFilter, triggerFilter, projectFilter, timeRange]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  // Charts data
  const trendData = useMemo(() => {
    const days: Record<string, { date: string; emptyToFull: number; fullToEmpty: number }> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date('2025-04-29');
      d.setDate(d.getDate() - i);
      const key = formatDateShort(d);
      days[key] = { date: key, emptyToFull: 0, fullToEmpty: 0 };
    }
    filtered.forEach((r) => {
      const d = formatDateShort(new Date(r.changeTime));
      if (days[d]) {
        if (r.beforeStatus === '空载' && r.afterStatus === '满载') days[d].emptyToFull++;
        if (r.beforeStatus === '满载' && r.afterStatus === '空载') days[d].fullToEmpty++;
      }
    });
    return Object.values(days);
  }, [filtered]);

  const typeDistData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      counts[r.carrierType] = (counts[r.carrierType] || 0) + 1;
    });
    return Object.entries(counts).map(([type, count]) => ({ type, count }));
  }, [filtered]);

  const triggerPieData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      counts[r.triggerMethod] = (counts[r.triggerMethod] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [filtered]);

  const handleExport = () => {
    alert(`正在导出 ${filtered.length} 条空满载记录为 Excel...`);
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
            <option value="all">全部类型</option>
            {CARRIER_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <select value={statusChangeFilter} onChange={(e) => { setStatusChangeFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部状态变化</option>
          <option value="空->满">空载→满载</option>
          <option value="满->空">满载→空载</option>
          <option value="未知->空">未知→空载</option>
          <option value="未知->满">未知→满载</option>
        </select>
        <select value={triggerFilter} onChange={(e) => { setTriggerFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部触发方式</option>
          {TRIGGER_METHODS.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={projectFilter} onChange={(e) => { setProjectFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部项目</option>
          {PROJECTS.filter(p => p !== null).map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select value={timeRange} onChange={(e) => { setTimeRange(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="7d">近7天</option>
          <option value="30d">近30天</option>
          <option value="90d">近90天</option>
          <option value="1y">本年度</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input type="text" value={search} onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }} placeholder="搜索载具编号、类型、记录ID..." className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" />
          </div>
        </div>
        <button onClick={handleExport} className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <Download size={15} /> 导出当前数据
        </button>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">空满载状态变化趋势（近30天）</div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={trendData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend />
              <Line type="monotone" dataKey="emptyToFull" stroke="#2563EB" name="空载→满载" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="fullToEmpty" stroke="#10B981" name="满载→空载" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">触发方式占比</div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart><Pie data={triggerPieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>{triggerPieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-card p-4">
        <div className="text-sm font-medium text-[#0F172A] mb-3">载具类型空满载分布</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={typeDistData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="type" /><YAxis /><Tooltip /><Legend /><Bar dataKey="count" fill="#2563EB" name="记录数" /></BarChart>
        </ResponsiveContainer>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#F1F5F9]">
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">记录ID</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">载具编号</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">类型/型号</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">变更时间</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">变更前→后</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">触发方式</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">触发位置</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">关联调拨单</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">关联项目</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">操作人</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">备注</th>
            </tr></thead>
            <tbody>
              {paginated.map((r, idx) => (
                <motion.tr key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: idx * 0.03 }} className="group border-b border-[#E2E8F0] hover:bg-[#F8FAFC] transition-colors">
                  <td className="px-3 py-3"><span className="text-sm font-mono text-[#0F172A]">{r.id}</span></td>
                  <td className="px-3 py-3"><span className="text-sm font-medium text-[#0F172A]">{r.carrierCode}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.carrierType} / {r.carrierModel}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] font-mono whitespace-nowrap">{r.changeTime}</span></td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1">
                      <Tag label={r.beforeStatus} color={r.beforeStatus === '空载' ? '#F59E0B' : r.beforeStatus === '满载' ? '#10B981' : '#94A3B8'} bg={r.beforeStatus === '空载' ? '#FFFBEB' : r.beforeStatus === '满载' ? '#ECFDF5' : '#F1F5F9'} />
                      <ChevronRight size={14} className="text-[#94A3B8]" />
                      <Tag label={r.afterStatus} color={r.afterStatus === '空载' ? '#F59E0B' : r.afterStatus === '满载' ? '#10B981' : '#94A3B8'} bg={r.afterStatus === '空载' ? '#FFFBEB' : r.afterStatus === '满载' ? '#ECFDF5' : '#F1F5F9'} />
                    </div>
                  </td>
                  <td className="px-3 py-3"><span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', triggerMethodBadgeClass(r.triggerMethod))}>{r.triggerMethod}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.triggerLocation}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] font-mono">{r.transferOrderNo || '-'}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.relatedProject || '-'}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.operator || '-'}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#94A3B8] max-w-[120px] truncate block" title={r.remark || ''}>{r.remark || '-'}</span></td>
                </motion.tr>
              ))}
              {paginated.length === 0 && (
                <tr><td colSpan={11} className="py-16 text-center">
                  <div className="flex flex-col items-center gap-3"><Database size={48} className="text-[#CBD5E1]" /><p className="text-base text-[#475569]">暂无记录</p></div>
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <Pagination currentPage={currentPage} totalPages={totalPages} totalItems={filtered.length} onPageChange={(p) => setCurrentPage(p)} />
      </div>
    </div>
  );
}

/* ================================================================
   Tab 2: Inventory Snapshots
   ================================================================ */
function InventorySnapshotTab() {
  const [search, setSearch] = useState('');
  const [dimensionFilter, setDimensionFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [timeRange, setTimeRange] = useState('30d');
  const [currentPage, setCurrentPage] = useState(1);
  const [compareOpen, setCompareOpen] = useState(false);
  const [compareA, setCompareA] = useState('');
  const [compareB, setCompareB] = useState('');
  const pageSize = 10;

  const filtered = useMemo(() => {
    return MOCK_INVENTORY_SNAPSHOTS.filter((r) => {
      if (search) {
        const kw = search.toLowerCase();
        if (!r.dimensionName.toLowerCase().includes(kw) && !r.id.toLowerCase().includes(kw)) return false;
      }
      if (dimensionFilter !== 'all' && r.dimension !== dimensionFilter) return false;
      if (typeFilter !== 'all' && r.typeBreakdown[typeFilter] === undefined) return false;
      if (timeRange !== 'all') {
        const date = new Date(r.snapshotTime);
        const now = new Date('2025-04-29');
        const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
        const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
        if (date < cutoff) return false;
      }
      return true;
    });
  }, [search, dimensionFilter, typeFilter, timeRange]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  // Chart data
  const trendData = useMemo(() => {
    const days: Record<string, { date: string; inStock: number; inTransit: number; stagnant: number }> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date('2025-04-29');
      d.setDate(d.getDate() - i);
      const key = formatDateShort(d);
      days[key] = { date: key, inStock: 0, inTransit: 0, stagnant: 0 };
    }
    filtered.forEach((r) => {
      const d = formatDateShort(new Date(r.snapshotTime));
      if (days[d]) {
        days[d].inStock += r.inStockCount;
        days[d].inTransit += r.inTransitCount;
        days[d].stagnant += r.stagnantCount;
      }
    });
    return Object.values(days);
  }, [filtered]);

  const pieData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      Object.entries(r.typeBreakdown).forEach(([k, v]) => {
        counts[k] = (counts[k] || 0) + v;
      });
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [filtered]);

  const changeData = useMemo(() => {
    return filtered.slice(0, 10).map(r => ({ name: r.dimensionName, change: r.changeFromLast }));
  }, [filtered]);

  const handleExport = () => {
    alert(`正在导出 ${filtered.length} 条库存快照为 Excel...`);
  };

  const handleSnapshot = () => {
    alert('已触发库存快照生成（模拟），新快照将在几分钟后可用。');
  };

  const handleCompare = () => {
    if (!compareA || !compareB) { alert('请选择两个快照进行对比'); return; }
    alert(`正在对比快照 ${compareA} 与 ${compareB}...`);
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select value={dimensionFilter} onChange={(e) => { setDimensionFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
            <option value="all">全部维度</option>
            {DIMENSIONS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部载具类型</option>
          {CARRIER_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={timeRange} onChange={(e) => { setTimeRange(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="7d">近7天</option>
          <option value="30d">近30天</option>
          <option value="90d">近90天</option>
          <option value="1y">本年度</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input type="text" value={search} onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }} placeholder="搜索维度名称、快照ID..." className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" />
          </div>
        </div>
        <button onClick={() => setCompareOpen(!compareOpen)} className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <ArrowLeftRight size={15} /> 时间轴对比
        </button>
        <button onClick={handleSnapshot} className="h-9 px-4 rounded-md bg-[#2563EB] text-white text-sm hover:bg-[#1D4ED8] flex items-center gap-2 transition-colors">
          <RefreshCw size={15} /> 立即生成快照
        </button>
        <button onClick={handleExport} className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <Download size={15} /> 导出当前数据
        </button>
      </div>

      {/* Compare Panel */}
      <AnimatePresence>
        {compareOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="bg-white rounded-lg shadow-card p-4 overflow-hidden">
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-[#0F172A]">选择两个快照进行对比：</span>
              <select value={compareA} onChange={(e) => setCompareA(e.target.value)} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
                <option value="">选择快照A</option>
                {MOCK_INVENTORY_SNAPSHOTS.map(s => <option key={s.id} value={s.id}>{s.id} ({s.dimensionName})</option>)}
              </select>
              <ArrowLeftRight size={16} className="text-[#94A3B8]" />
              <select value={compareB} onChange={(e) => setCompareB(e.target.value)} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
                <option value="">选择快照B</option>
                {MOCK_INVENTORY_SNAPSHOTS.map(s => <option key={s.id} value={s.id}>{s.id} ({s.dimensionName})</option>)}
              </select>
              <button onClick={handleCompare} className="h-9 px-4 rounded-md bg-[#10B981] text-white text-sm hover:bg-[#059669] flex items-center gap-2 transition-colors">
                <Eye size={15} /> 开始对比
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">库存趋势（近30天）</div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={trendData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend />
              <Area type="monotone" dataKey="inStock" stackId="1" stroke="#2563EB" fill="#2563EB" fillOpacity={0.3} name="在库" />
              <Area type="monotone" dataKey="inTransit" stackId="1" stroke="#10B981" fill="#10B981" fillOpacity={0.3} name="在途" />
              <Area type="monotone" dataKey="stagnant" stackId="1" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.3} name="呆滞" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">库存结构（载具类型占比）</div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart><Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>{pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-white rounded-lg shadow-card p-4">
        <div className="text-sm font-medium text-[#0F172A] mb-3">环比变化 Top10</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={changeData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" angle={-20} textAnchor="end" height={60} /><YAxis /><Tooltip /><Legend />
            <Bar dataKey="change" fill="#2563EB" name="环比变化量" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#F1F5F9]">
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">快照ID</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">快照时间</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">统计维度</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">维度名称</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">载具总数</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">在库/在途</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">空载/满载/呆滞</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">类型分解</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">环比变化</th>
            </tr></thead>
            <tbody>
              {paginated.map((r, idx) => (
                <motion.tr key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: idx * 0.03 }} className="group border-b border-[#E2E8F0] hover:bg-[#F8FAFC] transition-colors">
                  <td className="px-3 py-3"><span className="text-sm font-mono text-[#0F172A]">{r.id}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] font-mono whitespace-nowrap">{r.snapshotTime}</span></td>
                  <td className="px-3 py-3"><Tag label={r.dimension} color="#2563EB" bg="#EFF6FF" /></td>
                  <td className="px-3 py-3"><span className="text-sm font-medium text-[#0F172A]">{r.dimensionName}</span></td>
                  <td className="px-3 py-3"><span className="text-sm font-semibold text-[#0F172A]">{r.totalCount}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.inStockCount} / {r.inTransitCount}</span></td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1">
                      <span className="text-xs text-[#F59E0B]">空{r.emptyCount}</span>
                      <span className="text-xs text-[#10B981]">满{r.fullCount}</span>
                      <span className="text-xs text-[#94A3B8]">呆{r.stagnantCount}</span>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(r.typeBreakdown).map(([k, v]) => (
                        <span key={k} className="text-[11px] text-[#475569] bg-[#F1F5F9] px-1.5 py-0.5 rounded">{k}:{v}</span>
                      ))}
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <span className={cn('text-sm font-medium', r.changeFromLast > 0 ? 'text-[#10B981]' : r.changeFromLast < 0 ? 'text-[#EF4444]' : 'text-[#475569]')}>
                      {r.changeFromLast > 0 ? '+' : ''}{r.changeFromLast}
                    </span>
                  </td>
                </motion.tr>
              ))}
              {paginated.length === 0 && (
                <tr><td colSpan={9} className="py-16 text-center">
                  <div className="flex flex-col items-center gap-3"><Database size={48} className="text-[#CBD5E1]" /><p className="text-base text-[#475569]">暂无快照</p></div>
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <Pagination currentPage={currentPage} totalPages={totalPages} totalItems={filtered.length} onPageChange={(p) => setCurrentPage(p)} />
      </div>
    </div>
  );
}

/* ================================================================
   Tab 3: IO Records
   ================================================================ */
function IoRecordsTab() {
  const [search, setSearch] = useState('');
  const [ioTypeFilter, setIoTypeFilter] = useState<'all' | IoType>('all');
  const [judgeFilter, setJudgeFilter] = useState<'all' | JudgeMethod>('all');
  const [siteFilter, setSiteFilter] = useState('all');
  const [projectFilter, setProjectFilter] = useState('all');
  const [resultFilter, setResultFilter] = useState<'all' | IoResult>('all');
  const [timeRange, setTimeRange] = useState('30d');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const filtered = useMemo(() => {
    return MOCK_IO_RECORDS.filter((r) => {
      if (search) {
        const kw = search.toLowerCase();
        if (!r.carrierCode.toLowerCase().includes(kw) && !r.carrierType.toLowerCase().includes(kw) && !r.id.toLowerCase().includes(kw)) return false;
      }
      if (ioTypeFilter !== 'all' && r.ioType !== ioTypeFilter) return false;
      if (judgeFilter !== 'all' && r.judgeMethod !== judgeFilter) return false;
      if (siteFilter !== 'all' && r.siteName !== siteFilter) return false;
      if (projectFilter !== 'all' && r.relatedProject !== projectFilter) return false;
      if (resultFilter !== 'all' && r.result !== resultFilter) return false;
      if (timeRange !== 'all') {
        const date = new Date(r.operationTime);
        const now = new Date('2025-04-29');
        const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : timeRange === '90d' ? 90 : 365;
        const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
        if (date < cutoff) return false;
      }
      return true;
    });
  }, [search, ioTypeFilter, judgeFilter, siteFilter, projectFilter, resultFilter, timeRange]);

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  // Charts
  const trendData = useMemo(() => {
    const days: Record<string, { date: string; inbound: number; outbound: number }> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date('2025-04-29');
      d.setDate(d.getDate() - i);
      const key = formatDateShort(d);
      days[key] = { date: key, inbound: 0, outbound: 0 };
    }
    filtered.forEach((r) => {
      const d = formatDateShort(new Date(r.operationTime));
      if (days[d]) {
        if (r.ioType === '入库') days[d].inbound++;
        else days[d].outbound++;
      }
    });
    return Object.values(days);
  }, [filtered]);

  const judgePieData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      counts[r.judgeMethod] = (counts[r.judgeMethod] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [filtered]);

  const siteTopData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      counts[r.siteName] = (counts[r.siteName] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 10);
  }, [filtered]);

  const abnormalTrendData = useMemo(() => {
    const days: Record<string, { date: string; abnormal: number }> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date('2025-04-29');
      d.setDate(d.getDate() - i);
      const key = formatDateShort(d);
      days[key] = { date: key, abnormal: 0 };
    }
    filtered.forEach((r) => {
      const d = formatDateShort(new Date(r.operationTime));
      if (days[d] && (r.result === '异常' || r.result === '失败')) {
        days[d].abnormal++;
      }
    });
    return Object.values(days);
  }, [filtered]);

  const handleExport = () => {
    alert(`正在导出 ${filtered.length} 条进出库记录为 Excel...`);
  };

  return (
    <div className="space-y-5">
      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-[#94A3B8]" />
          <select value={ioTypeFilter} onChange={(e) => { setIoTypeFilter(e.target.value as 'all' | IoType); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
            <option value="all">全部操作</option>
            <option value="入库">入库</option>
            <option value="出库">出库</option>
          </select>
        </div>
        <select value={judgeFilter} onChange={(e) => { setJudgeFilter(e.target.value as 'all' | JudgeMethod); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部判定方式</option>
          {JUDGE_METHODS.map(m => <option key={m} value={m}>{m}</option>)}
        </select>
        <select value={siteFilter} onChange={(e) => { setSiteFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部网点</option>
          {SITES.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select value={projectFilter} onChange={(e) => { setProjectFilter(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部项目</option>
          {PROJECTS.filter(p => p !== null).map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select value={resultFilter} onChange={(e) => { setResultFilter(e.target.value as 'all' | IoResult); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="all">全部结果</option>
          <option value="成功">成功</option>
          <option value="失败">失败</option>
          <option value="异常">异常</option>
        </select>
        <select value={timeRange} onChange={(e) => { setTimeRange(e.target.value); setCurrentPage(1); }} className="h-9 px-3 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] bg-white">
          <option value="7d">近7天</option>
          <option value="30d">近30天</option>
          <option value="90d">近90天</option>
          <option value="1y">本年度</option>
        </select>
        <div className="flex-1 min-w-[200px] max-w-sm ml-auto">
          <div className="relative">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <input type="text" value={search} onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }} placeholder="搜索载具编号、类型、记录ID..." className="w-full h-9 pl-9 pr-4 border border-[#CBD5E1] rounded-md text-sm focus:outline-none focus:border-[#2563EB] focus:shadow-focus" />
          </div>
        </div>
        <button onClick={handleExport} className="h-9 px-4 rounded-md border border-[#E2E8F0] bg-white text-sm text-[#0F172A] hover:bg-[#F8FAFC] flex items-center gap-2 transition-colors">
          <Download size={15} /> 导出当前数据
        </button>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">出入库量趋势（近30天）</div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={trendData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend />
              <Bar dataKey="inbound" fill="#2563EB" name="入库" />
              <Bar dataKey="outbound" fill="#10B981" name="出库" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">判定方式占比</div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart><Pie data={judgePieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>{judgePieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">出入库 Top10 网点</div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={siteTopData} layout="vertical"><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" /><YAxis dataKey="name" type="category" width={100} /><Tooltip /><Legend />
              <Bar dataKey="value" fill="#8B5CF6" name="记录数" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-lg shadow-card p-4">
          <div className="text-sm font-medium text-[#0F172A] mb-3">异常出入库趋势（近30天）</div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={abnormalTrendData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis /><Tooltip /><Legend />
              <Line type="monotone" dataKey="abnormal" stroke="#EF4444" name="异常/失败数" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="bg-[#F1F5F9]">
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">记录ID</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">操作类型</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">载具编号</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">类型/型号</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">操作时间</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">所属网点/仓库</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">判定方式</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">判定详情</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">位置变化</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">关联调拨单</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">关联项目</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">操作人</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">结果</th>
              <th className="px-3 py-2.5 text-left text-[13px] font-medium text-[#475569] whitespace-nowrap">异常原因</th>
            </tr></thead>
            <tbody>
              {paginated.map((r, idx) => (
                <motion.tr key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: idx * 0.03 }} className="group border-b border-[#E2E8F0] hover:bg-[#F8FAFC] transition-colors">
                  <td className="px-3 py-3"><span className="text-sm font-mono text-[#0F172A]">{r.id}</span></td>
                  <td className="px-3 py-3"><span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', statusBadgeClass(r.ioType))}>{r.ioType}</span></td>
                  <td className="px-3 py-3"><span className="text-sm font-medium text-[#0F172A]">{r.carrierCode}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.carrierType} / {r.carrierModel}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] font-mono whitespace-nowrap">{r.operationTime}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.siteName} / {r.warehouseName}</span></td>
                  <td className="px-3 py-3"><span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', judgeMethodBadgeClass(r.judgeMethod))}>{r.judgeMethod}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] max-w-[140px] truncate block" title={r.judgeDetail}>{r.judgeDetail}</span></td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1 text-xs text-[#475569]">
                      <span className="truncate max-w-[60px]">{r.beforeLocation}</span>
                      <ChevronRight size={12} className="text-[#94A3B8] flex-shrink-0" />
                      <span className="truncate max-w-[60px]">{r.afterLocation}</span>
                    </div>
                  </td>
                  <td className="px-3 py-3"><span className="text-xs text-[#475569] font-mono">{r.transferOrderNo || '-'}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.relatedProject || '-'}</span></td>
                  <td className="px-3 py-3"><span className="text-sm text-[#475569]">{r.operator || '-'}</span></td>
                  <td className="px-3 py-3"><span className={cn('inline-flex items-center px-2 py-0.5 rounded text-xs font-medium', statusBadgeClass(r.result))}>{r.result}</span></td>
                  <td className="px-3 py-3"><span className="text-xs text-[#EF4444] max-w-[120px] truncate block" title={r.abnormalReason || ''}>{r.abnormalReason || '-'}</span></td>
                </motion.tr>
              ))}
              {paginated.length === 0 && (
                <tr><td colSpan={14} className="py-16 text-center">
                  <div className="flex flex-col items-center gap-3"><Database size={48} className="text-[#CBD5E1]" /><p className="text-base text-[#475569]">暂无记录</p></div>
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        <Pagination currentPage={currentPage} totalPages={totalPages} totalItems={filtered.length} onPageChange={(p) => setCurrentPage(p)} />
      </div>
    </div>
  );
}

/* ================================================================
   Main Page Component
   ================================================================ */
const TAB_OPTIONS = [
  { key: 'empty-full', label: '历史空满载记录', icon: Scale },
  { key: 'inventory', label: '历史库存统计', icon: Warehouse },
  { key: 'io', label: '历史进出库记录', icon: ArrowLeftRight },
] as const;

export default function HistoryDataCenterPage() {
  const [activeTab, setActiveTab] = useState<'empty-full' | 'inventory' | 'io'>('empty-full');

  // KPI calculations
  const kpiData = useMemo(() => {
    const emptyFullTotal = MOCK_EMPTY_FULL_RECORDS.length;
    const snapshotTotal = MOCK_INVENTORY_SNAPSHOTS.length;
    const ioTotal = MOCK_IO_RECORDS.length;
    const allDates = [
      ...MOCK_EMPTY_FULL_RECORDS.map(r => new Date(r.changeTime)),
      ...MOCK_INVENTORY_SNAPSHOTS.map(r => new Date(r.snapshotTime)),
      ...MOCK_IO_RECORDS.map(r => new Date(r.operationTime)),
    ];
    const minDate = allDates.length > 0 ? new Date(Math.min(...allDates.map(d => d.getTime()))) : new Date();
    const today = new Date('2025-04-29');
    const coverageDays = Math.max(1, Math.ceil((today.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24)));
    return { emptyFullTotal, snapshotTotal, ioTotal, coverageDays };
  }, []);

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#0F172A]">历史数据中心</h1>
          <p className="text-sm text-[#475569] mt-1">载具状态、库存快照、出入库记录的深度追溯与统计分析</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KPICard
          title="历史空满载记录"
          value={kpiData.emptyFullTotal}
          subtext="状态变化追溯"
          color="#2563EB"
          icon={Scale}
        />
        <KPICard
          title="历史库存快照"
          value={kpiData.snapshotTotal}
          subtext="库存趋势分析"
          color="#8B5CF6"
          icon={Warehouse}
        />
        <KPICard
          title="历史进出库记录"
          value={kpiData.ioTotal}
          subtext="出入库审计"
          color="#10B981"
          icon={ArrowLeftRight}
        />
        <KPICard
          title="数据覆盖天数"
          value={`${kpiData.coverageDays}天`}
          subtext="从最早记录至今"
          color="#F59E0B"
          icon={Calendar}
        />
      </div>

      {/* Tab Navigation */}
      <div>
        <div className="flex border-b border-[#E2E8F0]">
          {TAB_OPTIONS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key as 'empty-full' | 'inventory' | 'io')}
              className={cn(
                'relative flex items-center gap-2 px-5 py-3 text-sm font-medium transition-colors',
                activeTab === tab.key ? 'text-[#2563EB]' : 'text-[#475569] hover:text-[#0F172A]'
              )}
            >
              <tab.icon size={16} />
              {tab.label}
              {activeTab === tab.key && (
                <motion.div
                  layoutId="historyTabIndicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2563EB] rounded-full"
                  transition={{ duration: 0.2 }}
                />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'empty-full' && <EmptyFullTab />}
          {activeTab === 'inventory' && <InventorySnapshotTab />}
          {activeTab === 'io' && <IoRecordsTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
