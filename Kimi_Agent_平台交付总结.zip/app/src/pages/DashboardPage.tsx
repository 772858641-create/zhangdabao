import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  RefreshCw,
  ChevronDown,
  ArrowUpDown,
  Package,
  Truck,
  Warehouse,
  Container,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';

// --- Types ---
interface SiteInventory {
  rank: number;
  siteName: string;
  carrierCount: number;
  normal: number;
  repairing: number;
  cleaning: number;
  damaged: number;
  scrapped: number;
}

type TimeRange = 'today' | 'yesterday' | '7d' | '30d' | 'thisMonth' | 'lastMonth';
type SortField = 'rank' | 'siteName' | 'carrierCount' | 'normal' | 'repairing' | 'cleaning' | 'damaged' | 'scrapped';
type SortDirection = 'asc' | 'desc';

const timeRangeOptions: { label: string; value: TimeRange }[] = [
  { label: '今天', value: 'today' },
  { label: '昨天', value: 'yesterday' },
  { label: '近7天', value: '7d' },
  { label: '近30天', value: '30d' },
  { label: '本月', value: 'thisMonth' },
  { label: '上月', value: 'lastMonth' },
];

const CHART_COLORS = [
  '#2563EB',
  '#10B981',
  '#F59E0B',
  '#EF4444',
  '#8B5CF6',
  '#06B6D4',
  '#EC4899',
  '#14B8A6',
];

// --- Sparkline mini chart component ---
function Sparkline({ data, color }: { data: number[]; color: string; positive?: boolean }) {
  const width = 120;
  const height = 36;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * height;
    return `${x},${y}`;
  });

  return (
    <svg width={width} height={height} className="flex-shrink-0">
      <polyline
        points={points.join(' ')}
        fill="none"
        stroke={color}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx={points[points.length - 1].split(',')[0]} cy={points[points.length - 1].split(',')[1]} r={3} fill={color} />
    </svg>
  );
}

// --- KPI Card component ---
interface KPICardProps {
  title: string;
  value: string;
  change: number;
  unit: string;
  color: string;
  icon: React.ReactNode;
  sparkData: number[];
  delay?: number;
}

function KPICard({ title, value, change, unit, color, icon, sparkData, delay = 0 }: KPICardProps) {
  const positive = change >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="bg-white rounded-lg shadow-card p-4 hover:shadow-card-hover transition-shadow duration-200 relative overflow-hidden"
      style={{ borderLeft: `4px solid ${color}` }}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-neutral-textSecondary mb-1">{title}</p>
          <div className="flex items-baseline gap-1">
            <span className="text-[28px] font-semibold text-neutral-textPrimary font-number tracking-tight">
              {value}
            </span>
            <span className="text-xs text-neutral-textSecondary">{unit}</span>
          </div>
          <div className="flex items-center gap-1 mt-1">
            {positive ? (
              <TrendingUp size={14} className="text-success" />
            ) : (
              <TrendingDown size={14} className="text-danger" />
            )}
            <span
              className={cn(
                'text-xs font-medium',
                positive ? 'text-success' : 'text-danger'
              )}
            >
              {positive ? '+' : ''}
              {change}%
            </span>
            <span className="text-[11px] text-neutral-textTertiary ml-0.5">环比</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${color}15` }}
          >
            {icon}
          </div>
          <Sparkline data={sparkData} color={color} positive={positive} />
        </div>
      </div>
    </motion.div>
  );
}

// --- Custom tooltip for charts ---
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white rounded-lg shadow-dropdown border border-neutral-border px-3 py-2">
      {label && <p className="text-xs text-neutral-textSecondary mb-1">{label}</p>}
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-2 py-0.5">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
          <span className="text-xs text-neutral-textSecondary">{entry.name}:</span>
          <span className="text-xs font-medium text-neutral-textPrimary font-number">{entry.value.toLocaleString()}</span>
        </div>
      ))}
    </div>
  );
}

// --- Main Dashboard Page ---
export default function DashboardPage() {
  const { carriers, sites, vehicles, carrierTypeDistribution } = useMockData();

  const [timeRange, setTimeRange] = useState<TimeRange>('7d');
  const [showTimeDropdown, setShowTimeDropdown] = useState(false);
  const [orgFilter, setOrgFilter] = useState<string>('all');
  const [refreshing, setRefreshing] = useState(false);
  const [sortField, setSortField] = useState<SortField>('carrierCount');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');

  // Refresh handler
  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  };

  // Generate sparkline data
  const generateSparkData = (base: number, length: number) =>
    Array.from({ length }, () => base + Math.floor(Math.random() * 40) - 20);

  // KPI data
  const kpiCards = useMemo(() => {
    const totalInStock = carriers.length;
    const totalInTransit = vehicles.filter((v) => v.status === 'in_transit').length;
    const todayInbound = 156; // Mock
    const todayOutbound = 203; // Mock

    return [
      {
        title: '在库总数',
        value: totalInStock.toLocaleString(),
        change: 3.2,
        unit: '个',
        color: '#2563EB',
        icon: <Package size={18} style={{ color: '#2563EB' }} />,
        sparkData: generateSparkData(totalInStock, 7),
      },
      {
        title: '在途总数',
        value: totalInTransit.toString(),
        change: 8.1,
        unit: '辆',
        color: '#10B981',
        icon: <Truck size={18} style={{ color: '#10B981' }} />,
        sparkData: generateSparkData(totalInTransit, 7),
      },
      {
        title: '今日入库',
        value: todayInbound.toString(),
        change: -12.5,
        unit: '个',
        color: '#F59E0B',
        icon: <Warehouse size={18} style={{ color: '#F59E0B' }} />,
        sparkData: generateSparkData(todayInbound, 7),
      },
      {
        title: '今日出库',
        value: todayOutbound.toString(),
        change: 5.7,
        unit: '个',
        color: '#8B5CF6',
        icon: <Container size={18} style={{ color: '#8B5CF6' }} />,
        sparkData: generateSparkData(todayOutbound, 7),
      },
    ];
  }, [carriers, vehicles]);

  // Site inventory bar chart data
  const siteInventoryData = useMemo(
    () =>
      sites.map((site) => {
        const siteCarriers = carriers.filter((c) => c.siteId === site.id);
        return {
          name: site.name.length > 8 ? site.name.slice(0, 8) + '...' : site.name,
          fullName: site.name,
          在库数: siteCarriers.filter((c) => c.status === 'normal').length,
          维修中: siteCarriers.filter((c) => c.status === 'repairing').length,
          清洁中: siteCarriers.filter((c) => c.status === 'cleaning').length,
          已损坏: siteCarriers.filter((c) => c.status === 'damaged').length,
          已报废: siteCarriers.filter((c) => c.status === 'scrapped').length,
        };
      }),
    [sites, carriers]
  );

  // 7-day in/out bound trend
  const sevenDayTrend = useMemo(
    () =>
      Array.from({ length: 7 }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (6 - i));
        const month = d.getMonth() + 1;
        const day = d.getDate();
        return {
          date: `${month}/${day}`,
          入库: 80 + Math.floor(Math.random() * 120),
          出库: 60 + Math.floor(Math.random() * 140),
          调拨: 20 + Math.floor(Math.random() * 60),
        };
      }),
    [refreshing]
  );

  // TOP 10 site inventory ranking
  const siteRankingData: SiteInventory[] = useMemo(() => {
    const data = sites.map((site, idx) => {
      const siteCarriers = carriers.filter((c) => c.siteId === site.id);
      return {
        rank: idx + 1,
        siteName: site.name,
        carrierCount: siteCarriers.length,
        normal: siteCarriers.filter((c) => c.status === 'normal').length,
        repairing: siteCarriers.filter((c) => c.status === 'repairing').length,
        cleaning: siteCarriers.filter((c) => c.status === 'cleaning').length,
        damaged: siteCarriers.filter((c) => c.status === 'damaged').length,
        scrapped: siteCarriers.filter((c) => c.status === 'scrapped').length,
      };
    });
    return data.sort((a, b) => b.carrierCount - a.carrierCount);
  }, [sites, carriers]);

  const sortedRanking = useMemo(() => {
    const sorted = [...siteRankingData];
    sorted.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return sortDirection === 'asc'
        ? String(aVal).localeCompare(String(bVal))
        : String(bVal).localeCompare(String(aVal));
    });
    return sorted;
  }, [siteRankingData, sortField, sortDirection]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const SortHeader = ({ field, children, className }: { field: SortField; children: React.ReactNode; className?: string }) => (
    <th
      className={cn(
        'px-3 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary cursor-pointer select-none hover:text-neutral-textPrimary transition-colors',
        className
      )}
      onClick={() => handleSort(field)}
    >
      <div className="flex items-center gap-1">
        {children}
        <ArrowUpDown size={12} className={cn(sortField === field ? 'text-primary' : 'text-neutral-textTertiary')} />
      </div>
    </th>
  );

  return (
    <div className="p-5 space-y-5">
      {/* Top Filter Bar */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="flex flex-wrap items-center gap-3 bg-white rounded-lg shadow-card px-4 py-3"
      >
        {/* Time range selector */}
        <div className="relative">
          <button
            onClick={() => setShowTimeDropdown(!showTimeDropdown)}
            className="flex items-center gap-2 h-8 px-3 text-[13px] border border-neutral-border-strong rounded-md bg-white text-neutral-textPrimary hover:border-primary focus:outline-none focus:border-primary focus:shadow-focus transition-all"
          >
            {timeRangeOptions.find((o) => o.value === timeRange)?.label}
            <ChevronDown size={14} className="text-neutral-textTertiary" />
          </button>
          {showTimeDropdown && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowTimeDropdown(false)} />
              <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-dropdown border border-neutral-border py-1 z-20 min-w-[120px]">
                {timeRangeOptions.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      setTimeRange(opt.value);
                      setShowTimeDropdown(false);
                    }}
                    className={cn(
                      'block w-full text-left px-3 py-1.5 text-[13px] hover:bg-neutral-surface-elevated transition-colors',
                      timeRange === opt.value ? 'text-primary bg-primary-light' : 'text-neutral-textPrimary'
                    )}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {/* Organization selector */}
        <select
          value={orgFilter}
          onChange={(e) => setOrgFilter(e.target.value)}
          className="h-8 px-3 text-[13px] border border-neutral-border-strong rounded-md bg-white text-neutral-textPrimary hover:border-primary focus:outline-none focus:border-primary focus:shadow-focus transition-all"
        >
          <option value="all">全部组织</option>
          <option value="org-2">华东汽车制造有限公司</option>
          <option value="org-3">南方物流集团</option>
          <option value="org-4">北方供应链管理有限公司</option>
        </select>

        <div className="flex-1" />

        {/* Refresh button */}
        <button
          onClick={handleRefresh}
          className="flex items-center gap-1.5 h-8 px-3 text-[13px] text-neutral-textSecondary hover:text-primary hover:bg-primary-light rounded-md transition-all"
        >
          <RefreshCw size={14} className={cn(refreshing && 'animate-spin')} />
          刷新
        </button>
      </motion.div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpiCards.map((card, i) => (
          <KPICard key={card.title} {...card} delay={i * 0.05} />
        ))}
      </div>

      {/* Charts Row 1: Bar + Pie */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Bar Chart: Site Inventory */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.15, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="lg:col-span-2 bg-white rounded-lg shadow-card p-4"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-neutral-textPrimary">各网点库存对比</h3>
            <span className="text-xs text-neutral-textTertiary">单位：个</span>
          </div>
          <div className="h-[260px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={siteInventoryData} barCategoryGap="20%">
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
                <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
                <Bar dataKey="在库数" fill="#2563EB" radius={[4, 4, 0, 0]} />
                <Bar dataKey="维修中" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                <Bar dataKey="清洁中" fill="#06B6D4" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Pie Chart: Carrier Type Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="bg-white rounded-lg shadow-card p-4"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-medium text-neutral-textPrimary">载具类型分布</h3>
          </div>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={carrierTypeDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={3}
                  dataKey="value"
                  nameKey="name"
                  strokeWidth={0}
                >
                  {carrierTypeDistribution.map((_e, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 justify-center">
            {carrierTypeDistribution.map((entry, index) => (
              <div key={entry.name} className="flex items-center gap-1.5">
                <span
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ backgroundColor: CHART_COLORS[index % CHART_COLORS.length] }}
                />
                <span className="text-xs text-neutral-textSecondary">{entry.name}</span>
                <span className="text-xs font-medium text-neutral-textPrimary font-number">
                  {((entry.value / carrierTypeDistribution.reduce((s, c) => s + c.value, 0)) * 100).toFixed(1)}%
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Charts Row 2: Line Chart */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="bg-white rounded-lg shadow-card p-4"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-neutral-textPrimary">近7天出入库趋势</h3>
          <span className="text-xs text-neutral-textTertiary">单位：个</span>
        </div>
        <div className="h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sevenDayTrend}>
              <defs>
                <linearGradient id="colorIn" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorOut" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.1} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
              <Area type="monotone" dataKey="入库" stroke="#2563EB" strokeWidth={2.5} fill="url(#colorIn)" dot={{ r: 4, fill: '#2563EB', strokeWidth: 0 }} activeDot={{ r: 6 }} />
              <Area type="monotone" dataKey="出库" stroke="#10B981" strokeWidth={2.5} fill="url(#colorOut)" dot={{ r: 4, fill: '#10B981', strokeWidth: 0 }} activeDot={{ r: 6 }} />
              <Line type="monotone" dataKey="调拨" stroke="#F59E0B" strokeWidth={2.5} dot={{ r: 4, fill: '#F59E0B', strokeWidth: 0 }} activeDot={{ r: 6 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* TOP 10 Site Inventory Table */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className="bg-white rounded-lg shadow-card p-4"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-neutral-textPrimary">TOP10 网点库存排名</h3>
          <span className="text-xs text-neutral-textTertiary">共 {sites.length} 个网点</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-neutral-surface-elevated">
                <SortHeader field="rank" className="w-14">排名</SortHeader>
                <SortHeader field="siteName">网点名称</SortHeader>
                <SortHeader field="carrierCount" className="text-right">载具总数</SortHeader>
                <SortHeader field="normal" className="text-right">正常</SortHeader>
                <SortHeader field="repairing" className="text-right">维修中</SortHeader>
                <SortHeader field="cleaning" className="text-right">清洁中</SortHeader>
                <SortHeader field="damaged" className="text-right">已损坏</SortHeader>
                <SortHeader field="scrapped" className="text-right">已报废</SortHeader>
                <th className="px-3 py-2.5 text-right text-[13px] font-medium text-neutral-textSecondary">分布</th>
              </tr>
            </thead>
            <tbody>
              {sortedRanking.slice(0, 10).map((row, index) => (
                <motion.tr
                  key={row.siteName}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2, delay: index * 0.03 }}
                  className={cn(
                    'border-t border-neutral-border hover:bg-primary-light transition-colors duration-150',
                    index % 2 === 1 && 'bg-neutral-background'
                  )}
                >
                  <td className="px-3 py-3">
                    <span
                      className={cn(
                        'inline-flex items-center justify-center w-6 h-6 rounded-full text-xs font-medium font-number',
                        index < 3
                          ? 'bg-primary-light text-primary'
                          : 'bg-neutral-surface-elevated text-neutral-textSecondary'
                      )}
                    >
                      {row.rank}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-sm text-neutral-textPrimary">{row.siteName}</td>
                  <td className="px-3 py-3 text-sm font-medium text-neutral-textPrimary font-number text-right">
                    {row.carrierCount}
                  </td>
                  <td className="px-3 py-3 text-sm text-success font-number text-right">{row.normal}</td>
                  <td className="px-3 py-3 text-sm text-warning font-number text-right">{row.repairing}</td>
                  <td className="px-3 py-3 text-sm text-info font-number text-right">{row.cleaning}</td>
                  <td className="px-3 py-3 text-sm text-danger font-number text-right">{row.damaged}</td>
                  <td className="px-3 py-3 text-sm text-neutral-textTertiary font-number text-right">{row.scrapped}</td>
                  <td className="px-3 py-3 text-right">
                    <div className="flex items-center justify-end gap-1 h-2 w-20 ml-auto">
                      {row.carrierCount > 0 && (
                        <>
                          <div
                            className="h-full rounded-l bg-success"
                            style={{ width: `${(row.normal / row.carrierCount) * 100}%` }}
                          />
                          <div
                            className="h-full bg-warning"
                            style={{ width: `${(row.repairing / row.carrierCount) * 100}%` }}
                          />
                          <div
                            className="h-full bg-info"
                            style={{ width: `${(row.cleaning / row.carrierCount) * 100}%` }}
                          />
                          <div
                            className="h-full bg-danger"
                            style={{ width: `${(row.damaged / row.carrierCount) * 100}%` }}
                          />
                          <div
                            className="h-full rounded-r bg-neutral-textTertiary"
                            style={{ width: `${(row.scrapped / row.carrierCount) * 100}%` }}
                          />
                        </>
                      )}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
