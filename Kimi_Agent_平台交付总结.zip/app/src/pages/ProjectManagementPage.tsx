import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  FolderKanban, Building2, Truck, Route, BarChart3, Plus, Edit, Trash2, Eye, Users, Calendar
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────────────────

interface ParticipatingOrg {
  id: string;
  name: string;
  status: 'APPROVED' | 'PENDING';
  joinedAt: string;
}

interface LogicalSite {
  logicId: string;
  logicalName: string;
  physicalSiteName: string;
}

interface TransferRoute {
  id: string;
  fromOrg: string;
  toOrg: string;
  fromSite: string;
  toSite: string;
  frequency: string;
  status: string;
}

interface Carrier {
  id: string;
  name: string;
  type: string;
  orgName: string;
  status: string;
}

interface Project {
  id: string;
  name: string;
  code: string;
  responsibleOrg: string;
  description: string;
  startDate: string;
  endDate: string;
  status: 'ONGOING' | 'ENDED' | 'DISBANDED';
  progress: number;
  participatingOrgs: ParticipatingOrg[];
  logicalSites: LogicalSite[];
  transferRoutes: TransferRoute[];
  carriers: Carrier[];
  carrierCount: number;
  createdAt: string;
  kpis: {
    monthlyTransfers: number;
    onTimeRate: number;
    utilizationRate: number;
    alarmCount: number;
  };
}

// ─── Mock Data ───────────────────────────────────────────────────────────────

const PIE_COLORS = ['var(--color-primary)', 'var(--color-neutral-textSecondary)', 'var(--color-neutral-textTertiary)'];
const BAR_COLOR = 'var(--color-primary)';

const mockProjects: Project[] = [
  {
    id: '1', name: '华东冷链物流项目', code: 'HDLL2024001', responsibleOrg: '华东运营中心',
    description: '覆盖江浙沪地区的冷链物流配送网络建设，包含12个配送节点。',
    startDate: '2024-01-15', endDate: '2024-12-31', status: 'ONGOING', progress: 78,
    carrierCount: 156, createdAt: '2024-01-10',
    participatingOrgs: [
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2024-01-10' },
      { id: 'o2', name: '华南运营中心', status: 'APPROVED', joinedAt: '2024-01-12' },
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2024-02-01' },
    ],
    logicalSites: [
      { logicId: 'LS001', logicalName: '上海中心仓', physicalSiteName: '青浦物流园' },
      { logicId: 'LS002', logicalName: '杭州分仓', physicalSiteName: '萧山物流基地' },
      { logicId: 'LS003', logicalName: '南京中转站', physicalSiteName: '江宁配送中心' },
    ],
    transferRoutes: [
      { id: 'r1', fromOrg: '华东运营中心', toOrg: '华南运营中心', fromSite: '上海中心仓', toSite: '广州中心仓', frequency: '每日2班', status: 'ACTIVE' },
      { id: 'r2', fromOrg: '华东运营中心', toOrg: '华北运营中心', fromSite: '上海中心仓', toSite: '北京中心仓', frequency: '每日1班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c1', name: '保温箱-A001', type: '保温箱', orgName: '华东运营中心', status: '在库' },
      { id: 'c2', name: '冷藏车-B002', type: '冷藏车', orgName: '华南运营中心', status: '在途' },
    ],
    kpis: { monthlyTransfers: 342, onTimeRate: 96.5, utilizationRate: 87.2, alarmCount: 3 },
  },
  {
    id: '2', name: '华南城配网络', code: 'HNCP2024002', responsibleOrg: '华南运营中心',
    description: '珠三角城市配送网络优化，提升次日达覆盖率至95%以上。',
    startDate: '2024-02-01', endDate: '2025-01-31', status: 'ONGOING', progress: 62,
    carrierCount: 203, createdAt: '2024-01-20',
    participatingOrgs: [
      { id: 'o2', name: '华南运营中心', status: 'APPROVED', joinedAt: '2024-01-20' },
      { id: 'o4', name: '西南运营中心', status: 'APPROVED', joinedAt: '2024-02-15' },
      { id: 'o5', name: '华中运营中心', status: 'PENDING', joinedAt: '' },
    ],
    logicalSites: [
      { logicId: 'LS004', logicalName: '广州中心仓', physicalSiteName: '增城物流园' },
      { logicId: 'LS005', logicalName: '深圳分仓', physicalSiteName: '龙岗配送中心' },
    ],
    transferRoutes: [
      { id: 'r3', fromOrg: '华南运营中心', toOrg: '西南运营中心', fromSite: '广州中心仓', toSite: '成都中心仓', frequency: '每日1班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c3', name: '配送箱-C003', type: '配送箱', orgName: '华南运营中心', status: '在库' },
    ],
    kpis: { monthlyTransfers: 278, onTimeRate: 94.2, utilizationRate: 82.1, alarmCount: 7 },
  },
  {
    id: '3', name: '华北仓配一体化', code: 'HBCK2024003', responsibleOrg: '华北运营中心',
    description: '京津冀仓配一体化项目，实现仓储与配送资源统一调度。',
    startDate: '2024-03-01', endDate: '2024-11-30', status: 'ONGOING', progress: 91,
    carrierCount: 128, createdAt: '2024-02-20',
    participatingOrgs: [
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2024-03-05' },
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2024-03-01' },
      { id: 'o6', name: '东北运营中心', status: 'APPROVED', joinedAt: '2024-03-10' },
    ],
    logicalSites: [
      { logicId: 'LS006', logicalName: '北京中心仓', physicalSiteName: '通州物流基地' },
      { logicId: 'LS007', logicalName: '天津分仓', physicalSiteName: '滨海新区物流中心' },
    ],
    transferRoutes: [
      { id: 'r4', fromOrg: '华北运营中心', toOrg: '华东运营中心', fromSite: '北京中心仓', toSite: '上海中心仓', frequency: '每日2班', status: 'ACTIVE' },
      { id: 'r5', fromOrg: '华北运营中心', toOrg: '东北运营中心', fromSite: '北京中心仓', toSite: '沈阳中心仓', frequency: '隔日1班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c4', name: '托盘-D004', type: '托盘', orgName: '华北运营中心', status: '在库' },
    ],
    kpis: { monthlyTransfers: 198, onTimeRate: 98.1, utilizationRate: 91.5, alarmCount: 1 },
  },
  {
    id: '4', name: '西部跨境物流通道', code: 'XBKB2024004', responsibleOrg: '西南运营中心',
    description: '连接西南地区与东南亚的跨境物流通道建设。',
    startDate: '2024-04-01', endDate: '2025-06-30', status: 'ONGOING', progress: 45,
    carrierCount: 89, createdAt: '2024-03-15',
    participatingOrgs: [
      { id: 'o4', name: '西南运营中心', status: 'APPROVED', joinedAt: '2024-04-01' },
      { id: 'o7', name: '西北运营中心', status: 'APPROVED', joinedAt: '2024-04-10' },
    ],
    logicalSites: [
      { logicId: 'LS008', logicalName: '成都中心仓', physicalSiteName: '双流物流园' },
      { logicId: 'LS009', logicalName: '昆明分仓', physicalSiteName: '经开区配送中心' },
    ],
    transferRoutes: [
      { id: 'r6', fromOrg: '西南运营中心', toOrg: '西北运营中心', fromSite: '成都中心仓', toSite: '西安中心仓', frequency: '每日1班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c5', name: '集装箱-E005', type: '集装箱', orgName: '西南运营中心', status: '在途' },
    ],
    kpis: { monthlyTransfers: 156, onTimeRate: 89.3, utilizationRate: 76.4, alarmCount: 12 },
  },
  {
    id: '5', name: '华中电商快配项目', code: 'HZDS2024005', responsibleOrg: '华中运营中心',
    description: '面向电商客户的极速配送服务，承诺江浙沪皖次日达。',
    startDate: '2024-05-01', endDate: '2024-10-31', status: 'ONGOING', progress: 88,
    carrierCount: 245, createdAt: '2024-04-20',
    participatingOrgs: [
      { id: 'o5', name: '华中运营中心', status: 'APPROVED', joinedAt: '2024-05-01' },
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2024-05-05' },
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2024-05-10' },
    ],
    logicalSites: [
      { logicId: 'LS010', logicalName: '武汉中心仓', physicalSiteName: '东西湖物流园' },
      { logicId: 'LS011', logicalName: '长沙分仓', physicalSiteName: '金霞物流中心' },
    ],
    transferRoutes: [
      { id: 'r7', fromOrg: '华中运营中心', toOrg: '华东运营中心', fromSite: '武汉中心仓', toSite: '上海中心仓', frequency: '每日3班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c6', name: '快递袋-F006', type: '快递袋', orgName: '华中运营中心', status: '在库' },
    ],
    kpis: { monthlyTransfers: 512, onTimeRate: 97.8, utilizationRate: 93.2, alarmCount: 2 },
  },
  {
    id: '6', name: '东北农产冷链专线', code: 'DBNC2024006', responsibleOrg: '东北运营中心',
    description: '东北地区农产品冷链运输专线，覆盖黑吉辽三省。',
    startDate: '2024-06-01', endDate: '2025-03-31', status: 'ONGOING', progress: 34,
    carrierCount: 67, createdAt: '2024-05-25',
    participatingOrgs: [
      { id: 'o6', name: '东北运营中心', status: 'APPROVED', joinedAt: '2024-06-01' },
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2024-06-10' },
    ],
    logicalSites: [
      { logicId: 'LS012', logicalName: '沈阳中心仓', physicalSiteName: '沈北物流基地' },
      { logicId: 'LS013', logicalName: '哈尔滨分仓', physicalSiteName: '平房配送中心' },
    ],
    transferRoutes: [
      { id: 'r8', fromOrg: '东北运营中心', toOrg: '华北运营中心', fromSite: '沈阳中心仓', toSite: '北京中心仓', frequency: '每日1班', status: 'ACTIVE' },
    ],
    carriers: [
      { id: 'c7', name: '冷藏箱-G007', type: '冷藏箱', orgName: '东北运营中心', status: '在途' },
    ],
    kpis: { monthlyTransfers: 98, onTimeRate: 92.5, utilizationRate: 68.7, alarmCount: 5 },
  },
  {
    id: '7', name: '华东医药配送项目', code: 'HDYY2023007', responsibleOrg: '华东运营中心',
    description: '医药制品恒温配送项目，符合GSP认证标准。',
    startDate: '2023-06-01', endDate: '2024-05-31', status: 'ENDED', progress: 100,
    carrierCount: 92, createdAt: '2023-05-20',
    participatingOrgs: [
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2023-06-01' },
      { id: 'o2', name: '华南运营中心', status: 'APPROVED', joinedAt: '2023-06-15' },
    ],
    logicalSites: [
      { logicId: 'LS014', logicalName: '上海医药仓', physicalSiteName: '张江医药物流园' },
      { logicId: 'LS015', logicalName: '苏州分仓', physicalSiteName: '工业园区配送站' },
    ],
    transferRoutes: [
      { id: 'r9', fromOrg: '华东运营中心', toOrg: '华南运营中心', fromSite: '上海医药仓', toSite: '广州医药仓', frequency: '每日1班', status: 'ENDED' },
    ],
    carriers: [
      { id: 'c8', name: '医药箱-H008', type: '医药箱', orgName: '华东运营中心', status: '已回收' },
    ],
    kpis: { monthlyTransfers: 186, onTimeRate: 99.2, utilizationRate: 95.1, alarmCount: 0 },
  },
  {
    id: '8', name: '全国零担货运网络', code: 'QGLD2023008', responsibleOrg: '华北运营中心',
    description: '全国零担货物运输网络整合，覆盖一二线共68个城市。',
    startDate: '2023-03-01', endDate: '2024-02-29', status: 'ENDED', progress: 100,
    carrierCount: 312, createdAt: '2023-02-15',
    participatingOrgs: [
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2023-03-01' },
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2023-03-10' },
      { id: 'o5', name: '华中运营中心', status: 'APPROVED', joinedAt: '2023-03-15' },
      { id: 'o4', name: '西南运营中心', status: 'APPROVED', joinedAt: '2023-04-01' },
    ],
    logicalSites: [
      { logicId: 'LS016', logicalName: '北京零担枢纽', physicalSiteName: '顺义货运站' },
      { logicId: 'LS017', logicalName: '上海分拨中心', physicalSiteName: '虹桥货运基地' },
      { logicId: 'LS018', logicalName: '武汉转运站', physicalSiteName: '汉口北物流园' },
    ],
    transferRoutes: [
      { id: 'r10', fromOrg: '华北运营中心', toOrg: '华东运营中心', fromSite: '北京零担枢纽', toSite: '上海分拨中心', frequency: '每日4班', status: 'ENDED' },
      { id: 'r11', fromOrg: '华北运营中心', toOrg: '华中运营中心', fromSite: '北京零担枢纽', toSite: '武汉转运站', frequency: '每日2班', status: 'ENDED' },
    ],
    carriers: [
      { id: 'c9', name: '零担笼-I009', type: '零担笼', orgName: '华北运营中心', status: '已回收' },
    ],
    kpis: { monthlyTransfers: 876, onTimeRate: 95.6, utilizationRate: 88.3, alarmCount: 0 },
  },
  {
    id: '9', name: '华东汽配快运项目', code: 'HDQK2023009', responsibleOrg: '华东运营中心',
    description: '汽车配件行业专项快运服务，提供定时达和精准达两种服务模式。',
    startDate: '2023-09-01', endDate: '2024-04-30', status: 'ENDED', progress: 100,
    carrierCount: 74, createdAt: '2023-08-15',
    participatingOrgs: [
      { id: 'o1', name: '华东运营中心', status: 'APPROVED', joinedAt: '2023-09-01' },
      { id: 'o3', name: '华北运营中心', status: 'APPROVED', joinedAt: '2023-09-10' },
    ],
    logicalSites: [
      { logicId: 'LS019', logicalName: '上海汽配仓', physicalSiteName: '嘉定汽车城物流园' },
      { logicId: 'LS020', logicalName: '宁波分仓', physicalSiteName: '北仑配送中心' },
    ],
    transferRoutes: [
      { id: 'r12', fromOrg: '华东运营中心', toOrg: '华北运营中心', fromSite: '上海汽配仓', toSite: '北京中心仓', frequency: '每日1班', status: 'ENDED' },
    ],
    carriers: [
      { id: 'c10', name: '汽配箱-J010', type: '汽配箱', orgName: '华东运营中心', status: '已回收' },
    ],
    kpis: { monthlyTransfers: 245, onTimeRate: 96.8, utilizationRate: 90.2, alarmCount: 0 },
  },
  {
    id: '10', name: '西北应急物资储备', code: 'XBYJ2022010', responsibleOrg: '西北运营中心',
    description: '西北地区应急物资储备与调运体系建设项目。项目已提前解散，资产已清算。',
    startDate: '2022-07-01', endDate: '2023-06-30', status: 'DISBANDED', progress: 100,
    carrierCount: 0, createdAt: '2022-06-15',
    participatingOrgs: [
      { id: 'o7', name: '西北运营中心', status: 'APPROVED', joinedAt: '2022-07-01' },
    ],
    logicalSites: [
      { logicId: 'LS021', logicalName: '西安中心仓', physicalSiteName: '国际港务区物流园' },
    ],
    transferRoutes: [],
    carriers: [],
    kpis: { monthlyTransfers: 0, onTimeRate: 0, utilizationRate: 0, alarmCount: 0 },
  },
];

const allOrgs = [
  { id: 'o1', name: '华东运营中心' },
  { id: 'o2', name: '华南运营中心' },
  { id: 'o3', name: '华北运营中心' },
  { id: 'o4', name: '西南运营中心' },
  { id: 'o5', name: '华中运营中心' },
  { id: 'o6', name: '东北运营中心' },
  { id: 'o7', name: '西北运营中心' },
];

const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  ONGOING: { label: '进行中', variant: 'default' },
  ENDED: { label: '已结束', variant: 'secondary' },
  DISBANDED: { label: '已解散', variant: 'destructive' },
};

const statusStyleMap: Record<string, string> = {
  ONGOING: 'bg-[var(--color-primary)] text-white',
  ENDED: 'bg-[var(--color-neutral-textSecondary)] text-white',
  DISBANDED: 'bg-[var(--color-danger)] text-white',
};

// ─── Component ───────────────────────────────────────────────────────────────

export default function ProjectManagementPage() {
  const [projects, setProjects] = useState<Project[]>(mockProjects);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [disbandOpen, setDisbandOpen] = useState(false);
  const [disbandCheckOpen, setDisbandCheckOpen] = useState(false);
  const [detailTab, setDetailTab] = useState('basic');
  const [editProject, setEditProject] = useState<Project | null>(null);
  const [editOpen, setEditOpen] = useState(false);

  // Create form state
  const [createForm, setCreateForm] = useState({
    name: '', code: '', responsibleOrg: '', participatingOrgs: [] as string[],
    description: '', startDate: '', endDate: ''
  });

  const filteredProjects = useMemo(() => {
    return projects.filter(p => {
      const matchSearch = !searchQuery || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.code.toLowerCase().includes(searchQuery.toLowerCase());
      const matchStatus = statusFilter === 'all' || p.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [projects, searchQuery, statusFilter]);

  // Statistics
  const totalCount = projects.length;
  const ongoingCount = projects.filter(p => p.status === 'ONGOING').length;
  const endedCount = projects.filter(p => p.status === 'ENDED').length;
  const disbandedCount = projects.filter(p => p.status === 'DISBANDED').length;
  const thisMonthNew = projects.filter(p => {
    const d = new Date(p.createdAt);
    const now = new Date();
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
  }).length;

  // Status distribution for pie chart
  const statusPieData = [
    { name: '进行中', value: ongoingCount, color: PIE_COLORS[0] },
    { name: '已结束', value: endedCount, color: PIE_COLORS[1] },
    { name: '已解散', value: disbandedCount, color: PIE_COLORS[2] },
  ].filter(d => d.value > 0);

  // Org participation ranking for bar chart
  const orgParticipationData = useMemo(() => {
    const map: Record<string, number> = {};
    projects.forEach(p => {
      if (p.status !== 'DISBANDED') {
        p.participatingOrgs.forEach(o => {
          if (o.status === 'APPROVED') {
            map[o.name] = (map[o.name] || 0) + 1;
          }
        });
      }
    });
    return Object.entries(map)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [projects]);

  const handleViewDetail = (project: Project) => {
    setSelectedProject(project);
    setDetailTab('basic');
    setDetailOpen(true);
  };

  const handleEdit = (project: Project) => {
    setEditProject(project);
    setEditOpen(true);
  };

  const handleDisbandCheck = (project: Project) => {
    setSelectedProject(project);
    setDisbandCheckOpen(true);
  };

  const confirmDisband = () => {
    if (!selectedProject) return;
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? { ...p, status: 'DISBANDED' as const, progress: 100 } : p));
    setDisbandCheckOpen(false);
    setDisbandOpen(false);
    setDetailOpen(false);
  };

  const handleCreate = () => {
    if (!createForm.name || !createForm.code || !createForm.responsibleOrg || !createForm.startDate || !createForm.endDate) return;
    const newProject: Project = {
      id: `${projects.length + 1}`,
      name: createForm.name,
      code: createForm.code,
      responsibleOrg: createForm.responsibleOrg,
      description: createForm.description,
      startDate: createForm.startDate,
      endDate: createForm.endDate,
      status: 'ONGOING',
      progress: 0,
      carrierCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      participatingOrgs: [
        { id: `o${createForm.responsibleOrg}`, name: createForm.responsibleOrg, status: 'APPROVED', joinedAt: new Date().toISOString().split('T')[0] },
        ...createForm.participatingOrgs.map((orgName, idx) => ({
          id: `on${idx}`, name: orgName, status: 'PENDING' as const, joinedAt: ''
        }))
      ],
      logicalSites: [],
      transferRoutes: [],
      carriers: [],
      kpis: { monthlyTransfers: 0, onTimeRate: 0, utilizationRate: 0, alarmCount: 0 },
    };
    setProjects(prev => [...prev, newProject]);
    setCreateForm({ name: '', code: '', responsibleOrg: '', participatingOrgs: [], description: '', startDate: '', endDate: '' });
    setCreateOpen(false);
  };

  const handleSaveEdit = () => {
    if (!editProject) return;
    setProjects(prev => prev.map(p => p.id === editProject.id ? editProject : p));
    setEditOpen(false);
    setEditProject(null);
  };

  const getDisbandPrerequisites = (project: Project) => {
    const checks = [
      { label: '项目状态为进行中或已结束', pass: project.status === 'ONGOING' || project.status === 'ENDED' },
      { label: '所有载具已回收', pass: project.carriers.length === 0 || project.carriers.every(c => c.status === '已回收') },
      { label: '无未处理报警', pass: project.kpis.alarmCount === 0 },
      { label: '所有流转线路已关闭', pass: project.transferRoutes.length === 0 || project.transferRoutes.every(r => r.status === 'ENDED' || r.status === 'CLOSED') },
    ];
    return checks;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--color-neutral-textPrimary)] flex items-center gap-2">
            <FolderKanban className="w-6 h-6 text-[var(--color-primary)]" />
            项目管理
          </h1>
          <p className="text-sm text-[var(--color-neutral-textSecondary)] mt-1">项目视角的载具管理与组织协作</p>
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          创建项目
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center">
              <FolderKanban className="w-5 h-5 text-[var(--color-primary)]" />
            </div>
            <div>
              <div className="text-sm text-[var(--color-neutral-textSecondary)]">项目总数</div>
              <div className="text-xl font-bold">{totalCount}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--color-success)]/10 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-[var(--color-success)]" />
            </div>
            <div>
              <div className="text-sm text-[var(--color-neutral-textSecondary)]">进行中</div>
              <div className="text-xl font-bold">{ongoingCount}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--color-neutral-textSecondary)]/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-[var(--color-neutral-textSecondary)]" />
            </div>
            <div>
              <div className="text-sm text-[var(--color-neutral-textSecondary)]">已结束</div>
              <div className="text-xl font-bold">{endedCount}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[var(--color-warning)]/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-[var(--color-warning)]" />
            </div>
            <div>
              <div className="text-sm text-[var(--color-neutral-textSecondary)]">本月新增</div>
              <div className="text-xl font-bold">{thisMonthNew}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[var(--color-primary)]" />
              项目状态分布
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={statusPieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  nameKey="name"
                  label={({ name, value, percent }) => `${name}: ${value} (${(percent * 100).toFixed(0)}%)`}
                >
                  {statusPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[var(--color-primary)]" />
              各组织参与项目数排名
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={orgParticipationData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} style={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill={BAR_COLOR} radius={[0, 4, 4, 0]} name="参与项目数" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Project List Section */}
      <div className="space-y-4">
        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          <Input
            placeholder="搜索项目名称 / 编号"
            className="w-[300px]"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="全部状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="ONGOING">进行中</SelectItem>
              <SelectItem value="ENDED">已结束</SelectItem>
              <SelectItem value="DISBANDED">已解散</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredProjects.map(project => (
            <Card key={project.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                {/* Card Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="min-w-0 flex-1">
                    <div className="font-medium text-base truncate">{project.name}</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)]">{project.code}</div>
                  </div>
                  <Badge className={statusStyleMap[project.status]}>
                    {statusMap[project.status]?.label}
                  </Badge>
                </div>

                {/* Description */}
                <div className="text-sm text-[var(--color-neutral-textSecondary)] mb-3 line-clamp-2 min-h-[2.5rem]">
                  {project.description}
                </div>

                {/* Meta Row */}
                <div className="flex items-center gap-4 text-xs text-[var(--color-neutral-textSecondary)] mb-3">
                  <span className="flex items-center gap-1">
                    <Building2 className="w-3 h-3" />
                    {project.responsibleOrg}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    {project.participatingOrgs.length}个组织
                  </span>
                  <span className="flex items-center gap-1">
                    <Truck className="w-3 h-3" />
                    {project.carrierCount}个载具
                  </span>
                </div>

                {/* Date Range */}
                <div className="flex items-center gap-1 text-xs text-[var(--color-neutral-textTertiary)] mb-3">
                  <Calendar className="w-3 h-3" />
                  {project.startDate} ~ {project.endDate}
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-[var(--color-neutral-textSecondary)]">项目进度</span>
                    <span className="font-medium">{project.progress}%</span>
                  </div>
                  <Progress value={project.progress} className="h-2" />
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-3 border-t border-[var(--color-neutral-border)]">
                  <Button variant="outline" size="sm" className="flex-1" onClick={() => handleViewDetail(project)}>
                    <Eye className="w-3 h-3 mr-1" />
                    查看详情
                  </Button>
                  {(project.status === 'ONGOING' || project.status === 'ENDED') && (
                    <>
                      <Button variant="outline" size="sm" className="flex-1" onClick={() => handleEdit(project)}>
                        <Edit className="w-3 h-3 mr-1" />
                        编辑
                      </Button>
                      <Button variant="destructive" size="sm" className="flex-1" onClick={() => handleDisbandCheck(project)}>
                        <Trash2 className="w-3 h-3 mr-1" />
                        解散
                      </Button>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="text-center py-12 text-[var(--color-neutral-textSecondary)]">
            <FolderKanban className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <div className="text-base">暂无匹配的项目</div>
            <div className="text-sm mt-1">请调整搜索条件或筛选条件</div>
          </div>
        )}
      </div>

      {/* ─── Project Detail Dialog ─── */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderKanban className="w-5 h-5 text-[var(--color-primary)]" />
              {selectedProject?.name}
            </DialogTitle>
            <DialogDescription>
              项目编号: {selectedProject?.code} | 状态:
              <Badge className={`ml-2 ${selectedProject ? statusStyleMap[selectedProject.status] : ''}`}>
                {selectedProject ? statusMap[selectedProject.status]?.label : ''}
              </Badge>
            </DialogDescription>
          </DialogHeader>

          {selectedProject && (
            <Tabs value={detailTab} onValueChange={setDetailTab} className="space-y-4">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="basic">基本信息</TabsTrigger>
                <TabsTrigger value="orgs">参与组织</TabsTrigger>
                <TabsTrigger value="carriers">载具管理</TabsTrigger>
                <TabsTrigger value="routes">流转线路</TabsTrigger>
                <TabsTrigger value="operations">运营数据</TabsTrigger>
              </TabsList>

              {/* Basic Info Tab */}
              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">项目编号:</span>
                    <span className="ml-2 font-medium">{selectedProject.code}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">负责组织:</span>
                    <span className="ml-2 font-medium">{selectedProject.responsibleOrg}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">开始时间:</span>
                    <span className="ml-2 font-medium">{selectedProject.startDate}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">结束时间:</span>
                    <span className="ml-2 font-medium">{selectedProject.endDate}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">参与组织数:</span>
                    <span className="ml-2 font-medium">{selectedProject.participatingOrgs.length}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">载具数量:</span>
                    <span className="ml-2 font-medium">{selectedProject.carrierCount}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">创建时间:</span>
                    <span className="ml-2 font-medium">{selectedProject.createdAt}</span>
                  </div>
                  <div>
                    <span className="text-[var(--color-neutral-textSecondary)]">当前进度:</span>
                    <span className="ml-2 font-medium">{selectedProject.progress}%</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[var(--color-neutral-textSecondary)]">项目描述:</span>
                    <div className="mt-1 p-3 bg-[var(--color-neutral-bg)] rounded-md text-[var(--color-neutral-textPrimary)]">
                      {selectedProject.description}
                    </div>
                  </div>
                </div>
                <div>
                  <span className="text-sm text-[var(--color-neutral-textSecondary)]">项目进度</span>
                  <Progress value={selectedProject.progress} className="h-3 mt-2" />
                </div>
              </TabsContent>

              {/* Participating Orgs Tab */}
              <TabsContent value="orgs" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">参与组织列表</h3>
                  {selectedProject.status === 'ONGOING' && (
                    <Button size="sm" variant="outline">
                      <Plus className="w-3 h-3 mr-1" />
                      添加组织
                    </Button>
                  )}
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>组织名称</TableHead>
                      <TableHead>状态</TableHead>
                      <TableHead>加入时间</TableHead>
                      <TableHead className="text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedProject.participatingOrgs.map(org => (
                      <TableRow key={org.id}>
                        <TableCell className="font-medium">{org.name}</TableCell>
                        <TableCell>
                          <Badge variant={org.status === 'APPROVED' ? 'default' : 'secondary'}>
                            {org.status === 'APPROVED' ? '已批准' : '待审批'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-[var(--color-neutral-textSecondary)]">
                          {org.joinedAt || '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          {selectedProject.status === 'ONGOING' && org.name !== selectedProject.responsibleOrg && (
                            <Button variant="ghost" size="sm" className="text-[var(--color-danger)] hover:text-[var(--color-danger)]">
                              <Trash2 className="w-3 h-3 mr-1" />
                              移除
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {selectedProject.participatingOrgs.length === 0 && (
                  <div className="text-center py-8 text-[var(--color-neutral-textSecondary)]">
                    <Building2 className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    暂无参与组织
                  </div>
                )}
              </TabsContent>

              {/* Carrier Management Tab */}
              <TabsContent value="carriers" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">载具列表 ({selectedProject.carriers.length})</h3>
                  {selectedProject.status === 'ONGOING' && (
                    <Button size="sm" variant="outline">
                      <Plus className="w-3 h-3 mr-1" />
                      分配载具
                    </Button>
                  )}
                </div>
                {selectedProject.carriers.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>载具名称</TableHead>
                        <TableHead>类型</TableHead>
                        <TableHead>所属组织</TableHead>
                        <TableHead>状态</TableHead>
                        <TableHead className="text-right">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedProject.carriers.map(carrier => (
                        <TableRow key={carrier.id}>
                          <TableCell className="font-medium">{carrier.name}</TableCell>
                          <TableCell>{carrier.type}</TableCell>
                          <TableCell>{carrier.orgName}</TableCell>
                          <TableCell>
                            <Badge variant={carrier.status === '在库' ? 'default' : carrier.status === '在途' ? 'secondary' : 'outline'}>
                              {carrier.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <Truck className="w-3 h-3 mr-1" />
                              回收
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-[var(--color-neutral-textSecondary)]">
                    <Truck className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    暂无分配载具
                  </div>
                )}
                {/* Carrier summary cards */}
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <Card className="p-3 text-center">
                    <div className="text-xl font-bold text-[var(--color-primary)]">{selectedProject.carrierCount}</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)]">载具总数</div>
                  </Card>
                  <Card className="p-3 text-center">
                    <div className="text-xl font-bold text-[var(--color-success)]">
                      {selectedProject.carriers.filter(c => c.status === '在库').length}
                    </div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)]">在库</div>
                  </Card>
                  <Card className="p-3 text-center">
                    <div className="text-xl font-bold text-[var(--color-warning)]">
                      {selectedProject.carriers.filter(c => c.status === '在途').length}
                    </div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)]">在途</div>
                  </Card>
                </div>
              </TabsContent>

              {/* Transfer Routes Tab */}
              <TabsContent value="routes" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-medium">流转线路列表 ({selectedProject.transferRoutes.length})</h3>
                  {selectedProject.status === 'ONGOING' && (
                    <Button size="sm" variant="outline">
                      <Plus className="w-3 h-3 mr-1" />
                      新增线路
                    </Button>
                  )}
                </div>
                {selectedProject.transferRoutes.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>出发组织</TableHead>
                        <TableHead>出发网点</TableHead>
                        <TableHead>目的组织</TableHead>
                        <TableHead>目的网点</TableHead>
                        <TableHead>频次</TableHead>
                        <TableHead>状态</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedProject.transferRoutes.map(route => (
                        <TableRow key={route.id}>
                          <TableCell>{route.fromOrg}</TableCell>
                          <TableCell className="text-[var(--color-neutral-textSecondary)]">{route.fromSite}</TableCell>
                          <TableCell>{route.toOrg}</TableCell>
                          <TableCell className="text-[var(--color-neutral-textSecondary)]">{route.toSite}</TableCell>
                          <TableCell>{route.frequency}</TableCell>
                          <TableCell>
                            <Badge variant={route.status === 'ACTIVE' ? 'default' : 'secondary'}>
                              {route.status === 'ACTIVE' ? '运营中' : '已关闭'}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-[var(--color-neutral-textSecondary)]">
                    <Route className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    暂无流转线路
                  </div>
                )}
              </TabsContent>

              {/* Operations Data Tab */}
              <TabsContent value="operations" className="space-y-4">
                <h3 className="text-sm font-medium flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-[var(--color-primary)]" />
                  运营仪表盘
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="p-4 text-center">
                    <div className="text-2xl font-bold text-[var(--color-primary)]">{selectedProject.kpis.monthlyTransfers}</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)] mt-1">本月调拨次数</div>
                  </Card>
                  <Card className="p-4 text-center">
                    <div className="text-2xl font-bold text-[var(--color-success)]">{selectedProject.kpis.onTimeRate}%</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)] mt-1">准点到达率</div>
                  </Card>
                  <Card className="p-4 text-center">
                    <div className="text-2xl font-bold text-[var(--color-info)]">{selectedProject.kpis.utilizationRate}%</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)] mt-1">载具利用率</div>
                  </Card>
                  <Card className="p-4 text-center">
                    <div className="text-2xl font-bold text-[var(--color-danger)]">{selectedProject.kpis.alarmCount}</div>
                    <div className="text-xs text-[var(--color-neutral-textSecondary)] mt-1">未处理报警</div>
                  </Card>
                </div>

                {/* Mini bar chart for monthly transfers */}
                <Card className="p-4">
                  <div className="text-sm font-medium mb-4">近6个月调拨趋势</div>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={[
                        { month: '1月', value: Math.round(selectedProject.kpis.monthlyTransfers * 0.7) },
                        { month: '2月', value: Math.round(selectedProject.kpis.monthlyTransfers * 0.8) },
                        { month: '3月', value: Math.round(selectedProject.kpis.monthlyTransfers * 0.85) },
                        { month: '4月', value: Math.round(selectedProject.kpis.monthlyTransfers * 0.9) },
                        { month: '5月', value: Math.round(selectedProject.kpis.monthlyTransfers * 0.95) },
                        { month: '6月', value: selectedProject.kpis.monthlyTransfers },
                      ]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" style={{ fontSize: 12 }} />
                      <YAxis style={{ fontSize: 12 }} />
                      <Tooltip />
                      <Bar dataKey="value" fill={BAR_COLOR} radius={[4, 4, 0, 0]} name="调拨次数" />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              </TabsContent>
            </Tabs>
          )}

          <DialogFooter className="pt-4 border-t border-[var(--color-neutral-border)]">
            {(selectedProject?.status === 'ONGOING' || selectedProject?.status === 'ENDED') && (
              <Button variant="destructive" onClick={() => { setDetailOpen(false); handleDisbandCheck(selectedProject); }}>
                <Trash2 className="w-4 h-4 mr-2" />
                解散项目
              </Button>
            )}
            <Button variant="outline" onClick={() => setDetailOpen(false)}>关闭</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Create Project Dialog ─── */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-[var(--color-primary)]" />
              创建新项目
            </DialogTitle>
            <DialogDescription>填写项目基本信息以创建新项目</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium">项目名称 <span className="text-[var(--color-danger)]">*</span></label>
              <Input
                placeholder="请输入项目名称"
                value={createForm.name}
                onChange={e => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium">项目编号 <span className="text-[var(--color-danger)]">*</span></label>
              <Input
                placeholder="如: HDLL2024001"
                value={createForm.code}
                onChange={e => setCreateForm(prev => ({ ...prev, code: e.target.value }))}
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium">负责组织 <span className="text-[var(--color-danger)]">*</span></label>
              <Select
                value={createForm.responsibleOrg}
                onValueChange={val => setCreateForm(prev => ({ ...prev, responsibleOrg: val }))}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="选择负责组织" />
                </SelectTrigger>
                <SelectContent>
                  {allOrgs.map(org => (
                    <SelectItem key={org.id} value={org.name}>{org.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">参与组织</label>
              <div className="mt-1 space-y-2">
                {allOrgs.filter(o => o.name !== createForm.responsibleOrg).map(org => (
                  <label key={org.id} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300"
                      checked={createForm.participatingOrgs.includes(org.name)}
                      onChange={e => {
                        setCreateForm(prev => ({
                          ...prev,
                          participatingOrgs: e.target.checked
                            ? [...prev.participatingOrgs, org.name]
                            : prev.participatingOrgs.filter(n => n !== org.name)
                        }));
                      }}
                    />
                    {org.name}
                  </label>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium">开始日期 <span className="text-[var(--color-danger)]">*</span></label>
                <Input
                  type="date"
                  value={createForm.startDate}
                  onChange={e => setCreateForm(prev => ({ ...prev, startDate: e.target.value }))}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium">结束日期 <span className="text-[var(--color-danger)]">*</span></label>
                <Input
                  type="date"
                  value={createForm.endDate}
                  onChange={e => setCreateForm(prev => ({ ...prev, endDate: e.target.value }))}
                  className="mt-1"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium">项目描述</label>
              <Textarea
                placeholder="请输入项目描述..."
                value={createForm.description}
                onChange={e => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                className="mt-1"
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>取消</Button>
            <Button onClick={handleCreate}>创建</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Edit Project Dialog ─── */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="w-5 h-5 text-[var(--color-primary)]" />
              编辑项目
            </DialogTitle>
            <DialogDescription>修改项目 {editProject?.name} 的信息</DialogDescription>
          </DialogHeader>
          {editProject && (
            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium">项目名称</label>
                <Input
                  value={editProject.name}
                  onChange={e => setEditProject({ ...editProject, name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium">项目编号</label>
                <Input value={editProject.code} disabled className="mt-1 bg-gray-50" />
              </div>
              <div>
                <label className="text-sm font-medium">负责组织</label>
                <Select
                  value={editProject.responsibleOrg}
                  onValueChange={val => setEditProject({ ...editProject, responsibleOrg: val })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {allOrgs.map(org => (
                      <SelectItem key={org.id} value={org.name}>{org.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">开始日期</label>
                  <Input
                    type="date"
                    value={editProject.startDate}
                    onChange={e => setEditProject({ ...editProject, startDate: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">结束日期</label>
                  <Input
                    type="date"
                    value={editProject.endDate}
                    onChange={e => setEditProject({ ...editProject, endDate: e.target.value })}
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium">项目描述</label>
                <Textarea
                  value={editProject.description}
                  onChange={e => setEditProject({ ...editProject, description: e.target.value })}
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>取消</Button>
            <Button onClick={handleSaveEdit}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Disband Check Dialog ─── */}
      <Dialog open={disbandCheckOpen} onOpenChange={setDisbandCheckOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[var(--color-danger)]">
              <Trash2 className="w-5 h-5" />
              解散项目确认
            </DialogTitle>
            <DialogDescription>
              解散项目 "{selectedProject?.name}" 前，请确认以下前置条件已全部满足
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-4">
            {selectedProject && getDisbandPrerequisites(selectedProject).map((check, idx) => (
              <div
                key={idx}
                className={`flex items-center gap-3 p-3 rounded-md ${check.pass ? 'bg-[var(--color-success)]/10' : 'bg-[var(--color-danger)]/10'}`}
              >
                <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold ${check.pass ? 'bg-[var(--color-success)] text-white' : 'bg-[var(--color-danger)] text-white'}`}>
                  {check.pass ? '✓' : '✗'}
                </div>
                <span className={`text-sm ${check.pass ? 'text-[var(--color-success)]' : 'text-[var(--color-danger)]'}`}>
                  {check.label}
                </span>
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDisbandCheckOpen(false)}>取消</Button>
            <Button
              variant="destructive"
              disabled={selectedProject ? !getDisbandPrerequisites(selectedProject).every(c => c.pass) : true}
              onClick={() => setDisbandOpen(true)}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              确认解散
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ─── Final Disband Confirmation Dialog ─── */}
      <Dialog open={disbandOpen} onOpenChange={setDisbandOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-[var(--color-danger)]">最终确认</DialogTitle>
            <DialogDescription>
              此操作不可撤销。解散后项目状态将变更为"已解散"，所有相关数据将归档。
              <br /><br />
              确定要解散项目 <strong>"{selectedProject?.name}"</strong> 吗？
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDisbandOpen(false)}>取消</Button>
            <Button variant="destructive" onClick={confirmDisband}>
              <Trash2 className="w-4 h-4 mr-2" />
              确认解散
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
