import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Wifi, Server, Cpu, MessageSquare, Zap, Activity,
  Shield, WifiOff,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ─── Mock Data ─── */
const BROKER_NODES = [
  { name: 'Broker-01', ip: '192.168.1.101', connections: 4230, cpuUsage: 45, memoryUsage: 62, messageThroughput: 8540, status: 'normal' as const },
  { name: 'Broker-02', ip: '192.168.1.102', connections: 3890, cpuUsage: 52, memoryUsage: 58, messageThroughput: 7200, status: 'normal' as const },
  { name: 'Broker-03', ip: '192.168.1.103', connections: 2150, cpuUsage: 78, memoryUsage: 85, messageThroughput: 4300, status: 'warning' as const },
  { name: 'Broker-04', ip: '192.168.1.104', connections: 120, cpuUsage: 12, memoryUsage: 20, messageThroughput: 210, status: 'error' as const },
  { name: 'Broker-05', ip: '192.168.1.105', connections: 4010, cpuUsage: 38, memoryUsage: 55, messageThroughput: 8100, status: 'normal' as const },
];

const DEVICE_SESSIONS = Array.from({ length: 15 }, (_, i) => ({
  deviceId: `DEV-${String(i + 1).padStart(4, '0')}`,
  deviceType: ['定位器', '网关', '标签', '信标'][i % 4],
  connectionStatus: ['online', 'online', 'offline', 'reconnecting'][i % 4] as 'online' | 'offline' | 'reconnecting',
  clientId: `client_${i + 1}`,
  authMethod: ['TLS证书', '设备密钥'][i % 2],
  sessionToken: `token_${Math.random().toString(36).substring(2, 10)}`,
  lastHeartbeat: new Date(Date.now() - i * 60000).toLocaleString('zh-CN'),
  heartbeatInterval: [120, 600, 900, 1800][i % 4],
  offlineDuration: i % 3 === 0 ? '15分钟' : '-',
  ipAddress: `192.168.1.${100 + i}`,
  org: ['宁德时代', '上海物流', '宁波运输', '杭州仓储'][i % 4],
}));

const AUTH_RECORDS = Array.from({ length: 10 }, (_, i) => ({
  deviceId: `DEV-${String(i + 1).padStart(4, '0')}`,
  deviceType: ['定位器', '网关', '标签', '信标'][i % 4],
  certValidDays: [365, 180, 30, -5][i % 4],
  certStatus: ['valid', 'valid', 'expiring', 'expired'][i % 4] as 'valid' | 'expiring' | 'expired',
  issuedAt: new Date(Date.now() - i * 86400000 * 30).toLocaleDateString('zh-CN'),
  authMethod: ['TLS证书', '设备密钥'][i % 2],
}));

const HEARTBEAT_TIMEOUT_DATA = [
  { type: '定位器(2h)', count: 12 },
  { type: '网关(10min)', count: 45 },
  { type: '标签(15min)', count: 28 },
  { type: '信标(30min)', count: 8 },
];

const DISCONNECT_REASONS = [
  { reason: '网络闪断', count: 156, percentage: 52 },
  { reason: '设备断电', count: 78, percentage: 26 },
  { reason: '信号丢失', count: 38, percentage: 13 },
  { reason: 'TLS过期', count: 18, percentage: 6 },
  { reason: '流控拒绝', count: 10, percentage: 3 },
];

const RECONNECT_TREND = Array.from({ length: 7 }, (_, i) => ({
  day: `12-${14 + i}`,
  successRate: 92 + Math.random() * 8,
}));

const FLOW_RULES = [
  { deviceType: '定位器', targetQueue: '定位器队列', maxMessagesPerSec: 1, burstCapacity: 5, priority: 1, status: 'active' as const },
  { deviceType: '网关', targetQueue: '网关队列', maxMessagesPerSec: 6, burstCapacity: 20, priority: 2, status: 'active' as const },
  { deviceType: '标签', targetQueue: '标签队列', maxMessagesPerSec: 4, burstCapacity: 15, priority: 3, status: 'active' as const },
  { deviceType: '信标', targetQueue: '信标队列', maxMessagesPerSec: 2, burstCapacity: 8, priority: 4, status: 'paused' as const },
];

const RATE_LIMIT_RECORDS = Array.from({ length: 8 }, (_, i) => ({
  deviceId: `DEV-${String(i + 1).padStart(4, '0')}`,
  deviceType: ['定位器', '网关', '标签'][i % 3],
  exceedType: ['频率超限', '突发流量', '队列满'][i % 3],
  exceedCount: [15, 8, 23, 5][i % 4],
  triggeredAt: new Date(Date.now() - i * 3600000).toLocaleString('zh-CN'),
  handling: ['限流降速', '丢弃报文', '队列扩容'][i % 3],
}));

/* ─── Shared Components ─── */
function StatusBadge({ status, text }: { status: string; text: string }) {
  const configs: Record<string, { color: string; bg: string }> = {
    normal: { color: 'text-success', bg: 'bg-success-light' },
    warning: { color: 'text-warning', bg: 'bg-warning-light' },
    error: { color: 'text-danger', bg: 'bg-danger-light' },
    online: { color: 'text-success', bg: 'bg-success-light' },
    offline: { color: 'text-danger', bg: 'bg-danger-light' },
    reconnecting: { color: 'text-warning', bg: 'bg-warning-light' },
    valid: { color: 'text-success', bg: 'bg-success-light' },
    expiring: { color: 'text-warning', bg: 'bg-warning-light' },
    expired: { color: 'text-danger', bg: 'bg-danger-light' },
    active: { color: 'text-success', bg: 'bg-success-light' },
    paused: { color: 'text-neutral-textTertiary', bg: 'bg-neutral-background' },
  };
  const cfg = configs[status] || configs.normal;
  return <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium', cfg.bg, cfg.color)}>{text}</span>;
}

/* ─── KPICard ─── */
function KPICard({ title, value, subtitle, icon: Icon, color }: { title: string; value: string; subtitle: string; icon: React.ElementType; color: string }) {
  const colorMap: Record<string, string> = { blue: 'bg-primary-light text-primary', green: 'bg-success-light text-success', amber: 'bg-warning-light text-warning', red: 'bg-danger-light text-danger', purple: 'bg-purple-50 text-purple-500', cyan: 'bg-cyan-50 text-cyan-600' };
  return (
    <Card className="bg-[var(--neutral-surface)] border-neutral-border"><CardContent className="p-4 flex items-center gap-3">
      <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', colorMap[color] || colorMap.blue)}><Icon size={18} /></div>
      <div><p className="text-xs text-neutral-textTertiary">{title}</p><p className="text-lg font-bold text-neutral-textPrimary">{value}</p><p className="text-xs text-neutral-textTertiary">{subtitle}</p></div>
    </CardContent></Card>
  );
}

/* ─── Sub-Components ─── */
function BrokerCluster() {
  return (
    <div className="space-y-4">
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl overflow-hidden">
        <table className="w-full text-sm"><thead className="bg-neutral-background"><tr className="border-b border-neutral-border">
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">节点名称</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">IP地址</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">连接数</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">CPU</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">内存</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">消息吞吐</th>
          <th className="text-left px-4 py-3 font-medium text-neutral-textSecondary">状态</th>
        </tr></thead>
        <tbody>{BROKER_NODES.map((node, i) => (
          <motion.tr key={node.name} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
            className="border-b border-neutral-border last:border-0 hover:bg-neutral-background/50">
            <td className="px-4 py-3 text-neutral-textPrimary font-medium">{node.name}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{node.ip}</td>
            <td className="px-4 py-3 text-neutral-textPrimary">{node.connections.toLocaleString()}</td>
            <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-16 h-1.5 bg-neutral-border rounded-full overflow-hidden"><div className="h-full rounded-full bg-primary" style={{ width: `${node.cpuUsage}%` }} /></div><span className="text-xs text-neutral-textSecondary">{node.cpuUsage}%</span></div></td>
            <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-16 h-1.5 bg-neutral-border rounded-full overflow-hidden"><div className="h-full rounded-full bg-info" style={{ width: `${node.memoryUsage}%` }} /></div><span className="text-xs text-neutral-textSecondary">{node.memoryUsage}%</span></div></td>
            <td className="px-4 py-3 text-neutral-textPrimary">{node.messageThroughput.toLocaleString()}/s</td>
            <td className="px-4 py-3"><StatusBadge status={node.status} text={node.status === 'normal' ? '正常' : node.status === 'warning' ? '警告' : '异常'} /></td>
          </motion.tr>
        ))}</tbody>
      </table>
      </div>
    </div>
  );
}

function SessionList() {
  const [statusFilter, setStatusFilter] = useState('all');
  const filtered = statusFilter === 'all' ? DEVICE_SESSIONS : DEVICE_SESSIONS.filter(s => s.connectionStatus === statusFilter);
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        {[{ key: 'all', label: '全部' }, { key: 'online', label: '在线' }, { key: 'offline', label: '离线' }, { key: 'reconnecting', label: '重连中' }].map(opt => (
          <Button key={opt.key} variant={statusFilter === opt.key ? 'default' : 'outline'} size="sm" onClick={() => setStatusFilter(opt.key)}>{opt.label}</Button>
        ))}
      </div>
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl overflow-hidden">
        <table className="w-full text-sm"><thead className="bg-neutral-background"><tr className="border-b border-neutral-border">
          {['设备ID', '类型', '状态', '认证方式', '最后心跳', '心跳周期', '离线时长', 'IP地址', '组织'].map(h => (
            <th key={h} className="text-left px-3 py-2.5 font-medium text-neutral-textSecondary text-xs">{h}</th>
          ))}
        </tr></thead>
        <tbody>{filtered.map((s, i) => (
          <motion.tr key={s.deviceId} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
            className="border-b border-neutral-border last:border-0 hover:bg-neutral-background/50">
            <td className="px-3 py-2.5 text-neutral-textPrimary font-medium">{s.deviceId}</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary">{s.deviceType}</td>
            <td className="px-3 py-2.5"><StatusBadge status={s.connectionStatus} text={s.connectionStatus === 'online' ? '在线' : s.connectionStatus === 'offline' ? '离线' : '重连中'} /></td>
            <td className="px-3 py-2.5 text-neutral-textSecondary">{s.authMethod}</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary text-xs">{s.lastHeartbeat}</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary">{s.heartbeatInterval}s</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary">{s.offlineDuration}</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary text-xs">{s.ipAddress}</td>
            <td className="px-3 py-2.5 text-neutral-textSecondary">{s.org}</td>
          </motion.tr>
        ))}</tbody>
      </table>
      </div>
    </div>
  );
}

function AuthPanel() {
  return (
    <div className="space-y-4">
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl overflow-hidden">
        <table className="w-full text-sm"><thead className="bg-neutral-background"><tr className="border-b border-neutral-border">
          {['设备ID', '类型', '认证方式', '证书有效期', '证书状态', '颁发时间'].map(h => (
            <th key={h} className="text-left px-4 py-3 font-medium text-neutral-textSecondary">{h}</th>
          ))}
        </tr></thead>
        <tbody>{AUTH_RECORDS.map((r, i) => (
          <motion.tr key={r.deviceId} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
            className="border-b border-neutral-border last:border-0 hover:bg-neutral-background/50">
            <td className="px-4 py-3 text-neutral-textPrimary font-medium">{r.deviceId}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{r.deviceType}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{r.authMethod}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{r.certValidDays > 0 ? `${r.certValidDays}天` : `${Math.abs(r.certValidDays)}天前过期`}</td>
            <td className="px-4 py-3"><StatusBadge status={r.certStatus} text={r.certStatus === 'valid' ? '有效' : r.certStatus === 'expiring' ? '即将过期' : '已过期'} /></td>
            <td className="px-4 py-3 text-neutral-textSecondary">{r.issuedAt}</td>
          </motion.tr>
        ))}</tbody>
      </table>
      </div>
    </div>
  );
}

function HeartbeatDisconnect() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl p-4">
        <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">心跳超时分布</h3>
        <div className="space-y-3">{HEARTBEAT_TIMEOUT_DATA.map((item, i) => (
          <div key={i} className="flex items-center gap-3">
            <span className="text-sm text-neutral-textSecondary w-24">{item.type}</span>
            <div className="flex-1 h-4 bg-neutral-border rounded-full overflow-hidden"><motion.div className="h-full rounded-full bg-primary" initial={{ width: 0 }} animate={{ width: `${(item.count / 50) * 100}%` }} transition={{ duration: 0.8, delay: i * 0.1 }} /></div>
            <span className="text-sm font-medium text-neutral-textPrimary w-8 text-right">{item.count}</span>
          </div>
        ))}</div>
      </div>
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl p-4">
        <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">断线原因分布</h3>
        <div className="space-y-2">{DISCONNECT_REASONS.map((item, i) => (
          <div key={i} className="flex items-center justify-between py-2 border-b border-neutral-border last:border-0">
            <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: ['#2563EB', '#EF4444', '#F59E0B', '#8B5CF6', '#10B981'][i] }} /><span className="text-sm text-neutral-textSecondary">{item.reason}</span></div>
            <div className="flex items-center gap-3"><span className="text-sm text-neutral-textPrimary font-medium">{item.count}次</span><span className="text-xs text-neutral-textTertiary">{item.percentage}%</span></div>
          </div>
        ))}</div>
      </div>
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl p-4 lg:col-span-2">
        <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">近7天重连成功率趋势</h3>
        <div className="flex items-end gap-2 h-24">{RECONNECT_TREND.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div className="w-full bg-neutral-border rounded-t-md relative overflow-hidden" style={{ height: '80px' }}>
              <motion.div className="absolute bottom-0 w-full rounded-t-md bg-primary" initial={{ height: 0 }} animate={{ height: `${d.successRate}%` }} transition={{ duration: 0.5, delay: i * 0.1 }} />
            </div>
            <span className="text-xs text-neutral-textTertiary">{d.day}</span>
            <span className="text-xs font-medium text-neutral-textPrimary">{d.successRate.toFixed(1)}%</span>
          </div>
        ))}</div>
      </div>
    </div>
  );
}

function FlowControl() {
  return (
    <div className="space-y-4">
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl overflow-hidden">
        <table className="w-full text-sm"><thead className="bg-neutral-background"><tr className="border-b border-neutral-border">
          {['设备类型', '目标队列', '最大频率(条/秒)', '突发容量', '优先级', '状态'].map(h => (
            <th key={h} className="text-left px-4 py-3 font-medium text-neutral-textSecondary">{h}</th>
          ))}
        </tr></thead>
        <tbody>{FLOW_RULES.map((rule, i) => (
          <motion.tr key={rule.deviceType} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
            className="border-b border-neutral-border last:border-0 hover:bg-neutral-background/50">
            <td className="px-4 py-3 text-neutral-textPrimary font-medium">{rule.deviceType}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{rule.targetQueue}</td>
            <td className="px-4 py-3 text-neutral-textPrimary">{rule.maxMessagesPerSec}</td>
            <td className="px-4 py-3 text-neutral-textSecondary">{rule.burstCapacity}</td>
            <td className="px-4 py-3"><Badge variant="outline">P{rule.priority}</Badge></td>
            <td className="px-4 py-3"><StatusBadge status={rule.status} text={rule.status === 'active' ? '启用' : '暂停'} /></td>
          </motion.tr>
        ))}</tbody>
      </table>
      </div>
      <div className="bg-[var(--neutral-surface)] border border-neutral-border rounded-xl p-4">
        <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">限流触发记录</h3>
        <div className="space-y-2">{RATE_LIMIT_RECORDS.map((r, i) => (
          <div key={i} className="flex items-center justify-between py-2 border-b border-neutral-border last:border-0">
            <div className="flex items-center gap-2"><WifiOff size={14} className="text-warning" /><span className="text-sm text-neutral-textPrimary">{r.deviceId}</span><span className="text-xs text-neutral-textSecondary">{r.deviceType}</span></div>
            <div className="flex items-center gap-3"><Badge variant="outline" className="text-warning border-warning">{r.exceedType}</Badge><span className="text-xs text-neutral-textSecondary">{r.triggeredAt}</span><span className="text-xs text-success">{r.handling}</span></div>
          </div>
        ))}</div>
      </div>
    </div>
  );
}

/* ─── Main ─── */
export default function IotConnectionTab() {
  const [activeTab, setActiveTab] = useState('broker');

  return (
    <div className="space-y-4">
      {/* KPI */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="总连接数" value="15,390" subtitle="/ 20,000 容量" icon={Wifi} color="blue" />
        <KPICard title="在线设备" value="12,450" subtitle="80.9% 在线率" icon={Server} color="green" />
        <KPICard title="消息吞吐" value="24.5K" subtitle="消息/秒" icon={MessageSquare} color="purple" />
        <KPICard title="重连成功率" value="97.2%" subtitle="近7天平均" icon={Zap} color="cyan" />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-[var(--neutral-surface)] border border-neutral-border">
          <TabsTrigger value="broker" className="text-xs"><Server size={14} className="mr-1" />Broker集群</TabsTrigger>
          <TabsTrigger value="sessions" className="text-xs"><Wifi size={14} className="mr-1" />设备会话</TabsTrigger>
          <TabsTrigger value="heartbeat" className="text-xs"><Activity size={14} className="mr-1" />心跳断线</TabsTrigger>
          <TabsTrigger value="auth" className="text-xs"><Shield size={14} className="mr-1" />认证管理</TabsTrigger>
          <TabsTrigger value="flow" className="text-xs"><Cpu size={14} className="mr-1" />流量控制</TabsTrigger>
        </TabsList>
        <TabsContent value="broker" className="mt-4"><BrokerCluster /></TabsContent>
        <TabsContent value="sessions" className="mt-4"><SessionList /></TabsContent>
        <TabsContent value="heartbeat" className="mt-4"><HeartbeatDisconnect /></TabsContent>
        <TabsContent value="auth" className="mt-4"><AuthPanel /></TabsContent>
        <TabsContent value="flow" className="mt-4"><FlowControl /></TabsContent>
      </Tabs>
    </div>
  );
}
