import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import {
  Bell, Clock, CheckCircle, AlertTriangle, TrendingUp,
  Search, Wrench, ArrowRight, Ban, Eye, Trash2, Layers, Zap,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
interface AlarmItem {
  id: string;
  alarmNo: string;
  type: string;
  level: 'critical' | 'warning' | 'info';
  source: string;
  site: string;
  carrierId: string;
  message: string;
  triggerTime: string;
  status: 'pending' | 'confirmed' | 'workorder' | 'transfer' | 'ignored';
  handler?: string;
  handleTime?: string;
  handleAction?: string;
  handleRemark?: string;
}

interface EscalationRule {
  id: string;
  name: string;
  level: string;
  delayMinutes: number;
  notifyWay: string;
  notifyTarget: string;
  enabled: boolean;
}

interface AlarmCluster {
  id: string;
  name: string;
  alarmCount: number;
  rootCause: string;
  timeRange: string;
  alarms: string[];
}

// ==================== Mock Data ====================
const pendingAlarms: AlarmItem[] = [
  { id: 'AL001', alarmNo: 'AL-20250429-1001', type: '载具滞留超时', level: 'critical', source: '流转监控', site: '上海浦东', carrierId: 'CA-20250401-015', message: '载具在网点停留超过72小时', triggerTime: '2025-04-29 08:15', status: 'pending' },
  { id: 'AL002', alarmNo: 'AL-20250429-1002', type: '设备离线', level: 'warning', source: '设备监控', site: '苏州昆山', carrierId: 'CA-20250402-032', message: '定位器连续24小时未上报数据', triggerTime: '2025-04-29 08:30', status: 'pending' },
  { id: 'AL003', alarmNo: 'AL-20250429-1003', type: '调拨超时', level: 'critical', source: '调拨监控', site: '宁波北仑', carrierId: 'CA-20250403-008', message: '调拨单TB-20250425-0066超过预计到达时间', triggerTime: '2025-04-29 09:00', status: 'pending' },
  { id: 'AL004', alarmNo: 'AL-20250429-1004', type: '温度超限', level: 'warning', source: '传感器', site: '武汉东西湖', carrierId: 'CA-20250404-021', message: '冷链载具温度超过阈值35°C', triggerTime: '2025-04-29 09:45', status: 'pending' },
  { id: 'AL005', alarmNo: 'AL-20250429-1005', type: '载具滞留超时', level: 'info', source: '流转监控', site: '合肥经开', carrierId: 'CA-20250405-009', message: '载具在网点停留超过48小时', triggerTime: '2025-04-29 10:20', status: 'pending' },
  { id: 'AL006', alarmNo: 'AL-20250429-1006', type: '设备低电量', level: 'warning', source: '设备监控', site: '重庆两江', carrierId: 'CA-20250406-044', message: '定位器电量低于20%', triggerTime: '2025-04-29 11:00', status: 'pending' },
  { id: 'AL007', alarmNo: 'AL-20250429-1007', type: '围栏越界', level: 'critical', source: 'GPS监控', site: '成都龙泉驿', carrierId: 'CA-20250407-011', message: '载具超出设定电子围栏范围', triggerTime: '2025-04-29 11:30', status: 'pending' },
  { id: 'AL008', alarmNo: 'AL-20250429-1008', type: '标签分离', level: 'critical', source: '蓝牙信标', site: '长沙雨花', carrierId: 'CA-20250408-029', message: '蓝牙标签与载具分离超过30分钟', triggerTime: '2025-04-29 12:00', status: 'pending' },
];

const historyAlarms: AlarmItem[] = [
  { id: 'H001', alarmNo: 'AL-20250428-0990', type: '载具滞留超时', level: 'warning', source: '流转监控', site: '上海浦东', carrierId: 'CA-20250401-001', message: '载具滞留超时', triggerTime: '2025-04-28 10:00', status: 'confirmed', handler: '张伟', handleTime: '2025-04-28 11:30', handleAction: '确认', handleRemark: '已联系网点处理' },
  { id: 'H002', alarmNo: 'AL-20250428-0991', type: '设备离线', level: 'warning', source: '设备监控', site: '苏州昆山', carrierId: 'CA-20250402-015', message: '设备离线24小时', triggerTime: '2025-04-28 09:00', status: 'workorder', handler: '李强', handleTime: '2025-04-28 10:15', handleAction: '转工单', handleRemark: '已派维修人员' },
  { id: 'H003', alarmNo: 'AL-20250428-0992', type: '调拨超时', level: 'critical', source: '调拨监控', site: '宁波北仑', carrierId: 'CA-20250403-032', message: '调拨超时', triggerTime: '2025-04-28 08:00', status: 'transfer', handler: '王芳', handleTime: '2025-04-28 09:30', handleAction: '转调拨', handleRemark: '已重新安排调拨' },
  { id: 'H004', alarmNo: 'AL-20250428-0993', type: '温度超限', level: 'info', source: '传感器', site: '武汉东西湖', carrierId: 'CA-20250404-008', message: '温度轻微超标', triggerTime: '2025-04-28 07:00', status: 'ignored', handler: '赵磊', handleTime: '2025-04-28 08:00', handleAction: '忽略', handleRemark: '传感器校准中' },
  { id: 'H005', alarmNo: 'AL-20250427-0980', type: '载具滞留超时', level: 'warning', source: '流转监控', site: '重庆两江', carrierId: 'CA-20250405-021', message: '载具滞留', triggerTime: '2025-04-27 14:00', status: 'confirmed', handler: '孙丽', handleTime: '2025-04-27 16:00', handleAction: '确认', handleRemark: '网点已安排出库' },
  { id: 'H006', alarmNo: 'AL-20250427-0981', type: '围栏越界', level: 'critical', source: 'GPS监控', site: '成都龙泉驿', carrierId: 'CA-20250406-009', message: '围栏越界', triggerTime: '2025-04-27 12:00', status: 'workorder', handler: '周杰', handleTime: '2025-04-27 13:30', handleAction: '转工单', handleRemark: '已通知司机返回' },
  { id: 'H007', alarmNo: 'AL-20250426-0970', type: '标签分离', level: 'critical', source: '蓝牙信标', site: '长沙雨花', carrierId: 'CA-20250407-044', message: '标签分离', triggerTime: '2025-04-26 18:00', status: 'transfer', handler: '吴敏', handleTime: '2025-04-26 19:00', handleAction: '转调拨', handleRemark: '已安排重新绑定' },
  { id: 'H008', alarmNo: 'AL-20250426-0971', type: '设备低电量', level: 'info', source: '设备监控', site: '合肥经开', carrierId: 'CA-20250408-011', message: '低电量预警', triggerTime: '2025-04-26 16:00', status: 'ignored', handler: '郑华', handleTime: '2025-04-26 17:00', handleAction: '忽略', handleRemark: '已安排批量充电' },
];

const escalationRules: EscalationRule[] = [
  { id: 'ER001', name: '严重报警-一级升级', level: '严重', delayMinutes: 30, notifyWay: '短信+App推送', notifyTarget: '值班主管', enabled: true },
  { id: 'ER002', name: '严重报警-二级升级', level: '严重', delayMinutes: 60, notifyWay: '电话+邮件', notifyTarget: '部门经理', enabled: true },
  { id: 'ER003', name: '警告报警-一级升级', level: '警告', delayMinutes: 120, notifyWay: 'App推送', notifyTarget: '值班主管', enabled: true },
  { id: 'ER004', name: '警告报警-二级升级', level: '警告', delayMinutes: 240, notifyWay: '邮件', notifyTarget: '部门经理', enabled: false },
  { id: 'ER005', name: '信息报警-升级', level: '信息', delayMinutes: 480, notifyWay: '邮件', notifyTarget: '运维人员', enabled: true },
];

const alarmClusters: AlarmCluster[] = [
  { id: 'CL001', name: '上海浦东滞留集群', alarmCount: 5, rootCause: '网点爆仓导致出库延迟', timeRange: '2025-04-28 ~ 2025-04-29', alarms: ['AL-20250429-1001', 'AL-20250428-0990', 'AL-20250428-0985', 'AL-20250427-0980', 'AL-20250427-0975'] },
  { id: 'CL002', name: '设备离线集群', alarmCount: 3, rootCause: '基站维护导致信号中断', timeRange: '2025-04-29 08:00 ~ 09:00', alarms: ['AL-20250429-1002', 'AL-20250429-0995', 'AL-20250429-0994'] },
  { id: 'CL003', name: '调拨延迟集群', alarmCount: 4, rootCause: '恶劣天气影响运输', timeRange: '2025-04-28 ~ 2025-04-29', alarms: ['AL-20250429-1003', 'AL-20250428-0992', 'AL-20250428-0988', 'AL-20250427-0978'] },
];

// ==================== Helpers ====================
function getLevelBadge(level: string) {
  if (level === 'critical') return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">严重</Badge>;
  if (level === 'warning') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">警告</Badge>;
  return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">信息</Badge>;
}

function getStatusBadge(status: string) {
  switch (status) {
    case 'pending': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">待处理</Badge>;
    case 'confirmed': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已确认</Badge>;
    case 'workorder': return <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100">已转工单</Badge>;
    case 'transfer': return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">已转调拨</Badge>;
    case 'ignored': return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">已忽略</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function AlarmWorkflowPage() {
  const [activeTab, setActiveTab] = useState('pending');
  const [search, setSearch] = useState('');
  const [pendingData, setPendingData] = useState(pendingAlarms);
  const [historyData] = useState(historyAlarms);
  const [rulesData, setRulesData] = useState(escalationRules);

  // Dialogs
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [workorderOpen, setWorkorderOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [ignoreOpen, setIgnoreOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedAlarm, setSelectedAlarm] = useState<AlarmItem | null>(null);

  // Form states
  const [confirmRemark, setConfirmRemark] = useState('');
  const [woType, setWoType] = useState('');
  const [woDesc, setWoDesc] = useState('');
  const [woAssignee, setWoAssignee] = useState('');
  const [transferNo, setTransferNo] = useState('');
  const [transferRemark, setTransferRemark] = useState('');
  const [ignoreReason, setIgnoreReason] = useState('');

  const filteredPending = useMemo(() => {
    return pendingData.filter(a => a.alarmNo.toLowerCase().includes(search.toLowerCase()) || a.message.includes(search));
  }, [pendingData, search]);

  const stats = useMemo(() => ({
    pending: pendingData.length,
    critical: pendingData.filter(a => a.level === 'critical').length,
    today: pendingData.filter(a => a.triggerTime.startsWith('2025-04-29')).length,
    week: 47,
    rate: '92%',
  }), [pendingData]);

  const handleAction = (action: string) => {
    if (!selectedAlarm) return;
    setPendingData(prev => prev.filter(a => a.id !== selectedAlarm.id));
    switch (action) {
      case 'confirm': setConfirmOpen(false); break;
      case 'workorder': setWorkorderOpen(false); break;
      case 'transfer': setTransferOpen(false); break;
      case 'ignore': setIgnoreOpen(false); break;
    }
    alert(`报警 ${selectedAlarm.alarmNo} 已${action === 'confirm' ? '确认' : action === 'workorder' ? '转工单' : action === 'transfer' ? '转调拨' : '忽略'}`);
  };

  const openAction = (alarm: AlarmItem, action: string) => {
    setSelectedAlarm(alarm);
    switch (action) {
      case 'confirm': setConfirmRemark(''); setConfirmOpen(true); break;
      case 'workorder': setWoType(''); setWoDesc(''); setWoAssignee(''); setWorkorderOpen(true); break;
      case 'transfer': setTransferNo(''); setTransferRemark(''); setTransferOpen(true); break;
      case 'ignore': setIgnoreReason(''); setIgnoreOpen(true); break;
      case 'detail': setDetailOpen(true); break;
    }
  };

  const toggleRule = (id: string) => {
    setRulesData(prev => prev.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">报警处理工作流</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">报警确认 · 转工单 · 转调拨 · 升级规则 · 根因分析</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '待处理', value: stats.pending, icon: Bell, color: 'text-red-600', bg: 'bg-red-50' },
          { label: '严重报警', value: stats.critical, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
          { label: '今日报警', value: stats.today, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '本周报警', value: stats.week, icon: TrendingUp, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '处理率', value: stats.rate, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-[480px]">
          <TabsTrigger value="pending">待处理 ({stats.pending})</TabsTrigger>
          <TabsTrigger value="history">处理历史</TabsTrigger>
          <TabsTrigger value="rules">升级规则</TabsTrigger>
          <TabsTrigger value="clusters">报警簇</TabsTrigger>
        </TabsList>

        {/* Tab 1: Pending */}
        <TabsContent value="pending" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索报警编号或内容..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
          </div>
          <div className="space-y-3">
            {filteredPending.map(alarm => (
              <Card key={alarm.id} className="border-l-4 border-l-red-500">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[var(--neutral-text-primary)]">{alarm.alarmNo}</span>
                        {getLevelBadge(alarm.level)}
                        {getStatusBadge(alarm.status)}
                        <span className="text-xs text-[var(--neutral-text-tertiary)] ml-2">{alarm.triggerTime}</span>
                      </div>
                      <div className="text-sm text-[var(--neutral-text-primary)]">{alarm.message}</div>
                      <div className="flex items-center gap-4 text-xs text-[var(--neutral-text-secondary)]">
                        <span>来源：{alarm.source}</span>
                        <span>网点：{alarm.site}</span>
                        <span>载具：{alarm.carrierId}</span>
                        <span>类型：{alarm.type}</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1 shrink-0">
                      <Button variant="outline" size="sm" className="h-7 text-emerald-600" onClick={() => openAction(alarm, 'confirm')}>
                        <CheckCircle className="w-3 h-3 mr-1" />确认
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 text-purple-600" onClick={() => openAction(alarm, 'workorder')}>
                        <Wrench className="w-3 h-3 mr-1" />转工单
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 text-blue-600" onClick={() => openAction(alarm, 'transfer')}>
                        <ArrowRight className="w-3 h-3 mr-1" />转调拨
                      </Button>
                      <Button variant="outline" size="sm" className="h-7 text-gray-500" onClick={() => openAction(alarm, 'ignore')}>
                        <Ban className="w-3 h-3 mr-1" />忽略
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7" onClick={() => openAction(alarm, 'detail')}>
                        <Eye className="w-3 h-3 mr-1" />详情
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 2: History */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">报警编号</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">类型</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">级别</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">触发时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">处理动作</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">处理人</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">处理时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">备注</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historyData.map(h => (
                    <TableRow key={h.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{h.alarmNo}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.type}</TableCell>
                      <TableCell>{getLevelBadge(h.level)}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.triggerTime}</TableCell>
                      <TableCell>{getStatusBadge(h.status)}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.handler}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{h.handleTime}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs max-w-[150px] truncate">{h.handleRemark}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Escalation Rules */}
        <TabsContent value="rules" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-[var(--neutral-text-secondary)]">共 {rulesData.length} 条升级规则</div>
            <Button size="sm" onClick={() => alert('创建规则功能暂未开放')}><Zap className="w-4 h-4 mr-1" />新建规则</Button>
          </div>
          <div className="space-y-3">
            {rulesData.map(rule => (
              <Card key={rule.id}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-[var(--neutral-text-primary)]">{rule.name}</span>
                        {getLevelBadge(rule.level === '严重' ? 'critical' : rule.level === '警告' ? 'warning' : 'info')}
                      </div>
                      <div className="flex items-center gap-4 text-xs text-[var(--neutral-text-secondary)]">
                        <span>延迟：{rule.delayMinutes} 分钟</span>
                        <span>通知方式：{rule.notifyWay}</span>
                        <span>通知对象：{rule.notifyTarget}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch checked={rule.enabled} onCheckedChange={() => toggleRule(rule.id)} />
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => alert('编辑规则：' + rule.name)}>
                        <Eye className="w-3 h-3" />
                      </Button>
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-red-500">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 4: Clusters */}
        <TabsContent value="clusters" className="space-y-4">
          <div className="space-y-3">
            {alarmClusters.map(cluster => (
              <Card key={cluster.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Layers className="w-4 h-4 text-blue-500" />
                        <span className="font-medium text-[var(--neutral-text-primary)]">{cluster.name}</span>
                        <Badge className="bg-red-100 text-red-700">{cluster.alarmCount} 个报警</Badge>
                      </div>
                      <div className="text-sm text-[var(--neutral-text-primary)] mb-1">
                        <span className="text-[var(--neutral-text-secondary)]">根因分析：</span>{cluster.rootCause}
                      </div>
                      <div className="text-xs text-[var(--neutral-text-secondary)] mb-2">时间范围：{cluster.timeRange}</div>
                      <div className="flex flex-wrap gap-1">
                        {cluster.alarms.map(a => (
                          <Badge key={a} variant="outline" className="text-[10px]">{a}</Badge>
                        ))}
                      </div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => alert(`批量处理集群：${cluster.name}`)}>
                      批量处理
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* ========== Dialogs ========== */}

      {/* Confirm Dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>确认报警</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警编号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警内容：{selectedAlarm.message}</div>
              <div>
                <Label className="text-sm font-medium">处理备注</Label>
                <Textarea value={confirmRemark} onChange={e => setConfirmRemark(e.target.value)} placeholder="输入确认备注" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setConfirmOpen(false)}>取消</Button>
                <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={() => handleAction('confirm')}>确认</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Workorder Dialog */}
      <Dialog open={workorderOpen} onOpenChange={setWorkorderOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>转工单</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警编号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
              <div>
                <Label className="text-sm font-medium">工单类型</Label>
                <Select value={woType} onValueChange={setWoType}>
                  <SelectTrigger><SelectValue placeholder="选择工单类型" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="维修工单">维修工单</SelectItem>
                    <SelectItem value="巡检工单">巡检工单</SelectItem>
                    <SelectItem value="调度工单">调度工单</SelectItem>
                    <SelectItem value="其他">其他</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">工单描述</Label>
                <Textarea value={woDesc} onChange={e => setWoDesc(e.target.value)} placeholder="输入工单描述" />
              </div>
              <div>
                <Label className="text-sm font-medium">指派给</Label>
                <Select value={woAssignee} onValueChange={setWoAssignee}>
                  <SelectTrigger><SelectValue placeholder="选择处理人" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="维修组">维修组</SelectItem>
                    <SelectItem value="巡检组">巡检组</SelectItem>
                    <SelectItem value="调度组">调度组</SelectItem>
                    <SelectItem value="值班主管">值班主管</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setWorkorderOpen(false)}>取消</Button>
                <Button onClick={() => handleAction('workorder')} disabled={!woType}>创建工单</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Transfer Dialog */}
      <Dialog open={transferOpen} onOpenChange={setTransferOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>转调拨</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警编号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">关联载具：{selectedAlarm.carrierId}</div>
              <div>
                <Label className="text-sm font-medium">调拨单号</Label>
                <Select value={transferNo} onValueChange={setTransferNo}>
                  <SelectTrigger><SelectValue placeholder="选择调拨单" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TB-20250429-0089">TB-20250429-0089</SelectItem>
                    <SelectItem value="TB-20250429-0090">TB-20250429-0090</SelectItem>
                    <SelectItem value="TB-20250429-0091">TB-20250429-0091</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm font-medium">备注</Label>
                <Textarea value={transferRemark} onChange={e => setTransferRemark(e.target.value)} placeholder="输入调拨备注" />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setTransferOpen(false)}>取消</Button>
                <Button onClick={() => handleAction('transfer')} disabled={!transferNo}>确认转调拨</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Ignore Dialog */}
      <Dialog open={ignoreOpen} onOpenChange={setIgnoreOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>忽略报警</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警编号：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">报警内容：{selectedAlarm.message}</div>
              <div>
                <Label className="text-sm font-medium">忽略原因</Label>
                <Select value={ignoreReason} onValueChange={setIgnoreReason}>
                  <SelectTrigger><SelectValue placeholder="选择忽略原因" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="误报">误报</SelectItem>
                    <SelectItem value="已知问题">已知问题</SelectItem>
                    <SelectItem value="维护中">维护中</SelectItem>
                    <SelectItem value="重复报警">重复报警</SelectItem>
                    <SelectItem value="其他">其他</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIgnoreOpen(false)}>取消</Button>
                <Button variant="destructive" onClick={() => handleAction('ignore')} disabled={!ignoreReason}>确认忽略</Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>报警详情</DialogTitle></DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-[var(--neutral-text-secondary)]">报警编号：</span><span className="font-medium text-[var(--neutral-text-primary)]">{selectedAlarm.alarmNo}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">报警类型：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.type}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">报警级别：</span>{getLevelBadge(selectedAlarm.level)}</div>
                <div><span className="text-[var(--neutral-text-secondary)]">触发时间：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.triggerTime}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">报警来源：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.source}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">所属网点：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.site}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">关联载具：</span><span className="text-[var(--neutral-text-primary)]">{selectedAlarm.carrierId}</span></div>
              </div>
              <div className="bg-[var(--neutral-background)] rounded-lg p-3">
                <div className="text-xs text-[var(--neutral-text-secondary)] mb-1">报警内容</div>
                <div className="text-sm text-[var(--neutral-text-primary)]">{selectedAlarm.message}</div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
