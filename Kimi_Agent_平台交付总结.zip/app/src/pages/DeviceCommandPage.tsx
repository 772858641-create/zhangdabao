import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Send, CheckCircle, XCircle, Clock, Loader2,
  Search, Plus, Terminal, Zap, Eye,
  AlertTriangle,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
interface DeviceCommand {
  id: string;
  cmdNo: string;
  type: string;
  deviceId: string;
  deviceName: string;
  priority: 'high' | 'medium' | 'low';
  createTime: string;
  sendTime?: string;
  executeTime?: string;
  completeTime?: string;
  status: 'pending' | 'sent' | 'executing' | 'success' | 'failed' | 'timeout';
  result?: string;
  errorMsg?: string;
  params: string;
}

interface CommandTimeline {
  step: string;
  time: string;
  status: 'done' | 'current' | 'pending';
}

interface BatchProgress {
  id: string;
  name: string;
  total: number;
  success: number;
  failed: number;
  pending: number;
  progress: number;
}

// ==================== Mock Data ====================
const commands: DeviceCommand[] = [
  { id: 'C001', cmdNo: 'CMD-20250429-1001', type: '定位模式切换', deviceId: 'DEV-20250401-001', deviceName: '定位器-A001', priority: 'high', createTime: '2025-04-29 08:00', sendTime: '2025-04-29 08:01', executeTime: '2025-04-29 08:02', completeTime: '2025-04-29 08:03', status: 'success', result: '定位模式已切换至实时追踪', params: 'mode: realtime' },
  { id: 'C002', cmdNo: 'CMD-20250429-1002', type: '重启设备', deviceId: 'DEV-20250401-015', deviceName: '定位器-A015', priority: 'high', createTime: '2025-04-29 08:15', sendTime: '2025-04-29 08:16', executeTime: '2025-04-29 08:17', completeTime: '2025-04-29 08:19', status: 'success', result: '设备重启成功', params: '-' },
  { id: 'C003', cmdNo: 'CMD-20250429-1003', type: '心跳间隔设置', deviceId: 'DEV-20250402-032', deviceName: '固定网关-B032', priority: 'medium', createTime: '2025-04-29 09:00', sendTime: '2025-04-29 09:01', status: 'sent', params: 'interval: 300s' },
  { id: 'C004', cmdNo: 'CMD-20250429-1004', type: '参数配置', deviceId: 'DEV-20250403-008', deviceName: '车载网关-C008', priority: 'medium', createTime: '2025-04-29 09:30', sendTime: '2025-04-29 09:31', executeTime: '2025-04-29 09:32', status: 'executing', params: 'threshold: -70dBm' },
  { id: 'C005', cmdNo: 'CMD-20250429-1005', type: '固件检查', deviceId: 'DEV-20250404-021', deviceName: '标签-D021', priority: 'low', createTime: '2025-04-29 10:00', status: 'pending', params: 'check: firmware_version' },
  { id: 'C006', cmdNo: 'CMD-20250429-1006', type: '定位模式切换', deviceId: 'DEV-20250405-009', deviceName: '信标-E009', priority: 'medium', createTime: '2025-04-29 10:30', sendTime: '2025-04-29 10:31', executeTime: '2025-04-29 10:32', completeTime: '2025-04-29 10:33', status: 'success', result: '模式切换完成', params: 'mode: power_save' },
  { id: 'C007', cmdNo: 'CMD-20250429-1007', type: '重启设备', deviceId: 'DEV-20250406-044', deviceName: '定位器-A044', priority: 'high', createTime: '2025-04-29 11:00', sendTime: '2025-04-29 11:01', status: 'timeout', errorMsg: '设备未响应，连接超时', params: '-' },
  { id: 'C008', cmdNo: 'CMD-20250429-1008', type: '参数配置', deviceId: 'DEV-20250407-011', deviceName: '固定网关-B011', priority: 'medium', createTime: '2025-04-29 11:30', sendTime: '2025-04-29 11:31', executeTime: '2025-04-29 11:32', completeTime: '2025-04-29 11:33', status: 'failed', errorMsg: '参数范围超出限制', params: 'power: 20dBm' },
  { id: 'C009', cmdNo: 'CMD-20250429-1009', type: '心跳间隔设置', deviceId: 'DEV-20250408-029', deviceName: '车载网关-C029', priority: 'low', createTime: '2025-04-29 13:00', sendTime: '2025-04-29 13:01', executeTime: '2025-04-29 13:02', completeTime: '2025-04-29 13:03', status: 'success', result: '心跳间隔已设置为600秒', params: 'interval: 600s' },
  { id: 'C010', cmdNo: 'CMD-20250429-1010', type: '固件检查', deviceId: 'DEV-20250409-017', deviceName: '标签-D017', priority: 'low', createTime: '2025-04-29 14:00', sendTime: '2025-04-29 14:01', executeTime: '2025-04-29 14:02', status: 'executing', params: 'check: battery_level' },
  { id: 'C011', cmdNo: 'CMD-20250429-1011', type: '重启设备', deviceId: 'DEV-20250410-055', deviceName: '定位器-A055', priority: 'high', createTime: '2025-04-29 14:30', status: 'pending', params: '-' },
  { id: 'C012', cmdNo: 'CMD-20250429-1012', type: '定位模式切换', deviceId: 'DEV-20250411-003', deviceName: '信标-E003', priority: 'medium', createTime: '2025-04-29 15:00', sendTime: '2025-04-29 15:01', status: 'sent', params: 'mode: standard' },
  { id: 'C013', cmdNo: 'CMD-20250429-1013', type: '参数配置', deviceId: 'DEV-20250412-067', deviceName: '车载网关-C067', priority: 'high', createTime: '2025-04-29 15:30', sendTime: '2025-04-29 15:31', executeTime: '2025-04-29 15:32', completeTime: '2025-04-29 15:33', status: 'success', result: '参数配置成功', params: 'sensitivity: high' },
  { id: 'C014', cmdNo: 'CMD-20250429-1014', type: '心跳间隔设置', deviceId: 'DEV-20250413-022', deviceName: '固定网关-B022', priority: 'low', createTime: '2025-04-29 16:00', sendTime: '2025-04-29 16:01', status: 'timeout', errorMsg: '设备离线，指令超时', params: 'interval: 900s' },
  { id: 'C015', cmdNo: 'CMD-20250429-1015', type: '固件检查', deviceId: 'DEV-20250414-041', deviceName: '标签-D041', priority: 'medium', createTime: '2025-04-29 16:30', sendTime: '2025-04-29 16:31', executeTime: '2025-04-29 16:32', completeTime: '2025-04-29 16:33', status: 'success', result: '固件版本正常 v2.1.3', params: 'check: firmware' },
];

const batchProgress: BatchProgress[] = [
  { id: 'B001', name: '批量重启-华东区域', total: 45, success: 42, failed: 2, pending: 1, progress: 98 },
  { id: 'B002', name: '定位模式切换-全部载具', total: 120, success: 98, failed: 5, pending: 17, progress: 86 },
  { id: 'B003', name: '心跳间隔调整-华南区域', total: 38, success: 30, failed: 1, pending: 7, progress: 82 },
];

// ==================== Helpers ====================
function getStatusBadge(status: string) {
  switch (status) {
    case 'pending': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">待下发</Badge>;
    case 'sent': return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">已下发</Badge>;
    case 'executing': return <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100">执行中</Badge>;
    case 'success': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">成功</Badge>;
    case 'failed': return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">失败</Badge>;
    case 'timeout': return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">超时</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

function getStatusIcon(status: string) {
  switch (status) {
    case 'pending': return <Clock className="w-4 h-4 text-amber-500" />;
    case 'sent': return <Send className="w-4 h-4 text-blue-500" />;
    case 'executing': return <Loader2 className="w-4 h-4 text-purple-500 animate-spin" />;
    case 'success': return <CheckCircle className="w-4 h-4 text-emerald-500" />;
    case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
    case 'timeout': return <AlertTriangle className="w-4 h-4 text-gray-500" />;
    default: return <Clock className="w-4 h-4 text-[var(--neutral-text-tertiary)]" />;
  }
}

function getPriorityBadge(p: string) {
  if (p === 'high') return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">高</Badge>;
  if (p === 'medium') return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">中</Badge>;
  return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">低</Badge>;
}

function generateTimeline(cmd: DeviceCommand): CommandTimeline[] {
  const steps: CommandTimeline[] = [
    { step: '指令创建', time: cmd.createTime, status: 'done' },
    { step: '进入队列', time: cmd.createTime, status: 'done' },
  ];
  if (cmd.sendTime) {
    steps.push({ step: '指令下发', time: cmd.sendTime, status: 'done' });
  } else {
    steps.push({ step: '指令下发', time: '-', status: 'pending' });
  }

  if (cmd.executeTime) {
    steps.push({ step: '设备执行', time: cmd.executeTime, status: 'done' });
  } else if (cmd.status === 'sent') {
    steps.push({ step: '设备执行', time: '-', status: 'current' });
  } else {
    steps.push({ step: '设备执行', time: '-', status: 'pending' });
  }

  if (cmd.completeTime) {
    steps.push({ step: '结果上报', time: cmd.completeTime, status: 'done' });
  } else if (cmd.status === 'executing') {
    steps.push({ step: '结果上报', time: '-', status: 'current' });
  } else if (cmd.status === 'pending' || cmd.status === 'sent') {
    steps.push({ step: '结果上报', time: '-', status: 'pending' });
  } else {
    steps.push({ step: '结果上报', time: '-', status: cmd.status === 'timeout' ? 'current' : 'done' });
  }

  return steps;
}

export default function DeviceCommandPage() {
  const [cmdData, setCmdData] = useState(commands);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [addOpen, setAddOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedCmd, setSelectedCmd] = useState<DeviceCommand | null>(null);

  // Add form states
  const [cmdType, setCmdType] = useState('');
  const [deviceId, setDeviceId] = useState('');
  const [priority, setPriority] = useState('medium');
  const [params, setParams] = useState('');

  const filtered = useMemo(() => {
    return cmdData.filter(c => {
      const matchSearch = c.cmdNo.toLowerCase().includes(search.toLowerCase()) || c.deviceId.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || c.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [cmdData, search, statusFilter]);

  const stats = useMemo(() => ({
    pending: cmdData.filter(c => c.status === 'pending').length,
    sent: cmdData.filter(c => c.status === 'sent').length,
    success: cmdData.filter(c => c.status === 'success').length,
    failed: cmdData.filter(c => c.status === 'failed' || c.status === 'timeout').length,
    executing: cmdData.filter(c => c.status === 'executing').length,
  }), [cmdData]);

  const openDetail = (cmd: DeviceCommand) => {
    setSelectedCmd(cmd);
    setDetailOpen(true);
  };

  const addCommand = () => {
    if (!cmdType || !deviceId) return;
    const newCmd: DeviceCommand = {
      id: `C${Date.now()}`,
      cmdNo: `CMD-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(Math.random() * 9000 + 1000)}`,
      type: cmdType,
      deviceId,
      deviceName: `设备-${deviceId.split('-').pop()}`,
      priority: priority as 'high' | 'medium' | 'low',
      createTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status: 'pending',
      params: params || '-',
    };
    setCmdData(prev => [newCmd, ...prev]);
    setAddOpen(false);
    setCmdType('');
    setDeviceId('');
    setPriority('medium');
    setParams('');
  };

  const retryCommand = (id: string) => {
    setCmdData(prev => prev.map(c => c.id === id ? { ...c, status: 'pending' as const, errorMsg: undefined } : c));
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">设备指令下发</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">指令队列 · 执行状态机 · 批量进度 · 生命周期追踪</p>
        </div>
        <Button size="sm" onClick={() => { setCmdType(''); setDeviceId(''); setPriority('medium'); setParams(''); setAddOpen(true); }}>
          <Plus className="w-4 h-4 mr-1" />新建指令
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '待下发', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: '已下发', value: stats.sent, icon: Send, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '执行中', value: stats.executing, icon: Loader2, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: '执行成功', value: stats.success, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '执行失败', value: stats.failed, icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Batch Progress */}
      <div className="space-y-3">
        <div className="text-sm font-medium text-[var(--neutral-text-primary)]">批量指令进度</div>
        <div className="grid grid-cols-3 gap-4">
          {batchProgress.map(b => (
            <Card key={b.id}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-[var(--neutral-text-primary)]">{b.name}</span>
                  <Badge variant="outline">{b.total} 台设备</Badge>
                </div>
                <Progress value={b.progress} className="h-2" />
                <div className="flex items-center justify-between text-xs text-[var(--neutral-text-secondary)]">
                  <span className="text-emerald-600">成功 {b.success}</span>
                  <span className="text-red-500">失败 {b.failed}</span>
                  <span className="text-amber-500">待执行 {b.pending}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
          <Input placeholder="搜索指令编号或设备ID..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder="全部状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部状态</SelectItem>
            <SelectItem value="pending">待下发</SelectItem>
            <SelectItem value="sent">已下发</SelectItem>
            <SelectItem value="executing">执行中</SelectItem>
            <SelectItem value="success">成功</SelectItem>
            <SelectItem value="failed">失败</SelectItem>
            <SelectItem value="timeout">超时</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Command Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-[var(--neutral-background)]">
                <TableHead className="text-[var(--neutral-text-secondary)]">指令编号</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">指令类型</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">目标设备</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">优先级</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">创建时间</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)]">执行结果</TableHead>
                <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(cmd => (
                <TableRow key={cmd.id} className="hover:bg-[var(--neutral-background)]">
                  <TableCell className="font-medium text-[var(--neutral-text-primary)]">{cmd.cmdNo}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Terminal className="w-3.5 h-3.5 text-[var(--neutral-text-secondary)]" />
                      <span className="text-[var(--neutral-text-primary)]">{cmd.type}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-[var(--neutral-text-primary)]">{cmd.deviceName}</div>
                    <div className="text-xs text-[var(--neutral-text-tertiary)]">{cmd.deviceId}</div>
                  </TableCell>
                  <TableCell>{getPriorityBadge(cmd.priority)}</TableCell>
                  <TableCell className="text-[var(--neutral-text-secondary)]">{cmd.createTime}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {getStatusIcon(cmd.status)}
                      {getStatusBadge(cmd.status)}
                    </div>
                  </TableCell>
                  <TableCell className="text-xs max-w-[150px]">
                    {cmd.result ? <span className="text-emerald-600">{cmd.result}</span> : cmd.errorMsg ? <span className="text-red-500">{cmd.errorMsg}</span> : <span className="text-[var(--neutral-text-tertiary)]">-</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="sm" className="h-7" onClick={() => openDetail(cmd)}>
                        <Eye className="w-3 h-3 mr-1" />详情
                      </Button>
                      {(cmd.status === 'failed' || cmd.status === 'timeout') && (
                        <Button variant="ghost" size="sm" className="h-7 text-blue-600" onClick={() => retryCommand(cmd.id)}>
                          <Zap className="w-3 h-3 mr-1" />重试
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Command Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>新建指令</DialogTitle></DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="text-sm font-medium">指令类型</Label>
              <Select value={cmdType} onValueChange={setCmdType}>
                <SelectTrigger><SelectValue placeholder="选择指令类型" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="重启设备">重启设备</SelectItem>
                  <SelectItem value="定位模式切换">定位模式切换</SelectItem>
                  <SelectItem value="心跳间隔设置">心跳间隔设置</SelectItem>
                  <SelectItem value="参数配置">参数配置</SelectItem>
                  <SelectItem value="固件检查">固件检查</SelectItem>
                  <SelectItem value="数据上报">数据上报</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">目标设备</Label>
              <Select value={deviceId} onValueChange={setDeviceId}>
                <SelectTrigger><SelectValue placeholder="选择设备" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="DEV-20250401-001">定位器-A001</SelectItem>
                  <SelectItem value="DEV-20250401-015">定位器-A015</SelectItem>
                  <SelectItem value="DEV-20250402-032">固定网关-B032</SelectItem>
                  <SelectItem value="DEV-20250403-008">车载网关-C008</SelectItem>
                  <SelectItem value="DEV-20250404-021">标签-D021</SelectItem>
                  <SelectItem value="DEV-20250405-009">信标-E009</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">优先级</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">高</SelectItem>
                  <SelectItem value="medium">中</SelectItem>
                  <SelectItem value="low">低</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-sm font-medium">参数</Label>
              <Input value={params} onChange={e => setParams(e.target.value)} placeholder="如 mode: realtime" />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setAddOpen(false)}>取消</Button>
              <Button onClick={addCommand} disabled={!cmdType || !deviceId}>创建指令</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>指令详情</DialogTitle></DialogHeader>
          {selectedCmd && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div><span className="text-[var(--neutral-text-secondary)]">指令编号：</span><span className="font-medium text-[var(--neutral-text-primary)]">{selectedCmd.cmdNo}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">指令类型：</span><span className="text-[var(--neutral-text-primary)]">{selectedCmd.type}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">目标设备：</span><span className="text-[var(--neutral-text-primary)]">{selectedCmd.deviceName}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">设备ID：</span><span className="text-[var(--neutral-text-primary)]">{selectedCmd.deviceId}</span></div>
                <div><span className="text-[var(--neutral-text-secondary)]">优先级：</span>{getPriorityBadge(selectedCmd.priority)}</div>
                <div><span className="text-[var(--neutral-text-secondary)]">状态：</span>{getStatusBadge(selectedCmd.status)}</div>
              </div>
              <div className="bg-[var(--neutral-background)] rounded-lg p-3">
                <div className="text-xs text-[var(--neutral-text-secondary)] mb-1">参数</div>
                <div className="text-sm text-[var(--neutral-text-primary)]">{selectedCmd.params}</div>
              </div>
              {selectedCmd.result && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3">
                  <div className="text-xs text-emerald-600 mb-1">执行结果</div>
                  <div className="text-sm text-emerald-700">{selectedCmd.result}</div>
                </div>
              )}
              {selectedCmd.errorMsg && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <div className="text-xs text-red-600 mb-1">错误信息</div>
                  <div className="text-sm text-red-700">{selectedCmd.errorMsg}</div>
                </div>
              )}
              <div>
                <div className="text-sm font-medium text-[var(--neutral-text-primary)] mb-3">指令生命周期</div>
                <div className="space-y-2">
                  {generateTimeline(selectedCmd).map((t, idx, arr) => (
                    <div key={t.step} className="flex items-start gap-3">
                      <div className="flex flex-col items-center">
                        <div className={cn("w-3 h-3 rounded-full", t.status === 'done' ? "bg-emerald-500" : t.status === 'current' ? "bg-purple-500 animate-pulse" : "bg-[var(--neutral-border)]")} />
                        {idx < arr.length - 1 && <div className="w-0.5 h-6 bg-[var(--neutral-border)] mt-1" />}
                      </div>
                      <div className="flex-1 pb-2">
                        <div className="flex items-center gap-2">
                          <span className={cn("text-sm", t.status === 'done' ? "text-[var(--neutral-text-primary)]" : t.status === 'current' ? "text-purple-600 font-medium" : "text-[var(--neutral-text-tertiary)]")}>{t.step}</span>
                          {t.status === 'done' && <CheckCircle className="w-3 h-3 text-emerald-500" />}
                          {t.status === 'current' && <Loader2 className="w-3 h-3 text-purple-500 animate-spin" />}
                        </div>
                        <div className="text-xs text-[var(--neutral-text-secondary)]">{t.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
