import { useState, useMemo, useCallback } from 'react';
import {
  Plus,
  Upload,
  Download,
  Search,
  ChevronDown,
  MoreHorizontal,
  Eye,
  Pencil,
  Link2,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Wrench,
  ShieldCheck,
  Fuel,
  User,
  FileSpreadsheet,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import type { Vehicle } from '@/lib/mockData';
import { getStatusLabel, getStatusColor } from '@/lib/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
} from '@/components/ui/drawer';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// --- Types ---
type SortField = 'plateNumber' | 'type' | 'status' | 'driverName' | 'orgName' | 'createdAt';
type SortDirection = 'asc' | 'desc';
type StatusTab = 'all' | 'idle' | 'in_transit' | 'repairing' | 'inactive';

// --- Status Tag ---
function StatusTag({ status, text }: { status: string; text: string }) {
  const color = getStatusColor(status);
  return (
    <span
      className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: `${color}15`, color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
      {text}
    </span>
  );
}

// --- KPI Card ---
function KPICard({ label, value, subtext, color }: { label: string; value: string; subtext?: string; color: string }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow-card flex-1">
      <div className="flex items-center gap-2 mb-2">
        <div className="w-1 h-4 rounded-full" style={{ backgroundColor: color }} />
        <span className="text-xs text-[#475569]">{label}</span>
      </div>
      <div className="text-[28px] font-semibold text-[#0F172A] leading-tight">{value}</div>
      {subtext && <div className="text-xs text-[#94A3B8] mt-1">{subtext}</div>}
    </div>
  );
}

// --- Pagination ---
function PaginationBar({
  page,
  totalPages,
  pageSize,
  onPageChange,
  onPageSizeChange,
  total,
}: {
  page: number;
  totalPages: number;
  pageSize: number;
  onPageChange: (p: number) => void;
  onPageSizeChange: (s: number) => void;
  total: number;
}) {
  const pageSizes = [20, 50, 100];
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-[#E2E8F0]">
      <div className="flex items-center gap-2 text-sm text-[#475569]">
        <span>每页</span>
        <Select value={String(pageSize)} onValueChange={(v) => onPageSizeChange(Number(v))}>
          <SelectTrigger className="h-8 w-[70px] text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            {pageSizes.map((s) => (
              <SelectItem key={s} value={String(s)}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span>条</span>
        <span className="ml-4">共 {total} 条</span>
      </div>
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon-sm" onClick={() => onPageChange(Math.max(1, page - 1))} disabled={page <= 1}>
          <ChevronLeft size={16} />
        </Button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let pageNum: number;
          if (totalPages <= 5) pageNum = i + 1;
          else if (page <= 3) pageNum = i + 1;
          else if (page >= totalPages - 2) pageNum = totalPages - 4 + i;
          else pageNum = page - 2 + i;
          return (
            <Button
              key={pageNum}
              variant={pageNum === page ? 'default' : 'ghost'}
              size="icon-sm"
              className={cn('w-8 h-8 text-xs', pageNum === page && 'bg-[#2563EB] text-white')}
              onClick={() => onPageChange(pageNum)}
            >
              {pageNum}
            </Button>
          );
        })}
        <Button variant="ghost" size="icon-sm" onClick={() => onPageChange(Math.min(totalPages, page + 1))} disabled={page >= totalPages}>
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
}

// --- Bind Carrier Dialog ---
function BindCarrierDialog({ open, onClose, vehicle }: { open: boolean; onClose: () => void; vehicle?: Vehicle }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>绑定载具</DialogTitle>
          <DialogDescription>{vehicle && `为车辆 ${vehicle.plateNumber} 绑定载具`}</DialogDescription>
        </DialogHeader>
        <div className="py-4">
          <div className="relative mb-4">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input placeholder="搜索载具编号、名称..." className="pl-8" />
          </div>
          <div className="border rounded-lg max-h-[300px] overflow-y-auto">
            {[
              { code: 'CJ000001', name: '托盘-0001', type: '托盘', status: 'normal' },
              { code: 'CJ000002', name: '周转箱-0002', type: '周转箱', status: 'normal' },
              { code: 'CJ000003', name: '料架-0003', type: '料架', status: 'normal' },
              { code: 'CJ000004', name: '集装箱-0004', type: '集装箱', status: 'normal' },
              { code: 'CJ000005', name: '笼车-0005', type: '笼车', status: 'normal' },
            ].map((c) => (
              <div key={c.code} className="flex items-center justify-between px-4 py-3 border-b border-[#E2E8F0] last:border-0 hover:bg-[#F8FAFC]">
                <div>
                  <div className="text-sm font-medium text-[#0F172A]">{c.code}</div>
                  <div className="text-xs text-[#475569]">{c.name} · {c.type}</div>
                </div>
                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onClose}>绑定</Button>
              </div>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>关闭</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Maintenance Dialog ---
function MaintenanceDialog({ open, onClose, vehicle }: { open: boolean; onClose: () => void; vehicle?: Vehicle }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>新增运维记录</DialogTitle>
          <DialogDescription>{vehicle && `车辆：${vehicle.plateNumber}`}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">记录类型</label>
            <Select>
              <SelectTrigger><SelectValue placeholder="选择类型" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="repair">维修</SelectItem>
                <SelectItem value="maintenance">保养</SelectItem>
                <SelectItem value="insurance">保险</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">日期</label>
            <Input type="date" />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">描述</label>
            <textarea className="w-full min-h-[80px] rounded-md border border-[#E2E8F0] px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]/10" placeholder="请输入描述" />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">费用（元）</label>
            <Input type="number" placeholder="0.00" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Import Dialog ---
function ImportDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>批量导入车辆</DialogTitle>
          <DialogDescription>上传 Excel 文件批量导入车辆数据</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <FileSpreadsheet size={16} className="text-[#10B981]" />
            <span className="text-[#2563EB] cursor-pointer hover:underline">下载导入模板</span>
          </div>
          <div className="border-2 border-dashed border-[#CBD5E1] rounded-lg p-8 text-center hover:border-[#2563EB] hover:bg-[#EFF6FF] transition-colors cursor-pointer">
            <Upload size={32} className="mx-auto mb-2 text-[#94A3B8]" />
            <p className="text-sm text-[#475569]">拖拽文件到此处，或点击上传</p>
            <p className="text-xs text-[#94A3B8] mt-1">支持 .xlsx, .xls 格式，最大 10MB</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>开始导入</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// --- Vehicle Detail Drawer ---
function VehicleDetailDrawer({ vehicle, open, onClose, onBindCarrier, onAddMaintenance }: {
  vehicle?: Vehicle;
  open: boolean;
  onClose: () => void;
  onBindCarrier: () => void;
  onAddMaintenance: () => void;
}) {
  if (!vehicle) return null;

  const boundCarriers = [
    { code: 'CJ000001', name: '托盘-0001', type: '托盘', status: 'normal', boundAt: '2024-12-01' },
    { code: 'CJ000003', name: '料架-0003', type: '料架', status: 'normal', boundAt: '2024-12-10' },
    { code: 'CJ000005', name: '笼车-0005', type: '笼车', status: 'normal', boundAt: '2024-12-15' },
  ];

  const driverInfo = vehicle.driverName ? {
    name: vehicle.driverName,
    phone: '138****1234',
    license: '310***********1234',
    licenseType: 'A2',
    experience: '8年',
    status: 'active',
  } : null;

  const maintenanceRecords = [
    { date: '2024-12-10', type: '保养', desc: '常规保养，更换机油', cost: 580, status: 'completed' },
    { date: '2024-11-01', type: '维修', desc: '刹车系统维修', cost: 1200, status: 'completed' },
    { date: '2024-10-15', type: '保险', desc: '交强险+商业险续保', cost: 6800, status: 'completed' },
  ];

  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[640px] w-3/4">
        <DrawerHeader>
          <div className="flex items-center justify-between">
            <DrawerTitle className="text-xl font-semibold">{vehicle.plateNumber}</DrawerTitle>
            <StatusTag status={vehicle.status} text={getStatusLabel(vehicle.status)} />
          </div>
          <DrawerDescription>{vehicle.brand} {vehicle.model} · {vehicle.type}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4">
          <Tabs defaultValue="basic">
            <TabsList className="w-full">
              <TabsTrigger value="basic" className="flex-1">基本信息</TabsTrigger>
              <TabsTrigger value="carriers" className="flex-1">绑定载具</TabsTrigger>
              <TabsTrigger value="driver" className="flex-1">司机信息</TabsTrigger>
              <TabsTrigger value="maintenance" className="flex-1">运维记录</TabsTrigger>
              <TabsTrigger value="history" className="flex-1">调拨历史</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                {[
                  ['车牌号', vehicle.plateNumber],
                  ['车辆类型', vehicle.type],
                  ['品牌', vehicle.brand],
                  ['型号', vehicle.model],
                  ['载重', `${vehicle.capacity}kg`],
                  ['司机', vehicle.driverName || '未分配'],
                  ['所属组织', vehicle.orgName],
                  ['当前位置', vehicle.currentLocation],
                  ['创建时间', vehicle.createdAt],
                ].map(([label, value]) => (
                  <div key={label}>
                    <div className="text-xs text-[#94A3B8] mb-1">{label}</div>
                    <div className="text-sm text-[#0F172A]">{value}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 flex justify-end gap-2">
                <Button variant="outline">编辑</Button>
                <Button variant="outline" className="text-[#EF4444]">停用车辆</Button>
              </div>
            </TabsContent>

            <TabsContent value="carriers" className="mt-4">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm text-[#475569]">已绑定 {boundCarriers.length} 个载具</span>
                <Button size="sm" onClick={onBindCarrier}><Link2 size={14} className="mr-1" />绑定载具</Button>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-[#F1F5F9]">
                      <TableHead className="text-xs">载具编号</TableHead>
                      <TableHead className="text-xs">名称</TableHead>
                      <TableHead className="text-xs">类型</TableHead>
                      <TableHead className="text-xs">状态</TableHead>
                      <TableHead className="text-xs">绑定时间</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {boundCarriers.map((c) => (
                      <TableRow key={c.code}>
                        <TableCell className="font-mono text-xs">{c.code}</TableCell>
                        <TableCell className="text-xs">{c.name}</TableCell>
                        <TableCell className="text-xs">{c.type}</TableCell>
                        <TableCell><StatusTag status="normal" text="正常" /></TableCell>
                        <TableCell className="text-xs text-[#475569]">{c.boundAt}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="driver" className="mt-4">
              {driverInfo ? (
                <div className="space-y-4">
                  <div className="bg-[#F8FAFC] rounded-lg p-4 flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-[#EFF6FF] flex items-center justify-center">
                      <User size={28} className="text-[#2563EB]" />
                    </div>
                    <div>
                      <div className="text-lg font-medium text-[#0F172A]">{driverInfo.name}</div>
                      <div className="text-sm text-[#475569]">驾龄 {driverInfo.experience} · 驾驶证 {driverInfo.licenseType}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div><div className="text-xs text-[#94A3B8]">联系电话</div><div className="text-sm">{driverInfo.phone}</div></div>
                    <div><div className="text-xs text-[#94A3B8]">驾驶证号</div><div className="text-sm">{driverInfo.license}</div></div>
                  </div>
                  <div className="flex justify-end">
                    <Button variant="outline" size="sm">更换司机</Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-[#94A3B8]">
                  <User size={48} className="mx-auto mb-2 text-[#CBD5E1]" />
                  <p className="text-sm">未分配司机</p>
                  <Button size="sm" className="mt-3">分配司机</Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="maintenance" className="mt-4">
              <div className="flex justify-between items-center mb-3">
                <span className="text-sm text-[#475569]">运维记录</span>
                <Button size="sm" onClick={onAddMaintenance}><Wrench size={14} className="mr-1" />新增记录</Button>
              </div>
              <div className="space-y-3">
                {maintenanceRecords.map((r, i) => (
                  <div key={i} className="bg-[#F8FAFC] rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        {r.type === '保养' && <Fuel size={14} className="text-[#2563EB]" />}
                        {r.type === '维修' && <Wrench size={14} className="text-[#F59E0B]" />}
                        {r.type === '保险' && <ShieldCheck size={14} className="text-[#10B981]" />}
                        <span className="text-sm font-medium">{r.type}</span>
                      </div>
                      <span className="text-xs text-[#94A3B8]">{r.date}</span>
                    </div>
                    <div className="text-sm text-[#475569]">{r.desc}</div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-sm font-medium text-[#0F172A]">¥{r.cost}</span>
                      <StatusTag status="completed" text="已完成" />
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="history" className="mt-4">
              <div className="space-y-3">
                {[
                  { date: '2024-12-18', from: '上海浦东工厂', to: '宁波生产基地', status: 'completed' },
                  { date: '2024-12-10', from: '宁波生产基地', to: '上海浦东工厂', status: 'completed' },
                ].map((t, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-2 h-2 rounded-full bg-[#2563EB]" />
                      {i < 1 && <div className="w-px h-full bg-[#E2E8F0]" />}
                    </div>
                    <div className="pb-4">
                      <div className="text-xs text-[#94A3B8]">{t.date}</div>
                      <div className="text-sm text-[#0F172A]">{t.from} → {t.to}</div>
                      <StatusTag status={t.status} text={getStatusLabel(t.status)} />
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>关闭</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

// --- Vehicle Form Drawer ---
function VehicleFormDrawer({ vehicle, open, onClose }: {
  vehicle?: Vehicle;
  open: boolean;
  onClose: () => void;
}) {
  const isEdit = !!vehicle;
  return (
    <Drawer open={open} onOpenChange={(v) => !v && onClose()}>
      <DrawerContent className="sm:max-w-[560px] w-3/4">
        <DrawerHeader>
          <DrawerTitle>{isEdit ? '编辑车辆' : '新增车辆'}</DrawerTitle>
          <DrawerDescription>{isEdit ? `编辑车辆 ${vehicle?.plateNumber}` : '填写车辆信息'}</DrawerDescription>
        </DrawerHeader>
        <div className="flex-1 overflow-y-auto px-4 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">车牌号 {isEdit ? '' : '*'}</label>
              <Input defaultValue={vehicle?.plateNumber} disabled={isEdit} placeholder="如 沪A12345" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">车辆类型 *</label>
              <Select defaultValue={vehicle?.type || '货车'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="货车">货车</SelectItem>
                  <SelectItem value="面包车">面包车</SelectItem>
                  <SelectItem value="卡车">卡车</SelectItem>
                  <SelectItem value="叉车">叉车</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">品牌</label>
              <Input defaultValue={vehicle?.brand} placeholder="如 东风" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">型号</label>
              <Input defaultValue={vehicle?.model} placeholder="如 天龙KL" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">载重（kg）</label>
              <Input type="number" defaultValue={vehicle?.capacity} placeholder="0" />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">司机</label>
              <Select>
                <SelectTrigger><SelectValue placeholder="选择司机" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="u-2">张三</SelectItem>
                  <SelectItem value="u-3">李四</SelectItem>
                  <SelectItem value="u-4">王五</SelectItem>
                  <SelectItem value="u-5">赵六</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">所属组织</label>
              <Select defaultValue={vehicle?.orgId || 'org-2'}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="org-1">云载科技（总部）</SelectItem>
                  <SelectItem value="org-2">华东汽车制造有限公司</SelectItem>
                  <SelectItem value="org-3">南方物流集团</SelectItem>
                  <SelectItem value="org-4">北方供应链管理有限公司</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-[#475569]">车载网关</label>
              <Select>
                <SelectTrigger><SelectValue placeholder="选择网关设备" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="gw-1">GW-001</SelectItem>
                  <SelectItem value="gw-2">GW-002</SelectItem>
                  <SelectItem value="gw-3">GW-003</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-[#475569]">备注</label>
            <textarea className="w-full min-h-[80px] rounded-md border border-[#E2E8F0] px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]/10" placeholder="请输入备注" />
          </div>
        </div>
        <DrawerFooter>
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={onClose}>{isEdit ? '保存' : '创建'}</Button>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}

// ==================== MAIN PAGE ====================
export default function FleetManagementPage() {
  const { vehicles, carriers } = useMockData();

  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [statusTab, setStatusTab] = useState<StatusTab>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [orgFilter, setOrgFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortDir, setSortDir] = useState<SortDirection>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(20);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Dialog/Drawer states
  const [detailVehicle, setDetailVehicle] = useState<Vehicle | undefined>();
  const [showDetail, setShowDetail] = useState(false);
  const [editVehicle, setEditVehicle] = useState<Vehicle | undefined>();
  const [showForm, setShowForm] = useState(false);
  const [showBindCarrier, setShowBindCarrier] = useState(false);
  const [showMaintenance, setShowMaintenance] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Enrich vehicles with computed fields
  const enrichedVehicles = useMemo(() => {
    return vehicles.map((v) => ({
      ...v,
      boundCarrierCount: carriers.filter((c) => c.orgId === v.orgId).length % 5,
      gatewayId: v.gpsDeviceId ? `GW-${v.plateNumber.slice(-4)}` : null,
      lastLocation: v.currentLocation,
    }));
  }, [vehicles, carriers]);

  // Filter & Sort
  const filtered = useMemo(() => {
    let data = [...enrichedVehicles];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      data = data.filter((v) =>
        v.plateNumber.toLowerCase().includes(q) ||
        v.type.includes(q) ||
        (v.driverName || '').includes(q)
      );
    }

    if (statusTab !== 'all') {
      data = data.filter((v) => v.status === statusTab);
    }

    if (typeFilter !== 'all') {
      data = data.filter((v) => v.type === typeFilter);
    }

    if (orgFilter !== 'all') {
      data = data.filter((v) => v.orgId === orgFilter);
    }

    data.sort((a, b) => {
      const dir = sortDir === 'asc' ? 1 : -1;
      if (sortField === 'plateNumber') return dir * a.plateNumber.localeCompare(b.plateNumber);
      if (sortField === 'type') return dir * a.type.localeCompare(b.type);
      if (sortField === 'status') return dir * a.status.localeCompare(b.status);
      if (sortField === 'driverName') return dir * ((a.driverName || '') as string).localeCompare(b.driverName || '');
      if (sortField === 'orgName') return dir * a.orgName.localeCompare(b.orgName);
      return dir * a.createdAt.localeCompare(b.createdAt);
    });

    return data;
  }, [enrichedVehicles, searchQuery, statusTab, typeFilter, orgFilter, sortField, sortDir]);

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage, pageSize]);

  // Selection
  const allSelectedOnPage = pageData.length > 0 && pageData.every((v) => selectedIds.has(v.id));
  const someSelected = selectedIds.size > 0;

  const toggleSelectAll = useCallback(() => {
    if (allSelectedOnPage) {
      const next = new Set(selectedIds);
      pageData.forEach((v) => next.delete(v.id));
      setSelectedIds(next);
    } else {
      const next = new Set(selectedIds);
      pageData.forEach((v) => next.add(v.id));
      setSelectedIds(next);
    }
  }, [allSelectedOnPage, pageData, selectedIds]);

  const toggleSelectOne = useCallback((id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  }, [selectedIds]);

  const clearSelection = useCallback(() => setSelectedIds(new Set()), []);

  const handleSort = useCallback((field: SortField) => {
    setSortField((prev) => {
      if (prev === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return prev;
      }
      setSortDir('asc');
      return field;
    });
  }, []);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return <ChevronDown size={12} className="text-[#CBD5E1]" />;
    return sortDir === 'asc'
      ? <ChevronDown size={12} className="text-[#2563EB] rotate-180" />
      : <ChevronDown size={12} className="text-[#2563EB]" />;
  };

  // KPI data
  const kpiData = [
    { label: '车辆总数', value: String(vehicles.length), subtext: '全部车辆', color: '#2563EB' },
    { label: '空闲车辆', value: String(vehicles.filter((v) => v.status === 'idle').length), subtext: '可调度', color: '#10B981' },
    { label: '在途中', value: String(vehicles.filter((v) => v.status === 'in_transit').length), subtext: '运输中', color: '#06B6D4' },
    { label: '维修中', value: String(vehicles.filter((v) => v.status === 'repairing').length), subtext: '需关注', color: '#F59E0B' },
  ];

  const statusTabs: Array<{ key: StatusTab; label: string }> = [
    { key: 'all', label: '全部' },
    { key: 'idle', label: '空闲' },
    { key: 'in_transit', label: '在途中' },
    { key: 'repairing', label: '维修中' },
    { key: 'inactive', label: '已停用' },
  ];

  const typeOptions = [
    { value: 'all', label: '全部类型' },
    { value: '货车', label: '货车' },
    { value: '面包车', label: '面包车' },
    { value: '卡车', label: '卡车' },
    { value: '叉车', label: '叉车' },
  ];

  const orgOptions = [
    { value: 'all', label: '全部组织' },
    { value: 'org-1', label: '云载科技（总部）' },
    { value: 'org-2', label: '华东汽车制造有限公司' },
    { value: 'org-3', label: '南方物流集团' },
    { value: 'org-4', label: '北方供应链管理有限公司' },
  ];

  const handleExport = (type: string) => {
    setShowExportMenu(false);
    const blob = new Blob([JSON.stringify(filtered, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `车辆数据_${type}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 animate-fade-in-up">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-semibold text-[#0F172A] tracking-tight">车辆管理</h1>
          <Badge variant="secondary" className="text-xs">共 {filtered.length} 辆</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button onClick={() => { setEditVehicle(undefined); setShowForm(true); }}>
            <Plus size={16} className="mr-1" />新增车辆
          </Button>
          <Button variant="outline" onClick={() => setShowImport(true)}>
            <Upload size={16} className="mr-1" />导入
          </Button>
          <DropdownMenu open={showExportMenu} onOpenChange={setShowExportMenu}>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download size={16} className="mr-1" />导出
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleExport('current')}>导出当前页</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExport('all')}>导出全部</DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleExport('selected')}>导出选中项</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="flex gap-4">
        {kpiData.map((kpi) => (
          <KPICard key={kpi.label} {...kpi} />
        ))}
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg p-4 shadow-card space-y-4">
        <div className="flex items-center gap-3 flex-wrap">
          {/* Status tabs */}
          <div className="flex items-center bg-[#F1F5F9] rounded-md p-[3px]">
            {statusTabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setStatusTab(tab.key)}
                className={cn(
                  'px-3 py-1.5 text-xs font-medium rounded-md transition-all',
                  statusTab === tab.key
                    ? 'bg-white text-[#2563EB] shadow-sm'
                    : 'text-[#475569] hover:text-[#0F172A]'
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Type filter */}
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="h-8 w-[130px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {typeOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Org filter */}
          <Select value={orgFilter} onValueChange={setOrgFilter}>
            <SelectTrigger className="h-8 w-[180px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {orgOptions.map((o) => (
                <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex-1" />

          {/* Search */}
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
            <Input
              placeholder="搜索车牌号、车型、司机..."
              className="h-8 w-[240px] pl-8 text-xs"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Batch Operation Bar */}
      {someSelected && (
        <div className="bg-[#EFF6FF] rounded-md px-4 py-2 flex items-center justify-between animate-fade-in-up">
          <div className="flex items-center gap-3 text-sm">
            <span className="text-[#0F172A]">已选中 <strong className="text-[#2563EB]">{selectedIds.size}</strong> 辆</span>
            <button className="text-[#2563EB] text-xs hover:underline" onClick={toggleSelectAll}>全选当前页</button>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="h-7 text-xs"><Link2 size={12} className="mr-1" />批量绑定</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs"><Wrench size={12} className="mr-1" />批量设置状态</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs"><Download size={12} className="mr-1" />批量导出</Button>
            <Button size="sm" variant="outline" className="h-7 text-xs text-[#EF4444] hover:text-[#EF4444]"><Trash2 size={12} className="mr-1" />批量删除</Button>
            <button className="text-xs text-[#475569] hover:text-[#0F172A] ml-2" onClick={clearSelection}>取消选择</button>
          </div>
        </div>
      )}

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#F1F5F9] hover:bg-[#F1F5F9]">
                <TableHead className="w-[40px]">
                  <Checkbox checked={allSelectedOnPage} onCheckedChange={toggleSelectAll} aria-label="Select all" />
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('plateNumber')}>
                  <div className="flex items-center gap-1">车牌号 <SortIcon field="plateNumber" /></div>
                </TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('type')}>
                  <div className="flex items-center gap-1">车辆类型 <SortIcon field="type" /></div>
                </TableHead>
                <TableHead>品牌型号</TableHead>
                <TableHead>司机</TableHead>
                <TableHead>所属组织</TableHead>
                <TableHead className="cursor-pointer" onClick={() => handleSort('status')}>
                  <div className="flex items-center gap-1">当前状态 <SortIcon field="status" /></div>
                </TableHead>
                <TableHead>绑定载具数</TableHead>
                <TableHead>车载网关</TableHead>
                <TableHead>最近位置</TableHead>
                <TableHead className="w-[120px]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={11} className="text-center py-16 text-[#94A3B8]">
                    <div className="flex flex-col items-center gap-2">
                      <Search size={48} className="text-[#CBD5E1]" />
                      <p className="text-sm">未找到匹配的车辆</p>
                      <Button variant="outline" size="sm" onClick={() => {
                        setSearchQuery('');
                        setStatusTab('all');
                        setTypeFilter('all');
                        setOrgFilter('all');
                      }}>清除筛选</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                pageData.map((vehicle, idx) => (
                  <TableRow
                    key={vehicle.id}
                    className={cn(
                      'h-12',
                      idx % 2 === 1 && 'bg-[#F8FAFC]',
                      selectedIds.has(vehicle.id) && 'bg-[#EFF6FF] border-l-[3px] border-l-[#2563EB]'
                    )}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.has(vehicle.id)}
                        onCheckedChange={() => toggleSelectOne(vehicle.id)}
                        aria-label={`Select ${vehicle.plateNumber}`}
                      />
                    </TableCell>
                    <TableCell>
                      <button
                        className="text-sm font-medium text-[#2563EB] hover:underline"
                        onClick={() => { setDetailVehicle(vehicle); setShowDetail(true); }}
                      >
                        {vehicle.plateNumber}
                      </button>
                    </TableCell>
                    <TableCell>
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-[#F1F5F9] text-[#475569]">
                        {vehicle.type}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-[#475569]">{vehicle.brand} {vehicle.model}</TableCell>
                    <TableCell>
                      {vehicle.driverName ? (
                        <div className="flex items-center gap-1.5">
                          <div className="w-5 h-5 rounded-full bg-[#EFF6FF] flex items-center justify-center">
                            <User size={10} className="text-[#2563EB]" />
                          </div>
                          <span className="text-sm text-[#0F172A]">{vehicle.driverName}</span>
                        </div>
                      ) : (
                        <span className="text-xs text-[#94A3B8]">未分配</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-[#475569]">{vehicle.orgName}</TableCell>
                    <TableCell>
                      <StatusTag status={vehicle.status} text={getStatusLabel(vehicle.status)} />
                    </TableCell>
                    <TableCell className="text-sm text-[#0F172A]">{vehicle.boundCarrierCount}</TableCell>
                    <TableCell>
                      {vehicle.gatewayId ? (
                        <span className="font-mono text-xs text-[#475569]">{vehicle.gatewayId}</span>
                      ) : (
                        <span className="text-xs text-[#94A3B8]">未绑定</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-[#475569] max-w-[140px] truncate">{vehicle.lastLocation}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setDetailVehicle(vehicle); setShowDetail(true); }}>
                          <Eye size={14} className="text-[#475569]" />
                        </Button>
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setEditVehicle(vehicle); setShowForm(true); }}>
                          <Pencil size={14} className="text-[#475569]" />
                        </Button>
                        <Button variant="ghost" size="icon-sm" className="h-7 w-7" onClick={() => { setDetailVehicle(vehicle); setShowBindCarrier(true); }}>
                          <Link2 size={14} className="text-[#475569]" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon-sm" className="h-7 w-7">
                              <MoreHorizontal size={14} className="text-[#475569]" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => { setDetailVehicle(vehicle); setShowBindCarrier(true); }}>
                              <Link2 size={14} className="mr-2" />绑定载具
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => { setDetailVehicle(vehicle); setShowMaintenance(true); }}>
                              <Wrench size={14} className="mr-2" />新增运维
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => { setEditVehicle(vehicle); setShowForm(true); }}>
                              <Pencil size={14} className="mr-2" />编辑
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-[#EF4444]">
                              <Trash2 size={14} className="mr-2" />停用
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <PaginationBar
          page={currentPage}
          totalPages={totalPages}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={(s) => { setPageSize(s); setPage(1); }}
          total={filtered.length}
        />
      </div>

      {/* Detail Drawer */}
      <VehicleDetailDrawer
        vehicle={detailVehicle}
        open={showDetail}
        onClose={() => setShowDetail(false)}
        onBindCarrier={() => { setShowDetail(false); setShowBindCarrier(true); }}
        onAddMaintenance={() => { setShowDetail(false); setShowMaintenance(true); }}
      />

      {/* Form Drawer */}
      <VehicleFormDrawer
        vehicle={editVehicle}
        open={showForm}
        onClose={() => setShowForm(false)}
      />

      {/* Bind Carrier Dialog */}
      <BindCarrierDialog
        open={showBindCarrier}
        onClose={() => setShowBindCarrier(false)}
        vehicle={detailVehicle}
      />

      {/* Maintenance Dialog */}
      <MaintenanceDialog
        open={showMaintenance}
        onClose={() => setShowMaintenance(false)}
        vehicle={detailVehicle}
      />

      {/* Import Dialog */}
      <ImportDialog open={showImport} onClose={() => setShowImport(false)} />
    </div>
  );
}
