import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Shield,
  Eye,
  EyeOff,
  Edit3,
  Copy,
  Trash2,
  Search,
  Plus,
  ChevronRight,
  Settings,
  History,
  CheckCircle,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

type FieldPerm = 'editable' | 'readonly' | 'hidden';

interface FieldDef {
  name: string;
  code: string;
}

interface Scheme {
  id: string;
  name: string;
  roles: string[];
  modules: string[];
  fieldCount: number;
  status: 'active' | 'inactive';
  moduleFieldCounts: Record<string, number>;
}

interface HistoryRecord {
  id: string;
  schemeName: string;
  action: string;
  operator: string;
  timestamp: string;
  details: string;
}

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */

const MODULE_LIST = [
  { id: 'carriers', name: '载具管理' },
  { id: 'transfers', name: '调拨管理' },
  { id: 'alerts', name: '报警中心' },
  { id: 'sites', name: '网点管理' },
  { id: 'devices', name: '设备管理' },
  { id: 'users', name: '用户管理' },
  { id: 'billing', name: '计费结算' },
  { id: 'projects', name: '项目管理' },
];

const ROLE_LIST = ['超级管理员', '运营经理', '网点管理员', '财务专员', '运维工程师', '普通用户', '项目经理', '调度专员'];

const MODULE_FIELDS: Record<string, FieldDef[]> = {
  carriers: [
    { name: '载具编号', code: 'carrier_code' },
    { name: '载具名称', code: 'carrier_name' },
    { name: '载具类型', code: 'carrier_type' },
    { name: '所属组织', code: 'organization' },
    { name: '当前网点', code: 'current_site' },
    { name: '定位方式', code: 'location_mode' },
    { name: '空满载状态', code: 'load_status' },
    { name: '运维状态', code: 'ops_status' },
    { name: '实时位置', code: 'realtime_pos' },
    { name: '绑定设备', code: 'bound_device' },
    { name: '载具规格', code: 'specification' },
    { name: '载具状态', code: 'carrier_status' },
    { name: '上次维保日期', code: 'last_maintain' },
  ],
  transfers: [
    { name: '调拨单号', code: 'transfer_no' },
    { name: '调拨类型', code: 'transfer_type' },
    { name: '发起网点', code: 'from_site' },
    { name: '目标网点', code: 'to_site' },
    { name: '载具列表', code: 'carrier_list' },
    { name: '调拨状态', code: 'transfer_status' },
    { name: '申请人', code: 'applicant' },
    { name: '审批人', code: 'approver' },
    { name: '申请时间', code: 'apply_time' },
    { name: '完成时间', code: 'finish_time' },
    { name: '调拨原因', code: 'transfer_reason' },
    { name: '物流信息', code: 'logistics_info' },
    { name: '费用明细', code: 'cost_detail' },
    { name: '备注说明', code: 'remarks' },
    { name: '关联订单', code: 'related_order' },
  ],
  alerts: [
    { name: '报警编号', code: 'alert_id' },
    { name: '报警类型', code: 'alert_type' },
    { name: '报警级别', code: 'alert_level' },
    { name: '报警来源', code: 'alert_source' },
    { name: '关联载具', code: 'related_carrier' },
    { name: '报警时间', code: 'alert_time' },
    { name: '处理状态', code: 'handle_status' },
    { name: '处理人', code: 'handler' },
    { name: '处理时间', code: 'handle_time' },
    { name: '处理结果', code: 'handle_result' },
    { name: '报警描述', code: 'alert_desc' },
    { name: '处理备注', code: 'handle_remark' },
  ],
  sites: [
    { name: '网点编号', code: 'site_code' },
    { name: '网点名称', code: 'site_name' },
    { name: '网点类型', code: 'site_type' },
    { name: '所属区域', code: 'region' },
    { name: '详细地址', code: 'address' },
    { name: '负责人', code: 'manager' },
    { name: '联系电话', code: 'contact_phone' },
    { name: '载具容量', code: 'capacity' },
    { name: '当前库存', code: 'current_stock' },
    { name: '运营状态', code: 'ops_status' },
    { name: '经纬度', code: 'coordinates' },
    { name: '创建时间', code: 'create_time' },
    { name: '备注信息', code: 'site_remark' },
  ],
  devices: [
    { name: '设备编号', code: 'device_code' },
    { name: '设备名称', code: 'device_name' },
    { name: '设备类型', code: 'device_type' },
    { name: '所属载具', code: 'bound_carrier' },
    { name: '设备厂商', code: 'manufacturer' },
    { name: '设备型号', code: 'model' },
    { name: '固件版本', code: 'firmware_ver' },
    { name: '在线状态', code: 'online_status' },
    { name: '信号强度', code: 'signal_strength' },
    { name: '电池电量', code: 'battery_level' },
    { name: '安装时间', code: 'install_time' },
    { name: '最近上报', code: 'last_report' },
    { name: '设备序列号', code: 'serial_no' },
  ],
  users: [
    { name: '用户编号', code: 'user_id' },
    { name: '用户名', code: 'username' },
    { name: '真实姓名', code: 'real_name' },
    { name: '所属角色', code: 'role_name' },
    { name: '所属组织', code: 'user_org' },
    { name: '手机号', code: 'mobile' },
    { name: '邮箱地址', code: 'email' },
    { name: '账号状态', code: 'account_status' },
    { name: '最近登录', code: 'last_login' },
    { name: '创建时间', code: 'user_create_time' },
    { name: '权限范围', code: 'permission_scope' },
    { name: '登录IP', code: 'login_ip' },
  ],
  billing: [
    { name: '结算单号', code: 'bill_no' },
    { name: '结算周期', code: 'bill_period' },
    { name: '客户名称', code: 'customer_name' },
    { name: '网点名称', code: 'bill_site_name' },
    { name: '载具数量', code: 'carrier_quantity' },
    { name: '使用天数', code: 'usage_days' },
    { name: '计费单价', code: 'unit_price' },
    { name: '费用合计', code: 'total_amount' },
    { name: '结算状态', code: 'bill_status' },
    { name: '开票状态', code: 'invoice_status' },
    { name: '结算模板', code: 'bill_template' },
    { name: '审核人', code: 'bill_auditor' },
    { name: '生成时间', code: 'generate_time' },
  ],
  projects: [
    { name: '项目编号', code: 'project_code' },
    { name: '项目名称', code: 'project_name' },
    { name: '项目类型', code: 'project_type' },
    { name: '客户名称', code: 'project_customer' },
    { name: '项目经理', code: 'project_manager' },
    { name: '项目状态', code: 'project_status' },
    { name: '开始日期', code: 'start_date' },
    { name: '结束日期', code: 'end_date' },
    { name: '载具规模', code: 'carrier_scale' },
    { name: '关联网点', code: 'related_sites' },
    { name: '合同金额', code: 'contract_amount' },
    { name: '结算方式', code: 'settlement_method' },
    { name: '创建时间', code: 'project_create_time' },
    { name: '项目备注', code: 'project_remark' },
    { name: '审批流程', code: 'approval_process' },
  ],
};

const INITIAL_SCHEMES: Scheme[] = [
  {
    id: 'scheme-001',
    name: '管理员完整权限',
    roles: ['超级管理员'],
    modules: ['carriers', 'transfers', 'alerts', 'sites', 'devices', 'users', 'billing', 'projects'],
    fieldCount: 104,
    status: 'active',
    moduleFieldCounts: { carriers: 13, transfers: 15, alerts: 12, sites: 13, devices: 13, users: 12, billing: 13, projects: 15 },
  },
  {
    id: 'scheme-002',
    name: '运营经理权限',
    roles: ['运营经理', '调度专员'],
    modules: ['carriers', 'transfers', 'alerts', 'sites'],
    fieldCount: 53,
    status: 'active',
    moduleFieldCounts: { carriers: 13, transfers: 15, alerts: 12, sites: 13 },
  },
  {
    id: 'scheme-003',
    name: '财务结算权限',
    roles: ['财务专员'],
    modules: ['billing', 'projects', 'transfers'],
    fieldCount: 43,
    status: 'active',
    moduleFieldCounts: { billing: 13, projects: 15, transfers: 15 },
  },
  {
    id: 'scheme-004',
    name: '网点管理权限',
    roles: ['网点管理员'],
    modules: ['sites', 'carriers', 'alerts', 'devices'],
    fieldCount: 51,
    status: 'active',
    moduleFieldCounts: { sites: 13, carriers: 13, alerts: 12, devices: 13 },
  },
  {
    id: 'scheme-005',
    name: '运维工程师权限',
    roles: ['运维工程师'],
    modules: ['devices', 'carriers', 'alerts'],
    fieldCount: 38,
    status: 'active',
    moduleFieldCounts: { devices: 13, carriers: 13, alerts: 12 },
  },
  {
    id: 'scheme-006',
    name: '普通查看权限',
    roles: ['普通用户'],
    modules: ['carriers', 'sites', 'projects'],
    fieldCount: 41,
    status: 'inactive',
    moduleFieldCounts: { carriers: 13, sites: 13, projects: 15 },
  },
  {
    id: 'scheme-007',
    name: '项目经理权限',
    roles: ['项目经理'],
    modules: ['projects', 'carriers', 'transfers', 'billing'],
    fieldCount: 56,
    status: 'active',
    moduleFieldCounts: { projects: 15, carriers: 13, transfers: 15, billing: 13 },
  },
  {
    id: 'scheme-008',
    name: '报警监控权限',
    roles: ['运维工程师', '运营经理'],
    modules: ['alerts', 'devices', 'carriers'],
    fieldCount: 38,
    status: 'inactive',
    moduleFieldCounts: { alerts: 12, devices: 13, carriers: 13 },
  },
];

const INITIAL_HISTORY: HistoryRecord[] = [
  { id: 'h1', schemeName: '管理员完整权限', action: '创建方案', operator: '系统管理员', timestamp: '2024-01-15 09:30:00', details: '初始创建，包含全部模块字段权限' },
  { id: 'h2', schemeName: '运营经理权限', action: '修改字段权限', operator: '系统管理员', timestamp: '2024-02-20 14:22:10', details: '将"费用明细"字段从"可见且可编辑"调整为"仅可见"' },
  { id: 'h3', schemeName: '财务结算权限', action: '创建方案', operator: '系统管理员', timestamp: '2024-03-05 11:15:33', details: '新建财务专用权限方案' },
  { id: 'h4', schemeName: '网点管理权限', action: '启用方案', operator: '系统管理员', timestamp: '2024-03-18 08:45:52', details: '方案状态从"停用"切换为"启用"' },
  { id: 'h5', schemeName: '运维工程师权限', action: '修改字段权限', operator: '运营经理', timestamp: '2024-04-02 16:08:07', details: '增加报警中心模块的"处理备注"字段可见权限' },
  { id: 'h6', schemeName: '普通查看权限', action: '停用方案', operator: '系统管理员', timestamp: '2024-04-22 10:30:45', details: '因业务调整暂停使用该权限方案' },
  { id: 'h7', schemeName: '项目经理权限', action: '创建方案', operator: '系统管理员', timestamp: '2024-05-10 13:25:18', details: '新建项目经理专用权限方案，覆盖项目与计费模块' },
  { id: 'h8', schemeName: '报警监控权限', action: '修改角色范围', operator: '系统管理员', timestamp: '2024-05-28 09:12:40', details: '移除"普通用户"角色，仅保留运维与运营角色' },
  { id: 'h9', schemeName: '管理员完整权限', action: '批量调整权限', operator: '系统管理员', timestamp: '2024-06-15 15:45:22', details: '将用户管理模块的"登录IP"字段设为隐藏' },
  { id: 'h10', schemeName: '运营经理权限', action: '回滚操作', operator: '系统管理员', timestamp: '2024-06-20 11:05:33', details: '回滚至2024-02-18的版本，恢复"费用明细"字段编辑权限' },
];

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function permLabel(p: FieldPerm): string {
  switch (p) {
    case 'editable':
      return '可见且可编辑';
    case 'readonly':
      return '仅可见';
    case 'hidden':
      return '隐藏';
    default:
      return '';
  }
}

function permBadge(p: FieldPerm) {
  switch (p) {
    case 'editable':
      return <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100">可见且可编辑</Badge>;
    case 'readonly':
      return <Badge className="bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100">仅可见</Badge>;
    case 'hidden':
      return <Badge className="bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200">隐藏</Badge>;
    default:
      return null;
  }
}

/* ------------------------------------------------------------------ */
/*  Main Component                                                     */
/* ------------------------------------------------------------------ */

export default function FieldPermissionPage() {
  /* ---- local state ---- */
  const [schemes, setSchemes] = useState<Scheme[]>(INITIAL_SCHEMES);
  const [historyRecords, setHistoryRecords] = useState<HistoryRecord[]>(INITIAL_HISTORY);
  const [activeTab, setActiveTab] = useState('schemes');

  /* scheme list */
  const [schemeSearch, setSchemeSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingScheme, setEditingScheme] = useState<Scheme | null>(null);
  const [formName, setFormName] = useState('');
  const [formRoles, setFormRoles] = useState<string[]>([]);
  const [formModules, setFormModules] = useState<string[]>([]);
  const [formStatus, setFormStatus] = useState<'active' | 'inactive'>('active');

  /* matrix */
  const [matrixModule, setMatrixModule] = useState<string>('carriers');
  const [matrixPerms, setMatrixPerms] = useState<Record<string, FieldPerm>>(() => {
    const init: Record<string, FieldPerm> = {};
    Object.entries(MODULE_FIELDS).forEach(([modId, fields]) => {
      fields.forEach((f) => {
        init[`${modId}.${f.code}`] = modId === 'billing' || modId === 'alerts' ? 'readonly' : 'editable';
      });
    });
    return init;
  });

  /* preview */
  const [previewRole, setPreviewRole] = useState<string>('超级管理员');

  /* ---- derived ---- */
  const filteredSchemes = useMemo(() => {
    if (!schemeSearch.trim()) return schemes;
    return schemes.filter((s) => s.name.includes(schemeSearch) || s.roles.some((r) => r.includes(schemeSearch)));
  }, [schemes, schemeSearch]);

  const activeSchemes = useMemo(() => schemes.filter((s) => s.status === 'active'), [schemes]);

  const totalFieldCount = useMemo(() => {
    return schemes.reduce((sum, s) => sum + s.fieldCount, 0);
  }, [schemes]);

  const coveredRoles = useMemo(() => {
    const set = new Set<string>();
    schemes.forEach((s) => s.roles.forEach((r) => set.add(r)));
    return set.size;
  }, [schemes]);

  const chartData = useMemo(() => {
    return MODULE_LIST.map((mod) => {
      const editable = MODULE_FIELDS[mod.id].filter((f) => matrixPerms[`${mod.id}.${f.code}`] === 'editable').length;
      const readonly = MODULE_FIELDS[mod.id].filter((f) => matrixPerms[`${mod.id}.${f.code}`] === 'readonly').length;
      const hidden = MODULE_FIELDS[mod.id].filter((f) => matrixPerms[`${mod.id}.${f.code}`] === 'hidden').length;
      return {
        name: mod.name,
        可见且可编辑: editable,
        仅可见: readonly,
        隐藏: hidden,
      };
    });
  }, [matrixPerms]);

  /* ---- actions ---- */
  function openNewScheme() {
    setEditingScheme(null);
    setFormName('');
    setFormRoles([]);
    setFormModules([]);
    setFormStatus('active');
    setDialogOpen(true);
  }

  function openEditScheme(scheme: Scheme) {
    setEditingScheme(scheme);
    setFormName(scheme.name);
    setFormRoles([...scheme.roles]);
    setFormModules([...scheme.modules]);
    setFormStatus(scheme.status);
    setDialogOpen(true);
  }

  function saveScheme() {
    if (!formName.trim() || formRoles.length === 0 || formModules.length === 0) return;
    if (editingScheme) {
      setSchemes((prev) =>
        prev.map((s) =>
          s.id === editingScheme.id
            ? {
                ...s,
                name: formName,
                roles: formRoles,
                modules: formModules,
                status: formStatus,
                fieldCount: formModules.reduce((sum, m) => sum + (MODULE_FIELDS[m]?.length || 0), 0),
              }
            : s,
        ),
      );
      addHistory(editingScheme.name, '修改方案', `更新了方案配置：${formName}`);
    } else {
      const newScheme: Scheme = {
        id: `scheme-${Date.now()}`,
        name: formName,
        roles: formRoles,
        modules: formModules,
        fieldCount: formModules.reduce((sum, m) => sum + (MODULE_FIELDS[m]?.length || 0), 0),
        status: formStatus,
        moduleFieldCounts: Object.fromEntries(formModules.map((m) => [m, MODULE_FIELDS[m]?.length || 0])),
      };
      setSchemes((prev) => [...prev, newScheme]);
      addHistory(newScheme.name, '创建方案', `新建权限方案：${formName}`);
    }
    setDialogOpen(false);
  }

  function copyScheme(scheme: Scheme) {
    const copied: Scheme = {
      ...scheme,
      id: `scheme-${Date.now()}`,
      name: `${scheme.name}（复制）`,
      status: 'inactive' as const,
    };
    setSchemes((prev) => [...prev, copied]);
    addHistory(copied.name, '复制方案', `复制自方案：${scheme.name}`);
  }

  function deleteScheme(id: string) {
    const scheme = schemes.find((s) => s.id === id);
    if (scheme) {
      setSchemes((prev) => prev.filter((s) => s.id !== id));
      addHistory(scheme.name, '删除方案', `删除权限方案：${scheme.name}`);
    }
  }

  function addHistory(schemeName: string, action: string, details: string) {
    const record: HistoryRecord = {
      id: `h-${Date.now()}`,
      schemeName,
      action,
      operator: '当前用户',
      timestamp: new Date().toLocaleString('zh-CN', { hour12: false }).replace(/\//g, '-'),
      details,
    };
    setHistoryRecords((prev) => [record, ...prev]);
  }

  function toggleMatrixPerm(moduleId: string, fieldCode: string, target: FieldPerm) {
    setMatrixPerms((prev) => ({ ...prev, [`${moduleId}.${fieldCode}`]: target }));
  }

  function batchSetPerm(moduleId: string, target: FieldPerm) {
    const updates: Record<string, FieldPerm> = {};
    MODULE_FIELDS[moduleId]?.forEach((f) => {
      updates[`${moduleId}.${f.code}`] = target;
    });
    setMatrixPerms((prev) => ({ ...prev, ...updates }));
    addHistory('字段权限矩阵', '批量设置', `将${MODULE_LIST.find((m) => m.id === moduleId)?.name || moduleId}全部字段设为"${permLabel(target)}"`);
  }

  function rollbackHistory(record: HistoryRecord) {
    addHistory(record.schemeName, '回滚操作', `回滚操作记录：${record.action} - ${record.details}`);
  }

  /* ---- render helpers ---- */
  const roleOptionsForPreview = ROLE_LIST;

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" style={{ color: 'var(--color-text-primary)' }}>
            字段权限管理
          </h1>
          <p className="text-sm mt-1" style={{ color: 'var(--color-text-secondary)' }}>
            管理平台各模块字段的可见性与编辑权限，支持按角色精细化控制数据访问范围
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
          <span className="text-sm font-medium" style={{ color: 'var(--color-text-secondary)' }}>
            共 {schemes.length} 个权限方案
          </span>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5 lg:w-[640px]">
          <TabsTrigger value="schemes" className="flex items-center gap-1.5">
            <Settings className="h-4 w-4" />
            权限方案
          </TabsTrigger>
          <TabsTrigger value="matrix" className="flex items-center gap-1.5">
            <Eye className="h-4 w-4" />
            字段权限矩阵
          </TabsTrigger>
          <TabsTrigger value="preview" className="flex items-center gap-1.5">
            <Search className="h-4 w-4" />
            权限预览
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-1.5">
            <History className="h-4 w-4" />
            生效记录
          </TabsTrigger>
          <TabsTrigger value="stats" className="flex items-center gap-1.5">
            <CheckCircle className="h-4 w-4" />
            数据统计
          </TabsTrigger>
        </TabsList>

        {/* ==================== 权限方案 ==================== */}
        <TabsContent value="schemes" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Settings className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
                  <CardTitle>权限方案列表</CardTitle>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="搜索方案名称或角色..."
                      className="pl-9 w-[260px]"
                      value={schemeSearch}
                      onChange={(e) => setSchemeSearch(e.target.value)}
                    />
                  </div>
                  <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                    <DialogTrigger asChild>
                      <Button onClick={openNewScheme} className="gap-1.5">
                        <Plus className="h-4 w-4" />
                        新增方案
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>{editingScheme ? '编辑权限方案' : '新增权限方案'}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 py-2">
                        <div className="space-y-2">
                          <Label>方案名称</Label>
                          <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="请输入方案名称" />
                        </div>
                        <div className="space-y-2">
                          <Label>适用角色</Label>
                          <div className="flex flex-wrap gap-2 border rounded-md p-3">
                            {ROLE_LIST.map((role) => (
                              <div key={role} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`role-${role}`}
                                  checked={formRoles.includes(role)}
                                  onCheckedChange={(checked) => {
                                    setFormRoles((prev) => (checked ? [...prev, role] : prev.filter((r) => r !== role)));
                                  }}
                                />
                                <label htmlFor={`role-${role}`} className="text-sm cursor-pointer">
                                  {role}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>适用模块</Label>
                          <div className="flex flex-wrap gap-2 border rounded-md p-3">
                            {MODULE_LIST.map((mod) => (
                              <div key={mod.id} className="flex items-center space-x-2">
                                <Checkbox
                                  id={`mod-${mod.id}`}
                                  checked={formModules.includes(mod.id)}
                                  onCheckedChange={(checked) => {
                                    setFormModules((prev) => (checked ? [...prev, mod.id] : prev.filter((m) => m !== mod.id)));
                                  }}
                                />
                                <label htmlFor={`mod-${mod.id}`} className="text-sm cursor-pointer">
                                  {mod.name}
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id="scheme-status"
                            checked={formStatus === 'active'}
                            onCheckedChange={(checked) => setFormStatus(checked ? 'active' : 'inactive')}
                          />
                          <Label htmlFor="scheme-status" className="cursor-pointer">
                            {formStatus === 'active' ? '启用' : '停用'}
                          </Label>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setDialogOpen(false)}>
                          取消
                        </Button>
                        <Button onClick={saveScheme}>保存</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>方案名称</TableHead>
                    <TableHead>适用角色</TableHead>
                    <TableHead>适用模块</TableHead>
                    <TableHead>字段数量</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSchemes.map((scheme) => (
                    <TableRow key={scheme.id}>
                      <TableCell className="font-medium">{scheme.name}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {scheme.roles.map((r) => (
                            <Badge key={r} variant="outline" className="text-xs">
                              {r}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {scheme.modules.map((m) => (
                            <Badge key={m} variant="secondary" className="text-xs">
                              {MODULE_LIST.find((mod) => mod.id === m)?.name || m}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{scheme.fieldCount}</TableCell>
                      <TableCell>
                        {scheme.status === 'active' ? (
                          <Badge className="bg-emerald-50 text-emerald-700 border-emerald-200">启用</Badge>
                        ) : (
                          <Badge className="bg-slate-100 text-slate-500 border-slate-200">停用</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => openEditScheme(scheme)} title="编辑">
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => copyScheme(scheme)} title="复制">
                            <Copy className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => deleteScheme(scheme.id)} title="删除">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                  {filteredSchemes.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                        暂无匹配的权限方案
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== 字段权限矩阵 ==================== */}
        <TabsContent value="matrix" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <Eye className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
                  <CardTitle>字段权限矩阵</CardTitle>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground">选择模块：</span>
                  <Select value={matrixModule} onValueChange={setMatrixModule}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MODULE_LIST.map((mod) => (
                        <SelectItem key={mod.id} value={mod.id}>
                          {mod.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <CardDescription>
                设置「{MODULE_LIST.find((m) => m.id === matrixModule)?.name}」模块各字段的权限级别，支持批量操作
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Batch buttons */}
              <div className="flex items-center gap-2 mb-4 flex-wrap">
                <span className="text-sm font-medium">批量设置：</span>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => batchSetPerm(matrixModule, 'editable')}>
                  <Eye className="h-3.5 w-3.5" />
                  全部可见且可编辑
                </Button>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => batchSetPerm(matrixModule, 'readonly')}>
                  <EyeOff className="h-3.5 w-3.5" />
                  全部仅可见
                </Button>
                <Button variant="outline" size="sm" className="gap-1" onClick={() => batchSetPerm(matrixModule, 'hidden')}>
                  <Trash2 className="h-3.5 w-3.5" />
                  全部隐藏
                </Button>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead className="w-[50px] text-center">序号</TableHead>
                      <TableHead>字段名称</TableHead>
                      <TableHead>字段标识</TableHead>
                      <TableHead className="text-center">可见且可编辑</TableHead>
                      <TableHead className="text-center">仅可见</TableHead>
                      <TableHead className="text-center">隐藏</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {MODULE_FIELDS[matrixModule]?.map((field, idx) => {
                      const key = `${matrixModule}.${field.code}`;
                      const current = matrixPerms[key] || 'editable';
                      return (
                        <TableRow key={field.code} className="hover:bg-muted/30 transition-colors">
                          <TableCell className="text-center text-muted-foreground">{idx + 1}</TableCell>
                          <TableCell className="font-medium">{field.name}</TableCell>
                          <TableCell>
                            <code className="bg-muted px-1.5 py-0.5 rounded text-xs">{field.code}</code>
                          </TableCell>
                          <TableCell className="text-center">
                            <Checkbox
                              checked={current === 'editable'}
                              onCheckedChange={() => toggleMatrixPerm(matrixModule, field.code, 'editable')}
                            />
                          </TableCell>
                          <TableCell className="text-center">
                            <Checkbox
                              checked={current === 'readonly'}
                              onCheckedChange={() => toggleMatrixPerm(matrixModule, field.code, 'readonly')}
                            />
                          </TableCell>
                          <TableCell className="text-center">
                            <Checkbox
                              checked={current === 'hidden'}
                              onCheckedChange={() => toggleMatrixPerm(matrixModule, field.code, 'hidden')}
                            />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== 权限预览 ==================== */}
        <TabsContent value="preview" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <Search className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
                  <CardTitle>权限预览</CardTitle>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm text-muted-foreground">选择角色：</span>
                  <Select value={previewRole} onValueChange={setPreviewRole}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {roleOptionsForPreview.map((role) => (
                        <SelectItem key={role} value={role}>
                          {role}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <CardDescription>模拟「{previewRole}」角色在各模块中能看到的字段及权限级别</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {MODULE_LIST.map((mod) => {
                const matchedScheme = schemes.find((s) => s.status === 'active' && s.roles.includes(previewRole) && s.modules.includes(mod.id));
                if (!matchedScheme) return null;
                return (
                  <div key={mod.id} className="rounded-lg border overflow-hidden">
                    <div className="bg-muted/50 px-4 py-2.5 flex items-center justify-between">
                      <div className="flex items-center gap-2 font-medium text-sm">
                        <ChevronRight className="h-4 w-4" style={{ color: 'var(--color-primary)' }} />
                        {mod.name}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {MODULE_FIELDS[mod.id]?.length || 0} 个字段
                      </Badge>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                        {MODULE_FIELDS[mod.id]?.map((field) => {
                          const perm = matrixPerms[`${mod.id}.${field.code}`] || 'editable';
                          return (
                            <div key={field.code} className="flex items-center justify-between rounded-md border px-3 py-2 bg-background">
                              <span className="text-sm">{field.name}</span>
                              {permBadge(perm)}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Show message if no modules visible */}
              {(() => {
                const visibleModules = MODULE_LIST.filter((mod) =>
                  schemes.some((s) => s.status === 'active' && s.roles.includes(previewRole) && s.modules.includes(mod.id)),
                );
                if (visibleModules.length === 0) {
                  return (
                    <div className="text-center py-12 text-muted-foreground border rounded-lg">
                      <EyeOff className="h-10 w-10 mx-auto mb-3 opacity-40" />
                      <p>「{previewRole}」当前没有任何可见模块权限</p>
                    </div>
                  );
                }
                return null;
              })()}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== 权限生效记录 ==================== */}
        <TabsContent value="history" className="space-y-4 mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
                <CardTitle>权限变更历史</CardTitle>
              </div>
              <CardDescription>记录所有权限方案的新增、修改、删除及批量调整操作，支持一键回滚</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>时间</TableHead>
                    <TableHead>方案名称</TableHead>
                    <TableHead>操作类型</TableHead>
                    <TableHead>操作人</TableHead>
                    <TableHead>变更详情</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historyRecords.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell className="text-muted-foreground whitespace-nowrap">{record.timestamp}</TableCell>
                      <TableCell className="font-medium">{record.schemeName}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            record.action.includes('创建')
                              ? 'border-emerald-200 text-emerald-700 bg-emerald-50'
                              : record.action.includes('删除') || record.action.includes('停用')
                                ? 'border-red-200 text-red-700 bg-red-50'
                                : record.action.includes('回滚')
                                  ? 'border-amber-200 text-amber-700 bg-amber-50'
                                  : 'border-blue-200 text-blue-700 bg-blue-50'
                          }
                        >
                          {record.action}
                        </Badge>
                      </TableCell>
                      <TableCell>{record.operator}</TableCell>
                      <TableCell className="max-w-[300px] truncate" title={record.details}>
                        {record.details}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="h-8 gap-1" onClick={() => rollbackHistory(record)}>
                          <RotateIcon className="h-3.5 w-3.5" />
                          回滚
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {historyRecords.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                        暂无变更记录
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ==================== 数据统计 ==================== */}
        <TabsContent value="stats" className="space-y-4 mt-4">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              icon={<Shield className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />}
              label="方案总数"
              value={schemes.length.toString()}
              desc="已配置权限方案"
            />
            <StatCard
              icon={<CheckCircle className="h-5 w-5 text-emerald-500" />}
              label="启用方案数"
              value={activeSchemes.length.toString()}
              desc="当前生效中"
            />
            <StatCard
              icon={<Eye className="h-5 w-5 text-blue-500" />}
              label="覆盖字段数"
              value={totalFieldCount.toString()}
              desc="跨全部模块"
            />
            <StatCard
              icon={<Settings className="h-5 w-5 text-amber-500" />}
              label="覆盖角色数"
              value={coveredRoles.toString()}
              desc="已分配权限角色"
            />
          </div>

          {/* Chart */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <BarChartIcon className="h-5 w-5" style={{ color: 'var(--color-primary)' }} />
                <CardTitle>各模块字段权限分布</CardTitle>
              </div>
              <CardDescription>展示每个模块下字段的权限级别分布情况（可见且可编辑 / 仅可见 / 隐藏）</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="w-full h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border-secondary)" />
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        borderRadius: 8,
                        border: '1px solid var(--color-border-secondary)',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                      }}
                    />
                    <Legend />
                    <Bar dataKey="可见且可编辑" fill="#10b981" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="仅可见" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="隐藏" fill="#94a3b8" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Sub Components                                                     */
/* ------------------------------------------------------------------ */

function StatCard({
  icon,
  label,
  value,
  desc,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  desc: string;
}) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">{label}</p>
            <p className="text-3xl font-bold tracking-tight">{value}</p>
            <p className="text-xs text-muted-foreground">{desc}</p>
          </div>
          <div className="p-2.5 rounded-lg bg-muted">{icon}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function RotateIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  );
}

function BarChartIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M12 20V10" />
      <path d="M18 20V4" />
      <path d="M6 20v-4" />
    </svg>
  );
}
