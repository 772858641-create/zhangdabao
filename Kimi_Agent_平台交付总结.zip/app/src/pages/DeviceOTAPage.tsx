import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Card, CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';

import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from '@/components/ui/tabs';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Upload, RotateCcw, CheckCircle, Clock,
  Search, Plus, HardDrive, Zap, ArrowUp, Eye,
  AlertTriangle,
} from 'lucide-react';
import { cn } from '@/lib/utils';

// ==================== Types ====================
interface Firmware {
  id: string;
  version: string;
  name: string;
  deviceType: string;
  size: string;
  releaseDate: string;
  status: 'released' | 'testing' | 'deprecated';
  changelog: string;
}

interface UpgradeTask {
  id: string;
  taskName: string;
  firmwareVersion: string;
  deviceType: string;
  scope: 'all' | 'batch' | 'specific';
  scopeCount: number;
  startTime: string;
  status: 'pending' | 'running' | 'completed' | 'paused';
  successCount: number;
  failCount: number;
  progress: number;
  strategy: 'immediate' | 'schedule' | 'incremental';
}

interface DeviceUpgrade {
  id: string;
  deviceId: string;
  deviceName: string;
  currentVersion: string;
  targetVersion: string;
  status: 'waiting' | 'downloading' | 'upgrading' | 'success' | 'failed' | 'rolled_back';
  progress: number;
  startTime?: string;
  completeTime?: string;
  failReason?: string;
}

// ==================== Mock Data ====================
const firmwares: Firmware[] = [
  { id: 'F001', version: 'v2.3.1', name: '定位器固件-春季版', deviceType: '定位器', size: '4.2MB', releaseDate: '2025-04-15', status: 'released', changelog: '优化GPS定位精度；降低功耗15%；修复蓝牙连接稳定性问题' },
  { id: 'F002', version: 'v2.2.5', name: '定位器固件-稳定版', deviceType: '定位器', size: '4.1MB', releaseDate: '2025-03-20', status: 'released', changelog: '修复低温环境下信号丢失问题；增强数据加密' },
  { id: 'F003', version: 'v1.8.3', name: '网关固件-增强版', deviceType: '固定网关', size: '8.5MB', releaseDate: '2025-04-10', status: 'released', changelog: '支持更多蓝牙信标同时扫描；提升数据处理吞吐量' },
  { id: 'F004', version: 'v1.8.0', name: '网关固件-稳定版', deviceType: '固定网关', size: '8.3MB', releaseDate: '2025-02-28', status: 'deprecated', changelog: '基础版本' },
  { id: 'F005', version: 'v3.1.0', name: '车载网关固件-新版', deviceType: '车载网关', size: '12.1MB', releaseDate: '2025-04-20', status: 'testing', changelog: '新增车辆运动状态检测；支持OTA断点续传；优化高温环境性能' },
  { id: 'F006', version: 'v3.0.2', name: '车载网关固件-稳定版', deviceType: '车载网关', size: '11.8MB', releaseDate: '2025-03-15', status: 'released', changelog: '修复CAN总线通信偶发中断问题' },
  { id: 'F007', version: 'v1.2.1', name: '蓝牙标签固件', deviceType: '标签', size: '1.8MB', releaseDate: '2025-04-05', status: 'released', changelog: '延长广播间隔可调范围；优化电池寿命预估算法' },
  { id: 'F008', version: 'v1.1.5', name: '信标固件', deviceType: '信标', size: '2.1MB', releaseDate: '2025-03-25', status: 'released', changelog: '增强信号覆盖范围；支持远程功率调节' },
];

const upgradeTasks: UpgradeTask[] = [
  { id: 'T001', taskName: '定位器全量升级-v2.3.1', firmwareVersion: 'v2.3.1', deviceType: '定位器', scope: 'all', scopeCount: 580, startTime: '2025-04-20 02:00', status: 'completed', successCount: 572, failCount: 8, progress: 100, strategy: 'schedule' },
  { id: 'T002', taskName: '网关灰度升级-v1.8.3', firmwareVersion: 'v1.8.3', deviceType: '固定网关', scope: 'batch', scopeCount: 50, startTime: '2025-04-22 01:00', status: 'running', successCount: 42, failCount: 3, progress: 90, strategy: 'incremental' },
  { id: 'T003', taskName: '车载网关新版测试', firmwareVersion: 'v3.1.0', deviceType: '车载网关', scope: 'batch', scopeCount: 20, startTime: '2025-04-25 03:00', status: 'running', successCount: 12, failCount: 1, progress: 65, strategy: 'incremental' },
  { id: 'T004', taskName: '标签固件升级-v1.2.1', firmwareVersion: 'v1.2.1', deviceType: '标签', scope: 'all', scopeCount: 1200, startTime: '2025-04-28 02:00', status: 'pending', successCount: 0, failCount: 0, progress: 0, strategy: 'schedule' },
  { id: 'T005', taskName: '信标固件升级-v1.1.5', firmwareVersion: 'v1.1.5', deviceType: '信标', scope: 'all', scopeCount: 350, startTime: '2025-04-18 02:00', status: 'completed', successCount: 348, failCount: 2, progress: 100, strategy: 'immediate' },
];

const deviceUpgrades: DeviceUpgrade[] = [
  { id: 'D001', deviceId: 'DEV-20250401-001', deviceName: '定位器-A001', currentVersion: 'v2.2.5', targetVersion: 'v2.3.1', status: 'success', progress: 100, startTime: '2025-04-20 02:05', completeTime: '2025-04-20 02:12' },
  { id: 'D002', deviceId: 'DEV-20250401-015', deviceName: '定位器-A015', currentVersion: 'v2.2.5', targetVersion: 'v2.3.1', status: 'success', progress: 100, startTime: '2025-04-20 02:15', completeTime: '2025-04-20 02:22' },
  { id: 'D003', deviceId: 'DEV-20250402-032', deviceName: '固定网关-B032', currentVersion: 'v1.8.0', targetVersion: 'v1.8.3', status: 'upgrading', progress: 72, startTime: '2025-04-22 01:30' },
  { id: 'D004', deviceId: 'DEV-20250403-008', deviceName: '车载网关-C008', currentVersion: 'v3.0.2', targetVersion: 'v3.1.0', status: 'downloading', progress: 35, startTime: '2025-04-25 03:15' },
  { id: 'D005', deviceId: 'DEV-20250404-021', deviceName: '标签-D021', currentVersion: 'v1.1.8', targetVersion: 'v1.2.1', status: 'waiting', progress: 0 },
  { id: 'D006', deviceId: 'DEV-20250405-009', deviceName: '信标-E009', currentVersion: 'v1.1.3', targetVersion: 'v1.1.5', status: 'success', progress: 100, startTime: '2025-04-18 02:10', completeTime: '2025-04-18 02:18' },
  { id: 'D007', deviceId: 'DEV-20250406-044', deviceName: '定位器-A044', currentVersion: 'v2.2.5', targetVersion: 'v2.3.1', status: 'failed', progress: 45, startTime: '2025-04-20 02:45', failReason: '存储空间不足，升级包写入失败' },
  { id: 'D008', deviceId: 'DEV-20250407-011', deviceName: '固定网关-B011', currentVersion: 'v1.8.0', targetVersion: 'v1.8.3', status: 'rolled_back', progress: 100, startTime: '2025-04-22 01:45', completeTime: '2025-04-22 02:30', failReason: '升级后通信模块异常，自动回滚至v1.8.0' },
  { id: 'D009', deviceId: 'DEV-20250408-029', deviceName: '车载网关-C029', currentVersion: 'v3.0.2', targetVersion: 'v3.1.0', status: 'upgrading', progress: 88, startTime: '2025-04-25 03:30' },
  { id: 'D010', deviceId: 'DEV-20250410-055', deviceName: '定位器-A055', currentVersion: 'v2.2.5', targetVersion: 'v2.3.1', status: 'success', progress: 100, startTime: '2025-04-20 03:00', completeTime: '2025-04-20 03:08' },
  { id: 'D011', deviceId: 'DEV-20250411-003', deviceName: '标签-D003', currentVersion: 'v1.1.8', targetVersion: 'v1.2.1', status: 'waiting', progress: 0 },
  { id: 'D012', deviceId: 'DEV-20250412-067', deviceName: '固定网关-B067', currentVersion: 'v1.8.0', targetVersion: 'v1.8.3', status: 'success', progress: 100, startTime: '2025-04-22 02:00', completeTime: '2025-04-22 02:12' },
];

// ==================== Helpers ====================
function getFwStatusBadge(status: string) {
  switch (status) {
    case 'released': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已发布</Badge>;
    case 'testing': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">测试中</Badge>;
    case 'deprecated': return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">已废弃</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

function getTaskStatusBadge(status: string) {
  switch (status) {
    case 'pending': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">待执行</Badge>;
    case 'running': return <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100">执行中</Badge>;
    case 'completed': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">已完成</Badge>;
    case 'paused': return <Badge className="bg-gray-100 text-gray-700 hover:bg-gray-100">已暂停</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

function getUpgradeStatusBadge(status: string) {
  switch (status) {
    case 'waiting': return <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">等待中</Badge>;
    case 'downloading': return <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">下载中</Badge>;
    case 'upgrading': return <Badge className="bg-purple-100 text-purple-700 hover:bg-purple-100">升级中</Badge>;
    case 'success': return <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">成功</Badge>;
    case 'failed': return <Badge className="bg-red-100 text-red-700 hover:bg-red-100">失败</Badge>;
    case 'rolled_back': return <Badge className="bg-orange-100 text-orange-700 hover:bg-orange-100">已回滚</Badge>;
    default: return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function DeviceOTAPage() {
  const [activeTab, setActiveTab] = useState('firmware');
  const [search, setSearch] = useState('');
  const [fwData] = useState(firmwares);
  const [taskData] = useState(upgradeTasks);
  const [upgradeData] = useState(deviceUpgrades);
  const [changelogOpen, setChangelogOpen] = useState(false);
  const [rollbackOpen, setRollbackOpen] = useState(false);
  const [selectedFw, setSelectedFw] = useState<Firmware | null>(null);
  const [selectedUpgrade, setSelectedUpgrade] = useState<DeviceUpgrade | null>(null);

  const filteredFw = useMemo(() => {
    return fwData.filter(f => f.name.toLowerCase().includes(search.toLowerCase()) || f.version.includes(search));
  }, [fwData, search]);

  const stats = useMemo(() => ({
    totalFw: fwData.length,
    released: fwData.filter(f => f.status === 'released').length,
    running: taskData.filter(t => t.status === 'running').length,
    success: upgradeData.filter(u => u.status === 'success').length,
    fail: upgradeData.filter(u => u.status === 'failed' || u.status === 'rolled_back').length,
  }), [fwData, taskData, upgradeData]);

  const openChangelog = (fw: Firmware) => { setSelectedFw(fw); setChangelogOpen(true); };
  const openRollback = (u: DeviceUpgrade) => { setSelectedUpgrade(u); setRollbackOpen(true); };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--neutral-text-primary)]">设备OTA升级</h1>
          <p className="text-sm text-[var(--neutral-text-secondary)] mt-1">固件管理 · 升级任务 · 设备状态 · 差分升级 · 断电保护</p>
        </div>
        <Button size="sm" onClick={() => alert('上传固件功能暂未开放')}>
          <Upload className="w-4 h-4 mr-1" />上传固件
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '固件版本', value: stats.totalFw, icon: HardDrive, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: '已发布', value: stats.released, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '升级中', value: stats.running, icon: Zap, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: '升级成功', value: stats.success, icon: ArrowUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: '升级失败', value: stats.fail, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className={cn('w-10 h-10 rounded-full flex items-center justify-center', s.bg)}>
                  <s.icon className={cn('w-5 h-5', s.color)} />
                </div>
                <div>
                  <div className="text-sm text-[var(--neutral-text-secondary)]">{s.label}</div>
                  <div className="text-xl font-bold text-[var(--neutral-text-primary)]">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 lg:w-[360px]">
          <TabsTrigger value="firmware">固件版本</TabsTrigger>
          <TabsTrigger value="tasks">升级任务</TabsTrigger>
          <TabsTrigger value="devices">设备状态</TabsTrigger>
        </TabsList>

        {/* Tab 1: Firmware */}
        <TabsContent value="firmware" className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--neutral-text-tertiary)]" />
              <Input placeholder="搜索固件名称或版本..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {filteredFw.map(fw => (
              <motion.div key={fw.id} initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}>
                <Card className="h-full">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{fw.deviceType}</Badge>
                      {getFwStatusBadge(fw.status)}
                    </div>
                    <div className="text-lg font-bold text-[var(--neutral-text-primary)]">{fw.version}</div>
                    <div className="text-sm text-[var(--neutral-text-secondary)]">{fw.name}</div>
                    <div className="flex items-center gap-3 text-xs text-[var(--neutral-text-tertiary)]">
                      <span className="flex items-center gap-1"><HardDrive className="w-3 h-3" /> {fw.size}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {fw.releaseDate}</span>
                    </div>
                    <Button variant="outline" size="sm" className="w-full" onClick={() => openChangelog(fw)}>
                      <Eye className="w-3 h-3 mr-1" />查看变更日志
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {/* Tab 2: Upgrade Tasks */}
        <TabsContent value="tasks" className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-[var(--neutral-text-secondary)]">共 {taskData.length} 个升级任务</div>
            <Button size="sm" onClick={() => alert('创建升级任务暂未开放')}><Plus className="w-4 h-4 mr-1" />新建任务</Button>
          </div>
          <div className="space-y-3">
            {taskData.map(task => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[var(--neutral-text-primary)]">{task.taskName}</span>
                        {getTaskStatusBadge(task.status)}
                        <Badge variant="outline" className="text-[10px]">{task.strategy === 'immediate' ? '立即' : task.strategy === 'schedule' ? '定时' : '灰度'}</Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-[var(--neutral-text-secondary)]">
                        <span>目标设备：{task.deviceType}</span>
                        <span>范围：{task.scope === 'all' ? '全部' : task.scope === 'batch' ? '灰度批次' : '指定设备'}</span>
                        <span>设备数：{task.scopeCount}</span>
                        <span>开始时间：{task.startTime}</span>
                      </div>
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-[var(--neutral-text-secondary)]">升级进度</span>
                          <span className="text-[var(--neutral-text-primary)] font-medium">{task.progress}% ({task.successCount}/{task.scopeCount})</span>
                        </div>
                        <Progress value={task.progress} className="h-2" />
                      </div>
                      <div className="flex items-center gap-4 text-xs">
                        <span className="text-emerald-600">成功 {task.successCount}</span>
                        <span className="text-red-500">失败 {task.failCount}</span>
                        <span className="text-amber-500">待升级 {task.scopeCount - task.successCount - task.failCount}</span>
                      </div>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => alert(`查看任务详情：${task.taskName}`)}>详情</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 3: Device Upgrade Status */}
        <TabsContent value="devices" className="space-y-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[var(--neutral-background)]">
                    <TableHead className="text-[var(--neutral-text-secondary)]">设备名称</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">设备ID</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">当前版本</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">目标版本</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">进度</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">开始时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)]">完成时间</TableHead>
                    <TableHead className="text-[var(--neutral-text-secondary)] text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upgradeData.map(u => (
                    <TableRow key={u.id} className="hover:bg-[var(--neutral-background)]">
                      <TableCell className="font-medium text-[var(--neutral-text-primary)]">{u.deviceName}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)] text-xs">{u.deviceId}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{u.currentVersion}</TableCell>
                      <TableCell className="text-[var(--neutral-text-primary)]">{u.targetVersion}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          {u.status === 'downloading' && <Clock className="w-3 h-3 text-blue-500" />}
                          {u.status === 'upgrading' && <Zap className="w-3 h-3 text-purple-500" />}
                          {getUpgradeStatusBadge(u.status)}
                        </div>
                      </TableCell>
                      <TableCell>
                        {u.status === 'downloading' || u.status === 'upgrading' ? (
                          <div className="flex items-center gap-2">
                            <Progress value={u.progress} className="h-1.5 w-16" />
                            <span className="text-xs text-[var(--neutral-text-secondary)]">{u.progress}%</span>
                          </div>
                        ) : (
                          <span className="text-xs text-[var(--neutral-text-tertiary)]">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{u.startTime || '-'}</TableCell>
                      <TableCell className="text-[var(--neutral-text-secondary)]">{u.completeTime || '-'}</TableCell>
                      <TableCell className="text-right">
                        {u.status === 'failed' && (
                          <Button variant="ghost" size="sm" className="h-7 text-red-500" onClick={() => openRollback(u)}>
                            <RotateCcw className="w-3 h-3 mr-1" />回滚
                          </Button>
                        )}
                        {u.status !== 'failed' && (
                          <Button variant="ghost" size="sm" className="h-7">查看</Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Changelog Dialog */}
      <Dialog open={changelogOpen} onOpenChange={setChangelogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>变更日志</DialogTitle></DialogHeader>
          {selectedFw && (
            <div className="space-y-4 py-4">
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-[var(--neutral-text-primary)]">{selectedFw.version}</span>
                {getFwStatusBadge(selectedFw.status)}
              </div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">{selectedFw.name} · {selectedFw.deviceType} · {selectedFw.size}</div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">发布日期：{selectedFw.releaseDate}</div>
              <div className="bg-[var(--neutral-background)] rounded-lg p-3">
                <div className="text-xs text-[var(--neutral-text-secondary)] mb-1">变更内容</div>
                <div className="text-sm text-[var(--neutral-text-primary)] leading-relaxed">{selectedFw.changelog}</div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Rollback Dialog */}
      <Dialog open={rollbackOpen} onOpenChange={setRollbackOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>回滚设备</DialogTitle></DialogHeader>
          {selectedUpgrade && (
            <div className="space-y-4 py-4">
              <div className="text-sm text-[var(--neutral-text-secondary)]">
                设备：<span className="font-medium text-[var(--neutral-text-primary)]">{selectedUpgrade.deviceName}</span>（{selectedUpgrade.deviceId}）
              </div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">
                当前版本：{selectedUpgrade.targetVersion}（升级失败）
              </div>
              <div className="text-sm text-[var(--neutral-text-secondary)]">
                回滚目标版本：{selectedUpgrade.currentVersion}
              </div>
              {selectedUpgrade.failReason && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <div className="text-xs text-red-600 mb-1">失败原因</div>
                  <div className="text-sm text-red-700">{selectedUpgrade.failReason}</div>
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setRollbackOpen(false)}>取消</Button>
                <Button variant="destructive" onClick={() => { setRollbackOpen(false); alert(`设备 ${selectedUpgrade.deviceId} 已回滚至 ${selectedUpgrade.currentVersion}`); }}>
                  <RotateCcw className="w-4 h-4 mr-1" />确认回滚
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
