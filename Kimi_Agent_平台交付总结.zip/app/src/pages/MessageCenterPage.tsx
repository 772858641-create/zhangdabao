import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import {
  MessageSquare,
  Bell,
  Send,
  Mail,
  Check,
  Trash,
  Search,
  Filter,
  Settings,
  Eye,
  ChevronLeft,
  ChevronRight,
  Clock,
  User,
  FileText,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  VolumeX,
  Smartphone,
  BellRing,
} from 'lucide-react';

/* ── Types ── */
type MessageType = 'SYSTEM' | 'TRANSFER' | 'ALARM' | 'APPROVAL' | 'OTHER';
type NotificationChannel = 'site' | 'email' | 'sms' | 'dingtalk';

interface MessageItem {
  id: string;
  title: string;
  sender: string;
  content: string;
  time: string;
  read: boolean;
  type: MessageType;
  bizNo?: string;
  receivers?: string[];
}

interface NotificationConfig {
  type: MessageType;
  enabled: boolean;
  channels: NotificationChannel[];
}

/* ── Type config ── */
const typeMeta: Record<MessageType, { label: string; color: string; icon: typeof Bell }> = {
  SYSTEM:   { label: '系统通知',   color: 'bg-[hsl(var(--info))] text-white',           icon: Bell },
  TRANSFER: { label: '调拨通知',   color: 'bg-[hsl(var(--primary))] text-white',         icon: MessageSquare },
  ALARM:    { label: '报警通知',   color: 'bg-[hsl(var(--destructive))] text-white',     icon: AlertTriangle },
  APPROVAL: { label: '审批通知',   color: 'bg-[hsl(var(--warning))] text-black',         icon: FileText },
  OTHER:    { label: '其他',       color: 'bg-gray-400 text-white',                      icon: Mail },
};

const typeOptions: { value: MessageType | 'ALL'; label: string }[] = [
  { value: 'ALL', label: '全部' },
  { value: 'SYSTEM', label: '系统通知' },
  { value: 'TRANSFER', label: '调拨通知' },
  { value: 'ALARM', label: '报警通知' },
  { value: 'APPROVAL', label: '审批通知' },
  { value: 'OTHER', label: '其他' },
];

const readOptions = [
  { value: 'ALL', label: '全部' },
  { value: 'UNREAD', label: '未读' },
  { value: 'READ', label: '已读' },
];

/* ── Utility: format date ── */
const now = new Date();
const fmt = (d: Date) => d.toISOString().slice(0, 16).replace('T', ' ');

/* ── Mock Data: 30 messages ── */
const mockMessages: MessageItem[] = [
  { id: 'M001', title: '系统升级维护通知', sender: '系统管理员', content: '尊敬的用户，系统将于本周六凌晨2:00-4:00进行例行升级维护，期间部分服务可能不可用，请提前安排工作。', time: fmt(new Date(now.getTime() - 1000 * 60 * 15)), read: false, type: 'SYSTEM', bizNo: 'SYS-2024-001' },
  { id: 'M002', title: '调拨申请待审批', sender: '仓储部-李华', content: '您有一条来自仓储部的调拨申请待审批，调拨单号DB-2024-0156，请尽快处理。', time: fmt(new Date(now.getTime() - 1000 * 60 * 45)), read: false, type: 'TRANSFER', bizNo: 'DB-2024-0156' },
  { id: 'M003', title: '库存预警：A001-CPU芯片', sender: '库存监控系统', content: '物料A001-CPU芯片当前库存已低于安全库存阈值（安全库存：500，当前库存：320），请及时补货。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 2)), read: false, type: 'ALARM', bizNo: 'ALM-2024-0089' },
  { id: 'M004', title: '审批通过：采购申请PR-2024-0234', sender: '审批系统', content: '您的采购申请PR-2024-0234已通过审批，审批人：王经理，审批意见：同意，请尽快安排后续采购流程。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 3)), read: true, type: 'APPROVAL', bizNo: 'PR-2024-0234' },
  { id: 'M005', title: '月度盘点任务提醒', sender: '仓储部-张丽', content: '本月度库存盘点任务已生成，盘点范围：A1-A10库区，请于本月25日前完成盘点并提交结果。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 5)), read: false, type: 'SYSTEM', bizNo: 'PD-2024-0034' },
  { id: 'M006', title: '调拨完成通知', sender: '物流系统', content: '调拨单DB-2024-0150已完成，物料已送达目标仓库，请及时确认入库。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 6)), read: true, type: 'TRANSFER', bizNo: 'DB-2024-0150' },
  { id: 'M007', title: '高温报警：冷库B区', sender: '环境监控', content: '冷库B区温度异常，当前温度：-12°C，设定温度：-18°C，请立即检查制冷设备。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 8)), read: false, type: 'ALARM', bizNo: 'ALM-2024-0090' },
  { id: 'M008', title: '审批驳回：领料申请LM-2024-0056', sender: '审批系统', content: '您的领料申请LM-2024-0056已被驳回，驳回原因：库存不足，建议先发起采购申请。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 10)), read: true, type: 'APPROVAL', bizNo: 'LM-2024-0056' },
  { id: 'M009', title: '新用户注册审核', sender: '系统管理员', content: '有新用户"赵强"提交注册申请，角色：仓库管理员，请审核。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 12)), read: false, type: 'SYSTEM', bizNo: 'USR-2024-0012' },
  { id: 'M010', title: '调拨延迟提醒', sender: '物流系统', content: '调拨单DB-2024-0148已超过预计送达时间12小时，请及时跟进物流状态。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 14)), read: false, type: 'TRANSFER', bizNo: 'DB-2024-0148' },
  { id: 'M011', title: '设备保养到期提醒', sender: '设备管理', content: '叉车FK-003的定期保养将于3天后到期，请安排保养工作。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 16)), read: true, type: 'OTHER', bizNo: 'EQ-2024-0078' },
  { id: 'M012', title: '审批转交：调拨申请DB-2024-0160', sender: '审批系统', content: '原审批人刘主管已将调拨申请DB-2024-0160转交给您审批，请尽快处理。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 18)), read: false, type: 'APPROVAL', bizNo: 'DB-2024-0160' },
  { id: 'M013', title: '系统安全提醒', sender: '安全中心', content: '检测到您的账号在非常用地点登录，IP：203.12.45.67，如非本人操作请立即修改密码。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 20)), read: false, type: 'SYSTEM', bizNo: 'SEC-2024-0045' },
  { id: 'M014', title: '到货通知：PO-2024-0123', sender: '采购系统', content: '采购订单PO-2024-0123的货物已到港，预计明天送达仓库，请做好接货准备。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 22)), read: true, type: 'OTHER', bizNo: 'PO-2024-0123' },
  { id: 'M015', title: '库存积压预警：M002-电阻', sender: '库存分析', content: '物料M002-电阻库存周转天数已超过90天（当前：112天），建议关注并考虑促销清理。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 24)), read: true, type: 'ALARM', bizNo: 'ALM-2024-0091' },
  { id: 'M016', title: '调拨申请已批准', sender: '审批系统', content: '您提交的调拨申请DB-2024-0155已通过审批，调拨数量为1200件，请安排发货。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 26)), read: true, type: 'TRANSFER', bizNo: 'DB-2024-0155' },
  { id: 'M017', title: '密码即将过期', sender: '系统管理员', content: '您的登录密码将于7天后过期，为避免影响正常使用，请提前修改密码。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 28)), read: false, type: 'SYSTEM', bizNo: 'SYS-2024-002' },
  { id: 'M018', title: '审批催办：PR-2024-0240', sender: '采购部-王芳', content: '采购申请PR-2024-0240已提交3天，目前仍在等待您的审批，请尽快处理。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 30)), read: false, type: 'APPROVAL', bizNo: 'PR-2024-0240' },
  { id: 'M019', title: '湿度报警：仓库C区', sender: '环境监控', content: '仓库C区湿度超标，当前湿度：78%，设定上限：65%，请检查除湿设备。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 32)), read: false, type: 'ALARM', bizNo: 'ALM-2024-0092' },
  { id: 'M020', title: '调拨异常：DB-2024-0145', sender: '物流系统', content: '调拨单DB-2024-0145在运输途中发生异常，货物外包装破损，已拍照留存，请确认处理方式。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 36)), read: true, type: 'TRANSFER', bizNo: 'DB-2024-0145' },
  { id: 'M021', title: '节假日值班安排', sender: '行政部', content: '国庆节值班安排已发布，您的值班时间为10月3日-10月4日白班，请查看详细安排。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 40)), read: true, type: 'OTHER', bizNo: 'DUTY-2024-0010' },
  { id: 'M022', title: '审批完成：报废申请BF-2024-0012', sender: '审批系统', content: '报废申请BF-2024-0012已通过全部审批流程，准予报废，请按流程执行。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 44)), read: true, type: 'APPROVAL', bizNo: 'BF-2024-0012' },
  { id: 'M023', title: '系统功能更新', sender: '产品部', content: '库存管理模块新增"批次追溯"功能，支持按批次号查询物料全生命周期，欢迎体验。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 48)), read: false, type: 'SYSTEM', bizNo: 'SYS-2024-003' },
  { id: 'M024', title: '库存盘点差异报警', sender: '库存监控', content: 'A5库区盘点发现差异，系统库存：450，实际盘点：438，差异：-12，请核查原因。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 52)), read: false, type: 'ALARM', bizNo: 'ALM-2024-0093' },
  { id: 'M025', title: '调拨入库确认', sender: '仓储部-李明', content: '调拨单DB-2024-0142的物料已全部入库，入库数量：580件，入库单号RK-2024-0234。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 56)), read: true, type: 'TRANSFER', bizNo: 'DB-2024-0142' },
  { id: 'M026', title: '培训通知：WMS系统操作', sender: '人力资源部', content: 'WMS系统操作培训将于下周三下午2:00在3楼会议室举行，请相关人员准时参加。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 60)), read: true, type: 'OTHER', bizNo: 'TRAIN-2024-005' },
  { id: 'M027', title: '审批撤销：LM-2024-0060', sender: '审批系统', content: '领料申请LM-2024-0060已被申请人主动撤销，无需继续审批。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 64)), read: true, type: 'APPROVAL', bizNo: 'LM-2024-0060' },
  { id: 'M028', title: '服务器资源告警', sender: '运维中心', content: '数据库服务器CPU使用率持续超过85%已达15分钟，请及时排查。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 68)), read: false, type: 'SYSTEM', bizNo: 'OPS-2024-0034' },
  { id: 'M029', title: '调拨单自动取消提醒', sender: '物流系统', content: '调拨单DB-2024-0138因超过48小时未确认，已自动取消，如需重新调拨请重新提交申请。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 72)), read: true, type: 'TRANSFER', bizNo: 'DB-2024-0138' },
  { id: 'M030', title: '消防设施检查提醒', sender: '安全管理', content: '本月消防设施定期检查将于明天上午进行，请确保各区域消防通道畅通。', time: fmt(new Date(now.getTime() - 1000 * 60 * 60 * 76)), read: true, type: 'OTHER', bizNo: 'SAFE-2024-0023' },
];

/* ── KPI Card Component ── */
function KPICard({ title, value, icon: Icon, colorClass }: { title: string; value: number; icon: typeof Bell; colorClass: string }) {
  return (
    <Card className="flex-1 min-w-[200px]">
      <CardContent className="p-4 flex items-center gap-4">
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${colorClass}`}>
          <Icon size={24} />
        </div>
        <div>
          <p className="text-sm text-[hsl(var(--muted-foreground))]">{title}</p>
          <p className="text-2xl font-bold">{value}</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ── Notification Settings Dialog ── */
function NotificationSettingsDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [configs, setConfigs] = useState<NotificationConfig[]>([
    { type: 'SYSTEM', enabled: true, channels: ['site', 'email'] },
    { type: 'TRANSFER', enabled: true, channels: ['site', 'dingtalk'] },
    { type: 'ALARM', enabled: true, channels: ['site', 'sms', 'dingtalk'] },
    { type: 'APPROVAL', enabled: true, channels: ['site', 'email'] },
    { type: 'OTHER', enabled: false, channels: ['site'] },
  ]);
  const [dndEnabled, setDndEnabled] = useState(false);
  const [dndStart, setDndStart] = useState('22:00');
  const [dndEnd, setDndEnd] = useState('08:00');

  const toggleChannel = (idx: number, ch: NotificationChannel) => {
    setConfigs(prev => prev.map((c, i) => {
      if (i !== idx) return c;
      const has = c.channels.includes(ch);
      return { ...c, channels: has ? c.channels.filter(x => x !== ch) : [...c.channels, ch] };
    }));
  };

  const channelMeta: { key: NotificationChannel; label: string; icon: typeof Mail | typeof Smartphone | typeof BellRing | typeof MessageSquare }[] = [
    { key: 'site', label: '站内信', icon: MessageSquare },
    { key: 'email', label: '邮件', icon: Mail },
    { key: 'sms', label: '短信', icon: Smartphone },
    { key: 'dingtalk', label: '钉钉', icon: BellRing },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings size={18} />
            通知设置
          </DialogTitle>
          <DialogDescription>配置各类消息的通知方式和免打扰时段</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="channels" className="mt-2">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="channels">通知方式</TabsTrigger>
            <TabsTrigger value="dnd">免打扰</TabsTrigger>
          </TabsList>

          <TabsContent value="channels" className="space-y-4 mt-4">
            {configs.map((cfg, idx) => {
              const meta = typeMeta[cfg.type];
              const Icon = meta.icon;
              return (
                <div key={cfg.type} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Icon size={16} className="text-[hsl(var(--foreground))]" />
                      <span className="font-medium">{meta.label}</span>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={cfg.enabled}
                        onChange={() => setConfigs(prev => prev.map((c, i) => i === idx ? { ...c, enabled: !c.enabled } : c))}
                        className="w-4 h-4 accent-[hsl(var(--primary))]"
                      />
                      <span className="text-sm">{cfg.enabled ? '已开启' : '已关闭'}</span>
                    </label>
                  </div>
                  {cfg.enabled && (
                    <div className="flex gap-3 flex-wrap pl-6">
                      {channelMeta.map(ch => {
                        const ChIcon = ch.icon;
                        const active = cfg.channels.includes(ch.key);
                        return (
                          <button
                            key={ch.key}
                            onClick={() => toggleChannel(idx, ch.key)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm border transition-colors ${
                              active ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]' : 'border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] hover:border-[hsl(var(--primary))]/40'
                            }`}
                          >
                            <ChIcon size={14} />
                            {ch.label}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </TabsContent>

          <TabsContent value="dnd" className="space-y-4 mt-4">
            <div className="border rounded-lg p-4">
              <label className="flex items-center gap-2 cursor-pointer mb-4">
                <input
                  type="checkbox"
                  checked={dndEnabled}
                  onChange={() => setDndEnabled(!dndEnabled)}
                  className="w-4 h-4 accent-[hsl(var(--primary))]"
                />
                <span className="font-medium flex items-center gap-2">
                  <VolumeX size={16} />
                  开启免打扰模式
                </span>
              </label>
              {dndEnabled && (
                <div className="grid grid-cols-2 gap-4 pl-6">
                  <div>
                    <label className="text-sm text-[hsl(var(--muted-foreground))] mb-1 block">开始时间</label>
                    <Input type="time" value={dndStart} onChange={e => setDndStart(e.target.value)} className="w-full" />
                  </div>
                  <div>
                    <label className="text-sm text-[hsl(var(--muted-foreground))] mb-1 block">结束时间</label>
                    <Input type="time" value={dndEnd} onChange={e => setDndEnd(e.target.value)} className="w-full" />
                  </div>
                </div>
              )}
              <p className="text-xs text-[hsl(var(--muted-foreground))] mt-3">
                开启后，在设定时段内仅接收站内信，不推送邮件、短信和钉钉通知。
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>关闭</Button>
          <Button onClick={() => onOpenChange(false)}>
            <Check size={16} className="mr-1" />
            保存设置
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Send Message Dialog ── */
function SendMessageDialog({ open, onOpenChange, onSend }: { open: boolean; onOpenChange: (v: boolean) => void; onSend: (m: MessageItem) => void }) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [msgType, setMsgType] = useState<MessageType>('SYSTEM');
  const [receiver, setReceiver] = useState('');
  const [broadcast, setBroadcast] = useState(false);

  const handleSend = () => {
    if (!title.trim() || !content.trim()) return;
    const newMsg: MessageItem = {
      id: `M${Date.now()}`,
      title: title.trim(),
      sender: '当前用户',
      content: content.trim(),
      time: fmt(new Date()),
      read: false,
      type: msgType,
      receivers: broadcast ? ['全部用户'] : receiver.trim() ? [receiver.trim()] : undefined,
    };
    onSend(newMsg);
    setTitle('');
    setContent('');
    setReceiver('');
    setBroadcast(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send size={18} />
            发送消息
          </DialogTitle>
          <DialogDescription>填写消息内容并选择接收人</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          <div>
            <label className="text-sm font-medium mb-1 block">消息类型</label>
            <div className="flex gap-2 flex-wrap">
              {(typeOptions.filter(t => t.value !== 'ALL') as { value: MessageType; label: string }[]).map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setMsgType(opt.value)}
                  className={`px-3 py-1.5 rounded-md text-sm border transition-colors ${
                    msgType === opt.value ? 'border-[hsl(var(--primary))] bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]' : 'border-[hsl(var(--border))] hover:border-[hsl(var(--primary))]/40'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block flex items-center gap-1">
              <User size={14} />
              接收人
            </label>
            <Input
              placeholder="输入接收人用户名，多个用逗号分隔"
              value={receiver}
              onChange={e => setReceiver(e.target.value)}
              disabled={broadcast}
              className="w-full"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="broadcast"
              checked={broadcast}
              onChange={e => setBroadcast(e.target.checked)}
              className="w-4 h-4 accent-[hsl(var(--primary))]"
            />
            <label htmlFor="broadcast" className="text-sm cursor-pointer flex items-center gap-1">
              <BellRing size={14} />
              广播给所有用户
            </label>
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block flex items-center gap-1">
              <FileText size={14} />
              标题
            </label>
            <Input
              placeholder="输入消息标题"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-1 block flex items-center gap-1">
              <MessageSquare size={14} />
              内容
            </label>
            <textarea
              placeholder="输入消息内容..."
              value={content}
              onChange={e => setContent(e.target.value)}
              className="w-full min-h-[120px] rounded-md border border-[hsl(var(--border))] bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-[hsl(var(--muted-foreground))] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[hsl(var(--ring))] resize-none"
            />
          </div>
        </div>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>取消</Button>
          <Button onClick={handleSend} disabled={!title.trim() || !content.trim()}>
            <Send size={16} className="mr-1" />
            发送
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ── Message Detail Panel ── */
function MessageDetailPanel({
  message,
  onMarkRead,
  onDelete,
  onOpenBiz,
}: {
  message: MessageItem | null;
  onMarkRead: (id: string) => void;
  onDelete: (id: string) => void;
  onOpenBiz: (bizNo?: string) => void;
}) {
  if (!message) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-[hsl(var(--muted-foreground))]">
        <MessageSquare size={64} className="mb-4 opacity-30" />
        <p className="text-lg font-medium">选择一条消息查看详情</p>
        <p className="text-sm mt-1">从左侧列表中点击消息以查看完整内容</p>
      </div>
    );
  }

  const meta = typeMeta[message.type];
  const TIcon = meta.icon;

  return (
    <>
      <div className="p-4 border-b shrink-0">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className={meta.color}>
              <TIcon size={12} className="mr-1" />
              {meta.label}
            </Badge>
            {!message.read && (
              <Badge className="bg-[hsl(var(--destructive))] text-white">
                <XCircle size={12} className="mr-1" />
                未读
              </Badge>
            )}
            {message.read && (
              <Badge variant="outline" className="text-[hsl(var(--success))] border-[hsl(var(--success))]">
                <CheckCircle2 size={12} className="mr-1" />
                已读
              </Badge>
            )}
          </div>
          <div className="flex gap-1">
            {!message.read && (
              <Button size="sm" variant="outline" onClick={() => onMarkRead(message.id)}>
                <Check size={14} className="mr-1" />
                标记已读
              </Button>
            )}
            <Button size="sm" variant="destructive" onClick={() => onDelete(message.id)}>
              <Trash size={14} className="mr-1" />
              删除
            </Button>
          </div>
        </div>
        <h2 className="text-lg font-bold">{message.title}</h2>
      </div>

      <div className="p-4 border-b shrink-0">
        <div className="grid grid-cols-2 gap-y-2 gap-x-6 text-sm">
          <div className="flex items-center gap-2">
            <User size={14} className="text-[hsl(var(--muted-foreground))]" />
            <span className="text-[hsl(var(--muted-foreground))]">发送人：</span>
            <span>{message.sender}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-[hsl(var(--muted-foreground))]" />
            <span className="text-[hsl(var(--muted-foreground))]">接收时间：</span>
            <span>{message.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-[hsl(var(--muted-foreground))]" />
            <span className="text-[hsl(var(--muted-foreground))]">消息类型：</span>
            <span>{meta.label}</span>
          </div>
          {message.bizNo && (
            <div className="flex items-center gap-2">
              <FileText size={14} className="text-[hsl(var(--muted-foreground))]" />
              <span className="text-[hsl(var(--muted-foreground))]">关联单号：</span>
              <span className="font-mono">{message.bizNo}</span>
            </div>
          )}
          {message.receivers && (
            <div className="flex items-center gap-2 col-span-2">
              <Mail size={14} className="text-[hsl(var(--muted-foreground))]" />
              <span className="text-[hsl(var(--muted-foreground))]">接收人：</span>
              <span>{message.receivers.join(', ')}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="prose prose-sm max-w-none text-[hsl(var(--foreground))] leading-relaxed whitespace-pre-wrap">
          {message.content}
        </div>
      </div>

      {message.bizNo && (
        <div className="p-4 border-t shrink-0">
          <Button onClick={() => onOpenBiz(message.bizNo)}>
            <Eye size={16} className="mr-1" />
            查看关联业务
          </Button>
        </div>
      )}
    </>
  );
}

/* ── Message List Item ── */
function MessageListItem({
  msg,
  isSelected,
  isChecked,
  onToggleCheck,
  onSelect,
}: {
  msg: MessageItem;
  isSelected: boolean;
  isChecked: boolean;
  onToggleCheck: (e: React.MouseEvent) => void;
  onSelect: () => void;
}) {
  const meta = typeMeta[msg.type];
  const TypeIcon = meta.icon;

  return (
    <div
      onClick={onSelect}
      className={`flex items-start gap-3 p-3 border-b cursor-pointer transition-colors hover:bg-[hsl(var(--accent))] ${
        isSelected ? 'bg-[hsl(var(--accent))] border-l-4 border-l-[hsl(var(--primary))]' : 'border-l-4 border-l-transparent'
      } ${!msg.read ? 'bg-[hsl(var(--primary))]/5' : ''}`}
    >
      <input
        type="checkbox"
        checked={isChecked}
        onClick={onToggleCheck}
        onChange={() => {}}
        className="mt-1 w-4 h-4 accent-[hsl(var(--primary))]"
      />
      <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${meta.color}`}>
        <TypeIcon size={14} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <p className={`text-sm truncate ${!msg.read ? 'font-bold' : 'font-medium'}`}>{msg.title}</p>
          {!msg.read && <span className="w-2 h-2 rounded-full bg-[hsl(var(--destructive))] shrink-0" />}
        </div>
        <p className="text-xs text-[hsl(var(--muted-foreground))] truncate mb-1">{msg.sender} · {msg.time}</p>
        <p className="text-xs text-[hsl(var(--muted-foreground))] truncate">{msg.content}</p>
      </div>
      <Badge className={`shrink-0 text-[10px] ${meta.color}`}>
        {meta.label}
      </Badge>
    </div>
  );
}

/* ── Main Page ── */
export default function MessageCenterPage() {
  const [messages, setMessages] = useState<MessageItem[]>(mockMessages);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<MessageType | 'ALL'>('ALL');
  const [readFilter, setReadFilter] = useState<'ALL' | 'READ' | 'UNREAD'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [page, setPage] = useState(1);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sendOpen, setSendOpen] = useState(false);
  const pageSize = 10;

  /* Filter logic */
  const filteredMessages = useMemo(() => {
    return messages.filter(m => {
      if (typeFilter !== 'ALL' && m.type !== typeFilter) return false;
      if (readFilter === 'READ' && !m.read) return false;
      if (readFilter === 'UNREAD' && m.read) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return m.title.toLowerCase().includes(q) || m.sender.toLowerCase().includes(q) || m.content.toLowerCase().includes(q);
      }
      return true;
    });
  }, [messages, typeFilter, readFilter, searchQuery]);

  const pagedMessages = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filteredMessages.slice(start, start + pageSize);
  }, [filteredMessages, page]);

  const totalPages = Math.max(1, Math.ceil(filteredMessages.length / pageSize));

  const selectedMessage = useMemo(() => messages.find(m => m.id === selectedId) || null, [messages, selectedId]);

  /* KPI data calculations */
  const unreadCount = messages.filter(m => !m.read).length;
  const todayCount = messages.filter(m => {
    const t = new Date(m.time);
    const today = new Date();
    return t.getDate() === today.getDate() && t.getMonth() === today.getMonth() && t.getFullYear() === today.getFullYear();
  }).length;
  const systemCount = messages.filter(m => m.type === 'SYSTEM' && !m.read).length;
  const alarmCount = messages.filter(m => m.type === 'ALARM' && !m.read).length;

  /* Selection handlers */
  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllInPage = () => {
    const pageIds = new Set(pagedMessages.map(m => m.id));
    const allSelected = pagedMessages.every(m => selectedIds.has(m.id));
    if (allSelected) {
      setSelectedIds(prev => {
        const next = new Set(prev);
        pageIds.forEach(id => next.delete(id));
        return next;
      });
    } else {
      setSelectedIds(prev => {
        const next = new Set(prev);
        pageIds.forEach(id => next.add(id));
        return next;
      });
    }
  };

  /* Message actions */
  const markRead = (ids: string[]) => {
    setMessages(prev => prev.map(m => ids.includes(m.id) ? { ...m, read: true } : m));
    setSelectedIds(new Set());
  };

  const deleteMessages = (ids: string[]) => {
    setMessages(prev => prev.filter(m => !ids.includes(m.id)));
    if (selectedId && ids.includes(selectedId)) setSelectedId(null);
    setSelectedIds(new Set());
  };

  const handleSend = (newMsg: MessageItem) => {
    setMessages(prev => [newMsg, ...prev]);
  };

  const openBiz = (bizNo?: string) => {
    if (bizNo) {
      alert(`打开关联业务单：${bizNo}`);
    }
  };

  const handleMarkReadDetail = (id: string) => markRead([id]);
  const handleDeleteDetail = (id: string) => deleteMessages([id]);

  return (
    <div className="flex flex-col h-full gap-4 p-4 overflow-hidden">
      {/* Page Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Bell size={24} />
            消息中心
          </h1>
          <p className="text-sm text-[hsl(var(--muted-foreground))] mt-1">查看和管理您的所有系统消息、通知与提醒</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setSettingsOpen(true)}>
            <Settings size={16} className="mr-1" />
            通知设置
          </Button>
          <Button onClick={() => setSendOpen(true)}>
            <Send size={16} className="mr-1" />
            发送消息
          </Button>
        </div>
      </div>

      {/* KPI Statistics Cards */}
      <div className="flex gap-4 shrink-0 flex-wrap">
        <KPICard title="未读消息" value={unreadCount} icon={Mail} colorClass="bg-[hsl(var(--destructive))]/10 text-[hsl(var(--destructive))]" />
        <KPICard title="今日消息" value={todayCount} icon={Bell} colorClass="bg-[hsl(var(--primary))]/10 text-[hsl(var(--primary))]" />
        <KPICard title="未读系统通知" value={systemCount} icon={MessageSquare} colorClass="bg-[hsl(var(--info))]/10 text-[hsl(var(--info))]" />
        <KPICard title="未读报警通知" value={alarmCount} icon={AlertTriangle} colorClass="bg-[hsl(var(--warning))]/10 text-[hsl(var(--warning))]" />
      </div>

      {/* Main Content: Left List + Right Detail */}
      <div className="flex gap-4 flex-1 min-h-0">
        {/* Left: Message List Panel */}
        <Card className="flex-1 flex flex-col min-w-[380px] max-w-[520px] overflow-hidden">
          {/* Filters & Search */}
          <div className="p-3 border-b space-y-3 shrink-0">
            {/* Search */}
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" />
              <Input
                placeholder="搜索标题、发送人、内容..."
                value={searchQuery}
                onChange={e => { setSearchQuery(e.target.value); setPage(1); }}
                className="pl-9 w-full"
              />
            </div>

            {/* Type filter */}
            <div className="flex gap-2 flex-wrap">
              <div className="flex items-center gap-1 text-sm text-[hsl(var(--muted-foreground))]">
                <Filter size={14} />
                <span>筛选：</span>
              </div>
              {typeOptions.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => { setTypeFilter(opt.value); setPage(1); }}
                  className={`px-2.5 py-1 rounded-full text-xs transition-colors ${
                    typeFilter === opt.value
                      ? 'bg-[hsl(var(--primary))] text-white'
                      : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]/80'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Read status filter */}
            <div className="flex gap-2 flex-wrap">
              {readOptions.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => { setReadFilter(opt.value as 'ALL' | 'READ' | 'UNREAD'); setPage(1); }}
                  className={`px-2.5 py-1 rounded-full text-xs transition-colors ${
                    readFilter === opt.value
                      ? 'bg-[hsl(var(--primary))] text-white'
                      : 'bg-[hsl(var(--muted))] text-[hsl(var(--muted-foreground))] hover:bg-[hsl(var(--muted))]/80'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Batch operations toolbar */}
            {selectedIds.size > 0 && (
              <div className="flex items-center gap-2 pt-1 border-t">
                <span className="text-xs text-[hsl(var(--muted-foreground))]">已选 {selectedIds.size} 条</span>
                <Button size="sm" variant="outline" onClick={() => markRead(Array.from(selectedIds))}>
                  <Check size={14} className="mr-1" />
                  标记已读
                </Button>
                <Button size="sm" variant="destructive" onClick={() => deleteMessages(Array.from(selectedIds))}>
                  <Trash size={14} className="mr-1" />
                  删除
                </Button>
              </div>
            )}
          </div>

          {/* Message items list */}
          <div className="flex-1 overflow-y-auto">
            {pagedMessages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-40 text-[hsl(var(--muted-foreground))]">
                <Mail size={40} className="mb-2 opacity-40" />
                <p className="text-sm">暂无消息</p>
              </div>
            ) : (
              pagedMessages.map(msg => (
                <MessageListItem
                  key={msg.id}
                  msg={msg}
                  isSelected={selectedId === msg.id}
                  isChecked={selectedIds.has(msg.id)}
                  onToggleCheck={(e) => { e.stopPropagation(); toggleSelect(msg.id); }}
                  onSelect={() => {
                    setSelectedId(msg.id);
                    if (!msg.read) markRead([msg.id]);
                  }}
                />
              ))
            )}
          </div>

          {/* Pagination */}
          <div className="p-3 border-t flex items-center justify-between shrink-0">
            <div className="flex items-center gap-1">
              <input
                type="checkbox"
                checked={pagedMessages.length > 0 && pagedMessages.every(m => selectedIds.has(m.id))}
                onChange={selectAllInPage}
                className="w-4 h-4 accent-[hsl(var(--primary))]"
              />
              <span className="text-xs text-[hsl(var(--muted-foreground))]">全选本页</span>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage(p => Math.max(1, p - 1))}>
                <ChevronLeft size={14} />
              </Button>
              <span className="text-xs text-[hsl(var(--muted-foreground))]">
                {page} / {totalPages}
              </span>
              <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage(p => Math.min(totalPages, p + 1))}>
                <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        </Card>

        {/* Right: Message Detail Panel */}
        <Card className="flex-[2] flex flex-col overflow-hidden min-w-0">
          <MessageDetailPanel
            message={selectedMessage}
            onMarkRead={handleMarkReadDetail}
            onDelete={handleDeleteDetail}
            onOpenBiz={openBiz}
          />
        </Card>
      </div>

      {/* Dialog overlays */}
      <NotificationSettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
      <SendMessageDialog open={sendOpen} onOpenChange={setSendOpen} onSend={handleSend} />
    </div>
  );
}
