import { useMemo } from 'react';
import {
  Globe,
  TrendingUp,
  Timer,
  AlertTriangle,
  MapPin,
  Package,
  Route,
  Cpu,
  Warehouse,
  ArrowLeftRight,
  Zap,
  Shield,
  Activity,
  Ban,
  Users,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

/* ================================================================
   Types
   ================================================================ */

interface APIInfo {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  iconColor: string;
  iconBg: string;
  todayCalls: string;
  avgLatency: string;
  status: 'normal' | 'warning' | 'error';
  rateLimit: string;
}

interface RateLimitRule {
  id: string;
  apiName: string;
  threshold: string;
  triggers: number;
  exceededUsers: string[];
}

/* ================================================================
   Mock Data
   ================================================================ */

const apiList: APIInfo[] = [
  {
    id: 'api-1',
    name: '位置查询API',
    description: '输入载具编号返回最新位置，支持批量100个',
    icon: MapPin,
    iconColor: '#2563EB',
    iconBg: '#EFF6FF',
    todayCalls: '85.2K',
    avgLatency: '32ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
  {
    id: 'api-2',
    name: '状态查询API',
    description: '输入载具编号返回在库/在途/空满载状态',
    icon: Package,
    iconColor: '#10B981',
    iconBg: '#ECFDF5',
    todayCalls: '62.1K',
    avgLatency: '28ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
  {
    id: 'api-3',
    name: '历史轨迹API',
    description: '输入载具编号+时间范围返回轨迹点序列，支持道格拉斯-普克压缩',
    icon: Route,
    iconColor: '#8B5CF6',
    iconBg: '#F5F3FF',
    todayCalls: '23.4K',
    avgLatency: '120ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
  {
    id: 'api-4',
    name: '设备状态API',
    description: '输入设备编号返回在线/电量/信号/固件版本',
    icon: Cpu,
    iconColor: '#06B6D4',
    iconBg: '#ECFEFF',
    todayCalls: '45.6K',
    avgLatency: '25ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
  {
    id: 'api-5',
    name: '网点库存API',
    description: '输入网点编号返回在库载具清单含空满载状态',
    icon: Warehouse,
    iconColor: '#F59E0B',
    iconBg: '#FFFBEB',
    todayCalls: '18.9K',
    avgLatency: '55ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
  {
    id: 'api-6',
    name: '出入库事件API',
    description: '输入时间范围返回出入库事件流',
    icon: ArrowLeftRight,
    iconColor: '#EC4899',
    iconBg: '#FDF2F8',
    todayCalls: '10.6K',
    avgLatency: '65ms',
    status: 'normal',
    rateLimit: '100次/分钟',
  },
];

const rateLimitRules: RateLimitRule[] = [
  { id: 'rl-1', apiName: '位置查询API', threshold: '100次/分钟', triggers: 12, exceededUsers: ['user-api-03', 'user-api-07'] },
  { id: 'rl-2', apiName: '状态查询API', threshold: '100次/分钟', triggers: 8, exceededUsers: ['user-api-01'] },
  { id: 'rl-3', apiName: '历史轨迹API', threshold: '100次/分钟', triggers: 3, exceededUsers: ['user-api-05'] },
  { id: 'rl-4', apiName: '设备状态API', threshold: '100次/分钟', triggers: 5, exceededUsers: [] },
  { id: 'rl-5', apiName: '网点库存API', threshold: '100次/分钟', triggers: 1, exceededUsers: [] },
  { id: 'rl-6', apiName: '出入库事件API', threshold: '100次/分钟', triggers: 0, exceededUsers: [] },
];

const API_TREND_DAYS = ['12/14', '12/15', '12/16', '12/17', '12/18', '12/19', '12/20'];

function generateAPITrendData() {
  return API_TREND_DAYS.map((date) => ({
    date,
    '位置查询': 70 + Math.floor(Math.random() * 25),
    '状态查询': 50 + Math.floor(Math.random() * 20),
    '历史轨迹': 15 + Math.floor(Math.random() * 15),
    '设备状态': 35 + Math.floor(Math.random() * 20),
    '网点库存': 12 + Math.floor(Math.random() * 12),
    '出入库事件': 6 + Math.floor(Math.random() * 8),
  }));
}

/* ================================================================
   Helpers
   ================================================================ */

function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow duration-200">
      <CardContent className="p-4 flex items-start gap-4">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
          <Icon size={20} style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-neutral-textSecondary mb-1">{title}</p>
          <p className="text-[28px] font-semibold leading-tight text-neutral-textPrimary font-number">{value}</p>
          {subtext && <p className="text-xs text-neutral-textTertiary mt-1">{subtext}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; color: string; bg: string }> = {
    normal: { label: '正常', color: '#10B981', bg: '#ECFDF5' },
    warning: { label: '告警', color: '#F59E0B', bg: '#FFFBEB' },
    error: { label: '异常', color: '#EF4444', bg: '#FEF2F2' },
  };
  const c = config[status] || config.normal;
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ color: c.color, backgroundColor: c.bg }}>
      {c.label}
    </span>
  );
}

function APICard({ api }: { api: APIInfo }) {
  const Icon = api.icon;
  return (
    <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow duration-200">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: api.iconBg }}>
              <Icon size={18} style={{ color: api.iconColor }} />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-neutral-textPrimary">{api.name}</h3>
              <StatusBadge status={api.status} />
            </div>
          </div>
        </div>
        <p className="text-xs text-neutral-textSecondary mb-4 leading-relaxed line-clamp-2">{api.description}</p>
        <div className="grid grid-cols-3 gap-2 pt-3 border-t border-neutral-border">
          <div className="text-center">
            <p className="text-xs text-neutral-textTertiary mb-0.5">今日调用</p>
            <p className="text-sm font-semibold text-neutral-textPrimary font-number">{api.todayCalls}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-neutral-textTertiary mb-0.5">平均延迟</p>
            <p className="text-sm font-semibold text-neutral-textPrimary font-number">{api.avgLatency}</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-neutral-textTertiary mb-0.5">限流</p>
            <p className="text-sm font-medium text-neutral-textSecondary font-number">{api.rateLimit}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function DataAPITab() {
  const trendData = useMemo(() => generateAPITrendData(), []);

  const totalTriggers = rateLimitRules.reduce((sum, r) => sum + r.triggers, 0);
  const throttledUsers = Array.from(new Set(rateLimitRules.flatMap((r) => r.exceededUsers)));

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="API总数" value={6} subtext="核心API" color="#2563EB" icon={Globe} />
        <KPICard title="今日调用量" value="245.8K" subtext="次" color="#10B981" icon={TrendingUp} />
        <KPICard title="平均响应时间" value="45ms" subtext="P99 < 200ms" color="#F59E0B" icon={Timer} />
        <KPICard title="错误率" value="0.12%" subtext="健康" color="#EF4444" icon={AlertTriangle} />
      </div>

      {/* API List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {apiList.map((api) => (
          <APICard key={api.id} api={api} />
        ))}
      </div>

      {/* API Call Trend Line Chart */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Activity size={16} className="text-neutral-textSecondary" />
            近7天API每日调用量趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => [`${value}K次`, name]}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Line type="monotone" dataKey="位置查询" stroke="#2563EB" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="状态查询" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="历史轨迹" stroke="#8B5CF6" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="设备状态" stroke="#06B6D4" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="网点库存" stroke="#F59E0B" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="出入库事件" stroke="#EC4899" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Rate Limit Monitoring Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Rate Limit Stats */}
        <Card className="bg-neutral-surface border-neutral-border lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Shield size={16} className="text-neutral-textSecondary" />
              限流监控概览
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 p-3 rounded-lg bg-neutral-background">
              <div className="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center">
                <Ban size={18} className="text-warning" />
              </div>
              <div>
                <p className="text-xs text-neutral-textSecondary">今日限流触发次数</p>
                <p className="text-2xl font-semibold text-neutral-textPrimary font-number">{totalTriggers}</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-3 rounded-lg bg-neutral-background">
              <div className="w-10 h-10 rounded-full bg-danger/10 flex items-center justify-center">
                <Users size={18} className="text-danger" />
              </div>
              <div>
                <p className="text-xs text-neutral-textSecondary">被限流用户数</p>
                <p className="text-2xl font-semibold text-neutral-textPrimary font-number">{throttledUsers.length}</p>
              </div>
            </div>
            {throttledUsers.length > 0 && (
              <div className="pt-2">
                <p className="text-xs text-neutral-textSecondary mb-2">被限流用户列表</p>
                <div className="flex flex-wrap gap-1.5">
                  {throttledUsers.map((user) => (
                    <Badge key={user} variant="outline" className="text-xs border-danger/30 text-danger">
                      {user}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center gap-2 pt-2">
              <Zap size={14} className="text-success" />
              <span className="text-xs text-success">限流策略正常运行中</span>
            </div>
          </CardContent>
        </Card>

        {/* Rate Limit Rules Table */}
        <Card className="bg-neutral-surface border-neutral-border lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
              <Ban size={16} className="text-neutral-textSecondary" />
              限流规则明细
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-neutral-surface-elevated">
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">API名称</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">限流阈值</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">今日触发次数</th>
                    <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">超限用户</th>
                  </tr>
                </thead>
                <tbody>
                  {rateLimitRules.map((rl) => (
                    <tr key={rl.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                      <td className="px-4 py-3 text-sm text-neutral-textPrimary font-medium">{rl.apiName}</td>
                      <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{rl.threshold}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          'text-sm font-number font-medium',
                          rl.triggers === 0 ? 'text-success' : rl.triggers < 5 ? 'text-warning' : 'text-danger'
                        )}>
                          {rl.triggers}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        {rl.exceededUsers.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {rl.exceededUsers.map((u) => (
                              <span key={u} className="text-xs px-1.5 py-0.5 rounded bg-danger/10 text-danger font-number">{u}</span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-xs text-neutral-textTertiary">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
