import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Download,
  Eye,
  Edit3,
  Copy,
  Trash2,
  MoreHorizontal,
  X,
  CheckCircle,
  Clock,
  MapPin,
  Package,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Route,
  Activity,
  Timer,
  Link as LinkIcon,
  Unlink,
  ArrowRight,
  GripVertical,
  Save,
  LayoutDashboard,
  Settings,
  Bell,
  History,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMockData } from '@/hooks/useMockData';
import type { Route as RouteType, RouteNode } from '@/lib/mockData';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell,
} from 'recharts';

// ============================================================
// Status Config
// ============================================================

const routeStatusConfig = {
  active: { label: '已启用', bg: '#ECFDF5', text: '#10B981', dot: '#10B981' },
  inactive: { label: '已停用', bg: '#F1F5F9', text: '#94A3B8', dot: '#CBD5E1' },
};

// ============================================================
// Utility Components
// ============================================================

function KPICard({ title, value, color, icon: Icon }: { title: string; value: string | number; color: string; icon: React.ComponentType<{ size?: number; className?: string }> }) {
  return (
    <div className="bg-white rounded-lg shadow-card p-4 flex items-center gap-4">
      <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: color + '15' }}>
        <span style={{ color }}><Icon size={20} /></span>
      </div>
      <div>
        <div className="text-xs text-neutral-textSecondary mb-0.5">{title}</div>
        <div className="text-xl font-bold font-number text-neutral-textPrimary">{value}</div>
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: 'active' | 'inactive' }) {
  const config = routeStatusConfig[status];
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium"
      style={{ backgroundColor: config.bg, color: config.text }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: config.dot }} />
      {config.label}
    </span>
  );
}

function NodeTypeBadge({ type }: { type: string }) {
  const config: Record<string, { bg: string; text: string; label: string }> = {
    start: { bg: '#ECFDF5', text: '#10B981', label: '起点' },
    via: { bg: '#EFF6FF', text: '#2563EB', label: '途经' },
    end: { bg: '#F5F3FF', text: '#8B5CF6', label: '终点' },
  };
  const c = config[type] || config.via;
  return (
    <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium" style={{ backgroundColor: c.bg, color: c.text }}>
      {c.label}
    </span>
  );
}

// ============================================================
// Route Detail Drawer
// ============================================================

function RouteDetailDrawer({
  route,
  onClose,
  carriers,
  alarms,
}: {
  route: RouteType | null;
  onClose: () => void;
  carriers: { id: string; code: string; name: string; type: string; status: string }[];
  alarms: { id: string; type: string; level: string; message: string; createdAt: string; status: string; targetName?: string }[];
}) {
  const [activeTab, setActiveTab] = useState<'info' | 'carriers' | 'monitor' | 'alarms' | 'history'>('info');

  if (!route) return null;

  const routeAlarms = alarms.filter((a) => a.message.includes(route.name) || route.nodes.some((n) => a.message.includes(n.siteName)));
  const boundCarriers = carriers.slice(0, route.carrierCount % carriers.length || 5);

  const flowData = route.nodes.map((n) => ({
    name: n.siteName,
    carriers: Math.floor(Math.random() * 100) + 20,
    avgStay: Math.floor(Math.random() * 24) + 1,
  }));

  const alarmTypeData = [
    { name: '超时报警', value: 12, color: '#EF4444' },
    { name: '呆滞报警', value: 8, color: '#F59E0B' },
    { name: '偏离报警', value: 5, color: '#06B6D4' },
    { name: '循环超期', value: 3, color: '#8B5CF6' },
  ];

  const trendData = Array.from({ length: 7 }, (_, i) => ({
    day: `12/${String(14 + i).padStart(2, '0')}`,
    cycleTime: 20 + Math.floor(Math.random() * 15),
    timeoutRate: Math.floor(Math.random() * 10),
  }));

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex justify-end"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[720px] max-w-[90vw] h-full bg-white shadow-modal flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-semibold text-neutral-textPrimary">{route.name}</h2>
              <StatusBadge status={route.status} />
              <span className="text-xs text-neutral-textSecondary bg-neutral-background px-2 py-0.5 rounded">{route.code}</span>
            </div>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-neutral-border px-6">
            {[
              { key: 'info' as const, label: '路线信息', icon: Route },
              { key: 'carriers' as const, label: '绑定载具', icon: Package },
              { key: 'monitor' as const, label: '流转监控', icon: Activity },
              { key: 'alarms' as const, label: '报警记录', icon: Bell },
              { key: 'history' as const, label: '历史分析', icon: History },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={cn(
                  'flex items-center gap-1.5 px-4 py-3 text-sm border-b-2 transition-colors',
                  activeTab === tab.key
                    ? 'border-primary text-primary font-medium'
                    : 'border-transparent text-neutral-textSecondary hover:text-neutral-textPrimary'
                )}
              >
                <tab.icon size={14} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            <AnimatePresence mode="wait">
              {activeTab === 'info' && (
                <motion.div
                  key="info"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <InfoRow label="线路名称" value={route.name} />
                    <InfoRow label="线路编码" value={route.code} />
                    <InfoRow label="线路类型" value={route.type === 'fixed' ? '固定线路' : '临时线路'} />
                    <InfoRow label="归属组织" value={route.orgName} />
                    <InfoRow label="状态" value={<StatusBadge status={route.status} />} />
                    <InfoRow label="总距离" value={`${route.totalDistance} 公里`} />
                    <InfoRow label="预估时长" value={`${route.estimatedHours} 小时`} />
                    <InfoRow label="绑定载具" value={`${route.carrierCount} 个`} />
                  </div>

                  {/* Node Pipeline */}
                  <div className="mb-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">节点配置</h4>
                    <div className="flex items-center gap-2 overflow-x-auto pb-2">
                      {route.nodes.map((node, idx) => (
                        <div key={node.id} className="flex items-center gap-2 flex-shrink-0">
                          <div className="bg-white border border-neutral-border rounded-lg p-3 min-w-[140px] relative">
                            <div className="absolute -top-2 -left-1 w-5 h-5 rounded-full bg-primary text-white text-[10px] flex items-center justify-center font-medium">
                              {node.sequence}
                            </div>
                            <div className="text-sm font-medium text-neutral-textPrimary mb-1">{node.siteName}</div>
                            <div className="flex items-center gap-2 text-[10px] text-neutral-textSecondary">
                              <span className="flex items-center gap-0.5"><Clock size={10} /> {node.dwellMinutes}分钟</span>
                            </div>
                            <div className="mt-1">
                              <NodeTypeBadge type={idx === 0 ? 'start' : idx === route.nodes.length - 1 ? 'end' : 'via'} />
                            </div>
                          </div>
                          {idx < route.nodes.length - 1 && (
                            <div className="flex flex-col items-center flex-shrink-0">
                              <ArrowRight size={16} className="text-neutral-textTertiary" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Alarm Rules Summary */}
                  <div>
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">报警规则</h4>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { name: '超时报警', enabled: true, threshold: '24小时', level: '重要' },
                        { name: '呆滞报警', enabled: true, threshold: '12小时', level: '一般' },
                        { name: '偏离报警', enabled: false, threshold: '-', level: '-' },
                        { name: '循环超期', enabled: true, threshold: '7天', level: '紧急' },
                      ].map((rule) => (
                        <div key={rule.name} className="flex items-center justify-between p-3 bg-neutral-background rounded-md">
                          <div>
                            <div className="text-sm text-neutral-textPrimary">{rule.name}</div>
                            <div className="text-xs text-neutral-textSecondary">{rule.enabled ? `阈值: ${rule.threshold}` : '未启用'}</div>
                          </div>
                          <div className={cn('w-8 h-4 rounded-full relative transition-colors', rule.enabled ? 'bg-primary' : 'bg-neutral-border')}>
                            <div className={cn('w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-all shadow-sm', rule.enabled ? 'left-4' : 'left-0.5')} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'carriers' && (
                <motion.div
                  key="carriers"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-medium text-neutral-textPrimary">已绑定载具 ({boundCarriers.length})</h4>
                    <button className="h-7 px-3 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors flex items-center gap-1">
                      <LinkIcon size={12} />
                      绑定载具
                    </button>
                  </div>
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                        <th className="text-left px-3 py-2 rounded-tl-md w-10"><input type="checkbox" className="rounded" /></th>
                        <th className="text-left px-3 py-2">编号</th>
                        <th className="text-left px-3 py-2">名称</th>
                        <th className="text-left px-3 py-2">类型</th>
                        <th className="text-left px-3 py-2">当前节点</th>
                        <th className="text-left px-3 py-2 rounded-tr-md">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {boundCarriers.map((c, i) => (
                        <tr key={c.id} className={cn('border-b border-neutral-border', i % 2 === 1 && 'bg-neutral-background')}>
                          <td className="px-3 py-2"><input type="checkbox" className="rounded" /></td>
                          <td className="px-3 py-2 font-mono text-xs">{c.code}</td>
                          <td className="px-3 py-2">{c.name}</td>
                          <td className="px-3 py-2">{c.type}</td>
                          <td className="px-3 py-2 text-neutral-textSecondary">{route.nodes[i % route.nodes.length]?.siteName}</td>
                          <td className="px-3 py-2">
                            <button className="p-1 rounded hover:bg-neutral-background transition-colors" title="解绑">
                              <Unlink size={14} className="text-danger" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </motion.div>
              )}

              {activeTab === 'monitor' && (
                <motion.div
                  key="monitor"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-white border border-neutral-border rounded-lg p-3">
                      <div className="text-xs text-neutral-textSecondary mb-1">在途载具</div>
                      <div className="text-2xl font-bold font-number text-info">{Math.floor(route.carrierCount * 0.3)}</div>
                    </div>
                    <div className="bg-white border border-neutral-border rounded-lg p-3">
                      <div className="text-xs text-neutral-textSecondary mb-1">节点滞留</div>
                      <div className="text-2xl font-bold font-number text-warning">{Math.floor(route.carrierCount * 0.15)}</div>
                    </div>
                    <div className="bg-white border border-neutral-border rounded-lg p-3">
                      <div className="text-xs text-neutral-textSecondary mb-1">今日完成</div>
                      <div className="text-2xl font-bold font-number text-success">{Math.floor(route.carrierCount * 0.1)}</div>
                    </div>
                  </div>

                  <div className="bg-white border border-neutral-border rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">各节点载具分布</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={flowData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} />
                        <Tooltip />
                        <Bar dataKey="carriers" fill="#2563EB" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="bg-white border border-neutral-border rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">报警统计</h4>
                    <div className="flex items-center gap-8">
                      <ResponsiveContainer width={200} height={160}>
                        <PieChart>
                          <Pie data={alarmTypeData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value">
                            {alarmTypeData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="space-y-2">
                        {alarmTypeData.map((item) => (
                          <div key={item.name} className="flex items-center gap-2">
                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                            <span className="text-xs text-neutral-textSecondary">{item.name}: <strong className="text-neutral-textPrimary">{item.value}</strong></span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-neutral-border rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">各节点平均滞留时间</h4>
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                          <th className="text-left px-3 py-2 rounded-tl-md">节点</th>
                          <th className="text-left px-3 py-2">平均滞留(小时)</th>
                          <th className="text-left px-3 py-2">最大滞留</th>
                          <th className="text-left px-3 py-2 rounded-tr-md">状态</th>
                        </tr>
                      </thead>
                      <tbody>
                        {route.nodes.map((node) => (
                          <tr key={node.id} className="border-b border-neutral-border">
                            <td className="px-3 py-2 font-medium">{node.siteName}</td>
                            <td className="px-3 py-2 font-number">{(Math.random() * 8 + 1).toFixed(1)}</td>
                            <td className="px-3 py-2 font-number">{Math.floor(Math.random() * 24 + 8)}</td>
                            <td className="px-3 py-2">
                              <span className="text-xs text-success">正常</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </motion.div>
              )}

              {activeTab === 'alarms' && (
                <motion.div
                  key="alarms"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                >
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                        <th className="text-left px-3 py-2 rounded-tl-md">时间</th>
                        <th className="text-left px-3 py-2">类型</th>
                        <th className="text-left px-3 py-2">载具</th>
                        <th className="text-left px-3 py-2">级别</th>
                        <th className="text-left px-3 py-2 rounded-tr-md">状态</th>
                      </tr>
                    </thead>
                    <tbody>
                      {routeAlarms.length === 0 && (
                        <tr>
                          <td colSpan={5} className="text-center py-8 text-neutral-textSecondary text-xs">暂无报警记录</td>
                        </tr>
                      )}
                      {routeAlarms.map((a, i) => (
                        <tr key={a.id} className={cn('border-b border-neutral-border', i % 2 === 1 && 'bg-neutral-background')}>
                          <td className="px-3 py-2 text-xs">{a.createdAt}</td>
                          <td className="px-3 py-2">{a.type}</td>
                          <td className="px-3 py-2 font-mono text-xs">{a.targetName || '-'}</td>
                          <td className="px-3 py-2">
                            <span className={cn('text-xs', a.level === 'urgent' ? 'text-danger' : a.level === 'important' ? 'text-warning' : 'text-info')}>
                              {a.level === 'urgent' ? '紧急' : a.level === 'important' ? '重要' : a.level === 'normal' ? '一般' : '提示'}
                            </span>
                          </td>
                          <td className="px-3 py-2">
                            <span className={cn('text-xs', a.status === 'resolved' ? 'text-success' : a.status === 'handling' ? 'text-warning' : 'text-danger')}>
                              {a.status === 'resolved' ? '已解决' : a.status === 'handling' ? '处理中' : '未处理'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </motion.div>
              )}

              {activeTab === 'history' && (
                <motion.div
                  key="history"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <div className="bg-white border border-neutral-border rounded-lg p-4">
                    <h4 className="text-sm font-medium text-neutral-textPrimary mb-3">流转效率趋势（近7天）</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={trendData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
                        <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} />
                        <Tooltip />
                        <Line type="monotone" dataKey="cycleTime" stroke="#2563EB" strokeWidth={2} dot={{ r: 3 }} name="循环时长" />
                        <Line type="monotone" dataKey="timeoutRate" stroke="#EF4444" strokeWidth={2} dot={{ r: 3 }} name="超时率" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-neutral-background rounded-lg p-4 text-center">
                      <div className="text-xs text-neutral-textSecondary mb-1">平均循环时间</div>
                      <div className="text-xl font-bold font-number text-primary">{route.estimatedHours}h</div>
                    </div>
                    <div className="bg-neutral-background rounded-lg p-4 text-center">
                      <div className="text-xs text-neutral-textSecondary mb-1">超时率</div>
                      <div className="text-xl font-bold font-number text-warning">{(Math.random() * 10).toFixed(1)}%</div>
                    </div>
                    <div className="bg-neutral-background rounded-lg p-4 text-center">
                      <div className="text-xs text-neutral-textSecondary mb-1">呆滞率</div>
                      <div className="text-xl font-bold font-number text-info">{(Math.random() * 8).toFixed(1)}%</div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs text-neutral-textSecondary mb-1">{label}</label>
      <div className="text-sm text-neutral-textPrimary">{value}</div>
    </div>
  );
}

// ============================================================
// Create/Edit Route Modal
// ============================================================

function RouteEditModal({
  open,
  onClose,
  route,
  sites,
}: {
  open: boolean;
  onClose: () => void;
  route: RouteType | null;
  sites: { id: string; name: string }[];
}) {
  const [name, setName] = useState(route?.name || '');
  const [routeType, setRouteType] = useState<'fixed' | 'temporary'>(route?.type || 'fixed');
  const [status, setStatus] = useState<'active' | 'inactive'>((route?.status as 'active' | 'inactive') || 'active');
  const [nodes, setNodes] = useState<RouteNode[]>(route?.nodes || []);
  const [showAlarmRules, setShowAlarmRules] = useState(false);

  const isEdit = !!route;

  const addNode = () => {
    const newNode: RouteNode = {
      id: `rn-${Date.now()}`,
      siteId: sites[0]?.id || '',
      siteName: sites[0]?.name || '',
      lat: 0,
      lng: 0,
      sequence: nodes.length + 1,
      dwellMinutes: 60,
    };
    setNodes((prev) => [...prev, newNode]);
  };

  const removeNode = (id: string) => {
    if (nodes.length <= 2) return;
    setNodes((prev) => prev.filter((n) => n.id !== id).map((n, i) => ({ ...n, sequence: i + 1 })));
  };

  const updateNodeSite = (id: string, siteId: string) => {
    const site = sites.find((s) => s.id === siteId);
    setNodes((prev) => prev.map((n) => (n.id === id ? { ...n, siteId, siteName: site?.name || '' } : n)));
  };

  const moveNode = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === nodes.length - 1) return;
    const newNodes = [...nodes];
    const swapIdx = direction === 'up' ? index - 1 : index + 1;
    [newNodes[index], newNodes[swapIdx]] = [newNodes[swapIdx], newNodes[index]];
    setNodes(newNodes.map((n, i) => ({ ...n, sequence: i + 1 })));
  };

  if (!open) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[90vw] max-w-[960px] max-h-[85vh] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <h2 className="text-lg font-semibold text-neutral-textPrimary">
              {isEdit ? '编辑流转线路' : '创建流转线路'}
            </h2>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <div className="grid grid-cols-2 gap-6">
              {/* Left: Form */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
                  <Settings size={14} className="text-primary" />
                  基本信息
                </h3>
                <div>
                  <label className="block text-xs text-neutral-textSecondary mb-1">线路名称 <span className="text-danger">*</span></label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="请输入线路名称"
                    className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">线路类型</label>
                    <select
                      value={routeType}
                      onChange={(e) => setRouteType(e.target.value as 'fixed' | 'temporary')}
                      className="w-full h-8 px-2 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary bg-white"
                    >
                      <option value="fixed">固定线路</option>
                      <option value="temporary">临时线路</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-textSecondary mb-1">状态</label>
                    <div className="flex items-center gap-2 h-8">
                      <div
                        onClick={() => setStatus(status === 'active' ? 'inactive' : 'active')}
                        className={cn('w-9 h-5 rounded-full relative cursor-pointer transition-colors', status === 'active' ? 'bg-primary' : 'bg-neutral-border')}
                      >
                        <div className={cn('w-4 h-4 bg-white rounded-full absolute top-0.5 transition-all shadow-sm', status === 'active' ? 'left-4.5' : 'left-0.5')} style={{ left: status === 'active' ? '18px' : '2px' }} />
                      </div>
                      <span className="text-xs text-neutral-textSecondary">{status === 'active' ? '启用' : '停用'}</span>
                    </div>
                  </div>
                </div>

                <h3 className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2 pt-2">
                  <MapPin size={14} className="text-primary" />
                  节点配置
                  <span className="text-xs font-normal text-neutral-textSecondary">({nodes.length} 个节点)</span>
                </h3>
                <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                  {nodes.map((node, idx) => (
                    <motion.div
                      key={node.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2 }}
                      className="flex items-center gap-2 p-2 border border-neutral-border rounded-md bg-neutral-background"
                    >
                      <div className="w-6 h-6 rounded-full bg-primary text-white text-[10px] flex items-center justify-center flex-shrink-0 font-medium">
                        {node.sequence}
                      </div>
                      <GripVertical size={14} className="text-neutral-textTertiary flex-shrink-0" />
                      <select
                        value={node.siteId}
                        onChange={(e) => updateNodeSite(node.id, e.target.value)}
                        className="flex-1 h-7 px-2 text-xs border border-neutral-border-strong rounded focus:outline-none focus:border-primary bg-white"
                      >
                        {sites.map((s) => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <NodeTypeBadge type={idx === 0 ? 'start' : idx === nodes.length - 1 ? 'end' : 'via'} />
                      </div>
                      <div className="flex items-center gap-0.5 flex-shrink-0">
                        <button onClick={() => moveNode(idx, 'up')} className="p-1 rounded hover:bg-white transition-colors disabled:opacity-30" disabled={idx === 0}>
                          <ChevronLeft size={12} className="rotate-90 text-neutral-textSecondary" />
                        </button>
                        <button onClick={() => moveNode(idx, 'down')} className="p-1 rounded hover:bg-white transition-colors disabled:opacity-30" disabled={idx === nodes.length - 1}>
                          <ChevronLeft size={12} className="-rotate-90 text-neutral-textSecondary" />
                        </button>
                        <button
                          onClick={() => removeNode(node.id)}
                          disabled={nodes.length <= 2}
                          className="p-1 rounded hover:bg-danger-light transition-colors disabled:opacity-30"
                        >
                          <Trash2 size={12} className="text-danger" />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
                <button
                  onClick={addNode}
                  className="w-full h-8 flex items-center justify-center gap-1 text-xs text-primary border border-dashed border-primary rounded-md hover:bg-primary-light transition-colors"
                >
                  <Plus size={14} />
                  添加节点
                </button>

                {/* Alarm Rules */}
                <h3
                  className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2 pt-2 cursor-pointer"
                  onClick={() => setShowAlarmRules(!showAlarmRules)}
                >
                  <AlertTriangle size={14} className="text-warning" />
                  报警规则
                  <ChevronDown size={14} className={cn('text-neutral-textTertiary transition-transform', showAlarmRules && 'rotate-180')} />
                </h3>
                <AnimatePresence>
                  {showAlarmRules && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="space-y-2 overflow-hidden"
                    >
                      {[
                        { name: '超时报警', enabled: true, threshold: '24', unit: '小时' },
                        { name: '呆滞报警', enabled: true, threshold: '12', unit: '小时' },
                        { name: '偏离报警', enabled: false, threshold: '5', unit: '公里' },
                        { name: '循环超期', enabled: true, threshold: '7', unit: '天' },
                      ].map((rule) => (
                        <div key={rule.name} className="flex items-center justify-between p-2 bg-neutral-background rounded-md">
                          <div className="flex items-center gap-2">
                            <div className={cn('w-8 h-4 rounded-full relative cursor-pointer', rule.enabled ? 'bg-primary' : 'bg-neutral-border')}>
                              <div className={cn('w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-all', rule.enabled ? 'left-4' : 'left-0.5')} />
                            </div>
                            <span className="text-xs text-neutral-textPrimary">{rule.name}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <input type="text" defaultValue={rule.threshold} className="w-12 h-6 px-1 text-xs border border-neutral-border rounded text-center" />
                            <span className="text-[10px] text-neutral-textSecondary">{rule.unit}</span>
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Right: Visual Preview */}
              <div>
                <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3 flex items-center gap-2">
                  <Eye size={14} className="text-primary" />
                  路线预览
                </h3>
                <div className="bg-[#F1F5F9] rounded-lg p-4 h-[400px] relative">
                  <svg width="100%" height="100%" viewBox="0 0 400 360" className="absolute inset-0">
                    {Array.from({ length: 10 }).map((_, i) => (
                      <g key={i}>
                        <line x1={i * 40} y1={0} x2={i * 40} y2={360} stroke="#E2E8F0" strokeWidth={0.5} />
                        <line x1={0} y1={i * 36} x2={400} y2={i * 36} stroke="#E2E8F0" strokeWidth={0.5} />
                      </g>
                    ))}
                    {nodes.map((node, idx) => {
                      const x = 60 + (idx * ((400 - 120) / Math.max(nodes.length - 1, 1)));
                      const y = 180;
                      const color = idx === 0 ? '#10B981' : idx === nodes.length - 1 ? '#8B5CF6' : '#2563EB';
                      return (
                        <g key={node.id}>
                          {idx < nodes.length - 1 && (
                            <line
                              x1={x}
                              y1={y}
                              x2={60 + ((idx + 1) * ((400 - 120) / Math.max(nodes.length - 1, 1)))}
                              y2={y}
                              stroke="#CBD5E1"
                              strokeWidth={2}
                              strokeDasharray="4 2"
                              markerEnd="url(#arrow)"
                            />
                          )}
                          <circle cx={x} cy={y} r={10} fill={color} stroke="white" strokeWidth={2} />
                          <text x={x} y={y + 25} textAnchor="middle" fontSize={9} fill="#0F172A" fontWeight={500}>{node.siteName}</text>
                          <text x={x} y={y + 37} textAnchor="middle" fontSize={8} fill="#94A3B8">{node.dwellMinutes}min</text>
                        </g>
                      );
                    })}
                    <defs>
                      <marker id="arrow" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto">
                        <path d="M0,0 L6,3 L0,6 L2,3 Z" fill="#CBD5E1" />
                      </marker>
                    </defs>
                  </svg>
                </div>

                {/* Route Stats Preview */}
                <div className="grid grid-cols-3 gap-3 mt-3">
                  <div className="bg-neutral-background rounded-md p-2 text-center">
                    <div className="text-[10px] text-neutral-textSecondary">节点数</div>
                    <div className="text-sm font-bold font-number text-neutral-textPrimary">{nodes.length}</div>
                  </div>
                  <div className="bg-neutral-background rounded-md p-2 text-center">
                    <div className="text-[10px] text-neutral-textSecondary">预估距离</div>
                    <div className="text-sm font-bold font-number text-neutral-textPrimary">{route?.totalDistance || '-'} km</div>
                  </div>
                  <div className="bg-neutral-background rounded-md p-2 text-center">
                    <div className="text-[10px] text-neutral-textSecondary">预估时长</div>
                    <div className="text-sm font-bold font-number text-neutral-textPrimary">{route?.estimatedHours || '-'} h</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between px-6 py-4 border-t border-neutral-border">
            <button onClick={onClose} className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors">
              取消
            </button>
            <div className="flex gap-2">
              {!isEdit && (
                <button onClick={onClose} className="h-8 px-4 text-xs border border-neutral-border rounded-md hover:bg-neutral-background transition-colors">
                  保存为草稿
                </button>
              )}
              <button onClick={onClose} className="h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors flex items-center gap-1">
                <Save size={12} />
                {isEdit ? '保存修改' : '确认创建'}
              </button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Carrier Binding Modal
// ============================================================

function CarrierBindingModal({
  open,
  onClose,
  route,
  carriers,
}: {
  open: boolean;
  onClose: () => void;
  route: RouteType | null;
  carriers: { id: string; code: string; name: string; type: string; siteName: string }[];
}) {
  const [selected, setSelected] = useState<string[]>([]);
  const [filterSite, setFilterSite] = useState('');

  if (!open || !route) return null;

  const filtered = filterSite ? carriers.filter((c) => c.siteName === filterSite) : carriers;
  const uniqueSites = [...new Set(carriers.map((c) => c.siteName))];

  const toggle = (id: string) => {
    setSelected((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={onClose} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[640px] max-w-[90vw] max-h-[80vh] bg-white rounded-xl shadow-modal flex flex-col"
        >
          <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-border">
            <h2 className="text-lg font-semibold text-neutral-textPrimary">绑定载具到 {route.name}</h2>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-neutral-background transition-colors">
              <X size={18} className="text-neutral-textSecondary" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <div className="mb-3 flex items-center gap-2">
              <select
                value={filterSite}
                onChange={(e) => setFilterSite(e.target.value)}
                className="h-8 px-2 text-xs border border-neutral-border-strong rounded-md bg-white"
              >
                <option value="">全部网点</option>
                {uniqueSites.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <span className="text-xs text-neutral-textSecondary">已选 {selected.length} 个载具</span>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                  <th className="text-left px-3 py-2 w-10"><input type="checkbox" className="rounded" /></th>
                  <th className="text-left px-3 py-2">编号</th>
                  <th className="text-left px-3 py-2">名称</th>
                  <th className="text-left px-3 py-2">类型</th>
                  <th className="text-left px-3 py-2">所在网点</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 20).map((c) => (
                  <tr
                    key={c.id}
                    className="border-b border-neutral-border hover:bg-primary-light cursor-pointer transition-colors"
                    onClick={() => toggle(c.id)}
                  >
                    <td className="px-3 py-2">
                      <input
                        type="checkbox"
                        className="rounded"
                        checked={selected.includes(c.id)}
                        onChange={() => toggle(c.id)}
                      />
                    </td>
                    <td className="px-3 py-2 font-mono text-xs">{c.code}</td>
                    <td className="px-3 py-2">{c.name}</td>
                    <td className="px-3 py-2">{c.type}</td>
                    <td className="px-3 py-2 text-neutral-textSecondary">{c.siteName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-end gap-2 px-6 py-4 border-t border-neutral-border">
            <button onClick={onClose} className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors">取消</button>
            <button onClick={onClose} className="h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors">确认绑定</button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Flow Board View
// ============================================================

function FlowBoardView({
  open,
  onClose,
  routes,
  carriers,
}: {
  open: boolean;
  onClose: () => void;
  routes: RouteType[];
  carriers?: { id: string; code: string; type: string; status: string }[];
}) {
  void carriers;
  const [selectedRoute, setSelectedRoute] = useState<string>(routes[0]?.id || '');

  if (!open) return null;

  const route = routes.find((r) => r.id === selectedRoute) || routes[0];

  const nodeStatusData = route?.nodes.map((node, idx) => ({
    ...node,
    expectedArrival: `12/${String(20 + idx).padStart(2, '0')} ${String(8 + idx * 2).padStart(2, '0')}:00`,
    actualArrival: idx < 2 ? `12/${String(20 + idx).padStart(2, '0')} ${String(8 + idx * 2 + 1).padStart(2, '0')}:30` : '--',
    status: idx < 2 ? 'completed' : idx === 2 ? 'current' : 'pending',
    carrierCount: Math.floor(Math.random() * 80) + 10,
  })) || [];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex flex-col"
      >
        <div className="absolute inset-0 bg-[#F8FAFC]" />
        <div className="relative flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-3 border-b border-neutral-border bg-white">
            <div className="flex items-center gap-4">
              <LayoutDashboard size={18} className="text-primary" />
              <h2 className="text-base font-semibold text-neutral-textPrimary">流转看板</h2>
              <select
                value={selectedRoute}
                onChange={(e) => setSelectedRoute(e.target.value)}
                className="h-8 px-3 text-xs border border-neutral-border-strong rounded-md bg-white"
              >
                {routes.map((r) => (
                  <option key={r.id} value={r.id}>{r.name}</option>
                ))}
              </select>
            </div>
            <button
              onClick={onClose}
              className="h-8 px-4 text-xs border border-neutral-border rounded-md hover:bg-neutral-background transition-colors"
            >
              关闭
            </button>
          </div>

          {/* Board Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {/* Route Status Overview */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              {[
                { label: '正常流转', value: Math.floor((route?.carrierCount || 100) * 0.6), color: '#10B981', bg: '#ECFDF5' },
                { label: '警告', value: Math.floor((route?.carrierCount || 100) * 0.2), color: '#F59E0B', bg: '#FFFBEB' },
                { label: '报警', value: Math.floor((route?.carrierCount || 100) * 0.1), color: '#EF4444', bg: '#FEF2F2' },
                { label: '已完成', value: Math.floor((route?.carrierCount || 100) * 0.1), color: '#8B5CF6', bg: '#F5F3FF' },
              ].map((item) => (
                <div key={item.label} className="rounded-lg p-4" style={{ backgroundColor: item.bg }}>
                  <div className="text-xs mb-1" style={{ color: item.color }}>{item.label}</div>
                  <div className="text-2xl font-bold font-number" style={{ color: item.color }}>{item.value}</div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-3 gap-6">
              {/* Node Timeline */}
              <div className="col-span-2 bg-white rounded-lg shadow-card p-4">
                <h3 className="text-sm font-semibold text-neutral-textPrimary mb-4">节点流转状态</h3>
                <div className="space-y-0">
                  {nodeStatusData.map((node, idx) => (
                    <div key={node.id} className="flex gap-4">
                      <div className="flex flex-col items-center">
                        <div
                          className={cn('w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold', {
                            'bg-success text-white': node.status === 'completed',
                            'bg-primary text-white': node.status === 'current',
                            'bg-neutral-border text-neutral-textTertiary': node.status === 'pending',
                          })}
                        >
                          {node.sequence}
                        </div>
                        {idx < nodeStatusData.length - 1 && (
                          <div className={cn('w-0.5 h-16', node.status === 'completed' ? 'bg-success' : 'bg-neutral-border')} />
                        )}
                      </div>
                      <div className="flex-1 pb-6">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-neutral-textPrimary">{node.siteName}</span>
                          <span
                            className={cn('text-xs px-2 py-0.5 rounded', {
                              'bg-success-light text-success': node.status === 'completed',
                              'bg-primary-light text-primary': node.status === 'current',
                              'bg-neutral-background text-neutral-textTertiary': node.status === 'pending',
                            })}
                          >
                            {node.status === 'completed' ? '已完成' : node.status === 'current' ? '当前节点' : '待到达'}
                          </span>
                        </div>
                        <div className="flex gap-4 text-xs text-neutral-textSecondary">
                          <span>在途载具: <strong className="text-neutral-textPrimary">{node.carrierCount}</strong></span>
                          <span>预计到达: {node.expectedArrival}</span>
                          {node.actualArrival !== '--' && <span>实际到达: <strong className="text-success">{node.actualArrival}</strong></span>}
                          <span>滞留阈值: {node.dwellMinutes}分钟</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Panel */}
              <div className="space-y-4">
                {/* Efficiency Stats */}
                <div className="bg-white rounded-lg shadow-card p-4">
                  <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">效率指标</h3>
                  <div className="space-y-3">
                    {[
                      { label: '平均循环时间', value: `${route?.estimatedHours || '-'}h`, trend: '-5%' },
                      { label: '超时率', value: `${(Math.random() * 10).toFixed(1)}%`, trend: '-2%' },
                      { label: '呆滞率', value: `${(Math.random() * 8).toFixed(1)}%`, trend: '+1%' },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center justify-between">
                        <span className="text-xs text-neutral-textSecondary">{item.label}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold font-number text-neutral-textPrimary">{item.value}</span>
                          <span className={cn('text-[10px]', item.trend.startsWith('-') ? 'text-success' : 'text-danger')}>
                            {item.trend}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Active Alarms */}
                <div className="bg-white rounded-lg shadow-card p-4">
                  <h3 className="text-sm font-semibold text-neutral-textPrimary mb-3">实时报警</h3>
                  <div className="space-y-2">
                    {[
                      { type: '超时报警', node: '宁波生产基地仓库', time: '10分钟前', level: 'urgent' },
                      { type: '呆滞报警', node: '广州仓储中心', time: '30分钟前', level: 'important' },
                      { type: '偏离报警', node: '深圳配送中心', time: '1小时前', level: 'normal' },
                    ].map((alarm, i) => (
                      <div key={i} className="flex items-start gap-2 p-2 rounded-md bg-neutral-background">
                        <AlertTriangle
                          size={14}
                          className={cn('mt-0.5 flex-shrink-0', alarm.level === 'urgent' ? 'text-danger' : alarm.level === 'important' ? 'text-warning' : 'text-info')}
                        />
                        <div>
                          <div className="text-xs font-medium text-neutral-textPrimary">{alarm.type}</div>
                          <div className="text-[10px] text-neutral-textSecondary">{alarm.node} · {alarm.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Delete Confirm Modal
// ============================================================

function DeleteConfirmModal({ open, onClose, routeName }: { open: boolean; onClose: (confirmed?: boolean) => void; routeName: string }) {
  if (!open) return null;
  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 bg-[rgba(15,23,42,0.4)] backdrop-blur-sm" onClick={() => onClose()} />
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
          className="relative w-[400px] bg-white rounded-xl shadow-modal p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-danger-light flex items-center justify-center">
              <AlertTriangle size={20} className="text-danger" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-neutral-textPrimary">确认删除</h3>
              <p className="text-xs text-neutral-textSecondary">此操作不可撤销</p>
            </div>
          </div>
          <p className="text-sm text-neutral-textSecondary mb-6">
            确定要删除线路 <strong className="text-neutral-textPrimary">{routeName}</strong> 吗？绑定的载具将自动解绑。
          </p>
          <div className="flex justify-end gap-2">
            <button onClick={() => onClose()} className="h-8 px-4 text-xs text-neutral-textSecondary hover:bg-neutral-background rounded-md transition-colors">取消</button>
            <button onClick={() => onClose(true)} className="h-8 px-4 text-xs bg-danger text-white rounded-md hover:bg-danger-hover transition-colors">确认删除</button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// ============================================================
// Main Page Component
// ============================================================

export default function RouteConfigPage() {
  const mockData = useMockData();
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [searchName, setSearchName] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);
  const [detailRoute, setDetailRoute] = useState<RouteType | null>(null);
  const [editRoute, setEditRoute] = useState<RouteType | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showFlowBoard, setShowFlowBoard] = useState(false);
  const [bindRoute, setBindRoute] = useState<RouteType | null>(null);
  const [deleteRoute, setDeleteRoute] = useState<RouteType | null>(null);
  const [showMoreMenu, setShowMoreMenu] = useState<string | null>(null);

  const stats = useMemo(() => {
    const all = mockData.routes;
    return {
      total: all.length,
      active: all.filter((r) => r.status === 'active').length,
      alarmToday: 7,
      avgCycleTime: '2.3天',
    };
  }, [mockData.routes]);

  const filteredRoutes = useMemo(() => {
    let result = [...mockData.routes];
    if (statusFilter !== 'all') {
      result = result.filter((r) => r.status === statusFilter);
    }
    if (searchName) {
      result = result.filter((r) => r.name.toLowerCase().includes(searchName.toLowerCase()) || r.code.toLowerCase().includes(searchName.toLowerCase()));
    }
    return result;
  }, [mockData.routes, statusFilter, searchName]);

  const totalPages = Math.ceil(filteredRoutes.length / pageSize);
  const paginatedRoutes = filteredRoutes.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const carrierMap = useMemo(() => mockData.carriers.map((c) => ({
    id: c.id, code: c.code, name: c.name, type: c.type, status: c.status, siteName: c.siteName,
  })), [mockData.carriers]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) setCurrentPage(page);
  };

  const handleCopyRoute = (route: RouteType) => {
    setEditRoute({ ...route, id: `route-${Date.now()}`, name: `${route.name} (副本)`, code: `${route.code}-C` });
    setShowCreateModal(true);
    setShowMoreMenu(null);
  };

  return (
    <div className="animate-fade-in-up">
      {/* Page Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-2xl font-bold text-neutral-textPrimary tracking-tight">流转线路配置</h1>
          <p className="text-sm text-neutral-textSecondary mt-1">共 {mockData.routes.length} 条线路</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowFlowBoard(true)}
            className="h-9 px-4 flex items-center gap-2 text-sm border border-neutral-border bg-white text-neutral-textPrimary rounded-md hover:bg-neutral-background transition-colors"
          >
            <LayoutDashboard size={16} />
            流转看板
          </button>
          <button
            onClick={() => { setEditRoute(null); setShowCreateModal(true); }}
            className="h-9 px-4 flex items-center gap-2 text-sm bg-primary text-white rounded-md hover:bg-primary-hover transition-colors shadow-sm"
          >
            <Plus size={16} />
            创建线路
          </button>
          <button className="h-9 px-4 flex items-center gap-2 text-sm border border-neutral-border bg-white text-neutral-textPrimary rounded-md hover:bg-neutral-background transition-colors">
            <Download size={16} />
            导出
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4 mb-5">
        <KPICard title="路线总数" value={stats.total} color="#2563EB" icon={Route} />
        <KPICard title="启用中" value={stats.active} color="#10B981" icon={CheckCircle} />
        <KPICard title="今日报警" value={stats.alarmToday} color="#EF4444" icon={AlertTriangle} />
        <KPICard title="平均流转时长" value={stats.avgCycleTime} color="#06B6D4" icon={Timer} />
      </div>

      {/* Filter Bar */}
      <div className="bg-white rounded-lg shadow-card p-4 mb-4">
        <div className="flex flex-wrap gap-3 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs text-neutral-textSecondary mb-1">线路名称/编码</label>
            <div className="relative">
              <input
                type="text"
                placeholder="搜索线路..."
                value={searchName}
                onChange={(e) => setSearchName(e.target.value)}
                className="w-full h-8 px-3 text-xs border border-neutral-border-strong rounded-md focus:outline-none focus:border-primary focus:shadow-focus"
              />
            </div>
          </div>
          <div className="min-w-[120px]">
            <label className="block text-xs text-neutral-textSecondary mb-1">状态</label>
            <div className="flex gap-1 p-0.5 bg-neutral-background rounded-md">
              {[
                { key: 'all' as const, label: '全部' },
                { key: 'active' as const, label: '启用' },
                { key: 'inactive' as const, label: '停用' },
              ].map((s) => (
                <button
                  key={s.key}
                  onClick={() => { setStatusFilter(s.key); setCurrentPage(1); }}
                  className={cn(
                    'flex-1 h-7 text-xs rounded transition-colors',
                    statusFilter === s.key ? 'bg-white text-primary shadow-sm font-medium' : 'text-neutral-textSecondary hover:text-neutral-textPrimary'
                  )}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={() => { setSearchName(''); setStatusFilter('all'); }}
            className="h-8 px-3 text-xs text-neutral-textSecondary hover:text-primary hover:bg-primary-light rounded-md transition-colors"
          >
            重置
          </button>
        </div>
      </div>

      {/* Data Table */}
      <div className="bg-white rounded-lg shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-neutral-surface-elevated text-neutral-textSecondary text-xs">
                <th className="text-left px-4 py-2.5 w-10"><input type="checkbox" className="rounded" /></th>
                <th className="text-left px-4 py-2.5 font-medium">线路名称</th>
                <th className="text-left px-4 py-2.5 font-medium">状态</th>
                <th className="text-left px-4 py-2.5 font-medium">节点数</th>
                <th className="text-left px-4 py-2.5 font-medium">起始网点</th>
                <th className="text-left px-4 py-2.5 font-medium">目标网点</th>
                <th className="text-left px-4 py-2.5 font-medium">预估时长</th>
                <th className="text-left px-4 py-2.5 font-medium">绑定载具</th>
                <th className="text-left px-4 py-2.5 font-medium">类型</th>
                <th className="text-left px-4 py-2.5 font-medium">创建时间</th>
                <th className="text-left px-4 py-2.5 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginatedRoutes.map((route, index) => (
                <tr
                  key={route.id}
                  className={cn('border-b border-neutral-border hover:bg-primary-light transition-colors', index % 2 === 1 && 'bg-[#F8FAFC]')}
                >
                  <td className="px-4 py-3"><input type="checkbox" className="rounded" /></td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => setDetailRoute(route)}
                      className="text-sm font-medium text-primary hover:underline"
                    >
                      {route.name}
                    </button>
                    <div className="text-[10px] text-neutral-textTertiary font-mono">{route.code}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div
                      onClick={(e) => { e.stopPropagation(); }}
                      className={cn('w-8 h-4 rounded-full relative cursor-pointer inline-block', route.status === 'active' ? 'bg-primary' : 'bg-neutral-border')}
                    >
                      <div
                        className={cn('w-3.5 h-3.5 bg-white rounded-full absolute top-0.5 transition-all shadow-sm')}
                        style={{ left: route.status === 'active' ? '18px' : '2px' }}
                      />
                    </div>
                  </td>
                  <td className="px-4 py-3 font-number text-neutral-textPrimary">{route.nodes.length}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary">{route.nodes[0]?.siteName}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary">{route.nodes[route.nodes.length - 1]?.siteName}</td>
                  <td className="px-4 py-3 text-neutral-textSecondary">{route.estimatedHours}小时</td>
                  <td className="px-4 py-3 font-number text-neutral-textPrimary">{route.carrierCount}</td>
                  <td className="px-4 py-3">
                    <span className={cn('text-xs', route.type === 'fixed' ? 'text-primary' : 'text-warning')}>
                      {route.type === 'fixed' ? '固定' : '临时'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-neutral-textSecondary text-xs">{route.createdAt}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setDetailRoute(route)} className="p-1 rounded hover:bg-neutral-background transition-colors" title="详情">
                        <Eye size={14} className="text-primary" />
                      </button>
                      <button onClick={() => { setEditRoute(route); setShowCreateModal(true); }} className="p-1 rounded hover:bg-neutral-background transition-colors" title="编辑">
                        <Edit3 size={14} className="text-warning" />
                      </button>
                      <button onClick={() => handleCopyRoute(route)} className="p-1 rounded hover:bg-neutral-background transition-colors" title="复制">
                        <Copy size={14} className="text-info" />
                      </button>
                      <button onClick={() => setDeleteRoute(route)} className="p-1 rounded hover:bg-neutral-background transition-colors" title="删除">
                        <Trash2 size={14} className="text-danger" />
                      </button>
                      <div className="relative">
                        <button
                          onClick={() => setShowMoreMenu(showMoreMenu === route.id ? null : route.id)}
                          className="p-1 rounded hover:bg-neutral-background transition-colors"
                          title="更多"
                        >
                          <MoreHorizontal size={14} className="text-neutral-textSecondary" />
                        </button>
                        {showMoreMenu === route.id && (
                          <div className="absolute right-0 top-full mt-1 w-36 bg-white rounded-lg shadow-dropdown border border-neutral-border z-10 py-1">
                            <button
                              onClick={() => { setBindRoute(route); setShowMoreMenu(null); }}
                              className="w-full text-left px-3 py-2 text-xs text-neutral-textPrimary hover:bg-neutral-background transition-colors flex items-center gap-2"
                            >
                              <LinkIcon size={12} />
                              绑定载具
                            </button>
                            <button
                              onClick={() => { setShowFlowBoard(true); setShowMoreMenu(null); }}
                              className="w-full text-left px-3 py-2 text-xs text-neutral-textPrimary hover:bg-neutral-background transition-colors flex items-center gap-2"
                            >
                              <Activity size={12} />
                              查看监控
                            </button>
                            <button
                              onClick={() => { setShowFlowBoard(true); setShowMoreMenu(null); }}
                              className="w-full text-left px-3 py-2 text-xs text-neutral-textPrimary hover:bg-neutral-background transition-colors flex items-center gap-2"
                            >
                              <LayoutDashboard size={12} />
                              流转看板
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {paginatedRoutes.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <Route size={64} className="text-neutral-border mb-4" />
            <p className="text-neutral-textSecondary text-sm">暂无流转线路</p>
            <button onClick={() => { setEditRoute(null); setShowCreateModal(true); }} className="mt-3 h-8 px-4 text-xs bg-primary text-white rounded-md hover:bg-primary-hover transition-colors">
              创建线路
            </button>
          </div>
        )}

        {paginatedRoutes.length > 0 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-neutral-border">
            <span className="text-xs text-neutral-textSecondary">共 {filteredRoutes.length} 条，第 {currentPage}/{totalPages} 页</span>
            <div className="flex items-center gap-1">
              <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-background disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={cn('w-8 h-8 flex items-center justify-center rounded-md text-xs transition-colors', currentPage === page ? 'bg-primary text-white' : 'border border-neutral-border hover:bg-neutral-background text-neutral-textSecondary')}
                >
                  {page}
                </button>
              ))}
              <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages} className="w-8 h-8 flex items-center justify-center rounded-md border border-neutral-border hover:bg-neutral-background disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      <AnimatePresence>
        {detailRoute && (
          <RouteDetailDrawer
            route={detailRoute}
            onClose={() => setDetailRoute(null)}
            carriers={carrierMap}
            alarms={mockData.alarms.map((a) => ({ id: a.id, type: a.type, level: a.level, message: a.message, createdAt: a.createdAt, status: a.status }))}
          />
        )}
      </AnimatePresence>

      {/* Create/Edit Modal */}
      <RouteEditModal
        open={showCreateModal}
        onClose={() => { setShowCreateModal(false); setEditRoute(null); }}
        route={editRoute}
        sites={mockData.sites.map((s) => ({ id: s.id, name: s.name }))}
      />

      {/* Carrier Binding Modal */}
      <CarrierBindingModal
        open={!!bindRoute}
        onClose={() => setBindRoute(null)}
        route={bindRoute}
        carriers={carrierMap}
      />

      {/* Flow Board */}
      <FlowBoardView
        open={showFlowBoard}
        onClose={() => setShowFlowBoard(false)}
        routes={mockData.routes}
        carriers={carrierMap}
      />

      {/* Delete Confirm */}
      <DeleteConfirmModal
        open={!!deleteRoute}
        onClose={() => { setDeleteRoute(null); }}
        routeName={deleteRoute?.name || ''}
      />

      {/* Click outside to close more menu */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-0" onClick={() => setShowMoreMenu(null)} />
      )}
    </div>
  );
}
