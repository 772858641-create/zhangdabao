import { useMemo } from 'react';
import {
  Database,
  Flame,
  Thermometer,
  Snowflake,
  HardDrive,
  Zap,
  Archive,
  ArrowRight,
  Trash2,
  Clock,
  Gauge,
  ChevronRight,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { cn } from '@/lib/utils';

/* ================================================================
   Types
   ================================================================ */

interface StorageLayer {
  name: string;
  icon: React.ElementType;
  iconColor: string;
  iconBg: string;
  medium: string;
  mediumIcon: React.ElementType;
  dataRange: string;
  queryPerf: string;
  compressRatio: string;
  used: number;
  capacity: number;
  unit: string;
  duration: string;
  borderColor: string;
  chartColor: string;
}

interface RetentionPolicy {
  id: string;
  dataType: string;
  retention: string;
  layers: string;
  autoCleanup: boolean;
  status: 'active' | 'paused';
}

/* ================================================================
   Mock Data
   ================================================================ */

const storageLayers: StorageLayer[] = [
  {
    name: '热数据层',
    icon: Flame,
    iconColor: '#EF4444',
    iconBg: '#FEF2F2',
    medium: 'SSD高速存储',
    mediumIcon: Zap,
    dataRange: '最近7天原始报文',
    queryPerf: '秒级响应',
    compressRatio: '不压缩 (1:1)',
    used: 180,
    capacity: 250,
    unit: 'GB',
    duration: '7天',
    borderColor: '#EF4444',
    chartColor: '#EF4444',
  },
  {
    name: '温数据层',
    icon: Thermometer,
    iconColor: '#F59E0B',
    iconBg: '#FFFBEB',
    medium: '高性能磁盘',
    mediumIcon: HardDrive,
    dataRange: '7-90天小时聚合',
    queryPerf: '分钟级响应',
    compressRatio: '5:1 压缩',
    used: 890,
    capacity: 1200,
    unit: 'GB',
    duration: '90天',
    borderColor: '#F59E0B',
    chartColor: '#F59E0B',
  },
  {
    name: '冷数据层',
    icon: Snowflake,
    iconColor: '#06B6D4',
    iconBg: '#ECFEFF',
    medium: '归档存储',
    mediumIcon: Archive,
    dataRange: '90天+日级聚合',
    queryPerf: '小时级响应',
    compressRatio: '20:1 压缩',
    used: 1330,
    capacity: 5000,
    unit: 'GB',
    duration: '永久/2年',
    borderColor: '#06B6D4',
    chartColor: '#06B6D4',
  },
];

const retentionPolicies: RetentionPolicy[] = [
  { id: 'rp-1', dataType: '原始扫描记录', retention: '30天', layers: '热 → 删除', autoCleanup: true, status: 'active' },
  { id: 'rp-2', dataType: '设备位置轨迹', retention: '90天', layers: '热 → 温 → 删除', autoCleanup: true, status: 'active' },
  { id: 'rp-3', dataType: '载具状态变更日志', retention: '1年', layers: '热 → 温 → 冷', autoCleanup: true, status: 'active' },
  { id: 'rp-4', dataType: '报警事件记录', retention: '2年', layers: '热 → 温 → 冷', autoCleanup: true, status: 'active' },
  { id: 'rp-5', dataType: '业务操作日志', retention: '永久', layers: '热 → 温 → 冷', autoCleanup: false, status: 'active' },
];

function generateTrendData() {
  const data: Array<{ date: string; hot: number; warm: number; cold: number }> = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const label = `${d.getMonth() + 1}/${d.getDate()}`;
    const hot = 150 + Math.floor(Math.random() * 40) + Math.floor((30 - i) * 1.2);
    const warm = 700 + Math.floor(Math.random() * 150) + Math.floor((30 - i) * 6);
    const cold = 1100 + Math.floor(Math.random() * 200) + Math.floor((30 - i) * 8);
    data.push({ date: label, hot, warm, cold });
  }
  return data;
}

/* ================================================================
   Helpers
   ================================================================ */

function KPICard({ title, value, subtext, color, icon: Icon }: {
  title: string; value: string | number; subtext?: string; color: string; icon: React.ElementType;
}) {
  return (
    <Card className="bg-neutral-surface border-neutral-border hover:shadow-card-hover transition-shadow duration-200">
      <CardContent className="p-4 flex items-start gap-4">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}15` }}>
          <Icon size={20} style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs text-neutral-textSecondary mb-1">{title}</p>
          <p className="text-[28px] font-semibold leading-tight text-neutral-textPrimary font-number">{value}</p>
          {subtext && <p className="text-xs text-neutral-textTertiary mt-1">{subtext}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

function StatusBadge({ active }: { active: boolean }) {
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
      active ? 'bg-success/10 text-success' : 'bg-neutral-background text-neutral-textTertiary'
    )}>
      {active ? '启用' : '暂停'}
    </span>
  );
}

function LayerCard({ layer }: { layer: StorageLayer }) {
  const Icon = layer.icon;
  const MediumIcon = layer.mediumIcon;
  const pct = Math.round((layer.used / layer.capacity) * 100);

  return (
    <Card className="bg-neutral-surface border-neutral-border overflow-hidden" style={{ borderTop: `3px solid ${layer.borderColor}` }}>
      <CardContent className="p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: layer.iconBg }}>
            <Icon size={18} style={{ color: layer.iconColor }} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-neutral-textPrimary">{layer.name}</h3>
            <p className="text-xs text-neutral-textTertiary">保留 {layer.duration}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MediumIcon size={14} className="text-neutral-textTertiary" />
            <span className="text-xs text-neutral-textSecondary">{layer.medium}</span>
          </div>
          <div className="flex items-center gap-2">
            <Database size={14} className="text-neutral-textTertiary" />
            <span className="text-xs text-neutral-textSecondary">{layer.dataRange}</span>
          </div>
          <div className="flex items-center gap-2">
            <Gauge size={14} className="text-neutral-textTertiary" />
            <span className="text-xs text-neutral-textSecondary">{layer.queryPerf}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} className="text-neutral-textTertiary" />
            <span className="text-xs text-neutral-textSecondary">压缩比 {layer.compressRatio}</span>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-neutral-border">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs text-neutral-textSecondary">已使用</span>
            <span className="text-xs font-medium text-neutral-textPrimary font-number">{layer.used}{layer.unit} / {layer.capacity}{layer.unit}</span>
          </div>
          <Progress value={pct} className="h-2" />
          <p className="text-xs text-neutral-textTertiary mt-1 text-right font-number">{pct}%</p>
        </div>
      </CardContent>
    </Card>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function TimeSeriesStorageTab() {
  const trendData = useMemo(() => generateTrendData(), []);

  return (
    <div className="space-y-5">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KPICard title="总存储量" value="2.4TB" subtext="三层合计" color="#2563EB" icon={Database} />
        <KPICard title="热数据层" value="180GB" subtext="保留7天" color="#EF4444" icon={Flame} />
        <KPICard title="温数据层" value="890GB" subtext="保留90天" color="#F59E0B" icon={Thermometer} />
        <KPICard title="冷数据层" value="1.33TB" subtext="永久/2年" color="#06B6D4" icon={Snowflake} />
      </div>

      {/* Three Storage Layers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {storageLayers.map((layer) => (
          <LayerCard key={layer.name} layer={layer} />
        ))}
      </div>

      {/* Retention Policy Table */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Clock size={16} className="text-neutral-textSecondary" />
            数据保留策略配置
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-neutral-surface-elevated">
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">数据类型</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">保留时长</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">存储层级流转</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">自动清理</th>
                  <th className="px-4 py-2.5 text-left text-[13px] font-medium text-neutral-textSecondary whitespace-nowrap">状态</th>
                </tr>
              </thead>
              <tbody>
                {retentionPolicies.map((rp) => (
                  <tr key={rp.id} className="border-b border-neutral-border hover:bg-neutral-background transition-colors">
                    <td className="px-4 py-3 text-sm text-neutral-textPrimary font-medium">{rp.dataType}</td>
                    <td className="px-4 py-3 text-sm text-neutral-textSecondary font-number">{rp.retention}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        {rp.layers.split(' → ').map((part, i, arr) => (
                          <span key={i} className="flex items-center gap-1">
                            <span className={cn(
                              'text-xs px-1.5 py-0.5 rounded font-medium',
                              part === '热' ? 'bg-danger/10 text-danger' :
                              part === '温' ? 'bg-warning/10 text-warning' :
                              part === '冷' ? 'bg-info/10 text-info' :
                              'bg-neutral-background text-neutral-textTertiary'
                            )}>{part}</span>
                            {i < arr.length - 1 && <ArrowRight size={12} className="text-neutral-textTertiary" />}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {rp.autoCleanup ? (
                        <span className="inline-flex items-center gap-1 text-xs text-success">
                          <Trash2 size={12} /> 自动清理
                        </span>
                      ) : (
                        <span className="text-xs text-neutral-textTertiary">手动管理</span>
                      )}
                    </td>
                    <td className="px-4 py-3"><StatusBadge active={rp.status === 'active'} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Storage Trend Area Chart */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <Database size={16} className="text-neutral-textSecondary" />
            近30天三层存储容量变化趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={320}>
            <AreaChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <YAxis tick={{ fontSize: 11, fill: '#475569' }} axisLine={{ stroke: '#E2E8F0' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#FFFFFF',
                  border: '1px solid #E2E8F0',
                  borderRadius: '6px',
                  fontSize: '12px',
                }}
                formatter={(value: number, name: string) => {
                  const label = name === 'hot' ? '热数据层' : name === 'warm' ? '温数据层' : '冷数据层';
                  return [`${value} GB`, label];
                }}
              />
              <Legend wrapperStyle={{ fontSize: '12px' }} formatter={(value: string) => {
                return value === 'hot' ? '热数据层' : value === 'warm' ? '温数据层' : '冷数据层';
              }} />
              <Area type="monotone" dataKey="hot" stroke="#EF4444" fill="#EF4444" fillOpacity={0.15} strokeWidth={2} />
              <Area type="monotone" dataKey="warm" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.15} strokeWidth={2} />
              <Area type="monotone" dataKey="cold" stroke="#06B6D4" fill="#06B6D4" fillOpacity={0.15} strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Data Lifecycle Flow */}
      <Card className="bg-neutral-surface border-neutral-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary flex items-center gap-2">
            <ChevronRight size={16} className="text-neutral-textSecondary" />
            数据生命周期流转示意
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 py-6">
            {/* Hot */}
            <div className="flex flex-col items-center gap-2 px-6 py-4 rounded-lg border-2" style={{ borderColor: '#EF4444', backgroundColor: '#FEF2F2' }}>
              <Flame size={24} style={{ color: '#EF4444' }} />
              <span className="text-sm font-semibold text-neutral-textPrimary">热数据</span>
              <span className="text-xs text-neutral-textSecondary">7天 / 原始报文</span>
              <span className="text-xs text-neutral-textTertiary">不压缩</span>
            </div>

            <div className="flex flex-col items-center">
              <ArrowRight size={20} className="text-neutral-textTertiary hidden md:block" />
              <ArrowRight size={20} className="text-neutral-textTertiary block md:hidden rotate-90" />
              <span className="text-[10px] text-neutral-textTertiary mt-1">压缩 5:1</span>
            </div>

            {/* Warm */}
            <div className="flex flex-col items-center gap-2 px-6 py-4 rounded-lg border-2" style={{ borderColor: '#F59E0B', backgroundColor: '#FFFBEB' }}>
              <Thermometer size={24} style={{ color: '#F59E0B' }} />
              <span className="text-sm font-semibold text-neutral-textPrimary">温数据</span>
              <span className="text-xs text-neutral-textSecondary">90天 / 小时聚合</span>
              <span className="text-xs text-neutral-textTertiary">5:1 压缩</span>
            </div>

            <div className="flex flex-col items-center">
              <ArrowRight size={20} className="text-neutral-textTertiary hidden md:block" />
              <ArrowRight size={20} className="text-neutral-textTertiary block md:hidden rotate-90" />
              <span className="text-[10px] text-neutral-textTertiary mt-1">压缩 20:1</span>
            </div>

            {/* Cold */}
            <div className="flex flex-col items-center gap-2 px-6 py-4 rounded-lg border-2" style={{ borderColor: '#06B6D4', backgroundColor: '#ECFEFF' }}>
              <Snowflake size={24} style={{ color: '#06B6D4' }} />
              <span className="text-sm font-semibold text-neutral-textPrimary">冷数据</span>
              <span className="text-xs text-neutral-textSecondary">永久/2年 / 日级聚合</span>
              <span className="text-xs text-neutral-textTertiary">20:1 压缩</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
