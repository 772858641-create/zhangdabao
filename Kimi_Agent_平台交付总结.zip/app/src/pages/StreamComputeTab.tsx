import { motion } from 'framer-motion';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  Layers,
  Play,
  ArrowUpRight,
  Clock,
  Package,
  Unlink,
  MapPin,
  Wifi,
  Timer,
  GitBranch,
  BarChart3,
  Eye,
  Pause,
  RotateCcw,
  Radio,
  Sparkles,
  Zap,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ================================================================
   Theme
   ================================================================ */

const THEME = {
  spaceBg: '#070B19',
  spaceBgLight: '#0B1128',
  surfaceElevated: '#111D3D',
  borderSubtle: '#1A2B52',
  borderMedium: '#243B6D',
  textPrimary: '#E8EEF7',
  textSecondary: '#7A8BAF',
  textTertiary: '#4A5D85',
  auroraCyan: '#00D4FF',
  auroraGreen: '#00FF9D',
  auroraPurple: '#9D4EDD',
  auroraOrange: '#FF8C42',
  auroraPink: '#F72585',
  auroraYellow: '#FFD166',
};

/* ================================================================
   Chart Styles
   ================================================================ */

const chartTooltipStyle = {
  backgroundColor: 'rgba(7, 11, 25, 0.95)',
  border: '1px solid rgba(0, 212, 255, 0.2)',
  borderRadius: '8px',
  fontSize: '12px',
  color: '#E8EEF7',
  backdropFilter: 'blur(8px)',
  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
};

/* ================================================================
   Types
   ================================================================ */

interface StreamTask {
  id: string;
  name: string;
  status: '运行中';
  triggers: string;
  latency: string;
  description: string;
  lastTrigger: string;
  icon: React.ElementType;
}

/* ================================================================
   Mock Data
   ================================================================ */

const STREAM_TASKS: StreamTask[] = [
  {
    id: 'st1',
    name: '出入库判定流',
    status: '运行中',
    triggers: '3,240',
    latency: '180ms',
    description: '网关扫描蓝牙标签后30秒内完成标签→载具→网点→围栏关联计算',
    lastTrigger: '14:32:18',
    icon: Package,
  },
  {
    id: 'st2',
    name: '标签分离检测流',
    status: '运行中',
    triggers: '156',
    latency: '120ms',
    description: '15分钟滑动窗口内无扫描记录即判定疑似分离',
    lastTrigger: '14:28:05',
    icon: Unlink,
  },
  {
    id: 'st3',
    name: '围栏越界判定流',
    status: '运行中',
    triggers: '892',
    latency: '90ms',
    description: '定位器坐标进入/离开电子围栏多边形实时计算',
    lastTrigger: '14:31:42',
    icon: MapPin,
  },
  {
    id: 'st4',
    name: '设备在线状态流',
    status: '运行中',
    triggers: '2,340',
    latency: '50ms',
    description: '心跳超时自动标记离线：定位器2h/网关10min/标签15min',
    lastTrigger: '14:32:01',
    icon: Wifi,
  },
  {
    id: 'st5',
    name: '载具位置融合流',
    status: '运行中',
    triggers: '8,640',
    latency: '200ms',
    description: '多源位置数据实时优先级融合输出最佳位置',
    lastTrigger: '14:32:15',
    icon: Zap,
  },
  {
    id: 'st6',
    name: '在途超时检测流',
    status: '运行中',
    triggers: '45',
    latency: '300ms',
    description: '对在途载具调拨单预计到达时间倒计时监控',
    lastTrigger: '13:45:30',
    icon: Timer,
  },
];

const EVENT_OUTPUT_DATA = [
  { day: '01-15', inout: 3200, separate: 150, fence: 880, online: 2400, merge: 8500, timeout: 42 },
  { day: '01-16', inout: 3100, separate: 145, fence: 890, online: 2350, merge: 8600, timeout: 48 },
  { day: '01-17', inout: 3240, separate: 156, fence: 892, online: 2340, merge: 8640, timeout: 45 },
  { day: '01-18', inout: 3300, separate: 160, fence: 900, online: 2400, merge: 8700, timeout: 50 },
  { day: '01-19', inout: 3150, separate: 148, fence: 885, online: 2380, merge: 8550, timeout: 44 },
  { day: '01-20', inout: 3280, separate: 155, fence: 895, online: 2360, merge: 8620, timeout: 47 },
  { day: '01-21', inout: 3210, separate: 152, fence: 888, online: 2340, merge: 8580, timeout: 46 },
];

/* ================================================================
   Glass Card Component
   ================================================================ */

function GlassCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn('rounded-[10px] backdrop-blur-[12px]', className)}
      style={{
        background: 'rgba(11, 17, 40, 0.7)',
        border: '1px solid rgba(26, 43, 82, 0.8)',
        boxShadow: '0 2px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.03)',
      }}
    >
      {children}
    </div>
  );
}

/* ================================================================
   KPI Card Component
   ================================================================ */

interface KPICardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  accent: string;
}

function KPICard({ icon: Icon, label, value, sub, accent }: KPICardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="rounded-[10px] p-4"
      style={{
        background: 'rgba(11, 17, 40, 0.8)',
        border: `1px solid ${accent}40`,
        boxShadow: `0 0 16px ${accent}10, inset 0 1px 0 rgba(255,255,255,0.04)`,
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Icon size={16} style={{ color: accent }} />
        <span className="text-[11px] font-medium" style={{ color: THEME.textSecondary }}>{label}</span>
      </div>
      <div className="text-[22px] font-bold font-mono" style={{ color: THEME.textPrimary }}>{value}</div>
      <div className="text-xs mt-1" style={{ color: THEME.textTertiary }}>{sub}</div>
    </motion.div>
  );
}

/* ================================================================
   Status Badge Component
   ================================================================ */

function RunningBadge() {
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-[6px] text-[10px] font-medium"
      style={{
        background: 'rgba(0, 255, 157, 0.12)',
        color: '#00FF9D',
        border: '1px solid rgba(0, 255, 157, 0.3)',
      }}
    >
      运行中
    </span>
  );
}

/* ================================================================
   Stream Task Card Component
   ================================================================ */

function StreamTaskCard({ task, index }: { task: StreamTask; index: number }) {
  const Icon = task.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.08 }}
      className="rounded-[10px] p-4 transition-all duration-200 hover:border-cyan-500/30"
      style={{
        background: 'rgba(11, 17, 40, 0.8)',
        border: '1px solid rgba(26, 43, 82, 0.8)',
        boxShadow: '0 2px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.03)',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = 'rgba(0, 212, 255, 0.3)';
        e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 212, 255, 0.08), 0 2px 16px rgba(0, 0, 0, 0.3)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = 'rgba(26, 43, 82, 0.8)';
        e.currentTarget.style.boxShadow = '0 2px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.03)';
      }}
    >
      {/* Top row: name + badge */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <Icon size={16} style={{ color: THEME.auroraCyan }} />
          <span className="text-[13px] font-semibold truncate" style={{ color: THEME.textPrimary }}>{task.name}</span>
        </div>
        <RunningBadge />
      </div>

      {/* Stats row */}
      <div className="flex items-center gap-6 mb-3">
        <div>
          <div className="text-[10px]" style={{ color: THEME.textTertiary }}>今日触发</div>
          <div className="text-sm font-bold font-mono" style={{ color: THEME.textPrimary }}>{task.triggers}</div>
        </div>
        <div>
          <div className="text-[10px]" style={{ color: THEME.textTertiary }}>平均延迟</div>
          <div className="text-sm font-bold font-mono" style={{ color: THEME.auroraOrange }}>{task.latency}</div>
        </div>
      </div>

      {/* Description */}
      <p className="text-xs leading-relaxed mb-3 line-clamp-2" style={{ color: THEME.textSecondary }}>
        {task.description}
      </p>

      {/* Divider */}
      <div className="h-px mb-3" style={{ background: 'rgba(26, 43, 82, 0.5)' }} />

      {/* Bottom row */}
      <div className="flex items-center justify-between">
        <span className="text-[11px]" style={{ color: THEME.textTertiary }}>
          最近触发: <span className="font-mono">{task.lastTrigger}</span>
        </span>
        <div className="flex items-center gap-1">
          <button
            className="p-1.5 rounded-md transition-colors"
            style={{ color: THEME.textTertiary }}
            onMouseEnter={(e) => (e.currentTarget.style.color = THEME.auroraCyan)}
            onMouseLeave={(e) => (e.currentTarget.style.color = THEME.textTertiary)}
            title="查看详情"
          >
            <Eye size={14} />
          </button>
          <button
            className="p-1.5 rounded-md transition-colors"
            style={{ color: THEME.textTertiary }}
            onMouseEnter={(e) => (e.currentTarget.style.color = THEME.auroraOrange)}
            onMouseLeave={(e) => (e.currentTarget.style.color = THEME.textTertiary)}
            title="暂停"
          >
            <Pause size={14} />
          </button>
          <button
            className="p-1.5 rounded-md transition-colors"
            style={{ color: THEME.textTertiary }}
            onMouseEnter={(e) => (e.currentTarget.style.color = THEME.auroraGreen)}
            onMouseLeave={(e) => (e.currentTarget.style.color = THEME.textTertiary)}
            title="重启"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

/* ================================================================
   Topology Node Component
   ================================================================ */

function TopoNode({ icon: Icon, label, color = THEME.auroraCyan, small = false }: {
  icon: React.ElementType;
  label: string;
  color?: string;
  small?: boolean;
}) {
  return (
    <div
      className={cn(
        'flex items-center gap-1.5 rounded-lg transition-all duration-200 hover:scale-105',
        small ? 'px-2.5 py-1.5' : 'px-3.5 py-2'
      )}
      style={{
        background: 'rgba(11, 17, 40, 0.9)',
        border: `1px solid ${color}66`,
        boxShadow: `0 0 12px ${color}1A`,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = color;
        e.currentTarget.style.boxShadow = `0 0 16px ${color}33`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = `${color}66`;
        e.currentTarget.style.boxShadow = `0 0 12px ${color}1A`;
      }}
    >
      <Icon size={small ? 12 : 14} style={{ color }} />
      <span className={cn('font-medium', small ? 'text-[10px]' : 'text-xs')} style={{ color: THEME.textPrimary }}>
        {label}
      </span>
    </div>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function StreamComputeTab() {
  return (
    <div className="space-y-5">
      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard icon={Layers} label="流任务总数" value="6" sub="个" accent={THEME.auroraCyan} />
        <KPICard icon={Play} label="运行中任务" value="6/6" sub="全部正常" accent={THEME.auroraGreen} />
        <KPICard icon={ArrowUpRight} label="今日事件输出" value="45.2K" sub="条" accent={THEME.auroraPurple} />
        <KPICard icon={Clock} label="平均处理延迟" value="230" sub="ms" accent={THEME.auroraOrange} />
      </div>

      {/* ── Stream Task Cards (3x2 grid) ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {STREAM_TASKS.map((task, idx) => (
          <StreamTaskCard key={task.id} task={task} index={idx} />
        ))}
      </div>

      {/* ── Row: Topology + Bar Chart ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Stream Processing Topology */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <GitBranch size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>流处理拓扑图</h3>
          </div>

          <div
            className="relative rounded-lg p-6 overflow-hidden"
            style={{
              background: 'rgba(7, 11, 25, 0.5)',
              backgroundImage: `
                linear-gradient(rgba(26, 43, 82, 0.2) 1px, transparent 1px),
                linear-gradient(90deg, rgba(26, 43, 82, 0.2) 1px, transparent 1px)
              `,
              backgroundSize: '20px 20px',
              minHeight: 280,
            }}
          >
            <div className="flex items-center justify-center h-full gap-3 flex-wrap">
              {/* Input Node */}
              <TopoNode icon={Radio} label="设备接入" color={THEME.auroraCyan} />

              {/* Arrow */}
              <ChevronRight size={20} style={{ color: 'rgba(0, 212, 255, 0.3)' }} />

              {/* Clean Node */}
              <TopoNode icon={Sparkles} label="数据清洗" color={THEME.auroraCyan} />

              {/* Arrow */}
              <ChevronRight size={20} style={{ color: 'rgba(0, 212, 255, 0.3)' }} />

              {/* Task Nodes */}
              <div className="flex flex-wrap gap-2 max-w-[280px]">
                <TopoNode icon={Package} label="出入库" color={THEME.auroraPurple} small />
                <TopoNode icon={Unlink} label="分离" color={THEME.auroraPurple} small />
                <TopoNode icon={MapPin} label="围栏" color={THEME.auroraPurple} small />
                <TopoNode icon={Wifi} label="在线" color={THEME.auroraPurple} small />
                <TopoNode icon={Zap} label="融合" color={THEME.auroraPurple} small />
                <TopoNode icon={Timer} label="超时" color={THEME.auroraPurple} small />
              </div>

              {/* Arrow */}
              <ChevronRight size={20} style={{ color: 'rgba(0, 212, 255, 0.3)' }} />

              {/* Output Node */}
              <TopoNode icon={ArrowUpRight} label="业务输出" color={THEME.auroraGreen} />
            </div>
          </div>
        </GlassCard>

        {/* Event Output Statistics */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>事件输出统计</h3>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={EVENT_OUTPUT_DATA} barGap={1}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(26, 43, 82, 0.4)" />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 11, fill: '#4A5D85' }}
                axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
              />
              <YAxis
                tick={{ fontSize: 11, fill: '#4A5D85' }}
                axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
              />
              <Tooltip contentStyle={chartTooltipStyle as any} />
              <Legend
                wrapperStyle={{ fontSize: '10px', color: THEME.textSecondary }}
                iconSize={8}
              />
              <Bar dataKey="inout" name="出入库判定" fill="#00D4FF" barSize={10} radius={[2, 2, 0, 0]} />
              <Bar dataKey="separate" name="标签分离" fill="#00FF9D" barSize={10} radius={[2, 2, 0, 0]} />
              <Bar dataKey="fence" name="围栏越界" fill="#9D4EDD" barSize={10} radius={[2, 2, 0, 0]} />
              <Bar dataKey="online" name="设备在线" fill="#FF8C42" barSize={10} radius={[2, 2, 0, 0]} />
              <Bar dataKey="merge" name="载具融合" fill="#F72585" barSize={10} radius={[2, 2, 0, 0]} />
              <Bar dataKey="timeout" name="在途超时" fill="#FFD166" barSize={10} radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </GlassCard>
      </div>
    </div>
  );
}
