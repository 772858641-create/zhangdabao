import { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface Rule {
  id: string;
  name: string;
  deviceType: string;
  triggerField: string;
  operator: string;
  threshold: string;
  action: string;
  status: boolean;
  hits: number;
}

const initialRules: Rule[] = [
  { id: 'R-001', name: '高温告警规则', deviceType: '传感器', triggerField: 'temperature', operator: '>', threshold: '80', action: '告警', status: true, hits: 142 },
  { id: 'R-002', name: '低电量通知', deviceType: '定位器', triggerField: 'battery', operator: '<=', threshold: '20', action: '通知', status: true, hits: 89 },
  { id: 'R-003', name: '信号弱Webhook', deviceType: '车载终端', triggerField: 'signal', operator: '<', threshold: '30', action: 'webhook', status: false, hits: 34 },
  { id: 'R-004', name: '超速检测', deviceType: '车载终端', triggerField: 'speed', operator: '>', threshold: '120', action: '告警', status: true, hits: 12 },
  { id: 'R-005', name: '离线设备指令', deviceType: '定位器', triggerField: 'status', operator: '==', threshold: 'offline', action: '设备指令', status: true, hits: 56 },
  { id: 'R-006', name: '湿度异常', deviceType: '传感器', triggerField: 'humidity', operator: '>', threshold: '90', action: '告警', status: false, hits: 8 },
];

const deviceTypeOptions = ['车载终端', '定位器', '传感器'];
const fieldOptions = ['temperature', 'battery', 'signal', 'speed', 'status', 'humidity'];
const operatorOptions = ['>', '<=', '==', '!=', '<'];
const actionOptions = ['告警', '通知', 'webhook', '设备指令'];

function getActionBadge(action: string) {
  switch (action) {
    case '告警': return <Badge className="bg-danger-light text-danger border-danger">告警</Badge>;
    case '通知': return <Badge className="bg-primary-light text-primary border-primary-border">通知</Badge>;
    case 'webhook': return <Badge className="bg-info-light text-info border-info">webhook</Badge>;
    case '设备指令': return <Badge className="bg-warning-light text-warning border-warning">设备指令</Badge>;
    default: return <Badge variant="outline">{action}</Badge>;
  }
}

export default function IotRuleEngineTab() {
  const [rules, setRules] = useState<Rule[]>(initialRules);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formName, setFormName] = useState('');
  const [formDeviceType, setFormDeviceType] = useState('');
  const [formTriggerField, setFormTriggerField] = useState('');
  const [formOperator, setFormOperator] = useState('');
  const [formThreshold, setFormThreshold] = useState('');
  const [formAction, setFormAction] = useState('');
  const [formStatus, setFormStatus] = useState(true);

  const resetForm = () => {
    setFormName('');
    setFormDeviceType('');
    setFormTriggerField('');
    setFormOperator('');
    setFormThreshold('');
    setFormAction('');
    setFormStatus(true);
    setEditingId(null);
  };

  const openCreate = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEdit = (rule: Rule) => {
    setFormName(rule.name);
    setFormDeviceType(rule.deviceType);
    setFormTriggerField(rule.triggerField);
    setFormOperator(rule.operator);
    setFormThreshold(rule.threshold);
    setFormAction(rule.action);
    setFormStatus(rule.status);
    setEditingId(rule.id);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formName.trim() || !formDeviceType || !formTriggerField || !formOperator || !formThreshold || !formAction) return;

    if (editingId) {
      setRules((prev) =>
        prev.map((r) =>
          r.id === editingId
            ? { ...r, name: formName, deviceType: formDeviceType, triggerField: formTriggerField, operator: formOperator, threshold: formThreshold, action: formAction, status: formStatus }
            : r
        )
      );
    } else {
      const newRule: Rule = {
        id: `R-${String(rules.length + 1).padStart(3, '0')}`,
        name: formName,
        deviceType: formDeviceType,
        triggerField: formTriggerField,
        operator: formOperator,
        threshold: formThreshold,
        action: formAction,
        status: formStatus,
        hits: 0,
      };
      setRules((prev) => [...prev, newRule]);
    }
    setDialogOpen(false);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setRules((prev) => prev.filter((r) => r.id !== id));
  };

  const toggleStatus = (id: string) => {
    setRules((prev) => prev.map((r) => (r.id === id ? { ...r, status: !r.status } : r)));
  };

  const isFormValid = formName.trim() && formDeviceType && formTriggerField && formOperator && formThreshold && formAction;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div />
        <Button size="sm" className="h-9 text-xs" onClick={openCreate}>
          <Plus size={14} className="mr-1" />
          新建规则
        </Button>
      </div>

      {/* Rules Table */}
      <Card className="bg-neutral-surface border-neutral-border overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold text-neutral-textPrimary">规则列表</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-neutral-border hover:bg-transparent">
                <TableHead className="text-neutral-textSecondary text-xs">规则名称</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">触发条件</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">执行动作</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">状态</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">命中次数</TableHead>
                <TableHead className="text-neutral-textSecondary text-xs">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rules.map((rule) => (
                <TableRow key={rule.id} className="border-neutral-border hover:bg-neutral-background">
                  <TableCell className="text-xs text-neutral-textPrimary font-medium">{rule.name}</TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary">
                    {rule.triggerField} {rule.operator} {rule.threshold}
                  </TableCell>
                  <TableCell>{getActionBadge(rule.action)}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Switch checked={rule.status} onCheckedChange={() => toggleStatus(rule.id)} />
                      <span className={cn('text-xs', rule.status ? 'text-success' : 'text-neutral-textTertiary')}>
                        {rule.status ? '启用' : '禁用'}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-neutral-textSecondary font-number">{rule.hits.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-primary" onClick={() => openEdit(rule)}>
                        <Pencil size={14} />
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-danger" onClick={() => handleDelete(rule.id)}>
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md bg-neutral-surface border-neutral-border">
          <DialogHeader>
            <DialogTitle className="text-base text-neutral-textPrimary">
              {editingId ? '编辑规则' : '新建规则'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1 block">规则名称</label>
              <Input value={formName} onChange={(e) => setFormName(e.target.value)} placeholder="请输入规则名称" />
            </div>
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1 block">设备类型</label>
              <Select value={formDeviceType} onValueChange={setFormDeviceType}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="选择设备类型" />
                </SelectTrigger>
                <SelectContent>
                  {deviceTypeOptions.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-neutral-textSecondary mb-1 block">触发字段</label>
                <Select value={formTriggerField} onValueChange={setFormTriggerField}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择字段" />
                  </SelectTrigger>
                  <SelectContent>
                    {fieldOptions.map((f) => (
                      <SelectItem key={f} value={f}>{f}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-neutral-textSecondary mb-1 block">运算符</label>
                <Select value={formOperator} onValueChange={setFormOperator}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="选择运算符" />
                  </SelectTrigger>
                  <SelectContent>
                    {operatorOptions.map((o) => (
                      <SelectItem key={o} value={o}>{o}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1 block">阈值</label>
              <Input value={formThreshold} onChange={(e) => setFormThreshold(e.target.value)} placeholder="请输入阈值" />
            </div>
            <div>
              <label className="text-xs text-neutral-textSecondary mb-1 block">执行动作</label>
              <Select value={formAction} onValueChange={setFormAction}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="选择执行动作" />
                </SelectTrigger>
                <SelectContent>
                  {actionOptions.map((a) => (
                    <SelectItem key={a} value={a}>{a}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={formStatus} onCheckedChange={setFormStatus} />
              <span className="text-sm text-neutral-textPrimary">{formStatus ? '启用' : '禁用'}</span>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => { setDialogOpen(false); resetForm(); }}>
              取消
            </Button>
            <Button size="sm" className="h-8 text-xs" disabled={!isFormValid} onClick={handleSave}>
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
