import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  MessageSquare,
  Wifi,
  Shield,
  AlertTriangle,
  PieChart as PieChartIcon,
  Gauge,
  MapPin,
  Router,
  Truck,
  Route,
  Search,
  Filter,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/* ================================================================
   CSS Variables Theme (scoped to this component)
   ================================================================ */

const THEME = {
  spaceBg: '#070B19',
  spaceBgLight: '#0B1128',
  surfaceElevated: '#111D3D',
  borderSubtle: '#1A2B52',
  borderMedium: '#243B6D',
  textPrimary: '#E8EEF7',
  textSecondary: '#7A8BAF',
  textTertiary: '#4A5D85',
  auroraCyan: '#00D4FF',
  auroraCyanDim: 'rgba(0, 212, 255, 0.15)',
  auroraGreen: '#00FF9D',
  auroraPurple: '#9D4EDD',
  auroraOrange: '#FF8C42',
  auroraPink: '#F72585',
  chart1: '#00D4FF',
  chart2: '#00FF9D',
  chart3: '#FF8C42',
  chart4: '#9D4EDD',
  chart5: '#F72585',
};

/* ================================================================
   Types
   ================================================================ */

interface AuthRecord {
  id: string;
  deviceId: string;
  deviceType: string;
  authMethod: 'TLS证书' | '设备密钥';
  authTime: string;
  clientId: string;
  ipAddress: string;
  result: '成功' | '失败';
  failReason: string;
}

interface RateLimitTrigger {
  id: string;
  deviceId: string;
  exceedType: string;
  exceedCount: number;
  triggerTime: string;
  handleMethod: string;
}

interface RoutingRule {
  id: string;
  ruleName: string;
  deviceType: string;
  targetQueue: string;
  priority: '高' | '中' | '低';
  status: boolean;
}

interface TrafficDataPoint {
  minute: string;
  total: number;
  passed: number;
  rejected: number;
}

/* ================================================================
   Chart Styles
   ================================================================ */

const chartTooltipStyle = {
  backgroundColor: 'rgba(7, 11, 25, 0.95)',
  border: '1px solid rgba(0, 212, 255, 0.2)',
  borderRadius: '8px',
  fontSize: '12px',
  color: '#E8EEF7',
  backdropFilter: 'blur(8px)',
  boxShadow: '0 4px 16px rgba(0, 0, 0, 0.4)',
};

/* ================================================================
   Mock Data
   ================================================================ */

const PROTOCOL_DATA = [
  { name: 'MQTT', value: 62, color: '#00D4FF' },
  { name: 'HTTP', value: 18, color: '#9D4EDD' },
  { name: 'WebSocket', value: 12, color: '#00FF9D' },
  { name: 'TCP', value: 8, color: '#FF8C42' },
];

const DEVICE_TYPES = ['定位器', '网关', '车载网关', '蓝牙标签'];
const AUTH_METHODS: ('TLS证书' | '设备密钥')[] = ['TLS证书', '设备密钥'];
const FAIL_REASONS = ['', '', '', '', '', '', '', '', '', '证书过期', '密钥错误', 'IP不在白名单', '时间戳异常', '重复认证'];

function generateAuthRecords(): AuthRecord[] {
  const records: AuthRecord[] = [];
  for (let i = 1; i <= 20; i++) {
    const result: '成功' | '失败' = Math.random() > 0.15 ? '成功' : '失败';
    records.push({
      id: `auth_${i}`,
      deviceId: `DEV-2024-${String(10000 + i).slice(1)}`,
      deviceType: DEVICE_TYPES[i % DEVICE_TYPES.length],
      authMethod: AUTH_METHODS[i % AUTH_METHODS.length],
      authTime: `2024-01-15 ${String(8 + Math.floor(i / 3)).padStart(2, '0')}:${String((i * 7) % 60).padStart(2, '0')}:${String((i * 13) % 60).padStart(2, '0')}`,
      clientId: `${DEVICE_TYPES[i % DEVICE_TYPES.length].slice(0, 3)}_${String(10000 + i).slice(1)}_${Math.random().toString(36).slice(2, 6)}`,
      ipAddress: `192.168.${1 + (i % 10)}.${50 + (i % 200)}`,
      result,
      failReason: result === '失败' ? FAIL_REASONS[i % FAIL_REASONS.length] : '',
    });
  }
  return records;
}

const AUTH_RECORDS = generateAuthRecords();

function generateTrafficData(): TrafficDataPoint[] {
  const data: TrafficDataPoint[] = [];
  for (let i = 0; i < 60; i++) {
    const minute = `${String(9 + Math.floor(i / 60)).padStart(2, '0')}:${String(i % 60).padStart(2, '0')}`;
    const total = 800 + Math.floor(Math.random() * 1200) + Math.sin(i / 10) * 200;
    const rejected = Math.floor(Math.random() * 25);
    data.push({
      minute,
      total: Math.floor(total),
      passed: Math.floor(total) - rejected,
      rejected,
    });
  }
  return data;
}

const TRAFFIC_DATA = generateTrafficData();

const RATE_LIMIT_TRIGGERS: RateLimitTrigger[] = [
  { id: 'rl1', deviceId: 'GW-2024-00542', exceedType: '网关频率超限', exceedCount: 12, triggerTime: '2024-01-15 14:28:33', handleMethod: '自动限流降速' },
  { id: 'rl2', deviceId: 'VG-2024-00123', exceedType: '车载网关频率超限', exceedCount: 8, triggerTime: '2024-01-15 13:45:12', handleMethod: '队列缓冲' },
  { id: 'rl3', deviceId: 'GW-2024-00389', exceedType: '网关频率超限', exceedCount: 15, triggerTime: '2024-01-15 12:18:45', handleMethod: '自动限流降速' },
  { id: 'rl4', deviceId: 'LOC-2024-00765', exceedType: '定位器频率超限', exceedCount: 5, triggerTime: '2024-01-15 11:32:09', handleMethod: '丢弃重复包' },
  { id: 'rl5', deviceId: 'GW-2024-00671', exceedType: '网关频率超限', exceedCount: 20, triggerTime: '2024-01-15 10:55:27', handleMethod: '告警+限流' },
  { id: 'rl6', deviceId: 'VG-2024-00234', exceedType: '车载网关频率超限', exceedCount: 6, triggerTime: '2024-01-15 09:41:53', handleMethod: '队列缓冲' },
];

const ROUTING_RULES: RoutingRule[] = [
  { id: 'rr1', ruleName: '定位器数据路由', deviceType: '定位器', targetQueue: 'queue.locator.data', priority: '高', status: true },
  { id: 'rr2', ruleName: '网关数据路由', deviceType: '网关', targetQueue: 'queue.gateway.data', priority: '高', status: true },
  { id: 'rr3', ruleName: '标签数据路由', deviceType: '蓝牙标签', targetQueue: 'queue.tag.data', priority: '中', status: true },
  { id: 'rr4', ruleName: '信标数据路由', deviceType: '信标', targetQueue: 'queue.beacon.data', priority: '低', status: false },
];

/* ================================================================
   Glass Card Component
   ================================================================ */

function GlassCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'rounded-[10px] backdrop-blur-[12px]',
        className
      )}
      style={{
        background: 'rgba(11, 17, 40, 0.7)',
        border: '1px solid rgba(26, 43, 82, 0.8)',
        boxShadow: '0 2px 16px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.03)',
      }}
    >
      {children}
    </div>
  );
}

/* ================================================================
   KPICard Component
   ================================================================ */

interface KPICardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  sub: string;
  accent: string;
  progress?: number;
}

function KPICard({ icon: Icon, label, value, sub, accent, progress }: KPICardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="rounded-[10px] p-4"
      style={{
        background: 'rgba(11, 17, 40, 0.8)',
        border: `1px solid ${accent}40`,
        boxShadow: `0 0 16px ${accent}10, inset 0 1px 0 rgba(255,255,255,0.04)`,
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Icon size={16} style={{ color: accent }} />
        <span className="text-[11px] font-medium" style={{ color: THEME.textSecondary }}>{label}</span>
      </div>
      <div className="text-[22px] font-bold font-mono" style={{ color: THEME.textPrimary }}>{value}</div>
      <div className="text-xs mt-1" style={{ color: THEME.textTertiary }}>{sub}</div>
      {progress !== undefined && (
        <div className="mt-3 h-[6px] rounded-full overflow-hidden" style={{ background: 'rgba(26, 43, 82, 0.6)' }}>
          <div
            className="h-full rounded-full"
            style={{
              width: `${progress}%`,
              background: accent,
              boxShadow: `0 0 8px ${accent}66`,
            }}
          />
        </div>
      )}
    </motion.div>
  );
}

/* ================================================================
   Badge Component
   ================================================================ */

function StatusBadge({ result }: { result: '成功' | '失败' }) {
  const isSuccess = result === '成功';
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-[6px] text-[10px] font-medium"
      style={{
        background: isSuccess ? 'rgba(0, 255, 157, 0.12)' : 'rgba(247, 37, 133, 0.12)',
        color: isSuccess ? '#00FF9D' : '#F72585',
        border: `1px solid ${isSuccess ? 'rgba(0, 255, 157, 0.3)' : 'rgba(247, 37, 133, 0.3)'}`,
      }}
    >
      {result}
    </span>
  );
}

/* ================================================================
   Toggle Switch Component
   ================================================================ */

function ToggleSwitch({ checked, onChange }: { checked: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange} className="relative w-9 h-5 rounded-full transition-colors duration-200" style={{ background: checked ? '#00D4FF' : 'rgba(26, 43, 82, 0.8)' }}>
      <div
        className="absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all duration-200"
        style={{ left: checked ? 18 : 2 }}
      />
    </button>
  );
}

/* ================================================================
   Main Component
   ================================================================ */

export default function DataAccessTab() {
  const [resultFilter, setResultFilter] = useState<string>('All');
  const [methodFilter, setMethodFilter] = useState<string>('All');
  const [searchText, setSearchText] = useState('');
  const [routingRules, setRoutingRules] = useState(ROUTING_RULES);

  const filteredAuthRecords = useMemo(() => {
    return AUTH_RECORDS.filter((r) => {
      if (resultFilter !== 'All' && r.result !== resultFilter) return false;
      if (methodFilter !== 'All' && r.authMethod !== methodFilter) return false;
      if (searchText && !r.deviceId.toLowerCase().includes(searchText.toLowerCase()) && !r.clientId.toLowerCase().includes(searchText.toLowerCase())) return false;
      return true;
    });
  }, [resultFilter, methodFilter, searchText]);

  const handleToggleRule = (id: string) => {
    setRoutingRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: !r.status } : r))
    );
  };

  return (
    <div className="space-y-5">
      {/* ── KPI Cards ── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard icon={MessageSquare} label="今日接入消息" value="124.5K" sub="+8.2% 环比" accent={THEME.auroraCyan} />
        <KPICard icon={Wifi} label="在线连接数" value="15,390" sub="/ 20,000 容量" accent={THEME.auroraGreen} progress={76.9} />
        <KPICard icon={Shield} label="认证通过率" value="99.7%" sub="——" accent={THEME.auroraGreen} progress={99.7} />
        <KPICard icon={AlertTriangle} label="流量拒绝次数" value="23" sub="红色警示" accent={THEME.auroraPink} />
      </div>

      {/* ── Row 2: Pie Chart + Auth Table ── */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Protocol Distribution */}
        <GlassCard className="lg:col-span-2 p-4">
          <div className="flex items-center gap-2 mb-3">
            <PieChartIcon size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>接入协议分布</h3>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie
                data={PROTOCOL_DATA}
                cx="50%"
                cy="45%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
                nameKey="name"
                label={({ name, value }) => `${name}: ${value}%`}
              >
                {PROTOCOL_DATA.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={chartTooltipStyle as any} />
              <Legend
                verticalAlign="bottom"
                height={36}
                iconType="circle"
                wrapperStyle={{ fontSize: '12px', color: THEME.textSecondary }}
              />
            </PieChart>
          </ResponsiveContainer>
        </GlassCard>

        {/* Device Auth Records */}
        <GlassCard className="lg:col-span-3 p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Shield size={16} style={{ color: THEME.auroraCyan }} />
              <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>设备认证记录</h3>
            </div>
          </div>

          {/* Filter bar */}
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Filter size={14} style={{ color: THEME.textTertiary }} />
            <select
              value={resultFilter}
              onChange={(e) => setResultFilter(e.target.value)}
              className="rounded-md px-2 py-1 text-xs outline-none"
              style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)', color: THEME.textSecondary }}
            >
              <option value="All">认证结果</option>
              <option value="成功">成功</option>
              <option value="失败">失败</option>
            </select>
            <select
              value={methodFilter}
              onChange={(e) => setMethodFilter(e.target.value)}
              className="rounded-md px-2 py-1 text-xs outline-none"
              style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)', color: THEME.textSecondary }}
            >
              <option value="All">认证方式</option>
              <option value="TLS证书">TLS证书</option>
              <option value="设备密钥">设备密钥</option>
            </select>
            <div className="flex items-center gap-1 rounded-md px-2 py-1 flex-1 max-w-[200px]" style={{ background: 'rgba(11, 17, 40, 0.8)', border: '1px solid rgba(26, 43, 82, 0.8)' }}>
              <Search size={12} style={{ color: THEME.textTertiary }} />
              <input
                type="text"
                placeholder="设备ID / ClientId"
                value={searchText}
                onChange={(e) => setSearchText(e.target.value)}
                className="bg-transparent outline-none text-xs w-full"
                style={{ color: THEME.textSecondary }}
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-auto max-h-[320px]">
            {/* Header */}
            <div
              className="grid gap-2 px-3 py-2 text-[11px] font-semibold uppercase tracking-wide sticky top-0"
              style={{
                gridTemplateColumns: '120px 80px 80px 140px 120px 100px 60px 100px',
                background: 'rgba(17, 29, 61, 0.6)',
                borderBottom: '1px solid rgba(36, 59, 109, 0.5)',
                color: THEME.textTertiary,
              }}
            >
              <div>设备ID</div>
              <div>设备类型</div>
              <div>认证方式</div>
              <div>认证时间</div>
              <div>ClientId</div>
              <div>IP地址</div>
              <div>结果</div>
              <div>失败原因</div>
            </div>
            {/* Body */}
            {filteredAuthRecords.map((record, idx) => (
              <div
                key={record.id}
                className="grid gap-2 px-3 py-2 text-xs transition-colors"
                style={{
                  gridTemplateColumns: '120px 80px 80px 140px 120px 100px 60px 100px',
                  borderBottom: '1px solid rgba(26, 43, 82, 0.5)',
                  background: idx % 2 === 0 ? 'rgba(11, 17, 40, 0.4)' : 'rgba(11, 17, 40, 0.6)',
                  color: THEME.textSecondary,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = 'rgba(0, 212, 255, 0.04)')}
                onMouseLeave={(e) => (e.currentTarget.style.background = idx % 2 === 0 ? 'rgba(11, 17, 40, 0.4)' : 'rgba(11, 17, 40, 0.6)')}
              >
                <div className="font-mono truncate">{record.deviceId}</div>
                <div className="truncate">{record.deviceType}</div>
                <div className="truncate">{record.authMethod}</div>
                <div className="font-mono truncate">{record.authTime}</div>
                <div className="font-mono truncate">{record.clientId}</div>
                <div className="font-mono truncate">{record.ipAddress}</div>
                <div><StatusBadge result={record.result} /></div>
                <div className="truncate" style={{ color: record.failReason ? '#F72585' : THEME.textTertiary }}>{record.failReason || '—'}</div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* ── Row 3: Traffic Control + Routing Config ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Traffic Control Panel */}
        <GlassCard className="lg:col-span-2 p-4">
          <div className="flex items-center gap-2 mb-4">
            <Gauge size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>流量控制面板</h3>
          </div>

          {/* Rate Limit Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
            {/* 定位器 */}
            <div className="rounded-lg p-3" style={{ background: 'rgba(11, 17, 40, 0.6)', border: '1px solid rgba(26, 43, 82, 0.8)' }}>
              <div className="flex items-center gap-2 mb-2">
                <MapPin size={14} style={{ color: THEME.auroraCyan }} />
                <span className="text-xs font-medium" style={{ color: THEME.textPrimary }}>定位器</span>
              </div>
              <div className="text-lg font-bold font-mono" style={{ color: THEME.textPrimary }}>1次/分钟</div>
              <div className="text-xs mt-1" style={{ color: THEME.textSecondary }}>当前频率: 0.8次/分</div>
              <div className="flex items-center gap-1.5 mt-2">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#00FF9D', boxShadow: '0 0 6px #00FF9D' }} />
                <span className="text-[10px]" style={{ color: '#00FF9D' }}>正常</span>
              </div>
            </div>
            {/* 网关 */}
            <div className="rounded-lg p-3" style={{ background: 'rgba(11, 17, 40, 0.6)', border: '1px solid rgba(26, 43, 82, 0.8)' }}>
              <div className="flex items-center gap-2 mb-2">
                <Router size={14} style={{ color: THEME.auroraPurple }} />
                <span className="text-xs font-medium" style={{ color: THEME.textPrimary }}>网关</span>
              </div>
              <div className="text-lg font-bold font-mono" style={{ color: THEME.textPrimary }}>1次/10秒</div>
              <div className="text-xs mt-1" style={{ color: THEME.textSecondary }}>当前频率: 1.2次/10秒</div>
              <div className="flex items-center gap-1.5 mt-2">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#FF8C42', boxShadow: '0 0 6px #FF8C42' }} />
                <span className="text-[10px]" style={{ color: '#FF8C42' }}>接近</span>
              </div>
            </div>
            {/* 车载网关 */}
            <div className="rounded-lg p-3" style={{ background: 'rgba(11, 17, 40, 0.6)', border: '1px solid rgba(26, 43, 82, 0.8)' }}>
              <div className="flex items-center gap-2 mb-2">
                <Truck size={14} style={{ color: THEME.auroraGreen }} />
                <span className="text-xs font-medium" style={{ color: THEME.textPrimary }}>车载网关</span>
              </div>
              <div className="text-lg font-bold font-mono" style={{ color: THEME.textPrimary }}>1次/30秒</div>
              <div className="text-xs mt-1" style={{ color: THEME.textSecondary }}>当前频率: 0.6次/30秒</div>
              <div className="flex items-center gap-1.5 mt-2">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#00FF9D', boxShadow: '0 0 6px #00FF9D' }} />
                <span className="text-[10px]" style={{ color: '#00FF9D' }}>正常</span>
              </div>
            </div>
          </div>

          {/* Traffic Line Chart */}
          <div className="mb-4">
            <div className="text-xs mb-2" style={{ color: THEME.textSecondary }}>近1小时实时流量监控</div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={TRAFFIC_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26, 43, 82, 0.4)" />
                <XAxis
                  dataKey="minute"
                  tick={{ fontSize: 10, fill: '#4A5D85' }}
                  axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
                  interval={9}
                />
                <YAxis
                  tick={{ fontSize: 10, fill: '#4A5D85' }}
                  axisLine={{ stroke: 'rgba(26, 43, 82, 0.5)' }}
                />
                <Tooltip contentStyle={chartTooltipStyle as any} />
                <Legend wrapperStyle={{ fontSize: '11px', color: THEME.textSecondary }} />
                <Line type="monotone" dataKey="total" name="总消息量" stroke="#00D4FF" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                <Line type="monotone" dataKey="passed" name="通过消息" stroke="#00FF9D" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
                <Line type="monotone" dataKey="rejected" name="拒绝消息" stroke="#F72585" strokeWidth={2} dot={false} activeDot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Rate Limit Trigger Table */}
          <div className="text-xs mb-2" style={{ color: THEME.textSecondary }}>限流触发记录</div>
          <div className="overflow-auto max-h-[180px]">
            <div
              className="grid gap-2 px-3 py-2 text-[11px] font-semibold uppercase tracking-wide"
              style={{
                gridTemplateColumns: '120px 120px 80px 140px 120px',
                background: 'rgba(17, 29, 61, 0.6)',
                borderBottom: '1px solid rgba(36, 59, 109, 0.5)',
                color: THEME.textTertiary,
              }}
            >
              <div>设备ID</div>
              <div>超限类型</div>
              <div>超限次数</div>
              <div>触发时间</div>
              <div>处理方式</div>
            </div>
            {RATE_LIMIT_TRIGGERS.map((rl, idx) => (
              <div
                key={rl.id}
                className="grid gap-2 px-3 py-2 text-xs"
                style={{
                  gridTemplateColumns: '120px 120px 80px 140px 120px',
                  borderBottom: '1px solid rgba(26, 43, 82, 0.5)',
                  background: idx % 2 === 0 ? 'rgba(11, 17, 40, 0.4)' : 'rgba(11, 17, 40, 0.6)',
                  color: THEME.textSecondary,
                }}
              >
                <div className="font-mono truncate">{rl.deviceId}</div>
                <div className="truncate">{rl.exceedType}</div>
                <div className="font-mono">{rl.exceedCount}</div>
                <div className="font-mono truncate">{rl.triggerTime}</div>
                <div className="truncate">{rl.handleMethod}</div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Message Routing Config */}
        <GlassCard className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Route size={16} style={{ color: THEME.auroraCyan }} />
            <h3 className="text-sm font-semibold" style={{ color: THEME.textPrimary }}>消息路由配置</h3>
          </div>

          <div className="space-y-3">
            {routingRules.map((rule) => (
              <div
                key={rule.id}
                className="rounded-lg p-3"
                style={{ background: 'rgba(11, 17, 40, 0.6)', border: '1px solid rgba(26, 43, 82, 0.8)' }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium" style={{ color: THEME.textPrimary }}>{rule.ruleName}</span>
                  <ToggleSwitch checked={rule.status} onChange={() => handleToggleRule(rule.id)} />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px]" style={{ color: THEME.textTertiary }}>设备类型</span>
                    <span className="text-xs" style={{ color: THEME.textSecondary }}>{rule.deviceType}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px]" style={{ color: THEME.textTertiary }}>目标队列</span>
                    <span className="text-xs font-mono" style={{ color: THEME.textSecondary }}>{rule.targetQueue}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px]" style={{ color: THEME.textTertiary }}>优先级</span>
                    <span
                      className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-medium"
                      style={{
                        background: rule.priority === '高' ? 'rgba(255, 140, 66, 0.12)' : rule.priority === '中' ? 'rgba(0, 212, 255, 0.12)' : 'rgba(26, 43, 82, 0.6)',
                        color: rule.priority === '高' ? '#FF8C42' : rule.priority === '中' ? '#00D4FF' : '#7A8BAF',
                        border: `1px solid ${rule.priority === '高' ? 'rgba(255, 140, 66, 0.3)' : rule.priority === '中' ? 'rgba(0, 212, 255, 0.3)' : 'rgba(26, 43, 82, 0.8)'}`,
                      }}
                    >
                      {rule.priority}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
}
