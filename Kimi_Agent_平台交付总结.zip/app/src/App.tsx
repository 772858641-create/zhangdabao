import { lazy, Suspense } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import Layout from '@/components/layout/Layout';
import LoginPage from '@/pages/LoginPage';
import { useAuth } from '@/hooks/useAuth';
import { PageSkeleton } from '@/components/PageSkeleton';

/* ─── Lazy imports for all 53 pages ─── */
const DashboardPage = lazy(() => import('@/pages/DashboardPage'));
const MapDashboardPage = lazy(() => import('@/pages/MapDashboardPage'));
const DashboardConfigPage = lazy(() => import('@/pages/DashboardConfigPage'));
const MapBatchOpsPage = lazy(() => import('@/pages/MapBatchOpsPage'));
const VehicleManagementPage = lazy(() => import('@/pages/VehicleManagementPage'));
const FleetManagementPage = lazy(() => import('@/pages/FleetManagementPage'));
const MaterialManagementPage = lazy(() => import('@/pages/MaterialManagementPage'));
const CarrierAllocationPage = lazy(() => import('@/pages/CarrierAllocationPage'));
const VehicleFenceInOutPage = lazy(() => import('@/pages/VehicleFenceInOutPage'));
const VehicleUnbindRecordPage = lazy(() => import('@/pages/VehicleUnbindRecordPage'));
const BorrowReturnPage = lazy(() => import('@/pages/BorrowReturnPage'));
const TransferOwnershipPage = lazy(() => import('@/pages/TransferOwnershipPage'));
const ModelManagementPage = lazy(() => import('@/pages/ModelManagementPage'));
const TransferManagementPage = lazy(() => import('@/pages/TransferManagementPage'));
const TransferAuditPage = lazy(() => import('@/pages/TransferAuditPage'));
const TransferTrackReplayPage = lazy(() => import('@/pages/TransferTrackReplayPage'));
const ShipmentStatusPage = lazy(() => import('@/pages/ShipmentStatusPage'));
const RouteConfigPage = lazy(() => import('@/pages/RouteConfigPage'));
const RouteDashboardPage = lazy(() => import('@/pages/RouteDashboardPage'));
const DeviceManagementPage = lazy(() => import('@/pages/DeviceManagementPage'));
const DeviceCommandPage = lazy(() => import('@/pages/DeviceCommandPage'));
const DeviceOTAPage = lazy(() => import('@/pages/DeviceOTAPage'));
const DeviceShadowPage = lazy(() => import('@/pages/DeviceShadowPage'));
const IotPlatformPage = lazy(() => import('@/pages/IotPlatformPage'));
const BeaconManagementPage = lazy(() => import('@/pages/BeaconManagementPage'));
const TagSeparationPage = lazy(() => import('@/pages/TagSeparationPage'));
const SiteManagementPage = lazy(() => import('@/pages/SiteManagementPage'));
const OrgSiteAggregationPage = lazy(() => import('@/pages/OrgSiteAggregationPage'));
const DriverPage = lazy(() => import('@/pages/DriverPage'));
const InOutRuleEnginePage = lazy(() => import('@/pages/InOutRuleEnginePage'));
const InventoryCheckPage = lazy(() => import('@/pages/InventoryCheckPage'));
const StatisticsPage = lazy(() => import('@/pages/StatisticsPage'));
const BillingPage = lazy(() => import('@/pages/BillingPage'));
const ProjectManagementPage = lazy(() => import('@/pages/ProjectManagementPage'));
const MessageCenterPage = lazy(() => import('@/pages/MessageCenterPage'));
const AmapPage = lazy(() => import('@/pages/AmapPage'));
const DataMiddlePlatformPage = lazy(() => import('@/pages/DataMiddlePlatformPage'));
const AlarmManagementPage = lazy(() => import('@/pages/AlarmManagementPage'));
const AlarmWorkflowPage = lazy(() => import('@/pages/AlarmWorkflowPage'));
const AlarmAnalysisPage = lazy(() => import('@/pages/AlarmAnalysisPage'));
const UserManagementPage = lazy(() => import('@/pages/UserManagementPage'));
const RoleManagementPage = lazy(() => import('@/pages/RoleManagementPage'));
const MenuManagementPage = lazy(() => import('@/pages/MenuManagementPage'));
const OrgManagementPage = lazy(() => import('@/pages/OrgManagementPage'));
const DelegateLoginPage = lazy(() => import('@/pages/DelegateLoginPage'));
const FieldPermissionPage = lazy(() => import('@/pages/FieldPermissionPage'));
const WechatMiniProgramPage = lazy(() => import('@/pages/WechatMiniProgramPage'));
const ExportRecordPage = lazy(() => import('@/pages/ExportRecordPage'));
const AuditLogPage = lazy(() => import('@/pages/AuditLogPage'));
const HistoryDataCenterPage = lazy(() => import('@/pages/HistoryDataCenterPage'));
const SystemSettingsPage = lazy(() => import('@/pages/SystemSettingsPage'));
const MapSettingPage = lazy(() => import('@/pages/MapSettingPage'));
const AlarmSettingPage = lazy(() => import('@/pages/AlarmSettingPage'));

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/login" element={<LoginPage />} />
        </Route>
        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/" element={<Suspense fallback={<PageSkeleton />}><DashboardPage /></Suspense>} />
          <Route path="/dashboard" element={<Suspense fallback={<PageSkeleton />}><DashboardPage /></Suspense>} />
          <Route path="/map" element={<Suspense fallback={<PageSkeleton />}><MapDashboardPage /></Suspense>} />
          <Route path="/dashboard-config" element={<Suspense fallback={<PageSkeleton />}><DashboardConfigPage /></Suspense>} />
          <Route path="/map-batch-ops" element={<Suspense fallback={<PageSkeleton />}><MapBatchOpsPage /></Suspense>} />
          <Route path="/map-settings" element={<Suspense fallback={<PageSkeleton />}><MapSettingPage /></Suspense>} />
          <Route path="/vehicles" element={<Suspense fallback={<PageSkeleton />}><VehicleManagementPage /></Suspense>} />
          <Route path="/fleet" element={<Suspense fallback={<PageSkeleton />}><FleetManagementPage /></Suspense>} />
          <Route path="/materials" element={<Suspense fallback={<PageSkeleton />}><MaterialManagementPage /></Suspense>} />
          <Route path="/carrier-allocation" element={<Suspense fallback={<PageSkeleton />}><CarrierAllocationPage /></Suspense>} />
          <Route path="/vehicle-fence-inout" element={<Suspense fallback={<PageSkeleton />}><VehicleFenceInOutPage /></Suspense>} />
          <Route path="/vehicle-unbind-records" element={<Suspense fallback={<PageSkeleton />}><VehicleUnbindRecordPage /></Suspense>} />
          <Route path="/borrow-return" element={<Suspense fallback={<PageSkeleton />}><BorrowReturnPage /></Suspense>} />
          <Route path="/transfers-ownership" element={<Suspense fallback={<PageSkeleton />}><TransferOwnershipPage /></Suspense>} />
          <Route path="/models" element={<Suspense fallback={<PageSkeleton />}><ModelManagementPage /></Suspense>} />
          <Route path="/transfers" element={<Suspense fallback={<PageSkeleton />}><TransferManagementPage /></Suspense>} />
          <Route path="/transfer-audit" element={<Suspense fallback={<PageSkeleton />}><TransferAuditPage /></Suspense>} />
          <Route path="/transfer-track-replay" element={<Suspense fallback={<PageSkeleton />}><TransferTrackReplayPage /></Suspense>} />
          <Route path="/shipment-status" element={<Suspense fallback={<PageSkeleton />}><ShipmentStatusPage /></Suspense>} />
          <Route path="/routes" element={<Suspense fallback={<PageSkeleton />}><RouteConfigPage /></Suspense>} />
          <Route path="/route-dashboard" element={<Suspense fallback={<PageSkeleton />}><RouteDashboardPage /></Suspense>} />
          <Route path="/devices" element={<Suspense fallback={<PageSkeleton />}><DeviceManagementPage /></Suspense>} />
          <Route path="/device-commands" element={<Suspense fallback={<PageSkeleton />}><DeviceCommandPage /></Suspense>} />
          <Route path="/device-ota" element={<Suspense fallback={<PageSkeleton />}><DeviceOTAPage /></Suspense>} />
          <Route path="/device-shadow" element={<Suspense fallback={<PageSkeleton />}><DeviceShadowPage /></Suspense>} />
          <Route path="/iot-platform" element={<Suspense fallback={<PageSkeleton />}><IotPlatformPage /></Suspense>} />
          <Route path="/beacon-management" element={<Suspense fallback={<PageSkeleton />}><BeaconManagementPage /></Suspense>} />
          <Route path="/tag-separation" element={<Suspense fallback={<PageSkeleton />}><TagSeparationPage /></Suspense>} />
          <Route path="/sites" element={<Suspense fallback={<PageSkeleton />}><SiteManagementPage /></Suspense>} />
          <Route path="/org-site-aggregation" element={<Suspense fallback={<PageSkeleton />}><OrgSiteAggregationPage /></Suspense>} />
          <Route path="/drivers" element={<Suspense fallback={<PageSkeleton />}><DriverPage /></Suspense>} />
          <Route path="/inout-rules" element={<Suspense fallback={<PageSkeleton />}><InOutRuleEnginePage /></Suspense>} />
          <Route path="/inventory-check" element={<Suspense fallback={<PageSkeleton />}><InventoryCheckPage /></Suspense>} />
          <Route path="/statistics" element={<Suspense fallback={<PageSkeleton />}><StatisticsPage /></Suspense>} />
          <Route path="/billing" element={<Suspense fallback={<PageSkeleton />}><BillingPage /></Suspense>} />
          <Route path="/projects" element={<Suspense fallback={<PageSkeleton />}><ProjectManagementPage /></Suspense>} />
          <Route path="/messages" element={<Suspense fallback={<PageSkeleton />}><MessageCenterPage /></Suspense>} />
          <Route path="/amap" element={<Suspense fallback={<PageSkeleton />}><AmapPage /></Suspense>} />
          <Route path="/data-middle-platform" element={<Suspense fallback={<PageSkeleton />}><DataMiddlePlatformPage /></Suspense>} />
          <Route path="/alarms" element={<Suspense fallback={<PageSkeleton />}><AlarmManagementPage /></Suspense>} />
          <Route path="/alarm-workflow" element={<Suspense fallback={<PageSkeleton />}><AlarmWorkflowPage /></Suspense>} />
          <Route path="/alarm-analysis" element={<Suspense fallback={<PageSkeleton />}><AlarmAnalysisPage /></Suspense>} />
          <Route path="/alarm-settings" element={<Suspense fallback={<PageSkeleton />}><AlarmSettingPage /></Suspense>} />
          <Route path="/users" element={<Suspense fallback={<PageSkeleton />}><UserManagementPage /></Suspense>} />
          <Route path="/role-management" element={<Suspense fallback={<PageSkeleton />}><RoleManagementPage /></Suspense>} />
          <Route path="/menu-management" element={<Suspense fallback={<PageSkeleton />}><MenuManagementPage /></Suspense>} />
          <Route path="/org-management" element={<Suspense fallback={<PageSkeleton />}><OrgManagementPage /></Suspense>} />
          <Route path="/delegate-login" element={<Suspense fallback={<PageSkeleton />}><DelegateLoginPage /></Suspense>} />
          <Route path="/field-permissions" element={<Suspense fallback={<PageSkeleton />}><FieldPermissionPage /></Suspense>} />
          <Route path="/wechat-miniprogram" element={<Suspense fallback={<PageSkeleton />}><WechatMiniProgramPage /></Suspense>} />
          <Route path="/export-records" element={<Suspense fallback={<PageSkeleton />}><ExportRecordPage /></Suspense>} />
          <Route path="/audit-logs" element={<Suspense fallback={<PageSkeleton />}><AuditLogPage /></Suspense>} />
          <Route path="/history-data" element={<Suspense fallback={<PageSkeleton />}><HistoryDataCenterPage /></Suspense>} />
          <Route path="/settings" element={<Suspense fallback={<PageSkeleton />}><SystemSettingsPage /></Suspense>} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default App;
