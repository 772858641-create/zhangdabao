import { createRoot } from 'react-dom/client'
import { ThemeProvider } from '@/hooks/useTheme'
import './index.css'
import App from './App.tsx'

createRoot(document.getElementById('root')!).render(
  <ThemeProvider>
    <App />
  </ThemeProvider>
)
