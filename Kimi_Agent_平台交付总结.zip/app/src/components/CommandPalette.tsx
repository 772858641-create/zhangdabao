import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from '@/lib/toast';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';

import {
  Search,
  Command as CommandIcon,
  Home,
  RefreshCw,
  Moon,
  Sun,
  Clock,
  ArrowRight,
  LayoutDashboard,
  Map as MapPageIcon,
  Container,
  Truck,
  Cpu,
  Warehouse,
  ArrowLeftRight,
  Route,
  Bell,
  Users,
  Settings,
  BarChart3,
  Repeat,
  FolderKanban,
  MessageSquare,
  ClipboardCheck,
  ClipboardList,
  Workflow,
  Activity,
  Receipt,
  Globe,
  LayoutDashboard as DashboardIcon,
  Handshake,
  UserCog,
  Brain,
  Radio,
  Package,
  Terminal,
  Smartphone,
  KeyRound,
  ShieldCheck,
  Unlink,
  Braces,
  SquareDashedMousePointer,
  PlayCircle,
  Shield,
  Building2,
  Send,
  Boxes,
  type LucideIcon,
} from 'lucide-react';

// ── Types ────────────────────────────────────────────────

interface MenuItem {
  id: string;
  label: string;
  icon: LucideIcon;
  path: string;
  keywords: string[];
}

interface RecentItem {
  id: string;
  label: string;
  path: string;
  iconName: string;
  timestamp: number;
}

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

// ── Menu Data (43 items matching user list) ──────────────

const menuItems: MenuItem[] = [
  { id: 'dashboard', label: '数据看板', icon: LayoutDashboard, path: '/dashboard', keywords: ['shuju', 'kanban', 'data', 'dashboard'] },
  { id: 'map', label: '地图看板', icon: MapPageIcon, path: '/map', keywords: ['ditu', 'map', 'ditukanban'] },
  { id: 'map-batch-ops', label: '框选操作', icon: SquareDashedMousePointer, path: '/map-batch-ops', keywords: ['kuangxuan', 'batch', 'ops', 'kuangxuan caozuo'] },
  { id: 'vehicles', label: '载具管理', icon: Container, path: '/vehicles', keywords: ['zaiju', 'vehicle', 'container', 'zaiju guanli'] },
  { id: 'materials', label: '物料管理', icon: Package, path: '/materials', keywords: ['wuliao', 'material', 'wuliao guanli'] },
  { id: 'fleet', label: '车辆管理', icon: Truck, path: '/fleet', keywords: ['cheliang', 'fleet', 'car', 'cheliang guanli'] },
  { id: 'vehicle-fence-inout', label: '车辆围栏联动', icon: Shield, path: '/vehicle-fence-inout', keywords: ['cheliang', 'weilan', 'fence', 'vehicle fence'] },
  { id: 'devices', label: '设备管理', icon: Cpu, path: '/devices', keywords: ['shebei', 'device', 'cpu', 'shebei guanli'] },
  { id: 'device-commands', label: '设备指令', icon: Terminal, path: '/device-commands', keywords: ['shebei', 'zhiling', 'command', 'device command'] },
  { id: 'device-ota', label: 'OTA升级', icon: Smartphone, path: '/device-ota', keywords: ['ota', 'upgrade', 'shengji', 'OTA shengji'] },
  { id: 'device-shadow', label: '设备影子', icon: Braces, path: '/device-shadow', keywords: ['shebei', 'yingzi', 'shadow', 'device shadow'] },
  { id: 'tag-separation', label: '标签分离报警', icon: Unlink, path: '/tag-separation', keywords: ['biaoqian', 'fenli', 'tag', 'separation', 'alarm'] },
  { id: 'sites', label: '网点管理', icon: Warehouse, path: '/sites', keywords: ['wangdian', 'site', 'wangdian guanli'] },
  { id: 'org-site-aggregation', label: '组织网点聚合', icon: Building2, path: '/org-site-aggregation', keywords: ['zuzhi', 'wangdian', 'org', 'site', 'aggregation'] },
  { id: 'transfers', label: '调拨管理', icon: ArrowLeftRight, path: '/transfers', keywords: ['diaobo', 'transfer', 'diaobo guanli'] },
  { id: 'transfer-audit', label: '调拨审核', icon: ClipboardList, path: '/transfer-audit', keywords: ['diaobo', 'shenhe', 'audit', 'transfer audit'] },
  { id: 'transfer-track-replay', label: '轨迹回放', icon: PlayCircle, path: '/transfer-track-replay', keywords: ['guiji', 'track', 'replay', 'huifang', 'track replay'] },
  { id: 'routes', label: '流转线路', icon: Route, path: '/routes', keywords: ['liuzhuan', 'xianlu', 'route', 'flow route'] },
  { id: 'route-dashboard', label: '流转看板', icon: Activity, path: '/route-dashboard', keywords: ['liuzhuan', 'kanban', 'route', 'dashboard'] },
  { id: 'transfers-ownership', label: '过户管理', icon: Repeat, path: '/transfers-ownership', keywords: ['guohu', 'ownership', 'transfer', 'guohu guanli'] },
  { id: 'shipment-status', label: '发运状态', icon: Send, path: '/shipment-status', keywords: ['fayun', 'shipping', 'status', 'fayun zhuangtai'] },
  { id: 'carrier-allocation', label: '载具分配', icon: Boxes, path: '/carrier-allocation', keywords: ['zaiju', 'fenpei', 'allocation', 'vehicle allocation'] },
  { id: 'alarms', label: '报警中心', icon: Bell, path: '/alarms', keywords: ['baojing', 'alarm', 'baojing zhongxin'] },
  { id: 'alarm-workflow', label: '报警工作流', icon: Workflow, path: '/alarm-workflow', keywords: ['baojing', 'gongzuoliu', 'workflow', 'alarm workflow'] },
  { id: 'alarm-analysis', label: '报警分析', icon: Brain, path: '/alarm-analysis', keywords: ['baojing', 'fenxi', 'analysis', 'alarm analysis'] },
  { id: 'statistics', label: '数据统计', icon: BarChart3, path: '/statistics', keywords: ['shuju', 'tongji', 'statistics', 'data statistics'] },
  { id: 'projects', label: '项目管理', icon: FolderKanban, path: '/projects', keywords: ['xiangmu', 'project', 'xiangmu guanli'] },
  { id: 'messages', label: '消息中心', icon: MessageSquare, path: '/messages', keywords: ['xiaoxi', 'message', 'xiaoxi zhongxin'] },
  { id: 'inventory-check', label: '库存盘点', icon: ClipboardCheck, path: '/inventory-check', keywords: ['kucun', 'pandian', 'inventory', 'check'] },
  { id: 'billing', label: '计费结算', icon: Receipt, path: '/billing', keywords: ['jifei', 'jiesuan', 'billing', 'settlement'] },
  { id: 'amap', label: '高德地图', icon: Globe, path: '/amap', keywords: ['gaode', 'amap', 'gaode ditu', 'map'] },
  { id: 'dashboard-config', label: '看板配置', icon: DashboardIcon, path: '/dashboard-config', keywords: ['kanban', 'peizhi', 'dashboard', 'config'] },
  { id: 'borrow-return', label: '借用归还', icon: Handshake, path: '/borrow-return', keywords: ['jieyong', 'guihuan', 'borrow', 'return'] },
  { id: 'drivers', label: '司机管理', icon: UserCog, path: '/drivers', keywords: ['siji', 'driver', 'siji guanli'] },
  { id: 'users', label: '用户管理', icon: Users, path: '/users', keywords: ['yonghu', 'user', 'yonghu guanli'] },
  { id: 'delegate-login', label: '委托登录', icon: KeyRound, path: '/delegate-login', keywords: ['weituo', 'denglu', 'delegate', 'login'] },
  { id: 'field-permissions', label: '字段权限', icon: ShieldCheck, path: '/field-permissions', keywords: ['ziduan', 'quanxian', 'field', 'permission'] },
  { id: 'iot-platform', label: 'IoT数据中台', icon: Radio, path: '/iot-platform', keywords: ['iot', 'shuju', 'platform', 'IoT shuju'] },
  { id: 'beacon-management', label: '信标管理', icon: Radio, path: '/beacon-management', keywords: ['xinbiao', 'beacon', 'xinbiao guanli'] },
  { id: 'inout-rules', label: '出入库判定', icon: ShieldCheck, path: '/inout-rules', keywords: ['churu', 'ku', 'inout', 'rule', 'churu ku'] },
  { id: 'vehicle-unbind-records', label: '车辆解绑记录', icon: Unlink, path: '/vehicle-unbind-records', keywords: ['cheliang', 'jiebang', 'unbind', 'record', 'vehicle unbind'] },
  { id: 'wechat-miniprogram', label: '微信小程序管理', icon: Smartphone, path: '/wechat-miniprogram', keywords: ['weixin', 'xiaochengxu', 'wechat', 'miniprogram'] },
  { id: 'settings', label: '系统设置', icon: Settings, path: '/settings', keywords: ['xitong', 'shezhi', 'system', 'settings'] },
];

const iconMap: Record<string, LucideIcon> = {
  LayoutDashboard, MapPageIcon, SquareDashedMousePointer, Container, Package, Truck,
  Cpu, Warehouse, ArrowLeftRight, Route, Bell, Users, Settings, BarChart3,
  Repeat, FolderKanban, MessageSquare, ClipboardCheck, ClipboardList, Workflow,
  Activity, Receipt, Globe, DashboardIcon, Handshake, UserCog, Brain, Radio,
  Terminal, Smartphone, KeyRound, ShieldCheck, Unlink, Braces, Shield, Building2,
  PlayCircle, Send, Boxes,
};

const iconNameMap: Map<any, string> = new Map();
Object.entries(iconMap).forEach(([name, icon]) => iconNameMap.set(icon, name));

// ── localStorage helpers ─────────────────────────────────

const RECENT_KEY = 'command-palette-recent';
const MAX_RECENT = 6;

function loadRecents(): RecentItem[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as RecentItem[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveRecents(items: RecentItem[]) {
  localStorage.setItem(RECENT_KEY, JSON.stringify(items.slice(0, MAX_RECENT)));
}

function addRecent(menuItem: MenuItem) {
  const iconName = iconNameMap.get(menuItem.icon) ?? 'LayoutDashboard';
  const existing = loadRecents();
  const filtered = existing.filter((r) => r.id !== menuItem.id);
  const next: RecentItem[] = [
    {
      id: menuItem.id,
      label: menuItem.label,
      path: menuItem.path,
      iconName,
      timestamp: Date.now(),
    },
    ...filtered,
  ];
  saveRecents(next);
}

// ── Fuzzy search ───────────────────────────────────────────

function scoreMatch(item: MenuItem, query: string): number {
  const q = query.toLowerCase().trim();
  if (!q) return 1;

  const label = item.label.toLowerCase();
  const keywords = item.keywords;

  if (label === q) return 100;
  if (label.startsWith(q)) return 80;
  if (label.includes(q)) return 60;

  for (const kw of keywords) {
    const k = kw.toLowerCase();
    if (k === q) return 50;
    if (k.startsWith(q)) return 40;
    if (k.includes(q)) return 30;
  }

  if (item.path.toLowerCase().includes(q)) return 20;

  return 0;
}

// ── Component ──────────────────────────────────────────────

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const inputRef = useRef<HTMLInputElement>(null);

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [recentItems, setRecentItems] = useState<RecentItem[]>([]);

  // Load recents when opening
  useEffect(() => {
    if (open) {
      setRecentItems(loadRecents());
      setQuery('');
      setSelectedIndex(0);
      requestAnimationFrame(() => {
        inputRef.current?.focus();
      });
    }
  }, [open]);

  // Filtered results
  const filteredItems = useMemo(() => {
    const q = query.trim();
    if (!q) return menuItems;
    return menuItems
      .map((item) => ({ item, score: scoreMatch(item, q) }))
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .map(({ item }) => item);
  }, [query]);

  // Keyboard: Cmd/Ctrl+K opens
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        onOpenChange(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onOpenChange]);

  // Close on route change
  useEffect(() => {
    if (open) {
      onOpenChange(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);

  const handleSelectMenuItem = useCallback(
    (item: MenuItem) => {
      addRecent(item);
      navigate(item.path);
      onOpenChange(false);
    },
    [navigate, onOpenChange]
  );

  const handleSelectRecent = useCallback(
    (recent: RecentItem) => {
      const fullItem = menuItems.find((m) => m.id === recent.id);
      if (fullItem) addRecent(fullItem);
      navigate(recent.path);
      onOpenChange(false);
    },
    [navigate, onOpenChange]
  );

  const handleQuickAction = useCallback(
    (action: string) => {
      switch (action) {
        case 'home':
          navigate('/dashboard');
          onOpenChange(false);
          toast.info('已跳转到首页');
          break;
        case 'refresh':
          window.location.reload();
          break;
        case 'theme':
          toggleTheme();
          onOpenChange(false);
          toast.success(`已切换至${theme === 'light' ? '深色' : '浅色'}主题`);
          break;
      }
    },
    [navigate, onOpenChange, toggleTheme, theme]
  );

  // Determine groups visibility
  const hasQuery = query.trim().length > 0;
  const hasRecents = !hasQuery && recentItems.length > 0;
  const hasQuickActions = !hasQuery;

  // Build flat selectable list for keyboard nav
  const { flatItems, getIndexOfItem } = useMemo(() => {
    type FlatItem =
      | { type: 'quick'; index: number; action: string }
      | { type: 'recent'; index: number; recent: RecentItem }
      | { type: 'menu'; index: number; item: MenuItem };

    const items: FlatItem[] = [];

    if (hasQuickActions) {
      ['home', 'refresh', 'theme'].forEach((action, i) => {
        items.push({ type: 'quick', index: i, action });
      });
    }

    if (hasRecents) {
      recentItems.forEach((recent, i) => {
        items.push({ type: 'recent', index: i, recent });
      });
    }

    filteredItems.forEach((item, i) => {
      items.push({ type: 'menu', index: i, item });
    });

    function getItemAtIndex(idx: number): FlatItem | undefined {
      return items[idx];
    }

    function getIndexOfItem(type: FlatItem['type'], index: number): number {
      return items.findIndex((it) => it.type === type && it.index === index);
    }

    return { flatItems: items, getItemAtIndex, getIndexOfItem };
  }, [hasQuickActions, hasRecents, filteredItems, recentItems]);

  const totalSelectable = flatItems.length;

  // Keyboard navigation
  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onOpenChange(false);
        return;
      }

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % totalSelectable);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + totalSelectable) % totalSelectable);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const selected = flatItems[selectedIndex];
        if (!selected) return;
        if (selected.type === 'quick') {
          handleQuickAction(selected.action);
        } else if (selected.type === 'recent') {
          handleSelectRecent(selected.recent);
        } else if (selected.type === 'menu') {
          handleSelectMenuItem(selected.item);
        }
      }
    },
    [onOpenChange, totalSelectable, flatItems, selectedIndex, handleQuickAction, handleSelectRecent, handleSelectMenuItem]
  );

  const ThemeIcon = theme === 'light' ? Moon : Sun;

  const quickActions = [
    { id: 'home', label: '跳转到首页', icon: Home, shortcut: 'H', action: 'home' as const },
    { id: 'refresh', label: '刷新页面', icon: RefreshCw, shortcut: 'R', action: 'refresh' as const },
    { id: 'theme', label: '切换主题', icon: ThemeIcon, shortcut: 'T', action: 'theme' as const },
  ];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            onClick={() => onOpenChange(false)}
          />

          {/* Command Palette Container */}
          <motion.div
            className="relative w-full max-w-[640px] mx-4 rounded-xl border border-neutral-border bg-neutral-surface shadow-2xl overflow-hidden flex flex-col"
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{
              duration: 0.25,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            onKeyDown={handleKeyDown}
          >
            {/* Search Input */}
            <div className="flex items-center gap-3 px-4 h-14 border-b border-neutral-border shrink-0">
              <Search className="w-5 h-5 text-neutral-textTertiary shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                placeholder="搜索页面、功能或操作..."
                className="flex-1 bg-transparent text-sm text-neutral-textPrimary placeholder:text-neutral-textTertiary outline-none"
                autoFocus
              />
              <div className="flex items-center gap-1.5 shrink-0">
                <kbd className="hidden sm:inline-flex items-center justify-center h-6 px-1.5 rounded border border-neutral-border bg-neutral-background text-[10px] text-neutral-textSecondary font-mono">
                  <CommandIcon className="w-3 h-3 mr-0.5" />
                  K
                </kbd>
                <kbd className="hidden sm:inline-flex items-center justify-center h-6 px-1.5 rounded border border-neutral-border bg-neutral-background text-[10px] text-neutral-textSecondary font-mono">
                  ESC
                </kbd>
              </div>
            </div>

            {/* Content */}
            <div className="max-h-[60vh] overflow-y-auto">
              {/* Quick Actions */}
              {hasQuickActions && (
                <div className="px-2 py-2">
                  <div className="px-2 py-1.5 text-xs font-medium text-neutral-textTertiary">
                    快捷操作
                  </div>
                  <div className="grid grid-cols-3 gap-1">
                    {quickActions.map((action) => {
                      const Icon = action.icon;
                      const flatIndex = getIndexOfItem('quick', quickActions.indexOf(action));
                      const isSelected = selectedIndex === flatIndex;
                      return (
                        <button
                          key={action.id}
                          onClick={() => handleQuickAction(action.action)}
                          className={cn(
                            'flex flex-col items-center justify-center gap-1.5 rounded-lg px-2 py-3 transition-colors duration-150',
                            isSelected
                              ? 'bg-primary-light text-primary'
                              : 'hover:bg-neutral-background text-neutral-textSecondary'
                          )}
                        >
                          <Icon className="w-5 h-5" />
                          <span className="text-xs">{action.label}</span>
                          <kbd className="text-[10px] text-neutral-textTertiary font-mono">
                            {action.shortcut}
                          </kbd>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Recent Items */}
              {hasRecents && (
                <div className="px-2 py-2 border-t border-neutral-border">
                  <div className="px-2 py-1.5 text-xs font-medium text-neutral-textTertiary flex items-center gap-1.5">
                    <Clock className="w-3 h-3" />
                    最近访问
                  </div>
                  {recentItems.map((recent, idx) => {
                    const IconComp = iconMap[recent.iconName] ?? LayoutDashboard;
                    const flatIndex = getIndexOfItem('recent', idx);
                    const isSelected = selectedIndex === flatIndex;
                    return (
                      <button
                        key={recent.id}
                        onClick={() => handleSelectRecent(recent)}
                        className={cn(
                          'w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-colors duration-150',
                          isSelected
                            ? 'bg-primary-light text-primary'
                            : 'text-neutral-textSecondary hover:bg-neutral-background hover:text-neutral-textPrimary'
                        )}
                      >
                        <IconComp className="w-4 h-4 shrink-0" />
                        <span className="flex-1 text-left">{recent.label}</span>
                        <ArrowRight className="w-3.5 h-3.5 opacity-50" />
                      </button>
                    );
                  })}
                </div>
              )}

              {/* All Pages / Search Results */}
              <div className={cn('px-2 py-2', (hasQuickActions || hasRecents) && 'border-t border-neutral-border')}>
                <div className="px-2 py-1.5 text-xs font-medium text-neutral-textTertiary">
                  {hasQuery ? '搜索结果' : '所有页面'}
                </div>
                {filteredItems.length === 0 ? (
                  <div className="px-3 py-8 text-center text-sm text-neutral-textTertiary">
                    未找到与 &quot;{query}&quot; 相关的内容
                  </div>
                ) : (
                  filteredItems.map((item, idx) => {
                    const Icon = item.icon;
                    const flatIndex = getIndexOfItem('menu', idx);
                    const isSelected = selectedIndex === flatIndex;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleSelectMenuItem(item)}
                        className={cn(
                          'w-full flex items-center gap-3 rounded-md px-3 py-2.5 text-sm transition-colors duration-150',
                          isSelected
                            ? 'bg-primary-light text-primary'
                            : 'text-neutral-textSecondary hover:bg-neutral-background hover:text-neutral-textPrimary'
                        )}
                      >
                        <Icon className="w-4 h-4 shrink-0" />
                        <span className="flex-1 text-left">{item.label}</span>
                        <span className="text-xs text-neutral-textTertiary opacity-60 hidden sm:inline">
                          {item.path}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 opacity-50" />
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-4 h-9 border-t border-neutral-border bg-neutral-background text-neutral-textTertiary shrink-0">
              <div className="flex items-center gap-3 text-[11px]">
                <span className="flex items-center gap-1">
                  <kbd className="px-1 rounded border border-neutral-border bg-neutral-surface text-[10px]">↑↓</kbd>
                  选择
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1 rounded border border-neutral-border bg-neutral-surface text-[10px]">Enter</kbd>
                  跳转
                </span>
              </div>
              <span className="text-[11px]">
                {filteredItems.length} 个页面
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default CommandPalette;
