import { Outlet } from 'react-router-dom';

/**
 * Simple layout wrapper for pages without sidebar/topbar (e.g. login page)
 */
export default function Layout() {
  return (
    <div className="min-h-[100dvh]">
      <Outlet />
    </div>
  );
}
