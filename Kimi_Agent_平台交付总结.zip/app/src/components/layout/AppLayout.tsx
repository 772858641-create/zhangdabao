import { useState, useCallback } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

export default function AppLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const toggleCollapse = useCallback(() => {
    setCollapsed((prev) => !prev);
  }, []);

  const sidebarWidth = collapsed ? 64 : 220;

  return (
    <div className="min-h-[100dvh] bg-neutral-background">
      {/* Sidebar */}
      <Sidebar collapsed={collapsed} onToggleCollapse={toggleCollapse} />

      {/* Topbar - positioned relative to sidebar */}
      <div
        className="fixed top-0 right-0 z-30 transition-all duration-250"
        style={{
          left: sidebarWidth,
          transitionTimingFunction: 'ease',
        }}
      >
        <Topbar />
      </div>

      {/* Content area */}
      <main
        className="pt-14 transition-all duration-250 min-h-[100dvh]"
        style={{
          marginLeft: sidebarWidth,
          transitionTimingFunction: 'ease',
        }}
      >
        <div className="p-5">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{
                duration: 0.25,
                ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
              }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
