import { useState, useCallback, useMemo } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Container,
  ArrowLeftRight,
  Cpu,
  Warehouse,
  Bell,
  ShieldCheck,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  type LucideIcon,
} from 'lucide-react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { cn } from '@/lib/utils';

/* ─── 类型定义 ─── */
interface SubMenuItem {
  label: string;
  path: string;
}

interface MenuGroup {
  label: string;
  icon: LucideIcon;
  children: SubMenuItem[];
}

/* ─── 菜单数据：9个一级分组，收纳57个页面 ─── */
const menuGroups: MenuGroup[] = [
  {
    label: '数据看板',
    icon: LayoutDashboard,
    children: [
      { label: '数据看板', path: '/dashboard' },
      { label: '地图看板', path: '/map' },
      { label: '看板配置', path: '/dashboard-config' },
      { label: '框选操作', path: '/map-batch-ops' },
      { label: '地图设置', path: '/map-settings' },
    ],
  },
  {
    label: '载具资产',
    icon: Container,
    children: [
      { label: '载具管理', path: '/vehicles' },
      { label: '载具分配', path: '/carrier-allocation' },
      { label: '车辆管理', path: '/fleet' },
      { label: '物料管理', path: '/materials' },
      { label: '车辆围栏联动', path: '/vehicle-fence-inout' },
      { label: '车辆解绑记录', path: '/vehicle-unbind-records' },
      { label: '借用归还', path: '/borrow-return' },
      { label: '过户管理', path: '/transfers-ownership' },
      { label: '型号管理', path: '/models' },
    ],
  },
  {
    label: '调拨流转',
    icon: ArrowLeftRight,
    children: [
      { label: '调拨管理', path: '/transfers' },
      { label: '调拨审核', path: '/transfer-audit' },
      { label: '轨迹回放', path: '/transfer-track-replay' },
      { label: '发运状态', path: '/shipment-status' },
      { label: '流转线路', path: '/routes' },
      { label: '流转看板', path: '/route-dashboard' },
    ],
  },
  {
    label: 'IoT设备',
    icon: Cpu,
    children: [
      { label: '设备管理', path: '/devices' },
      { label: '设备指令', path: '/device-commands' },
      { label: 'OTA升级', path: '/device-ota' },
      { label: '设备影子', path: '/device-shadow' },
      { label: 'IoT数据中台', path: '/iot-platform' },
      { label: '信标管理', path: '/beacon-management' },
    ],
  },
  {
    label: '网点组织',
    icon: Warehouse,
    children: [
      { label: '网点管理', path: '/sites' },
      { label: '组织网点聚合', path: '/org-site-aggregation' },
      { label: '司机管理', path: '/drivers' },
    ],
  },
  {
    label: '报警中心',
    icon: Bell,
    children: [
      { label: '报警中心', path: '/alarms' },
      { label: '报警工作流', path: '/alarm-workflow' },
      { label: '报警分析', path: '/alarm-analysis' },
      { label: '报警设置', path: '/alarm-settings' },
      { label: '标签分离报警', path: '/tag-separation' },
    ],
  },
  {
    label: '精准出入库',
    icon: ShieldCheck,
    children: [
      { label: '出入库判定', path: '/inout-rules' },
      { label: '库存盘点', path: '/inventory-check' },
    ],
  },
  {
    label: '运营中心',
    icon: BarChart3,
    children: [
      { label: '数据统计', path: '/statistics' },
      { label: '导出记录', path: '/export-records' },
      { label: '历史数据', path: '/history-data' },
      { label: '审计日志', path: '/audit-logs' },
      { label: '计费结算', path: '/billing' },
      { label: '项目管理', path: '/projects' },
      { label: '消息中心', path: '/messages' },
      { label: '高德地图', path: '/amap' },
      { label: '数据中台', path: '/data-middle-platform' },
    ],
  },
  {
    label: '系统管理',
    icon: Settings,
    children: [
      { label: '用户管理', path: '/users' },
      { label: '角色管理', path: '/role-management' },
      { label: '菜单管理', path: '/menu-management' },
      { label: '组织管理', path: '/org-management' },
      { label: '委托登录', path: '/delegate-login' },
      { label: '字段权限', path: '/field-permissions' },
      { label: '微信小程序', path: '/wechat-miniprogram' },
      { label: '系统设置', path: '/settings' },
    ],
  },
];

/* ─── props ─── */
interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export default function Sidebar({ collapsed, onToggleCollapse }: SidebarProps) {
  const location = useLocation();

  /* 根据当前路由计算：哪个分组应该展开 */
  const activeGroupIndex = useMemo(() => {
    return menuGroups.findIndex((group) =>
      group.children.some((child) => {
        if (child.path === '/dashboard') {
          return location.pathname === '/dashboard' || location.pathname === '/';
        }
        return location.pathname.startsWith(child.path);
      })
    );
  }, [location.pathname]);

  /* 展开状态：默认展开当前路由所在组 */
  const [expandedGroups, setExpandedGroups] = useState<Set<number>>(() => {
    const init = new Set<number>();
    if (activeGroupIndex !== -1) init.add(activeGroupIndex);
    return init;
  });

  const toggleGroup = useCallback((index: number) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      return next;
    });
  }, []);

  const isChildActive = useCallback(
    (path: string) => {
      if (path === '/dashboard') {
        return location.pathname === '/dashboard' || location.pathname === '/';
      }
      return location.pathname.startsWith(path);
    },
    [location.pathname]
  );

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 h-full bg-[var(--neutral-surface)] border-r border-neutral-border z-40 flex flex-col transition-all duration-250',
        collapsed ? 'w-16' : 'w-[220px]'
      )}
    >
      {/* ── Logo ── */}
      <div
        className={cn(
          'h-14 flex items-center border-b border-neutral-border overflow-hidden',
          collapsed ? 'justify-center px-0' : 'px-4'
        )}
      >
        <AnimatePresence mode="wait">
          {collapsed ? (
            <motion.div
              key="collapsed-logo"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              className="flex items-center justify-center w-8 h-8 rounded bg-primary text-white font-bold text-sm"
            >
              载
            </motion.div>
          ) : (
            <motion.div
              key="expanded-logo"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
              className="flex items-center gap-2"
            >
              <div className="w-8 h-8 rounded bg-primary text-white flex items-center justify-center font-bold text-sm">载</div>
              <span className="font-semibold text-neutral-textPrimary">载具云</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Menu ── */}
      <nav className="flex-1 overflow-y-auto py-2">
        {menuGroups.map((group, groupIndex) => {
          const GroupIcon = group.icon;
          const isExpanded = expandedGroups.has(groupIndex);
          const hasActiveChild = group.children.some((c) => isChildActive(c.path));
          const isGroupActive = hasActiveChild && !isExpanded;

          if (collapsed) {
            return (
              <div key={group.label} className="relative mx-auto w-10">
                <NavLink
                  to={group.children[0].path}
                  className={cn(
                    'flex items-center justify-center h-10 w-10 rounded-md transition-colors duration-150 my-0.5',
                    hasActiveChild
                      ? 'bg-primary-light text-primary'
                      : 'text-neutral-textTertiary hover:bg-neutral-background hover:text-neutral-textSecondary'
                  )}
                  title={group.label}
                >
                  <GroupIcon size={18} />
                </NavLink>
              </div>
            );
          }

          return (
            <div key={group.label} className="mb-0.5">
              <button
                onClick={() => toggleGroup(groupIndex)}
                className={cn(
                  'w-full flex items-center mx-2 rounded-md transition-colors duration-150 h-10 px-3',
                  isGroupActive
                    ? 'bg-primary-light text-primary'
                    : 'text-neutral-textSecondary hover:bg-neutral-background hover:text-neutral-textPrimary'
                )}
              >
                <GroupIcon
                  size={18}
                  className={cn(
                    'flex-shrink-0 mr-3',
                    isGroupActive ? 'text-primary' : 'text-neutral-textTertiary'
                  )}
                />
                <span className={cn('text-sm flex-1 text-left whitespace-nowrap overflow-hidden', isGroupActive ? 'font-medium' : 'font-normal')}>
                  {group.label}
                </span>
                <motion.div animate={{ rotate: isExpanded ? 180 : 0 }} transition={{ duration: 0.2 }}>
                  <ChevronDown size={14} className="text-neutral-textTertiary ml-1" />
                </motion.div>
              </button>

              <AnimatePresence initial={false}>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25, ease: 'easeInOut' }}
                    className="overflow-hidden"
                  >
                    <div className="py-1">
                      {group.children.map((child) => {
                        const childActive = isChildActive(child.path);
                        return (
                          <NavLink
                            key={child.path}
                            to={child.path}
                            end={child.path === '/dashboard'}
                            className={cn(
                              'flex items-center h-9 mx-2 pl-9 pr-3 rounded-md text-sm transition-colors duration-150',
                              childActive
                                ? 'bg-primary-light text-primary font-medium'
                                : 'text-neutral-textTertiary hover:bg-neutral-background hover:text-neutral-textSecondary'
                            )}
                          >
                            <span className="whitespace-nowrap overflow-hidden">{child.label}</span>
                          </NavLink>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </nav>

      {/* ── Theme Toggle ── */}
      <div className="border-t border-neutral-border p-2">
        <div className={cn('flex items-center h-9 rounded-md transition-colors duration-150', collapsed ? 'justify-center w-10 mx-auto' : 'w-full px-3')}>
          <ThemeToggle />
          {!collapsed && <span className="text-xs ml-2 text-neutral-textTertiary">切换主题</span>}
        </div>
      </div>

      {/* ── Collapse Toggle ── */}
      <div className="border-t border-neutral-border p-2">
        <button
          onClick={onToggleCollapse}
          className={cn('flex items-center h-9 rounded-md text-neutral-textTertiary hover:bg-neutral-background hover:text-neutral-textSecondary transition-colors duration-150', collapsed ? 'justify-center w-10 mx-auto' : 'w-full px-3')}
          title={collapsed ? '展开' : '收起'}
        >
          {collapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={16} className="mr-2" /><span className="text-xs">收起侧边栏</span></>}
        </button>
      </div>
    </aside>
  );
}
