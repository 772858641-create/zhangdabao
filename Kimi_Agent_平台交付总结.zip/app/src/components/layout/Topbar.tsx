import { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  Bell,
  Maximize,
  Minimize,
  ChevronDown,
  User,
  Building2,
  LogOut,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';

const routeLabelMap: Record<string, string> = {
  '/': '数据看板',
  '/dashboard': '数据看板',
  '/map': '地图看板',
  '/vehicles': '载具管理',
  '/fleet': '车辆管理',
  '/devices': '设备管理',
  '/sites': '网点管理',
  '/transfers': '调拨管理',
  '/routes': '流转线路',
  '/alarms': '报警中心',
  '/users': '用户管理',
  '/settings': '系统设置',
};

export default function Topbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, switchOrg } = useAuth();
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  const currentPageLabel = routeLabelMap[location.pathname] || '数据看板';
  const breadcrumb = ['首页', currentPageLabel];

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleSwitchOrg = () => {
    const orgs = [
      { id: 'org-1', name: '云载科技（总部）' },
      { id: 'org-2', name: '华东汽车制造有限公司' },
      { id: 'org-3', name: '南方物流集团' },
      { id: 'org-4', name: '北方供应链管理有限公司' },
    ];
    const currentIdx = orgs.findIndex((o) => o.id === user?.orgId);
    const nextIdx = (currentIdx + 1) % orgs.length;
    switchOrg(orgs[nextIdx].id, orgs[nextIdx].name);
    setShowUserMenu(false);
  };

  // Mock notifications
  const notifications = [
    { id: 1, message: '载具 CJ000123 离线超过2小时', time: '10分钟前', unread: true },
    { id: 2, message: '调拨单 DB000001 已审核通过', time: '30分钟前', unread: true },
    { id: 3, message: '网点 上海浦东工厂 库存预警', time: '1小时前', unread: true },
    { id: 4, message: '设备 SB000012 电量低于20%', time: '2小时前', unread: false },
    { id: 5, message: '车辆 沪A12345 进入围栏区域', time: '3小时前', unread: false },
  ];

  const unreadCount = notifications.filter((n) => n.unread).length;

  return (
    <header
      className="fixed top-0 right-0 left-0 h-14 bg-white shadow-topbar z-30 flex items-center justify-between"
      style={{ marginLeft: undefined }}
    >
      {/* Left: Breadcrumb */}
      <div className="flex items-center h-full px-5">
        <nav className="flex items-center text-[13px]">
          {breadcrumb.map((item, idx) => (
            <span key={idx} className="flex items-center">
              {idx > 0 && (
                <span className="mx-2 text-neutral-border-strong">/</span>
              )}
              <span
                className={cn(
                  idx === breadcrumb.length - 1
                    ? 'text-neutral-textPrimary font-medium'
                    : 'text-neutral-textSecondary'
                )}
              >
                {item}
              </span>
            </span>
          ))}
        </nav>
      </div>

      {/* Center: Search */}
      <div className="absolute left-1/2 -translate-x-1/2">
        <div className="relative w-[360px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-textTertiary" />
          <input
            type="text"
            placeholder="搜索载具、设备、网点..."
            className="w-full h-9 pl-9 pr-4 text-[13px] bg-neutral-surface-elevated border border-neutral-border rounded-md text-neutral-textPrimary placeholder:text-neutral-textTertiary focus:outline-none focus:border-primary focus:shadow-focus transition-all duration-150"
          />
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1 pr-4">
        {/* Notification bell */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative flex items-center justify-center w-9 h-9 rounded-md text-neutral-textSecondary hover:bg-neutral-background transition-colors duration-150"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] flex items-center justify-center bg-danger text-white text-[11px] font-medium rounded-full px-1">
                {unreadCount}
              </span>
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.96 }}
                transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                className="absolute right-0 top-11 w-80 bg-white rounded-lg shadow-dropdown border border-neutral-border overflow-hidden"
              >
                <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-border">
                  <span className="text-sm font-medium text-neutral-textPrimary">通知</span>
                  <button className="text-xs text-primary hover:underline">全部已读</button>
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className={cn(
                        'flex items-start gap-3 px-4 py-3 hover:bg-neutral-background cursor-pointer transition-colors',
                        n.unread && 'bg-primary-light/30'
                      )}
                    >
                      <div className={cn('w-2 h-2 mt-1.5 rounded-full flex-shrink-0', n.unread ? 'bg-primary' : 'bg-neutral-border')} />
                      <div className="flex-1 min-w-0">
                        <p className="text-[13px] text-neutral-textPrimary leading-5">{n.message}</p>
                        <p className="text-[11px] text-neutral-textTertiary mt-0.5">{n.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="px-4 py-2.5 border-t border-neutral-border text-center">
                  <button
                    onClick={() => { navigate('/alarms'); setShowNotifications(false); }}
                    className="text-xs text-primary hover:underline"
                  >
                    查看全部通知
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Fullscreen toggle */}
        <button
          onClick={toggleFullscreen}
          className="flex items-center justify-center w-9 h-9 rounded-md text-neutral-textSecondary hover:bg-neutral-background transition-colors duration-150"
        >
          {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
        </button>

        {/* User avatar dropdown */}
        <div className="relative" ref={userMenuRef}>
          <button
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 h-9 pl-1 pr-2 rounded-md hover:bg-neutral-background transition-colors duration-150 ml-1"
          >
            <div className="w-7 h-7 rounded-full bg-primary-light flex items-center justify-center text-primary text-xs font-medium">
              {user?.name?.charAt(0) || '管'}
            </div>
            <span className="text-[13px] text-neutral-textPrimary max-w-[80px] truncate">
              {user?.name || '管理员'}
            </span>
            <ChevronDown size={14} className="text-neutral-textTertiary" />
          </button>

          <AnimatePresence>
            {showUserMenu && (
              <motion.div
                initial={{ opacity: 0, y: -4, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.96 }}
                transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                className="absolute right-0 top-11 w-52 bg-white rounded-lg shadow-dropdown border border-neutral-border overflow-hidden"
              >
                {/* User info */}
                <div className="px-4 py-3 border-b border-neutral-border">
                  <p className="text-sm font-medium text-neutral-textPrimary">{user?.name || '管理员'}</p>
                  <p className="text-xs text-neutral-textTertiary mt-0.5">{user?.account || 'admin'}</p>
                  <div className="flex items-center gap-1 mt-1.5">
                    <Building2 size={12} className="text-neutral-textTertiary" />
                    <p className="text-xs text-neutral-textSecondary truncate">{user?.orgName || '云载科技（总部）'}</p>
                  </div>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => { setShowUserMenu(false); }}
                    className="flex items-center gap-2.5 w-full px-4 py-2 text-[13px] text-neutral-textSecondary hover:bg-neutral-background hover:text-neutral-textPrimary transition-colors"
                  >
                    <User size={15} />
                    个人资料
                  </button>
                  <button
                    onClick={handleSwitchOrg}
                    className="flex items-center gap-2.5 w-full px-4 py-2 text-[13px] text-neutral-textSecondary hover:bg-neutral-background hover:text-neutral-textPrimary transition-colors"
                  >
                    <Building2 size={15} />
                    切换组织
                  </button>
                </div>

                <div className="border-t border-neutral-border py-1">
                  <button
                    onClick={handleLogout}
                    className="flex items-center gap-2.5 w-full px-4 py-2 text-[13px] text-danger hover:bg-danger-light transition-colors"
                  >
                    <LogOut size={15} />
                    退出登录
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  );
}
