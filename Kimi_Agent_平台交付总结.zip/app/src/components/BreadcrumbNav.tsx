import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Home, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const ROUTE_NAME_MAP: Record<string, string> = {
  '/dashboard': '数据看板',
  '/map': '地图看板',
  '/map-batch-ops': '框选操作',
  '/vehicles': '载具管理',
  '/materials': '物料管理',
  '/fleet': '车辆管理',
  '/devices': '设备管理',
  '/device-commands': '设备指令',
  '/device-ota': 'OTA升级',
  '/device-shadow': '设备影子',
  '/tag-separation': '标签分离报警',
  '/sites': '网点管理',
  '/vehicle-fence-inout': '车辆围栏联动',
  '/org-site-aggregation': '组织网点聚合',
  '/transfers': '调拨管理',
  '/transfer-audit': '调拨审核',
  '/transfer-track-replay': '轨迹回放',
  '/transfer-ownership': '过户管理',
  '/routes': '流转线路',
  '/route-dashboard': '流转看板',
  '/alarms': '报警中心',
  '/alarm-workflow': '报警工作流',
  '/alarm-analysis': '报警分析',
  '/statistics': '数据统计',
  '/projects': '项目管理',
  '/messages': '消息中心',
  '/inventory-check': '库存盘点',
  '/billing': '计费结算',
  '/amap': '高德地图',
  '/dashboard-config': '看板配置',
  '/borrow-return': '借用归还',
  '/drivers': '司机管理',
  '/users': '用户管理',
  '/delegate-login': '委托登录',
  '/field-permissions': '字段权限',
  '/iot-platform': 'IoT数据中台',
  '/beacon-management': '信标管理',
  '/inout-rules': '出入库判定',
  '/settings': '系统设置',
  '/shipment-status': '发运状态',
  '/carrier-allocation': '载具分配',
  '/vehicle-unbind-records': '车辆解绑记录',
  '/wechat-miniprogram': '微信小程序管理',
  '/alarm-settings': '报警设置',
  '/map-settings': '地图设置',
  '/export-records': '导出记录',
  '/history-data': '历史数据',
  '/audit-logs': '审计日志',
  '/role-management': '角色管理',
  '/menu-management': '菜单管理',
  '/org-management': '组织管理',
  '/models': '型号管理',
  '/data-middle-platform': '数据中台',
};

interface BreadcrumbItem {
  path: string;
  name: string;
  isLast: boolean;
}

interface BreadcrumbNavProps {
  pathname: string;
}

export default function BreadcrumbNav({ pathname }: BreadcrumbNavProps) {
  const items = useMemo<BreadcrumbItem[]>(() => {
    const normalized = pathname || '/';

    if (normalized === '/' || normalized === '/dashboard') {
      return [{ path: '/dashboard', name: '数据看板', isLast: true }];
    }

    const parts = normalized.split('/').filter(Boolean);
    const result: BreadcrumbItem[] = [];

    result.push({ path: '/dashboard', name: '数据看板', isLast: false });

    let currentPath = '';
    for (let i = 0; i < parts.length; i++) {
      currentPath += `/${parts[i]}`;
      const name = ROUTE_NAME_MAP[currentPath] || parts[i];
      result.push({
        path: currentPath,
        name,
        isLast: i === parts.length - 1,
      });
    }

    return result;
  }, [pathname]);

  return (
    <motion.nav
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="flex items-center gap-1.5 text-sm mb-4 select-none"
      aria-label="面包屑导航"
    >
      {items.map((item, index) => (
        <div key={`${item.path}-${index}`} className="flex items-center gap-1.5">
          {index > 0 && (
            <ChevronRight className="w-3.5 h-3.5 text-[var(--neutral-text-tertiary)] flex-shrink-0" />
          )}
          {item.isLast ? (
            <span className="font-medium text-[var(--neutral-text-primary)] truncate">
              {item.name}
            </span>
          ) : (
            <Link
              to={item.path}
              className="flex items-center gap-1 text-[var(--neutral-text-secondary)] hover:text-[var(--neutral-text-primary)] transition-colors duration-200"
            >
              {index === 0 && <Home className="w-3.5 h-3.5 flex-shrink-0" />}
              <span className="truncate">{item.name}</span>
            </Link>
          )}
        </div>
      ))}
    </motion.nav>
  );
}
