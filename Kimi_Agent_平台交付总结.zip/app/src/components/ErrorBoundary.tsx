import { Component, type ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-neutral-background">
          <div className="text-center max-w-md p-8">
            <div className="w-16 h-16 rounded-full bg-danger/10 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-danger" />
            </div>
            <h2 className="text-xl font-bold text-neutral-textPrimary mb-2">页面出错了</h2>
            <p className="text-sm text-neutral-textSecondary mb-6">
              {this.state.error?.message || '发生了意外错误，请尝试刷新页面'}
            </p>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => window.location.reload()}>刷新页面</Button>
              <Button variant="outline" onClick={() => window.history.back()}>返回上一页</Button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
