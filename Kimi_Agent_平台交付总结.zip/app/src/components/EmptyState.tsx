import { EmptyStateIcon } from '@/components/EmptyStateIcon';

interface EmptyStateProps {
  title?: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ title = '暂无数据', description = '当前条件下没有找到数据', action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-24 h-24 mb-4 text-neutral-textTertiary">
        <EmptyStateIcon />
      </div>
      <h3 className="text-lg font-medium text-neutral-textSecondary mb-1">{title}</h3>
      <p className="text-sm text-neutral-textTertiary mb-4 max-w-sm">{description}</p>
      {action}
    </div>
  );
}
