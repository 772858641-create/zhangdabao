export function EmptyStateIcon() {
  return (
    <svg viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="20" y="30" width="80" height="60" rx="8" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" />
      <circle cx="45" cy="55" r="8" stroke="currentColor" strokeWidth="2" />
      <line x1="60" y1="50" x2="85" y2="50" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <line x1="60" y1="60" x2="75" y2="60" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M35 85 L50 70 L65 80 L80 65 L95 85" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
