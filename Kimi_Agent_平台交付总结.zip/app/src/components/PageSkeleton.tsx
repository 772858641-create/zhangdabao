import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';

export function PageSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2"><Skeleton className="h-8 w-[200px]" /><Skeleton className="h-4 w-[300px]" /></div>
        <Skeleton className="h-10 w-[120px]" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}><CardContent className="p-4"><div className="flex items-center gap-3"><Skeleton className="h-10 w-10 rounded-full" /><div className="space-y-1"><Skeleton className="h-3 w-16" /><Skeleton className="h-6 w-12" /></div></div></CardContent></Card>
        ))}
      </div>
      <Card><CardContent className="p-4 space-y-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3"><Skeleton className="h-4 w-[120px]" /><Skeleton className="h-4 w-[200px]" /><Skeleton className="h-4 w-[100px]" /><Skeleton className="h-4 w-[80px]" /></div>
        ))}
      </CardContent></Card>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 p-2"><Skeleton className="h-4 w-full" /></div>
      ))}
    </div>
  );
}
