import { useRef, useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TableSkeleton } from '@/components/PageSkeleton';

interface VirtualTableProps<T> {
  data: T[];
  columns: { key: string; title: string; render?: (item: T) => React.ReactNode }[];
  rowHeight?: number;
  height?: number;
  loading?: boolean;
}

export function VirtualTable<T extends Record<string, any>>({
  data,
  columns,
  rowHeight = 48,
  height = 400,
  loading = false,
}: VirtualTableProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);

  if (loading) return <TableSkeleton rows={5} />;

  const visibleCount = Math.ceil(height / rowHeight) + 2;
  const startIdx = Math.floor(scrollTop / rowHeight);
  const endIdx = Math.min(startIdx + visibleCount, data.length);
  const visibleData = data.slice(startIdx, endIdx);
  const offsetY = startIdx * rowHeight;

  const totalHeight = data.length * rowHeight;

  return (
    <div
      ref={containerRef}
      style={{ height, overflow: 'auto' }}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
      className="border rounded-md"
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        <Table>
          <TableHeader className="sticky top-0 bg-white z-10 shadow-sm">
            <TableRow>{columns.map(col => <TableHead key={col.key}>{col.title}</TableHead>)}</TableRow>
          </TableHeader>
          <TableBody>
            <tr style={{ height: offsetY }} />
            {visibleData.map((item, idx) => (
              <TableRow key={idx} className="hover:bg-neutral-background transition-colors">
                {columns.map(col => (
                  <TableCell key={col.key}>
                    {col.render ? col.render(item) : item[col.key]}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
