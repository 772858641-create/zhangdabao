import { useMemo } from 'react';
import type { WidgetConfig } from '@/pages/DashboardConfigPage';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  ComposedChart,
} from 'recharts';
import { ArrowUpRight, ArrowDownRight, MapPin } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

const COLORS = [
  '#2563EB',
  '#10B981',
  '#F59E0B',
  '#EF4444',
  '#8B5CF6',
  '#06B6D4',
  '#EC4899',
  '#14B8A6',
];

function seededRandom(seed: number) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

function getSeedFromString(str: string) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

function useMockData(widget: WidgetConfig, filters: Record<string, string>) {
  return useMemo(() => {
    const seedBase = getSeedFromString(
      widget.i + widget.dataSource + widget.dimension + JSON.stringify(filters)
    );
    let seed = seedBase;
    const next = () => {
      seed += 1;
      return seededRandom(seed);
    };
    const nextInt = (min: number, max: number) =>
      Math.floor(next() * (max - min + 1)) + min;
    const nextFloat = (min: number, max: number) =>
      next() * (max - min) + min;

    const sourceMult: Record<string, number> = {
      vehicle: 1,
      material: 0.8,
      device: 1.2,
      site: 0.6,
      transfer: 0.9,
      alarm: 0.3,
      fleet: 1.1,
      project: 0.7,
      circulation: 0.85,
      ops: 0.75,
    };
    const dimMult =
      filters.dimension === 'org'
        ? 1.2
        : filters.dimension === 'site'
          ? 0.9
          : 1;
    const timeMult =
      filters.timeRange === 'year'
        ? 12
        : filters.timeRange === 'month'
          ? 4
          : 1;
    const baseMult =
      (sourceMult[widget.dataSource] || 1) * dimMult * timeMult;

    if (widget.type === 'kpi') {
      const value = Math.round(nextFloat(100, 5000) * baseMult);
      const prev = Math.round(value * (0.8 + next() * 0.4));
      const change = ((value - prev) / prev) * 100;
      return {
        value,
        prev,
        change,
        unit:
          widget.metric === 'percentage'
            ? '%'
            : widget.metric === 'time'
              ? 'h'
              : '',
      };
    }

    if (widget.type === 'table') {
      const rows = nextInt(5, 10);
      const headers = ['名称', '数值', '占比', '趋势'];
      const data: Record<string, string | number>[] = [];
      for (let i = 0; i < rows; i++) {
        const val = Math.round(nextFloat(50, 1000) * baseMult);
        data.push({
          名称: `${widget.dataSource}-${i + 1}`,
          数值: val,
          占比: `${nextFloat(5, 30).toFixed(1)}%`,
          趋势: next() > 0.5 ? '上升' : '下降',
        });
      }
      return { headers, data };
    }

    if (widget.type === 'rank') {
      const count = nextInt(5, 10);
      const data: { name: string; value: number }[] = [];
      for (let i = 0; i < count; i++) {
        data.push({
          name: `${widget.dataSource} ${i + 1}`,
          value: Math.round(
            nextFloat(100, 1000) * baseMult * (1 - i * 0.08)
          ),
        });
      }
      return data;
    }

    if (widget.type === 'funnel') {
      const stages = ['访问', '意向', '签约', '交付', '回款'];
      const data: { name: string; value: number; percent: number }[] = [];
      let prev = 1000;
      for (let i = 0; i < stages.length; i++) {
        const val = Math.round(prev * (0.5 + next() * 0.3));
        data.push({
          name: stages[i],
          value: val,
          percent: Math.round((val / 1000) * 100),
        });
        prev = val;
      }
      return data;
    }

    if (widget.type === 'heatmap') {
      const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
      const hours = ['早', '中', '晚'];
      const data: { x: string; y: string; value: number }[] = [];
      for (const day of days) {
        for (const hour of hours) {
          data.push({
            x: day,
            y: hour,
            value: Math.round(nextFloat(10, 100) * baseMult),
          });
        }
      }
      return data;
    }

    if (widget.type === 'map') {
      const sites = [
        '北京',
        '上海',
        '广州',
        '深圳',
        '杭州',
        '成都',
        '武汉',
        '西安',
      ];
      const data: { name: string; count: number }[] = [];
      for (let i = 0; i < nextInt(4, 8); i++) {
        data.push({
          name: sites[i],
          count: Math.round(nextFloat(50, 500) * baseMult),
        });
      }
      return data;
    }

    const count =
      filters.timeRange === 'year'
        ? 12
        : filters.timeRange === 'month'
          ? 4
          : 7;
    const labels =
      widget.dimension === 'time'
        ? Array.from(
            { length: count },
            (_, i) => `${i + 1}${widget.dataSource === 'vehicle' ? '月' : '日'}`
          )
        : ['A组', 'B组', 'C组', 'D组', 'E组', 'F组'];

    const data: Record<string, number | string>[] = [];
    for (
      let i = 0;
      i < Math.min(count, labels.length);
      i++
    ) {
      const item: Record<string, number | string> = {
        name: labels[i],
      };
      if (widget.type === 'combo') {
        item['数值'] = Math.round(nextFloat(50, 500) * baseMult);
        item['比率'] = Math.round(nextFloat(10, 100) * baseMult);
      } else {
        item['value'] = Math.round(nextFloat(50, 500) * baseMult);
      }
      if (widget.type === 'line') {
        item['value2'] = Math.round(nextFloat(30, 400) * baseMult);
      }
      data.push(item);
    }
    return data;
  }, [widget, filters]);
}

function KpiWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    value: number;
    prev: number;
    change: number;
    unit: string;
  };
  const isUp = data.change >= 0;
  return (
    <div className="flex flex-col justify-center h-full px-5 py-4">
      <div className="text-sm text-neutral-textSecondary mb-1">{widget.title}</div>
      <div className="flex items-end gap-2 mb-2">
        <span className="text-3xl font-bold text-neutral-textPrimary font-display">
          {data.value.toLocaleString()}
          {data.unit}
        </span>
      </div>
      <div
        className={cn(
          'flex items-center gap-1 text-sm',
          isUp ? 'text-success' : 'text-danger'
        )}
      >
        {isUp ? (
          <ArrowUpRight className="size-4" />
        ) : (
          <ArrowDownRight className="size-4" />
        )}
        <span>{Math.abs(data.change).toFixed(1)}%</span>
        <span className="ml-1 text-neutral-textTertiary">同比</span>
      </div>
    </div>
  );
}

function BarWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as { name: string; value: number }[];
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
        <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} />
        <YAxis tick={{ fontSize: 12, fill: '#475569' }} />
        <Tooltip
          contentStyle={{
            background: '#fff',
            border: '1px solid #E2E8F0',
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Bar dataKey="value" fill="#2563EB" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function LineWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    name: string;
    value: number;
    value2: number;
  }[];
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={`grad-${widget.i}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#2563EB" stopOpacity={0.3} />
            <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
        <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} />
        <YAxis tick={{ fontSize: 12, fill: '#475569' }} />
        <Tooltip
          contentStyle={{
            background: '#fff',
            border: '1px solid #E2E8F0',
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area
          type="monotone"
          dataKey="value"
          stroke="#2563EB"
          fill={`url(#grad-${widget.i})`}
          strokeWidth={2}
          name="本期"
        />
        <Line
          type="monotone"
          dataKey="value2"
          stroke="#10B981"
          strokeWidth={2}
          dot={false}
          name="同期"
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function PieWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as { name: string; value: number }[];
  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          innerRadius="40%"
          outerRadius="70%"
          paddingAngle={3}
          dataKey="value"
          nameKey="name"
        >
          {data.map((_, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={{
            background: '#fff',
            border: '1px solid #E2E8F0',
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function TableWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    headers: string[];
    data: Record<string, string | number>[];
  };
  return (
    <div className="h-full overflow-auto px-2">
      <Table>
        <TableHeader>
          <TableRow>
            {data.headers.map((h) => (
              <TableHead key={h} className="text-xs text-neutral-textSecondary">
                {h}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.data.map((row, idx) => (
            <TableRow key={idx}>
              {data.headers.map((h) => (
                <TableCell key={h} className="text-xs text-neutral-textPrimary py-1.5">
                  {row[h]}
                </TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function RankWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as { name: string; value: number }[];
  return (
    <div className="flex flex-col gap-1.5 h-full overflow-auto px-3 py-2">
      {data.map((item, index) => (
        <div
          key={item.name}
          className="flex items-center gap-3 rounded-md px-2 py-1.5 hover:bg-neutral-surface-elevated transition-colors"
        >
          <div
            className={cn(
              'flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold shrink-0',
              index === 0
                ? 'bg-warning text-white'
                : index === 1
                  ? 'bg-neutral-border-strong text-white'
                  : index === 2
                    ? 'bg-[#CD7F32] text-white'
                    : 'bg-neutral-surface-elevated text-neutral-textSecondary'
            )}
          >
            {index + 1}
          </div>
          <span className="flex-1 text-sm text-neutral-textPrimary truncate">
            {item.name}
          </span>
          <span className="text-sm font-semibold text-neutral-textPrimary font-display">
            {item.value.toLocaleString()}
          </span>
        </div>
      ))}
    </div>
  );
}

function ComboWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    name: string;
    数值: number;
    比率: number;
  }[];
  return (
    <ResponsiveContainer width="100%" height="100%">
      <ComposedChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
        <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#475569' }} />
        <YAxis
          yAxisId="left"
          tick={{ fontSize: 12, fill: '#475569' }}
        />
        <YAxis
          yAxisId="right"
          orientation="right"
          tick={{ fontSize: 12, fill: '#475569' }}
        />
        <Tooltip
          contentStyle={{
            background: '#fff',
            border: '1px solid #E2E8F0',
            borderRadius: 6,
            fontSize: 12,
          }}
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Bar
          yAxisId="left"
          dataKey="数值"
          fill="#2563EB"
          radius={[4, 4, 0, 0]}
        />
        <Line
          yAxisId="right"
          type="monotone"
          dataKey="比率"
          stroke="#F59E0B"
          strokeWidth={2}
          dot={false}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}

function FunnelWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    name: string;
    value: number;
    percent: number;
  }[];
  return (
    <div className="flex flex-col items-center justify-center h-full gap-2 px-4 py-2">
      {data.map((item, index) => {
        const width = 100 - index * 15;
        return (
          <div
            key={item.name}
            className="flex items-center justify-between rounded-md px-3 py-2 text-white text-sm"
            style={{
              width: `${width}%`,
              backgroundColor: COLORS[index % COLORS.length],
            }}
          >
            <span>{item.name}</span>
            <span className="font-semibold font-display">{item.value}</span>
          </div>
        );
      })}
    </div>
  );
}

function HeatmapWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as {
    x: string;
    y: string;
    value: number;
  }[];
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const hours = ['早', '中', '晚'];
  const maxVal = Math.max(...data.map((d) => d.value), 1);

  return (
    <div className="h-full overflow-auto px-2 py-2">
      <div className="grid" style={{ gridTemplateColumns: `60px repeat(${days.length}, 1fr)` }}>
        <div />
        {days.map((d) => (
          <div key={d} className="text-center text-xs text-neutral-textSecondary py-1">
            {d}
          </div>
        ))}
        {hours.map((h) => (
          <>
            <div className="text-xs text-neutral-textSecondary flex items-center justify-end pr-2">
              {h}
            </div>
            {days.map((d) => {
              const val = data.find((item) => item.x === d && item.y === h)?.value ?? 0;
              const intensity = val / maxVal;
              return (
                <div
                  key={`${d}-${h}`}
                  className="rounded-sm m-0.5 flex items-center justify-center text-xs font-medium"
                  style={{
                    backgroundColor: `rgba(37, 99, 235, ${0.1 + intensity * 0.85})`,
                    color: intensity > 0.5 ? '#fff' : '#0F172A',
                    minHeight: 24,
                  }}
                  title={`${d} ${h}: ${val}`}
                >
                  {val}
                </div>
              );
            })}
          </>
        ))}
      </div>
    </div>
  );
}

function MapWidget({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  const data = useMockData(widget, filters) as { name: string; count: number }[];
  return (
    <div className="flex flex-col gap-1 h-full overflow-auto px-3 py-2">
      {data.map((item) => (
        <div
          key={item.name}
          className="flex items-center gap-3 rounded-md px-2 py-2 hover:bg-neutral-surface-elevated transition-colors border border-neutral-border"
        >
          <MapPin className="size-4 text-primary shrink-0" />
          <span className="flex-1 text-sm text-neutral-textPrimary">
            {item.name}
          </span>
          <span className="text-sm font-semibold text-primary font-display">
            {item.count.toLocaleString()}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function WidgetRenderer({
  widget,
  filters,
}: {
  widget: WidgetConfig;
  filters: Record<string, string>;
}) {
  switch (widget.type) {
    case 'kpi':
      return <KpiWidget widget={widget} filters={filters} />;
    case 'bar':
      return <BarWidget widget={widget} filters={filters} />;
    case 'line':
      return <LineWidget widget={widget} filters={filters} />;
    case 'pie':
      return <PieWidget widget={widget} filters={filters} />;
    case 'table':
      return <TableWidget widget={widget} filters={filters} />;
    case 'rank':
      return <RankWidget widget={widget} filters={filters} />;
    case 'combo':
      return <ComboWidget widget={widget} filters={filters} />;
    case 'funnel':
      return <FunnelWidget widget={widget} filters={filters} />;
    case 'heatmap':
      return <HeatmapWidget widget={widget} filters={filters} />;
    case 'map':
      return <MapWidget widget={widget} filters={filters} />;
    default:
      return null;
  }
}
