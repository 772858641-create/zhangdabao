import { useState, useEffect } from 'react';
import type { WidgetConfig, DashboardPage } from '@/pages/DashboardConfigPage';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  BarChart3,
  LineChart,
  PieChart,
  Table,
  Trophy,
  Layers,
  Funnel,
  Grid3x3,
  MapPin,
  Activity,
  Type,
} from 'lucide-react';

const DATA_SOURCES = [
  { value: 'vehicle', label: '载具数据' },
  { value: 'material', label: '物料数据' },
  { value: 'device', label: '设备数据' },
  { value: 'site', label: '网点数据' },
  { value: 'transfer', label: '调拨数据' },
  { value: 'alarm', label: '报警数据' },
  { value: 'fleet', label: '车辆数据' },
  { value: 'project', label: '项目数据' },
  { value: 'circulation', label: '流转数据' },
  { value: 'ops', label: '运维数据' },
];

const DIMENSIONS = [
  { value: 'time', label: '时间' },
  { value: 'org', label: '组织' },
  { value: 'site', label: '网点' },
  { value: 'type', label: '载具类型' },
];

const METRICS = [
  { value: 'count', label: '数量' },
  { value: 'time', label: '时长' },
  { value: 'percentage', label: '百分比' },
];

const AGGREGATIONS = [
  { value: 'count', label: '计数' },
  { value: 'sum', label: '求和' },
  { value: 'avg', label: '平均值' },
  { value: 'max', label: '最大值' },
  { value: 'min', label: '最小值' },
];

const WIDGET_TYPES: {
  type: WidgetConfig['type'];
  label: string;
  icon: React.ReactNode;
}[] = [
  { type: 'kpi', label: 'KPI卡片', icon: <Activity className="size-4" /> },
  { type: 'bar', label: '柱状图', icon: <BarChart3 className="size-4" /> },
  { type: 'line', label: '折线图', icon: <LineChart className="size-4" /> },
  { type: 'pie', label: '饼图', icon: <PieChart className="size-4" /> },
  { type: 'table', label: '数据表格', icon: <Table className="size-4" /> },
  { type: 'rank', label: '排名榜', icon: <Trophy className="size-4" /> },
  { type: 'combo', label: '组合图表', icon: <Layers className="size-4" /> },
  { type: 'funnel', label: '漏斗图', icon: <Funnel className="size-4" /> },
  { type: 'heatmap', label: '热力图', icon: <Grid3x3 className="size-4" /> },
  { type: 'map', label: '地图分布', icon: <MapPin className="size-4" /> },
];

function WidgetFormFields({
  config,
  onChange,
}: {
  config: Partial<WidgetConfig>;
  onChange: (config: Partial<WidgetConfig>) => void;
}) {
  return (
    <div className="grid gap-4 py-2">
      <div className="grid gap-2">
        <Label>图表类型</Label>
        <div className="grid grid-cols-5 gap-2">
          {WIDGET_TYPES.map((wt) => (
            <button
              key={wt.type}
              type="button"
              onClick={() => onChange({ ...config, type: wt.type })}
              className={
                config.type === wt.type
                  ? 'flex flex-col items-center gap-1 rounded-md border-2 border-primary bg-primary-light p-2 text-xs text-primary transition-colors'
                  : 'flex flex-col items-center gap-1 rounded-md border border-neutral-border bg-neutral-surface p-2 text-xs text-neutral-textSecondary hover:border-neutral-border-strong transition-colors'
              }
            >
              {wt.icon}
              <span>{wt.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="widget-title">标题</Label>
        <Input
          id="widget-title"
          value={config.title || ''}
          onChange={(e) => onChange({ ...config, title: e.target.value })}
          placeholder="请输入组件标题"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label>数据源</Label>
          <Select
            value={config.dataSource || ''}
            onValueChange={(v) => onChange({ ...config, dataSource: v })}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择数据源" />
            </SelectTrigger>
            <SelectContent>
              {DATA_SOURCES.map((ds) => (
                <SelectItem key={ds.value} value={ds.value}>
                  {ds.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-2">
          <Label>维度</Label>
          <Select
            value={config.dimension || ''}
            onValueChange={(v) => onChange({ ...config, dimension: v })}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择维度" />
            </SelectTrigger>
            <SelectContent>
              {DIMENSIONS.map((d) => (
                <SelectItem key={d.value} value={d.value}>
                  {d.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label>指标</Label>
          <Select
            value={config.metric || ''}
            onValueChange={(v) => onChange({ ...config, metric: v })}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择指标" />
            </SelectTrigger>
            <SelectContent>
              {METRICS.map((m) => (
                <SelectItem key={m.value} value={m.value}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-2">
          <Label>聚合方式</Label>
          <Select
            value={config.aggregation || ''}
            onValueChange={(v) => onChange({ ...config, aggregation: v })}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择聚合方式" />
            </SelectTrigger>
            <SelectContent>
              {AGGREGATIONS.map((a) => (
                <SelectItem key={a.value} value={a.value}>
                  {a.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="grid gap-2">
          <Label htmlFor="widget-w">宽度（列）</Label>
          <Input
            id="widget-w"
            type="number"
            min={1}
            max={12}
            value={config.w || 4}
            onChange={(e) =>
              onChange({ ...config, w: parseInt(e.target.value || '4', 10) })
            }
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="widget-h">高度（行）</Label>
          <Input
            id="widget-h"
            type="number"
            min={1}
            max={20}
            value={config.h || 4}
            onChange={(e) =>
              onChange({ ...config, h: parseInt(e.target.value || '4', 10) })
            }
          />
        </div>
      </div>
    </div>
  );
}

export function AddWidgetDialog({
  open,
  onOpenChange,
  onAdd,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (widget: Omit<WidgetConfig, 'i' | 'x' | 'y'>) => void;
}) {
  const [config, setConfig] = useState<Partial<WidgetConfig>>({
    type: 'bar',
    title: '新组件',
    dataSource: 'vehicle',
    dimension: 'time',
    metric: 'count',
    aggregation: 'count',
    w: 4,
    h: 4,
  });

  function handleAdd() {
    if (!config.type || !config.title || !config.dataSource) return;
    onAdd({
      type: config.type,
      title: config.title,
      dataSource: config.dataSource,
      dimension: config.dimension || 'time',
      metric: config.metric || 'count',
      aggregation: config.aggregation || 'count',
      w: config.w || 4,
      h: config.h || 4,
    });
    onOpenChange(false);
    setConfig({
      type: 'bar',
      title: '新组件',
      dataSource: 'vehicle',
      dimension: 'time',
      metric: 'count',
      aggregation: 'count',
      w: 4,
      h: 4,
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>添加组件</DialogTitle>
          <DialogDescription>
            选择图表类型并配置数据源与尺寸
          </DialogDescription>
        </DialogHeader>
        <WidgetFormFields config={config} onChange={setConfig} />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleAdd}>添加</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function EditWidgetDialog({
  open,
  onOpenChange,
  widget,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  widget: WidgetConfig | null;
  onSave: (widget: WidgetConfig) => void;
}) {
  const [config, setConfig] = useState<Partial<WidgetConfig>>({});

  useEffect(() => {
    if (widget) {
      setConfig({ ...widget });
    }
  }, [widget]);

  function handleSave() {
    if (!widget || !config.type || !config.title) return;
    onSave({
      ...widget,
      type: config.type,
      title: config.title,
      dataSource: config.dataSource || widget.dataSource,
      dimension: config.dimension || widget.dimension,
      metric: config.metric || widget.metric,
      aggregation: config.aggregation || widget.aggregation,
      w: config.w ?? widget.w,
      h: config.h ?? widget.h,
    });
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>编辑组件</DialogTitle>
          <DialogDescription>修改组件的配置与尺寸</DialogDescription>
        </DialogHeader>
        <WidgetFormFields config={config} onChange={setConfig} />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={handleSave}>保存</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function ShareDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [linkType, setLinkType] = useState<'readonly' | 'iframe'>('readonly');
  const [validity, setValidity] = useState('7');
  const [password, setPassword] = useState('');

  const shareUrl = `https://example.com/share/dashboard/${linkType}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>分享看板</DialogTitle>
          <DialogDescription>生成分享链接或嵌入代码</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label>分享方式</Label>
            <div className="flex gap-2">
              <Button
                variant={linkType === 'readonly' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLinkType('readonly')}
              >
                <Type className="size-4 mr-1" />
                只读链接
              </Button>
              <Button
                variant={linkType === 'iframe' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setLinkType('iframe')}
              >
                <Layers className="size-4 mr-1" />
                iframe嵌入
              </Button>
            </div>
          </div>

          <div className="grid gap-2">
            <Label>有效期</Label>
            <Select value={validity} onValueChange={setValidity}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1天</SelectItem>
                <SelectItem value="7">7天</SelectItem>
                <SelectItem value="30">30天</SelectItem>
                <SelectItem value="0">永久</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="share-pwd">访问密码（可选）</Label>
            <Input
              id="share-pwd"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="不设置则无需密码"
            />
          </div>

          <div className="grid gap-2">
            <Label>链接/代码</Label>
            <div className="rounded-md border border-neutral-border bg-neutral-background p-3 text-xs text-neutral-textSecondary break-all">
              {linkType === 'iframe'
                ? `<iframe src="${shareUrl}" width="100%" height="800" frameborder="0"></iframe>`
                : shareUrl}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            关闭
          </Button>
          <Button
            onClick={() => {
              alert('链接已复制到剪贴板');
              onOpenChange(false);
            }}
          >
            复制
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function PageManageDialog({
  open,
  onOpenChange,
  pages,
  currentPageId,
  onAddPage,
  onRenamePage,
  onDeletePage,
  onSwitchPage,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pages: DashboardPage[];
  currentPageId: string;
  onAddPage: () => void;
  onRenamePage: (id: string, name: string) => void;
  onDeletePage: (id: string) => void;
  onSwitchPage: (id: string) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>页面管理</DialogTitle>
          <DialogDescription>管理看板页面</DialogDescription>
        </DialogHeader>
        <div className="grid gap-2 py-2 max-h-[300px] overflow-auto">
          {pages.map((page) => (
            <div
              key={page.id}
              className={
                page.id === currentPageId
                  ? 'flex items-center justify-between rounded-md border border-primary bg-primary-light px-3 py-2'
                  : 'flex items-center justify-between rounded-md border border-neutral-border bg-neutral-surface px-3 py-2'
              }
            >
              {editingId === page.id ? (
                <div className="flex items-center gap-2 flex-1">
                  <Input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="h-8"
                    autoFocus
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        onRenamePage(page.id, editName);
                        setEditingId(null);
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 px-2"
                    onClick={() => {
                      onRenamePage(page.id, editName);
                      setEditingId(null);
                    }}
                  >
                    保存
                  </Button>
                </div>
              ) : (
                <>
                  <button
                    className="flex-1 text-left text-sm text-neutral-textPrimary"
                    onClick={() => {
                      onSwitchPage(page.id);
                      onOpenChange(false);
                    }}
                  >
                    {page.name}
                  </button>
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-neutral-textSecondary"
                      onClick={() => {
                        setEditingId(page.id);
                        setEditName(page.name);
                      }}
                    >
                      重命名
                    </Button>
                    {pages.length > 1 && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2 text-danger"
                        onClick={() => onDeletePage(page.id)}
                      >
                        删除
                      </Button>
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            关闭
          </Button>
          <Button onClick={onAddPage}>添加页面</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
