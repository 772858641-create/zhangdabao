import { useMemo } from 'react';
import {
  organizations,
  users,
  carriers,
  vehicles,
  devices,
  sites,
  transferOrders,
  routes,
  alarms,
  dashboardKPIs,
  utilizationTrend,
  carrierTypeDistribution,
  alarmTypeDistribution,
  transferTrend,
  getStatusLabel,
  getStatusColor,
  type Organization,
  type User,
  type Carrier,
  type Vehicle,
  type Device,
  type Site,
  type TransferOrder,
  type Route,
  type Alarm,
  type DashboardKPI,
} from '@/lib/mockData';

export interface MockDataStore {
  organizations: Organization[];
  users: User[];
  carriers: Carrier[];
  vehicles: Vehicle[];
  devices: Device[];
  sites: Site[];
  transferOrders: TransferOrder[];
  routes: Route[];
  alarms: Alarm[];
  dashboardKPIs: DashboardKPI[];
  utilizationTrend: typeof utilizationTrend;
  carrierTypeDistribution: typeof carrierTypeDistribution;
  alarmTypeDistribution: typeof alarmTypeDistribution;
  transferTrend: typeof transferTrend;
  getStatusLabel: typeof getStatusLabel;
  getStatusColor: typeof getStatusColor;
  // Filtered getters
  getCarriersByOrg: (orgId: string) => Carrier[];
  getCarriersBySite: (siteId: string) => Carrier[];
  getCarriersByStatus: (status: Carrier['status']) => Carrier[];
  getVehiclesByOrg: (orgId: string) => Vehicle[];
  getVehiclesByStatus: (status: Vehicle['status']) => Vehicle[];
  getDevicesByType: (type: Device['type']) => Device[];
  getDevicesByStatus: (status: Device['status']) => Device[];
  getAlarmsByLevel: (level: Alarm['level']) => Alarm[];
  getAlarmsByStatus: (status: Alarm['status']) => Alarm[];
  getTransferOrdersByStatus: (status: TransferOrder['status']) => TransferOrder[];
  getSitesByOrg: (orgId: string) => Site[];
  getUserById: (id: string) => User | undefined;
  getOrgById: (id: string) => Organization | undefined;
}

export function useMockData(): MockDataStore {
  return useMemo(
    () => ({
      organizations,
      users,
      carriers,
      vehicles,
      devices,
      sites,
      transferOrders,
      routes,
      alarms,
      dashboardKPIs,
      utilizationTrend,
      carrierTypeDistribution,
      alarmTypeDistribution,
      transferTrend,
      getStatusLabel,
      getStatusColor,
      getCarriersByOrg: (orgId: string) => carriers.filter((c) => c.orgId === orgId),
      getCarriersBySite: (siteId: string) => carriers.filter((c) => c.siteId === siteId),
      getCarriersByStatus: (status: Carrier['status']) => carriers.filter((c) => c.status === status),
      getVehiclesByOrg: (orgId: string) => vehicles.filter((v) => v.orgId === orgId),
      getVehiclesByStatus: (status: Vehicle['status']) => vehicles.filter((v) => v.status === status),
      getDevicesByType: (type: Device['type']) => devices.filter((d) => d.type === type),
      getDevicesByStatus: (status: Device['status']) => devices.filter((d) => d.status === status),
      getAlarmsByLevel: (level: Alarm['level']) => alarms.filter((a) => a.level === level),
      getAlarmsByStatus: (status: Alarm['status']) => alarms.filter((a) => a.status === status),
      getTransferOrdersByStatus: (status: TransferOrder['status']) =>
        transferOrders.filter((t) => t.status === status),
      getSitesByOrg: (orgId: string) => sites.filter((s) => s.orgId.startsWith(orgId)),
      getUserById: (id: string) => users.find((u) => u.id === id),
      getOrgById: (id: string) => {
        const findOrg = (orgs: Organization[]): Organization | undefined => {
          for (const org of orgs) {
            if (org.id === id) return org;
            if (org.children) {
              const found = findOrg(org.children);
              if (found) return found;
            }
          }
          return undefined;
        };
        return findOrg(organizations);
      },
    }),
    []
  );
}
