import { useState, useCallback, useEffect } from 'react';

export interface AuthUser {
  id: string;
  name: string;
  account: string;
  orgId: string;
  orgName: string;
  role: string;
  token: string;
}

const AUTH_KEY = 'vdm_auth_user';
const TOKEN_KEY = 'vdm_auth_token';

function getStoredUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* empty */ }
  return null;
}

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(getStoredUser);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isAuthenticated = !!user && !!localStorage.getItem(TOKEN_KEY);

  useEffect(() => {
    const stored = getStoredUser();
    if (stored) setUser(stored);
  }, []);

  const login = useCallback(async (account: string, _password: string, orgId: string, remember: boolean) => {
    setIsLoading(true);
    setError(null);

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 800));

    // Mock login: any username/password works
    const orgMap: Record<string, string> = {
      'org-1': '云载科技（总部）',
      'org-1-1-1': '上海运营中心',
      'org-1-1-2': '杭州运营中心',
      'org-1-2-1': '北京运营中心',
      'org-2': '华东汽车制造有限公司',
      'org-2-1': '上海浦东工厂',
      'org-2-2': '宁波生产基地',
      'org-3': '南方物流集团',
      'org-3-1': '广州仓储中心',
      'org-3-2': '深圳配送中心',
      'org-4': '北方供应链管理有限公司',
      'org-4-1': '天津港仓库',
      'org-4-2': '青岛物流中心',
    };

    const mockUser: AuthUser = {
      id: `u-${Date.now()}`,
      name: account || '管理员',
      account,
      orgId,
      orgName: orgMap[orgId] || '未知组织',
      role: 'admin',
      token: `mock_token_${Date.now()}`,
    };

    const expiryDays = remember ? 30 : 1;
    const expiryTime = Date.now() + expiryDays * 24 * 60 * 60 * 1000;
    const userWithExpiry = { ...mockUser, expiryTime };

    localStorage.setItem(AUTH_KEY, JSON.stringify(userWithExpiry));
    localStorage.setItem(TOKEN_KEY, mockUser.token);

    setUser(mockUser);
    setIsLoading(false);
    return mockUser;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_KEY);
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setError(null);
  }, []);

  const switchOrg = useCallback((orgId: string, orgName: string) => {
    if (user) {
      const updated = { ...user, orgId, orgName };
      setUser(updated);
      localStorage.setItem(AUTH_KEY, JSON.stringify(updated));
    }
  }, [user]);

  return {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    switchOrg,
  };
}
