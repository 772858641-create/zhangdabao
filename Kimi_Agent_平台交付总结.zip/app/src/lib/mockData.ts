// ============================================================
// Mock Data Store - Comprehensive mock data for all modules
// ============================================================

// --- Types ---

export interface Organization {
  id: string;
  name: string;
  type: 'service' | 'user';
  parentId: string | null;
  children?: Organization[];
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  account: string;
  phone: string;
  email: string;
  role: string;
  orgId: string;
  orgName: string;
  status: 'active' | 'inactive' | 'locked';
  lastLoginAt: string;
  createdAt: string;
}

export interface Carrier {
  id: string;
  code: string;
  name: string;
  type: '托盘' | '周转箱' | '料架' | '集装箱' | '笼车';
  status: 'normal' | 'repairing' | 'cleaning' | 'damaged' | 'scrapped';
  orgId: string;
  orgName: string;
  siteId: string;
  siteName: string;
  deviceId: string | null;
  deviceName: string | null;
  purchaseDate: string;
  price: number;
  currentLocation: string;
  lastUsedAt: string;
  createdAt: string;
}

export interface Vehicle {
  id: string;
  plateNumber: string;
  type: '货车' | '面包车' | '卡车' | '叉车';
  status: 'idle' | 'in_transit' | 'repairing' | 'inactive';
  driverId: string | null;
  driverName: string | null;
  orgId: string;
  orgName: string;
  brand: string;
  model: string;
  capacity: number;
  gpsDeviceId: string | null;
  currentLocation: string;
  lastLocationAt: string;
  createdAt: string;
}

export interface Device {
  id: string;
  code: string;
  name: string;
  type: 'GPS定位器' | '蓝牙标签' | 'RFID读写器' | '车载网关' | '温湿度传感器';
  status: 'online' | 'offline' | 'sleeping' | 'inactive';
  carrierId: string | null;
  carrierName: string | null;
  vehicleId: string | null;
  vehicleName: string | null;
  orgId: string;
  orgName: string;
  imei: string;
  firmwareVersion: string;
  batteryLevel: number | null;
  lastOnlineAt: string;
  installedAt: string;
  createdAt: string;
}

export interface Site {
  id: string;
  name: string;
  type: 'warehouse' | 'factory' | 'distribution';
  orgId: string;
  orgName: string;
  address: string;
  lat: number;
  lng: number;
  contactName: string;
  contactPhone: string;
  carrierCount: number;
  alertThreshold: number;
  fenceEnabled: boolean;
  createdAt: string;
}

export interface TransferOrder {
  id: string;
  code: string;
  type: '调拨' | '退运' | '维修';
  status: 'draft' | 'pending_review' | 'approved' | 'rejected' | 'in_transit' | 'pending_receipt' | 'completed' | 'cancelled' | 'exception';
  fromOrgId: string;
  fromOrgName: string;
  toOrgId: string;
  toOrgName: string;
  fromSiteId: string;
  fromSiteName: string;
  toSiteId: string;
  toSiteName: string;
  carrierCount: number;
  carriers: string[];
  vehicleId: string | null;
  vehicleName: string | null;
  driverName: string | null;
  plannedDate: string;
  actualDate: string | null;
  completedDate: string | null;
  createdBy: string;
  createdAt: string;
  remark: string;
}

export interface Route {
  id: string;
  name: string;
  code: string;
  type: 'fixed' | 'temporary';
  status: 'active' | 'inactive';
  orgId: string;
  orgName: string;
  nodes: RouteNode[];
  totalDistance: number;
  estimatedHours: number;
  carrierCount: number;
  createdAt: string;
}

export interface RouteNode {
  id: string;
  siteId: string;
  siteName: string;
  lat: number;
  lng: number;
  sequence: number;
  dwellMinutes: number;
}

export interface Alarm {
  id: string;
  type: string;
  level: 'urgent' | 'important' | 'normal' | 'info';
  status: 'unhandled' | 'handling' | 'resolved';
  targetType: 'carrier' | 'vehicle' | 'device' | 'site';
  targetId: string;
  targetName: string;
  message: string;
  location: string;
  handlerId: string | null;
  handlerName: string | null;
  resolvedAt: string | null;
  createdAt: string;
}

export interface DashboardKPI {
  label: string;
  value: number;
  change: number;
  unit: string;
  color: string;
}

// --- Organization Data ---

export const organizations: Organization[] = [
  {
    id: 'org-1',
    name: '云载科技（总部）',
    type: 'service',
    parentId: null,
    children: [
      { id: 'org-1-1', name: '华东大区', type: 'service', parentId: 'org-1', children: [
        { id: 'org-1-1-1', name: '上海运营中心', type: 'service', parentId: 'org-1-1' },
        { id: 'org-1-1-2', name: '杭州运营中心', type: 'service', parentId: 'org-1-1' },
      ]},
      { id: 'org-1-2', name: '华北大区', type: 'service', parentId: 'org-1', children: [
        { id: 'org-1-2-1', name: '北京运营中心', type: 'service', parentId: 'org-1-2' },
      ]},
    ],
  },
  {
    id: 'org-2',
    name: '华东汽车制造有限公司',
    type: 'user',
    parentId: null,
    children: [
      { id: 'org-2-1', name: '上海浦东工厂', type: 'user', parentId: 'org-2' },
      { id: 'org-2-2', name: '宁波生产基地', type: 'user', parentId: 'org-2' },
    ],
  },
  {
    id: 'org-3',
    name: '南方物流集团',
    type: 'user',
    parentId: null,
    children: [
      { id: 'org-3-1', name: '广州仓储中心', type: 'user', parentId: 'org-3' },
      { id: 'org-3-2', name: '深圳配送中心', type: 'user', parentId: 'org-3' },
    ],
  },
  {
    id: 'org-4',
    name: '北方供应链管理有限公司',
    type: 'user',
    parentId: null,
    children: [
      { id: 'org-4-1', name: '天津港仓库', type: 'user', parentId: 'org-4' },
      { id: 'org-4-2', name: '青岛物流中心', type: 'user', parentId: 'org-4' },
    ],
  },
];

// --- User Data ---

export const users: User[] = [
  { id: 'u-1', name: '系统管理员', avatar: '', account: 'admin', phone: '13800138000', email: 'admin@vehicle-cloud.com', role: 'super_admin', orgId: 'org-1', orgName: '云载科技（总部）', status: 'active', lastLoginAt: '2024-12-20 09:30:00', createdAt: '2024-01-01' },
  { id: 'u-2', name: '张三', avatar: '', account: 'zhangsan', phone: '13800138001', email: 'zhangsan@vehicle-cloud.com', role: 'admin', orgId: 'org-1-1-1', orgName: '上海运营中心', status: 'active', lastLoginAt: '2024-12-20 08:45:00', createdAt: '2024-02-15' },
  { id: 'u-3', name: '李四', avatar: '', account: 'lisi', phone: '13800138002', email: 'lisi@vehicle-cloud.com', role: 'operator', orgId: 'org-1-1-1', orgName: '上海运营中心', status: 'active', lastLoginAt: '2024-12-19 17:20:00', createdAt: '2024-03-01' },
  { id: 'u-4', name: '王五', avatar: '', account: 'wangwu', phone: '13800138003', email: 'wangwu@vehicle-cloud.com', role: 'viewer', orgId: 'org-2-1', orgName: '上海浦东工厂', status: 'active', lastLoginAt: '2024-12-18 16:00:00', createdAt: '2024-03-10' },
  { id: 'u-5', name: '赵六', avatar: '', account: 'zhaoliu', phone: '13800138004', email: 'zhaoliu@vehicle-cloud.com', role: 'admin', orgId: 'org-2', orgName: '华东汽车制造有限公司', status: 'active', lastLoginAt: '2024-12-20 10:00:00', createdAt: '2024-04-01' },
  { id: 'u-6', name: '孙七', avatar: '', account: 'sunqi', phone: '13800138005', email: 'sunqi@vehicle-cloud.com', role: 'operator', orgId: 'org-3-1', orgName: '广州仓储中心', status: 'inactive', lastLoginAt: '2024-11-30 14:00:00', createdAt: '2024-05-01' },
  { id: 'u-7', name: '周八', avatar: '', account: 'zhouba', phone: '13800138006', email: 'zhouba@vehicle-cloud.com', role: 'admin', orgId: 'org-4', orgName: '北方供应链管理有限公司', status: 'active', lastLoginAt: '2024-12-19 09:15:00', createdAt: '2024-06-01' },
  { id: 'u-8', name: '吴九', avatar: '', account: 'wujiu', phone: '13800138007', email: 'wujiu@vehicle-cloud.com', role: 'operator', orgId: 'org-1-2-1', orgName: '北京运营中心', status: 'active', lastLoginAt: '2024-12-20 07:30:00', createdAt: '2024-06-15' },
  { id: 'u-9', name: '郑十', avatar: '', account: 'zhengshi', phone: '13800138008', email: 'zhengshi@vehicle-cloud.com', role: 'viewer', orgId: 'org-2-2', orgName: '宁波生产基地', status: 'locked', lastLoginAt: '2024-10-20 11:00:00', createdAt: '2024-07-01' },
  { id: 'u-10', name: '钱十一', avatar: '', account: 'qian11', phone: '13800138009', email: 'qian11@vehicle-cloud.com', role: 'operator', orgId: 'org-3-2', orgName: '深圳配送中心', status: 'active', lastLoginAt: '2024-12-19 18:30:00', createdAt: '2024-08-01' },
];

// --- Carrier Data (50+ items) ---

const carrierStatuses: Carrier['status'][] = ['normal', 'repairing', 'cleaning', 'damaged', 'scrapped'];
const carrierTypes: Carrier['type'][] = ['托盘', '周转箱', '料架', '集装箱', '笼车'];
const carrierSites = ['上海浦东工厂仓库A', '上海浦东工厂仓库B', '宁波生产基地仓库', '广州仓储中心', '深圳配送中心', '天津港仓库', '青岛物流中心', '杭州运营中心仓库'];

export const carriers: Carrier[] = Array.from({ length: 55 }, (_, i) => {
  const idx = i + 1;
  const type = carrierTypes[i % carrierTypes.length];
  const status = carrierStatuses[i % carrierStatuses.length];
  return {
    id: `carrier-${idx}`,
    code: `CJ${String(idx).padStart(6, '0')}`,
    name: `${type}-${String(idx).padStart(4, '0')}`,
    type,
    status,
    orgId: `org-${2 + (i % 3)}`,
    orgName: ['华东汽车制造有限公司', '南方物流集团', '北方供应链管理有限公司'][i % 3],
    siteId: `site-${(i % 8) + 1}`,
    siteName: carrierSites[i % carrierSites.length],
    deviceId: i % 3 === 0 ? `device-${idx}` : null,
    deviceName: i % 3 === 0 ? `GPS-${String(idx).padStart(4, '0')}` : null,
    purchaseDate: `2024-${String((i % 12) + 1).padStart(2, '0')}-15`,
    price: [350, 280, 1200, 5000, 800][i % 5],
    currentLocation: carrierSites[i % carrierSites.length],
    lastUsedAt: `2024-12-${String((i % 20) + 1).padStart(2, '0')} ${String((i % 24)).padStart(2, '0')}:30:00`,
    createdAt: `2024-01-${String((i % 28) + 1).padStart(2, '0')}`,
  };
});

// --- Vehicle Data (20+ items) ---

const vehicleStatuses: Vehicle['status'][] = ['idle', 'in_transit', 'repairing', 'inactive'];
const vehicleTypes: Vehicle['type'][] = ['货车', '面包车', '卡车', '叉车'];

export const vehicles: Vehicle[] = Array.from({ length: 25 }, (_, i) => {
  const idx = i + 1;
  const type = vehicleTypes[i % vehicleTypes.length];
  const status = vehicleStatuses[i % vehicleStatuses.length];
  return {
    id: `vehicle-${idx}`,
    plateNumber: `沪A${String(Math.floor(Math.random() * 90000) + 10000)}`,
    type,
    status,
    driverId: i % 4 !== 0 ? `driver-${idx}` : null,
    driverName: i % 4 !== 0 ? ['张三', '李四', '王五', '赵六', '孙七'][i % 5] : null,
    orgId: `org-${2 + (i % 3)}`,
    orgName: ['华东汽车制造有限公司', '南方物流集团', '北方供应链管理有限公司'][i % 3],
    brand: ['东风', '解放', '福田', '江淮', '重汽'][i % 5],
    model: `${['A', 'B', 'C', 'D', 'E'][i % 5]}${Math.floor(Math.random() * 10) + 1}00`,
    capacity: [5, 10, 20, 2, 30][i % 5],
    gpsDeviceId: `device-gps-${idx}`,
    currentLocation: ['上海浦东新区', '宁波市北仑区', '广州市白云区', '深圳市宝安区', '天津市滨海新区'][i % 5],
    lastLocationAt: `2024-12-20 ${String((i % 24)).padStart(2, '0')}:15:00`,
    createdAt: `2024-03-${String((i % 28) + 1).padStart(2, '0')}`,
  };
});

// --- Device Data (30+ items) ---

const deviceTypes: Device['type'][] = ['GPS定位器', '蓝牙标签', 'RFID读写器', '车载网关', '温湿度传感器'];
const deviceStatuses: Device['status'][] = ['online', 'offline', 'sleeping', 'inactive'];

export const devices: Device[] = Array.from({ length: 35 }, (_, i) => {
  const idx = i + 1;
  const type = deviceTypes[i % deviceTypes.length];
  const status = deviceStatuses[i % deviceStatuses.length];
  return {
    id: `device-${idx}`,
    code: `SB${String(idx).padStart(6, '0')}`,
    name: `${type}-${String(idx).padStart(4, '0')}`,
    type,
    status,
    carrierId: i % 3 === 0 ? `carrier-${idx}` : null,
    carrierName: i % 3 === 0 ? `载具-${String(idx).padStart(4, '0')}` : null,
    vehicleId: i % 5 === 0 ? `vehicle-${idx}` : null,
    vehicleName: i % 5 === 0 ? `沪A${String(Math.floor(Math.random() * 90000) + 10000)}` : null,
    orgId: `org-${1 + (i % 4)}`,
    orgName: ['云载科技（总部）', '华东汽车制造有限公司', '南方物流集团', '北方供应链管理有限公司'][i % 4],
    imei: `86${Math.floor(Math.random() * 1000000000000)}`,
    firmwareVersion: `v${Math.floor(Math.random() * 5) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}`,
    batteryLevel: type === '蓝牙标签' ? Math.floor(Math.random() * 100) : null,
    lastOnlineAt: `2024-12-20 ${String((i % 24)).padStart(2, '0')}:00:00`,
    installedAt: `2024-${String((i % 12) + 1).padStart(2, '0')}-10`,
    createdAt: `2024-02-${String((i % 28) + 1).padStart(2, '0')}`,
  };
});

// --- Site Data ---

export const sites: Site[] = [
  { id: 'site-1', name: '上海浦东工厂仓库A', type: 'warehouse', orgId: 'org-2-1', orgName: '上海浦东工厂', address: '上海市浦东新区川沙路1000号', lat: 31.180, lng: 121.680, contactName: '王五', contactPhone: '13800138003', carrierCount: 1200, alertThreshold: 100, fenceEnabled: true, createdAt: '2024-01-15' },
  { id: 'site-2', name: '上海浦东工厂仓库B', type: 'warehouse', orgId: 'org-2-1', orgName: '上海浦东工厂', address: '上海市浦东新区申江路2000号', lat: 31.220, lng: 121.550, contactName: '王五', contactPhone: '13800138003', carrierCount: 800, alertThreshold: 80, fenceEnabled: true, createdAt: '2024-02-01' },
  { id: 'site-3', name: '宁波生产基地仓库', type: 'factory', orgId: 'org-2-2', orgName: '宁波生产基地', address: '浙江省宁波市北仑区新碶街道500号', lat: 29.910, lng: 121.840, contactName: '郑十', contactPhone: '13800138008', carrierCount: 2000, alertThreshold: 150, fenceEnabled: true, createdAt: '2024-01-20' },
  { id: 'site-4', name: '广州仓储中心', type: 'warehouse', orgId: 'org-3-1', orgName: '广州仓储中心', address: '广东省广州市白云区太和镇300号', lat: 23.290, lng: 113.310, contactName: '孙七', contactPhone: '13800138005', carrierCount: 3500, alertThreshold: 200, fenceEnabled: false, createdAt: '2024-03-01' },
  { id: 'site-5', name: '深圳配送中心', type: 'distribution', orgId: 'org-3-2', orgName: '深圳配送中心', address: '广东省深圳市宝安区福永街道400号', lat: 22.670, lng: 113.810, contactName: '钱十一', contactPhone: '13800138009', carrierCount: 1800, alertThreshold: 120, fenceEnabled: true, createdAt: '2024-02-15' },
  { id: 'site-6', name: '天津港仓库', type: 'warehouse', orgId: 'org-4-1', orgName: '天津港仓库', address: '天津市滨海新区东疆保税港区100号', lat: 39.020, lng: 117.720, contactName: '周八', contactPhone: '13800138006', carrierCount: 2500, alertThreshold: 180, fenceEnabled: false, createdAt: '2024-03-10' },
  { id: 'site-7', name: '青岛物流中心', type: 'distribution', orgId: 'org-4-2', orgName: '青岛物流中心', address: '山东省青岛市黄岛区前湾港路200号', lat: 35.950, lng: 120.190, contactName: '周八', contactPhone: '13800138006', carrierCount: 1500, alertThreshold: 100, fenceEnabled: true, createdAt: '2024-04-01' },
  { id: 'site-8', name: '杭州运营中心仓库', type: 'warehouse', orgId: 'org-1-1-2', orgName: '杭州运营中心', address: '浙江省杭州市萧山区靖江街道600号', lat: 30.230, lng: 120.430, contactName: '张三', contactPhone: '13800138001', carrierCount: 900, alertThreshold: 70, fenceEnabled: true, createdAt: '2024-04-15' },
];

// --- Transfer Order Data (15+ items) ---

const transferStatuses: TransferOrder['status'][] = ['draft', 'pending_review', 'approved', 'rejected', 'in_transit', 'pending_receipt', 'completed', 'cancelled', 'exception'];

export const transferOrders: TransferOrder[] = Array.from({ length: 18 }, (_, i) => {
  const idx = i + 1;
  const status = transferStatuses[i % transferStatuses.length];
  return {
    id: `transfer-${idx}`,
    code: `DB${String(idx).padStart(8, '0')}`,
    type: ['调拨', '退运', '维修'][i % 3] as TransferOrder['type'],
    status,
    fromOrgId: `org-${2 + (i % 3)}`,
    fromOrgName: ['华东汽车制造有限公司', '南方物流集团', '北方供应链管理有限公司'][i % 3],
    toOrgId: `org-${2 + ((i + 1) % 3)}`,
    toOrgName: ['华东汽车制造有限公司', '南方物流集团', '北方供应链管理有限公司'][(i + 1) % 3],
    fromSiteId: `site-${(i % 8) + 1}`,
    fromSiteName: sites[i % 8].name,
    toSiteId: `site-${((i + 3) % 8) + 1}`,
    toSiteName: sites[(i + 3) % 8].name,
    carrierCount: Math.floor(Math.random() * 50) + 5,
    carriers: Array.from({ length: Math.floor(Math.random() * 10) + 3 }, (_, j) => `carrier-${(i * 10) + j + 1}`),
    vehicleId: i % 3 === 0 ? `vehicle-${idx}` : null,
    vehicleName: i % 3 === 0 ? `沪A${String(Math.floor(Math.random() * 90000) + 10000)}` : null,
    driverName: i % 3 === 0 ? ['张三', '李四', '王五'][i % 3] : null,
    plannedDate: `2024-12-${String((i % 15) + 5).padStart(2, '0')}`,
    actualDate: status !== 'draft' && status !== 'pending_review' ? `2024-12-${String((i % 15) + 6).padStart(2, '0')}` : null,
    completedDate: status === 'completed' ? `2024-12-${String((i % 15) + 10).padStart(2, '0')}` : null,
    createdBy: ['admin', 'zhangsan', 'lisi', 'wangwu'][i % 4],
    createdAt: `2024-12-${String((i % 10) + 1).padStart(2, '0')} 10:00:00`,
    remark: ['加急处理', '常规调拨', '客户要求', ''][i % 4],
  };
});

// --- Route Data (5+ routes) ---

export const routes: Route[] = [
  {
    id: 'route-1', name: '华东循环线路A', code: 'LX-001', type: 'fixed', status: 'active',
    orgId: 'org-2', orgName: '华东汽车制造有限公司',
    nodes: [
      { id: 'rn-1', siteId: 'site-1', siteName: '上海浦东工厂仓库A', lat: 31.180, lng: 121.680, sequence: 1, dwellMinutes: 120 },
      { id: 'rn-2', siteId: 'site-2', siteName: '上海浦东工厂仓库B', lat: 31.220, lng: 121.550, sequence: 2, dwellMinutes: 60 },
      { id: 'rn-3', siteId: 'site-3', siteName: '宁波生产基地仓库', lat: 29.910, lng: 121.840, sequence: 3, dwellMinutes: 180 },
      { id: 'rn-4', siteId: 'site-8', siteName: '杭州运营中心仓库', lat: 30.230, lng: 120.430, sequence: 4, dwellMinutes: 90 },
    ],
    totalDistance: 485, estimatedHours: 12, carrierCount: 350, createdAt: '2024-03-01',
  },
  {
    id: 'route-2', name: '华南配送线路', code: 'LX-002', type: 'fixed', status: 'active',
    orgId: 'org-3', orgName: '南方物流集团',
    nodes: [
      { id: 'rn-5', siteId: 'site-4', siteName: '广州仓储中心', lat: 23.290, lng: 113.310, sequence: 1, dwellMinutes: 240 },
      { id: 'rn-6', siteId: 'site-5', siteName: '深圳配送中心', lat: 22.670, lng: 113.810, sequence: 2, dwellMinutes: 120 },
    ],
    totalDistance: 145, estimatedHours: 4, carrierCount: 280, createdAt: '2024-04-01',
  },
  {
    id: 'route-3', name: '华北干线B', code: 'LX-003', type: 'fixed', status: 'active',
    orgId: 'org-4', orgName: '北方供应链管理有限公司',
    nodes: [
      { id: 'rn-7', siteId: 'site-6', siteName: '天津港仓库', lat: 39.020, lng: 117.720, sequence: 1, dwellMinutes: 300 },
      { id: 'rn-8', siteId: 'site-7', siteName: '青岛物流中心', lat: 35.950, lng: 120.190, sequence: 2, dwellMinutes: 150 },
      { id: 'rn-9', siteId: 'site-1', siteName: '上海浦东工厂仓库A', lat: 31.180, lng: 121.680, sequence: 3, dwellMinutes: 120 },
    ],
    totalDistance: 980, estimatedHours: 22, carrierCount: 420, createdAt: '2024-05-01',
  },
  {
    id: 'route-4', name: '长三角支线C', code: 'LX-004', type: 'temporary', status: 'active',
    orgId: 'org-2', orgName: '华东汽车制造有限公司',
    nodes: [
      { id: 'rn-10', siteId: 'site-1', siteName: '上海浦东工厂仓库A', lat: 31.180, lng: 121.680, sequence: 1, dwellMinutes: 60 },
      { id: 'rn-11', siteId: 'site-3', siteName: '宁波生产基地仓库', lat: 29.910, lng: 121.840, sequence: 2, dwellMinutes: 60 },
    ],
    totalDistance: 220, estimatedHours: 5, carrierCount: 150, createdAt: '2024-06-01',
  },
  {
    id: 'route-5', name: '全国大循环', code: 'LX-005', type: 'fixed', status: 'inactive',
    orgId: 'org-1', orgName: '云载科技（总部）',
    nodes: [
      { id: 'rn-12', siteId: 'site-1', siteName: '上海浦东工厂仓库A', lat: 31.180, lng: 121.680, sequence: 1, dwellMinutes: 120 },
      { id: 'rn-13', siteId: 'site-4', siteName: '广州仓储中心', lat: 23.290, lng: 113.310, sequence: 2, dwellMinutes: 120 },
      { id: 'rn-14', siteId: 'site-6', siteName: '天津港仓库', lat: 39.020, lng: 117.720, sequence: 3, dwellMinutes: 120 },
      { id: 'rn-15', siteId: 'site-7', siteName: '青岛物流中心', lat: 35.950, lng: 120.190, sequence: 4, dwellMinutes: 120 },
    ],
    totalDistance: 2850, estimatedHours: 58, carrierCount: 800, createdAt: '2024-07-01',
  },
];

// --- Alarm Data (20+ items) ---

const alarmTypes = [
  '离线报警', '低电量报警', '超速报警', '围栏越界', '载具滞留',
  '温度异常', '湿度异常', '震动报警', '调拨超时', '未按计划到达',
  '载具丢失', '设备故障', '信号弱', '非法开启', '路线偏离',
  '载具积压', '未授权移动',
];

const alarmLevels: Alarm['level'][] = ['urgent', 'important', 'normal', 'info'];
const alarmStatuses: Alarm['status'][] = ['unhandled', 'handling', 'resolved'];

export const alarms: Alarm[] = Array.from({ length: 25 }, (_, i) => {
  const idx = i + 1;
  const level = alarmLevels[i % alarmLevels.length];
  const status = alarmStatuses[i % alarmStatuses.length];
  return {
    id: `alarm-${idx}`,
    type: alarmTypes[i % alarmTypes.length],
    level,
    status,
    targetType: ['carrier', 'vehicle', 'device', 'site'][i % 4] as Alarm['targetType'],
    targetId: `${['carrier', 'vehicle', 'device', 'site'][i % 4]}-${idx}`,
    targetName: `${['载具', '车辆', '设备', '网点'][i % 4]}-${String(idx).padStart(4, '0')}`,
    message: `${alarmTypes[i % alarmTypes.length]}：${['上海浦东工厂', '宁波生产基地', '广州仓储中心', '深圳配送中心'][i % 4]}的${['载具', '车辆', '设备', '网点'][i % 4]}触发报警`,
    location: ['上海浦东新区', '宁波市北仑区', '广州市白云区', '深圳市宝安区', '天津市滨海新区'][i % 5],
    handlerId: status !== 'unhandled' ? `u-${(i % 8) + 1}` : null,
    handlerName: status !== 'unhandled' ? ['系统管理员', '张三', '李四', '王五', '赵六', '孙七', '周八', '吴九'][i % 8] : null,
    resolvedAt: status === 'resolved' ? `2024-12-20 ${String((i % 24)).padStart(2, '0')}:30:00` : null,
    createdAt: `2024-12-${String((i % 20) + 1).padStart(2, '0')} ${String((i % 24)).padStart(2, '0')}:15:00`,
  };
});

// --- Dashboard KPI Data ---

export const dashboardKPIs: DashboardKPI[] = [
  { label: '载具总量', value: 14580, change: 5.2, unit: '个', color: '#2563EB' },
  { label: '在线载具', value: 12356, change: 3.8, unit: '个', color: '#10B981' },
  { label: '在途车辆', value: 186, change: -2.1, unit: '辆', color: '#06B6D4' },
  { label: '今日调拨', value: 342, change: 12.5, unit: '单', color: '#8B5CF6' },
  { label: '未处理报警', value: 23, change: -8.3, unit: '条', color: '#EF4444' },
  { label: '网点覆盖', value: 156, change: 2.0, unit: '个', color: '#F59E0B' },
];

// --- Chart Data ---

export const utilizationTrend = Array.from({ length: 30 }, (_, i) => ({
  date: `12/${String(i + 1).padStart(2, '0')}`,
  utilization: 78 + Math.random() * 18,
  online: 11000 + Math.floor(Math.random() * 2000),
  offline: 2000 + Math.floor(Math.random() * 500),
}));

export const carrierTypeDistribution = [
  { name: '托盘', value: 5200, color: '#2563EB' },
  { name: '周转箱', value: 3800, color: '#10B981' },
  { name: '料架', value: 2100, color: '#F59E0B' },
  { name: '集装箱', value: 1800, color: '#8B5CF6' },
  { name: '笼车', value: 1680, color: '#06B6D4' },
];

export const alarmTypeDistribution = [
  { name: '离线报警', value: 45 },
  { name: '围栏越界', value: 32 },
  { name: '载具滞留', value: 28 },
  { name: '低电量报警', value: 25 },
  { name: '温度异常', value: 18 },
  { name: '震动报警', value: 15 },
  { name: '其他', value: 22 },
];

export const transferTrend = Array.from({ length: 12 }, (_, i) => ({
  month: `${String(i + 1).padStart(2, '0')}月`,
  completed: 800 + Math.floor(Math.random() * 400),
  pending: 100 + Math.floor(Math.random() * 100),
  exception: 20 + Math.floor(Math.random() * 40),
}));

// --- Utility functions ---

export const statusMap: Record<string, { label: string; color: string }> = {
  normal: { label: '正常', color: '#10B981' },
  repairing: { label: '维修中', color: '#F59E0B' },
  cleaning: { label: '清洁中', color: '#06B6D4' },
  damaged: { label: '已损坏', color: '#EF4444' },
  scrapped: { label: '已报废', color: '#94A3B8' },
  idle: { label: '空闲', color: '#10B981' },
  in_transit: { label: '在途中', color: '#2563EB' },
  inactive: { label: '已停用', color: '#94A3B8' },
  online: { label: '在线', color: '#10B981' },
  offline: { label: '离线', color: '#EF4444' },
  sleeping: { label: '休眠', color: '#94A3B8' },
  inactive_device: { label: '未激活', color: '#CBD5E1' },
  draft: { label: '草稿', color: '#CBD5E1' },
  pending_review: { label: '待审核', color: '#F59E0B' },
  approved: { label: '审核通过', color: '#2563EB' },
  rejected: { label: '审核驳回', color: '#EF4444' },
  pending_receipt: { label: '待签收', color: '#8B5CF6' },
  completed: { label: '已完成', color: '#10B981' },
  cancelled: { label: '已取消', color: '#94A3B8' },
  exception: { label: '异常', color: '#EF4444' },
  urgent: { label: '紧急', color: '#EF4444' },
  important: { label: '重要', color: '#F59E0B' },
  important_alarm: { label: '重要', color: '#F59E0B' },
  info: { label: '提示', color: '#94A3B8' },
  unhandled: { label: '未处理', color: '#EF4444' },
  handling: { label: '处理中', color: '#F59E0B' },
  resolved: { label: '已解决', color: '#10B981' },
  active: { label: '启用', color: '#10B981' },
  active_route: { label: '启用', color: '#10B981' },
  inactive_route: { label: '停用', color: '#94A3B8' },
};

export function getStatusLabel(status: string): string {
  return statusMap[status]?.label || status;
}

export function getStatusColor(status: string): string {
  return statusMap[status]?.color || '#94A3B8';
}
