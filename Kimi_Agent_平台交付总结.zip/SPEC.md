# 载具数字化管理平台 - 后端API规范

## 架构概述
- Node.js + Express + TypeScript
- MySQL (via Prisma ORM) + Redis (缓存/会话)
- JWT认证 + RBAC权限控制
- RESTful API设计
- 模块化路由结构

## 项目结构
```
backend/
├── prisma/
│   └── schema.prisma       # 已定义
├── src/
│   ├── config/             # 配置
│   │   └── index.ts
│   ├── middleware/         # 中间件
│   │   ├── auth.ts         # JWT认证
│   │   ├── rbac.ts         # 权限控制
│   │   ├── errorHandler.ts # 错误处理
│   │   ├── validate.ts     # 请求验证
│   │   └── logger.ts       # 日志
│   ├── routes/             # 路由
│   │   ├── auth.ts         # 认证路由
│   │   ├── carriers.ts     # 载具路由
│   │   ├── vehicles.ts     # 车辆路由
│   │   ├── devices.ts      # 设备路由
│   │   ├── sites.ts        # 网点路由
│   │   ├── transfers.ts    # 调拨路由
│   │   ├── routes.ts       # 流转线路路由
│   │   ├── alarms.ts       # 报警路由
│   │   ├── users.ts        # 用户路由
│   │   ├── organizations.ts # 组织路由
│   │   ├── dashboard.ts    # 数据看板路由
│   │   ├── settings.ts     # 系统设置路由
│   │   └── index.ts        # 路由聚合
│   ├── controllers/        # 控制器
│   │   ├── authController.ts
│   │   ├── carrierController.ts
│   │   ├── vehicleController.ts
│   │   ├── deviceController.ts
│   │   ├── siteController.ts
│   │   ├── transferController.ts
│   │   ├── routeController.ts
│   │   ├── alarmController.ts
│   │   ├── userController.ts
│   │   ├── orgController.ts
│   │   ├── dashboardController.ts
│   │   └── settingController.ts
│   ├── services/           # 业务逻辑层
│   │   ├── authService.ts
│   │   ├── carrierService.ts
│   │   ├── vehicleService.ts
│   │   ├── deviceService.ts
│   │   ├── siteService.ts
│   │   ├── transferService.ts
│   │   ├── routeService.ts
│   │   ├── alarmService.ts
│   │   ├── userService.ts
│   │   ├── orgService.ts
│   │   ├── dashboardService.ts
│   │   └── settingService.ts
│   ├── utils/              # 工具函数
│   │   ├── response.ts     # 统一响应格式
│   │   ├── pagination.ts   # 分页工具
│   │   ├── crypto.ts       # 加密工具
│   │   └── constants.ts    # 常量
│   ├── types/              # 类型定义
│   │   └── index.ts
│   ├── app.ts              # Express应用
│   └── index.ts            # 入口文件
├── .env
├── package.json
├── tsconfig.json
└── Dockerfile
```

## 统一API响应格式
```typescript
interface ApiResponse<T> {
  code: number;       // 200成功, 400请求错误, 401未认证, 403无权限, 404不存在, 500服务器错误
  message: string;
  data?: T;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}
```

## 分页参数
```
?page=1&pageSize=20&sortField=createdAt&sortOrder=desc
```

## 认证
- 登录: POST /api/auth/login → 返回 { token, user }
- 所有API (除login) 需要 Header: `Authorization: Bearer <token>`
- Token 包含: userId, orgId, role, permissions
- Token 有效期: 24小时

## RBAC权限矩阵
| 模块 | 权限码 | 说明 |
|------|--------|------|
| dashboard | dashboard:read | 查看看板 |
| carriers | carriers:read, carriers:manage | 载具查看/管理 |
| vehicles | vehicles:read, vehicles:manage | 车辆查看/管理 |
| devices | devices:read, devices:manage | 设备查看/管理 |
| sites | sites:read, sites:manage | 网点查看/管理 |
| transfers | transfers:read, transfers:manage | 调拨查看/管理 |
| routes | routes:read, routes:manage | 流转线路查看/管理 |
| alarms | alarms:read, alarms:manage | 报警查看/管理 |
| users | users:read, users:manage | 用户查看/管理 |
| settings | settings:read, settings:manage | 系统设置 |

## API路由清单

### 认证
- POST /api/auth/login
- GET /api/auth/me
- POST /api/auth/logout
- POST /api/auth/refresh

### 载具管理
- GET /api/carriers (列表, 支持分页/筛选/搜索)
- GET /api/carriers/:id (详情)
- POST /api/carriers (创建)
- PUT /api/carriers/:id (更新)
- DELETE /api/carriers/:id (删除)
- POST /api/carriers/import (导入)
- GET /api/carriers/export (导出)
- POST /api/carriers/:id/bind-device (绑定设备)
- DELETE /api/carriers/:id/unbind-device/:deviceId (解绑设备)
- POST /api/carriers/:id/bind-material (绑定物料)
- PUT /api/carriers/:id/threshold (阈值设置)
- PUT /api/carriers/:id/ops-status (运维状态变更)
- POST /api/carriers/:id/transfer (载具调拨)

### 车辆管理
- GET /api/vehicles
- GET /api/vehicles/:id
- POST /api/vehicles
- PUT /api/vehicles/:id
- DELETE /api/vehicles/:id
- POST /api/vehicles/:id/bind-carrier
- DELETE /api/vehicles/:id/unbind-carrier/:carrierId
- POST /api/vehicles/:id/maintenance (运维记录)
- GET /api/vehicles/:id/position (实时位置)
- POST /api/vehicles/:id/gateway (绑定网关)

### 设备管理
- GET /api/devices
- GET /api/devices/:id
- POST /api/devices
- PUT /api/devices/:id
- DELETE /api/devices/:id
- POST /api/devices/:id/command (指令下发)
- GET /api/devices/:id/commands (指令历史)
- POST /api/devices/:id/ota (OTA升级)
- GET /api/devices/:id/history (历史数据)
- POST /api/devices/:id/transfer-ownership (设备过户)

### 网点管理
- GET /api/sites
- GET /api/sites/:id
- POST /api/sites
- PUT /api/sites/:id
- DELETE /api/sites/:id
- POST /api/sites/:id/fence (围栏设置)
- GET /api/sites/:id/inventory (库存概览)
- PUT /api/sites/:id/io-rules (出入库规则)
- POST /api/sites/:id/alert (库存预警设置)
- GET /api/sites/:id/beacons (信标管理)
- GET /api/sites/tree (层级树)
- GET /api/sites/aggregation (聚合视图)

### 调拨管理
- GET /api/transfers
- GET /api/transfers/:id
- POST /api/transfers (发起调拨)
- PUT /api/transfers/:id (更新)
- POST /api/transfers/:id/submit (提交审核)
- POST /api/transfers/:id/review (审核)
- POST /api/transfers/:id/cancel (取消)
- POST /api/transfers/:id/revoke (撤回)
- POST /api/transfers/:id/abort (异常终止)
- POST /api/transfers/:id/receipt (到货签收)
- GET /api/transfers/:id/track (轨迹回放)
- POST /api/transfers/:id/reverse (反向调拨)

### 流转线路
- GET /api/routes
- GET /api/routes/:id
- POST /api/routes
- PUT /api/routes/:id
- DELETE /api/routes/:id
- POST /api/routes/:id/toggle (启用/停用)
- POST /api/routes/:id/copy (复制)
- PUT /api/routes/:id/nodes (节点配置)
- POST /api/routes/:id/bind-carrier (绑定载具)
- GET /api/routes/:id/monitor (流转监控)
- GET /api/routes/dashboard (流转看板)

### 报警管理
- GET /api/alarms
- GET /api/alarms/:id
- POST /api/alarms/:id/handle (处理报警)
- POST /api/alarms/batch-handle (批量处理)
- PUT /api/alarms/:id/ignore (忽略)
- GET /api/alarms/rules (报警规则)
- PUT /api/alarms/rules/:id (更新规则)
- GET /api/alarms/stats (报警统计)

### 用户管理
- GET /api/users
- GET /api/users/:id
- POST /api/users
- PUT /api/users/:id
- DELETE /api/users/:id
- POST /api/users/:id/reset-password
- GET /api/roles
- POST /api/roles
- PUT /api/roles/:id
- DELETE /api/roles/:id
- GET /api/permissions

### 组织管理
- GET /api/organizations
- GET /api/organizations/:id
- POST /api/organizations
- PUT /api/organizations/:id
- DELETE /api/organizations/:id
- GET /api/organizations/:id/tree (子组织树)
- GET /api/organizations/:id/users (组织用户)
- PUT /api/organizations/:id/permissions (权限分配)
- GET /api/organizations/:id/stats (组织统计)

### 数据看板
- GET /api/dashboard/kpi (KPI数据)
- GET /api/dashboard/charts (图表数据)
- GET /api/dashboard/site-ranking (网点排名)

### 系统设置
- GET /api/settings
- PUT /api/settings (更新设置)
- GET /api/settings/thresholds (报警阈值)
- PUT /api/settings/thresholds (更新阈值)
- GET /api/settings/logs (操作日志)
- GET /api/settings/backups (备份列表)
- POST /api/settings/backups (创建备份)
- POST /api/settings/backups/:id/restore (恢复备份)

## 环境变量
```
DATABASE_URL=mysql://user:pass@localhost:3306/vehicle_platform
REDIS_URL=redis://localhost:6379
JWT_SECRET=your-secret-key
JWT_EXPIRES_IN=24h
PORT=3000
NODE_ENV=production
```

## 部署方式
- Docker容器化
- Nginx反向代理
- PM2进程管理
- 腾讯云服务器 (CentOS/Ubuntu)
