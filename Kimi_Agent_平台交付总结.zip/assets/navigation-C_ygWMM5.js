import{b as o}from"./index-ranVWt2-.js";const t=[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]],i=o("navigation",t);export{i as N};
