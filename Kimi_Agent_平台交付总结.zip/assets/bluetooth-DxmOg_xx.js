import{b as o}from"./index-ranVWt2-.js";const t=[["path",{d:"m7 7 10 10-5 5V2l5 5L7 17",key:"1q5490"}]],c=o("bluetooth",t);export{c as B};
