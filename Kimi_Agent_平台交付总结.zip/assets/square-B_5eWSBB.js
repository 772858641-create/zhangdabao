import{b as e}from"./index-ranVWt2-.js";const t=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]],r=e("square",t);export{r as S};
