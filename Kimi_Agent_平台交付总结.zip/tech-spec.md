## Tech Spec: ProjectManagementPage

### 组件清单
- **shadcn/ui**: Dialog, Button, Input, Badge, Select, Card, Tabs, Progress, ScrollArea, Label, Textarea
- **lucide-react**: FolderKanban, Building2, Truck, Route, BarChart3, Plus, Edit, Trash2, Eye, Search, Users, Calendar, CheckCircle, XCircle, TrendingUp, ChevronRight, AlertTriangle, PieChart, Activity
- **Recharts**: PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer

### 状态管理
- `currentView`: 'list' | 'detail' — 控制列表/详情视图切换
- `selectedProject`: Project | null — 当前选中的项目
- `isCreateOpen`: boolean — 创建弹窗开关
- `isDissolveOpen`: boolean — 解散弹窗开关
- `dissolveTarget`: Project | null — 解散目标项目
- `searchQuery`: string — 搜索关键词
- `statusFilter`: string — 状态筛选
- `projects`: Project[] — 项目列表状态（用于解散后更新）
- `activeTab`: string — 详情页激活的Tab

### 文件结构
单文件 `/mnt/agents/output/app/src/pages/ProjectManagementPage.tsx`，内部包含：
- 接口定义
- Mock数据
- 辅助函数/常量
- 子组件（ListView, DetailView, CreateDialog, DissolveDialog, StatsSection）
- 主导出组件

### 动画规划
- 列表卡片 hover：translateY(-4px) + shadow 过渡，CSS transition 150ms
- 弹窗出现/消失：Dialog 自带动画
- 视图切换：opacity 淡入淡出，CSS transition 200ms
- Tab 切换：无额外动画，使用 Tabs 组件默认行为

### 依赖
- recharts (已确认外部依赖)