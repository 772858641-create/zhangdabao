# 载具数字化管理平台 - 剩余模块开发计划

## 当前状态
从 mvp-supplement 分支合并后，已有 37 个页面，构建部署成功。
URL: https://b4bu77evsmxb6.ok.kimi.link

## 剩余 7 个未开发模块

### 批次一（3个并行）
1. **TransferTrackReplayPage** `/transfer-track-replay` - 调拨轨迹回放
   - 地图轨迹展示 + 时间轴播放控制
   - 节点停留标记 + 速度/里程统计
   
2. **ShipmentStatusPage** `/shipment-status` - 发运状态管理
   - 发运单列表 + 状态流转
   - 物流公司对接 + 签收追踪
   
3. **CarrierAllocationPage** `/carrier-allocation` - 载具分配管理
   - 分配规则 + 自动分配
   - 载具池管理 + 使用率分析

### 批次二（2个并行）
4. **VehicleFenceInOutPage** `/vehicle-fence-inout` - 车辆围栏联动出入库
   - 围栏规则配置 + 进出事件
   - 自动出入库联动 + 报警

5. **OrgSiteAggregationPage** `/org-site-aggregation` - 组织网点聚合
   - 组织架构树 + 网点数据聚合
   - 多维度统计 + 钻取分析

### 批次三（2个并行）
6. **VehicleUnbindRecordPage** `/vehicle-unbind-records` - 车辆解绑记录
   - 解绑申请 + 审批流
   - 历史记录 + 原因分析
   
7. **WechatMiniProgramPage** `/wechat-miniprogram` - 微信小程序管理
   - 小程序配置 + 用户管理
   - 扫码绑定 + 消息推送

## 技术栈
- React 19 + TypeScript + Vite + Tailwind CSS + shadcn/ui
- Recharts 图表 + Framer Motion 动画 + Lucide 图标
- Mock 数据驱动

## 执行方式
每批并行创建子代理开发页面，完成后更新 App.tsx + Sidebar.tsx，构建部署。
